---
description: 교안예시.md
---

---
description: studyplanexample.md
---

# MODULE: Lesson Plan Example (Few-Shot)
> **Version:** 1.7 (Implicit Content Structure)
> **Role:** Golden Sample Provider
> **Function:** Provide standard lesson plan structure, Tone & Manner guide, Few-Shot data for LLM training

---

## 1. Overview

### 1.1. Purpose
This module defines the ideal **Shape and Structure** of the lesson plan that `studyplanmaker.md` should generate. Since LLMs have a characteristic of imitating Examples more strongly than Instructions, the example in this file becomes the most important reference point determining the quality of the output.

### 1.2. Reference Priority
- **Header Hierarchy:** Abstract headers like [Content] are NOT used; the actual topic must appear immediately as an H2 (##) header.
- **No Numbering:** Do not number headers like 1., 1.1., etc.

---

## 2. [TEMPLATE] Standard Lesson Plan Example (Full Example)

**(OOC: The content below is the full text of a standard lesson plan on the topic of 'Generative AI and Game Design'. Imitate this format exactly.)**

### 2.1. `// "Content" //`
- A tag indicating what concept this section exemplifies.
- **Do not refer to the format.**
- **"Content" is the writing policy for that section, so actively refer to that content.**

***

// 기본 학습 //
# 📝 생성형 AI와 게임 기획 개요

<br>

## 개요
![](https://develrocket-bucket.s3.ap-northeast-2.amazonaws.com/learning/DES-102/DES-10202_GenAIDesignBasics/DES-1020201_GenAIGamePlan/101_GenAIDesign/Image01.png)

<br>

- 2022년 ChatGPT, Midjourney 등 강력한 성능의 생성형 AI가 본격적으로 상용화 된 이후, AI는 산업계의 핵심 기술이 되었습니다.
- 게임 개발 관점에서도 반복 작업을 줄이고 검증 속도를 높여주는 강력한 도구입니다.
- 하지만 원리와 한계를 파악하지 않고 도입할 경우 저작권 침해, 데이터 편향 등 부작용을 야기할 수 있습니다.
- 본 교과에서는 생성형 AI의 원리를 이해하고, 실제 기획 프로세스에 안전하게 적용하는 방법을 학습합니다.

<br>

## 학습 목표
- **핵심 개념 이해:**
    - AI, 머신러닝, 딥러닝, 생성형 AI의 관계와 원리를 구분하여 설명할 수 있다.
- **실무 활용 파악:**
    - 실제 게임 프로젝트(블리자드, 유비소프트 등)의 AI 도입 사례를 분석한다.
- **도구 활용 능력:**
    - Gemini를 활용하여 텍스트 및 이미지 생성 프롬프트를 작성할 수 있다.
- **비판적 시각:**
    - 할루시네이션, 저작권 이슈 등 AI의 한계를 인지하고 윤리적인 사용법을 익힌다.

<br>

## 생성형 AI의 개념
- **전통적 AI vs 생성형 AI**
    - 전통적 AI: 규칙 기반(Rule-based). FSM, BT 등 개발자가 정한 규칙대로 행동.
    - 생성형 AI: 데이터 기반(Data-driven). 딥러닝을 통해 데이터의 통계적 패턴을 학습하여 새로운 결과물 생성.

<br>

## 주요 용어 정리

<br>

| 용어 | 정의 | 비고 |
| :---: | :--- | :--- |
| **머신러닝** | 데이터를 통해 스스로 규칙을 찾는 학습 방법 | AI의 하위 집합 |
| **딥러닝** | 인공신경망(뉴런)을 여러 층으로 쌓아 학습하는 방식 | 머신러닝의 핵심 기술 |
| **LLM** | 거대 언어 모델. 텍스트 패턴을 확률적으로 예측하여 생성 | GPT, Gemini 등 |
| **프롬프트** | AI에게 작업을 지시하는 자연어 명령어 | '입력값'을 의미 |

<br>

## 게임 개발 활용 사례
- **기획:**
    - 세계관 설정, 퀘스트 지문 작성, 밸런스 시뮬레이션 코드 초안 작성.
- **아트:**
    - 컨셉 아트(Stable Diffusion), UI 아이콘 생성, 애니메이션 레퍼런스.
- **프로그래밍:**
    - 스크립트 작성 보조(Copilot), 버그 탐색 및 리팩토링 제안.
- **사례:**
    - 유비소프트 'Ghostwriter': NPC의 반복적인 대사(Bark) 자동 생성.
    - 블리자드: 내부 데이터 학습 모델을 활용한 컨셉 아트 초안 제작.

<br>

## 교과 기준 도구 : Gemini
본 과정에서는 접근성과 확장성이 뛰어난 구글의 **Gemini** 서비스를 주 도구로 사용합니다.
- **특징:** 구글 워크스페이스 연동, 멀티모달(이미지/텍스트 동시 처리), 무료 접근성.
- **주요 기능:**
    - **채팅:** 자연어 문답.
    - **Gems (커스텀 봇):** 특정 페르소나와 지침을 사전 주입하여 특화된 작업을 수행하는 봇 제작 기능. (※ 본 실습의 핵심)

<br><br>

---

<br>

// 평가 //
// "교과목 레벨 테스트" 안내는 교안의 첫 차시 학습목표 뒤와 마지막 차시 맨 마지막에만 기재 //
# 📝 교과목 레벨 테스트

<br>

## 과제 : 시나리오 및 시각화 커스텀 봇 제작
- 위 실습 가이드를 응용하여, 본인의 기획 의도가 담긴 커스텀 봇 2종을 제작하고 보고서를 제출하십시오.
    - 봇 이름 및 기획 의도 (Why)
    - 입력한 지침(Instructions) 전문 (How)
    - 실제 사용 예시 스크린샷 2장 이상 (Result)
    - 제작 과정에서 겪은 할루시네이션 및 해결 과정 (Insight)

<br>

// 실습 가이드 //
# ⚙️ 일일 퀘스트 - 개인
// 일일 퀘스트는 개인 or 조별. 과제의 분량에 따라 적으면 개인, 많으면 조별로 진행 // 

## 퀘스트 배경
- 당신은 AI 전문가로서 효율적인 LLM사용을 위한 Bot Agent를 만들고자 합니다.
- 이론에서 배운 내용을 바탕으로, 실제 업무를 도와줄 'AI 조수(Gem)'를 만들어 봅시다.

<br>

## 퀘스트 완료 조건
// 실습의 평가항목, 절차, 참고사항, 참고자료 등을 기재. 앞의 항목들 중 일부만 사용해도 무관. //

### ■ Step 1. 기획 의도 설정
- 봇을 만들기 전, 어떤 문제를 해결할 것인지 정의합니다.
    - **Target:** 시나리오 작가
    - **Problem:** 아이디어는 많은데 구체적인 대사로 바꾸는 데 시간이 오래 걸림.
    - **Solution:** "상황만 던져주면, 느와르 풍의 대사로 바꿔주는 봇"

<br>

### ■ Step 2. Gemini Gems 설정 진입
1. Gemini 메인 화면 좌측 메뉴의 `Gem manager` 클릭.
2. `New Gem` 버튼 클릭.
3. 이름(Name)에 `[느와르 시나리오 작가]` 입력.

<br>

### ■ Step 3. 지침(Instructions) 프롬프트 작성
- 가장 중요한 단계입니다. AI에게 역할을 부여합니다. (아래 내용을 복사하여 입력해보세요)

<br>

> **Role:** 당신은 1940년대 느와르 영화 전문 시나리오 작가입니다.
> **Task:** 사용자가 '상황'을 입력하면, 이를 거칠고 비관적인 느와르 풍의 대사(Script)로 변환하세요.
> **Constraint:**
> 1. 문체는 하드보일드 스타일을 유지할 것.
> 2. 지문(Action description)을 반드시 포함할 것.
> 3. 한국어로 출력하되, 가끔 영어 슬랭을 섞을 것.

<br>

### ■ Step 4. 테스트 및 튜닝
- 우측 미리보기(Preview) 창에 "주인공이 배신자를 골목에서 만난 상황"이라고 입력해봅니다.
- 결과가 마음에 들지 않으면 지침(Instructions)을 수정하여 말투를 교정합니다.
- 만족스러우면 `Create`를 눌러 저장합니다.

<br>

## 제출 형태
- **제출 마감:** n월 n일 nn:nn // 시간에 24시간 표기법 사용 //
- **제출물:**
    1. **시나리오 초안 작성 봇:** 세계관이나 특정 장르에 특화된 텍스트 생성 봇.
    2. **이미지 프롬프트 작성 봇:** 원하는 화풍을 묘사하는 구체적인 영문 프롬프트를 짜주는 봇.
- **보고서 양식 :** PDF // PDF 형식 고정 //
- **파일명:** `yymmdd_nn(강의)-n(차시)_"제목"_Ver01_조or이름`