---
description: 서식규약.md
---

# [Formatting Rules Document: Detailed Lesson Plan Style Guide]

## 0. Priority Rules (READ FIRST)

**When rules conflict with examples:**
- ALWAYS follow the rules in this document (formattingrules.md)
- Examples (studyplanexample.md) are for tone/style reference only
- If uncertain, parse the structure step-by-step according to Section 6 Workflow

**Element Relationship Identification:**
- Do NOT rely on visual proximity alone
- MUST identify the exact element types (Heading, Body, Content) first
- THEN apply the corresponding rule from Section 3.2 matrix
- **Example:** A heading with an image below it, followed by text, is NOT "Heading→Text" but "Heading→Content" + "Content→Text" (two separate relationships)

---

## 1. Definitions & Scope

### 1.1. Narrative Elements
*Rule Application: Primary target for Tone conversion. Considered as 'Content' when determining 'Empty Header Deletion'.*
- **Heading:** Hierarchical headers starting with `#`, `##`, etc.
- **Body:** Natural language sentences consisting of general text, lists (`-`), etc.
- **Key Concept:** Text in a specific format consisting of `**Heading**` and description within the body.

### 1.2. Block Elements
*Rule Application: Not considered as contextual 'Content' (for header deletion logic). Treated as physical 'Blocks' to applying forced line break rules before and after.*
- **Media:** Images (HTML `<img src>`), Video links.
    - *Rule:* Images must be centered using `<p align="center"><img src="URL" alt="filename"></p>`.
- **Code Block:** Source code area wrapped with ` ``` `.
- **Table:** A set of data in rows and columns written in Markdown syntax. (Note: Text inside the table can be subject to tone conversion)
- **Quote (`>`):** Quote area written in Markdown syntax.

### 1.3. Spacing Zone
- **Definition:** Physical empty space inserted to visually separate elements.
- **Composition:** A combination of `[Enter (Source Code Empty Line) + <br> tag + Enter (Source Code Empty Line)]`.

### 1.4. Paragraph Unit
- **Definition:** A logical bundle of data combining Heading and Body (or Content).
- **Range:** 
    - From the point where a specific Heading Level (`Level 1`~`Level 4`) starts, up to **just before the Spacing Zone where the next Heading Level appears**.
    - 'Next Heading Level' targets all types of Heading Levels (`Level 1`~`Level 4`).

---

## 2. Heading Depth & Structure Rules (Typography)

### 2.1. Hierarchy
- **Level 1 (`# 📝`)**: **Session Topic**
    - Comprehensive learning objective.
    - *Example: `# 📝 3D Scene Composition and Rendering Basics`*
- **Level 2 (`##`)**: **Key Content**
    - Main keyword.
    - *Example: `# 📝 3D Scene Composition...` / ` ## Composition of 3D Objects `*
- **Level 3 (`### ■`)**: **Key Content Depth 1**
    - Title of sub-explanation unit 1 of the main keyword.
    - *Example: `...` / ` ## Composition of 3D Objects ` / ` ### ■ 3 KEY Elements of 3D Rendering `*
- **Level 4 (`#### &nbsp;&nbsp; ▣`)**: **Key Content Depth 2**
    - Title of sub-explanation unit 2 of the main keyword.
    - *Example: `...` / ` ### ■ 3 KEY Elements... ` / `#### ▣ Mesh : Geometric Shape`*


### 2.2. Body Lists
- **Depth 1 (`-`)**: Basic description text.
- **Depth 2 (`  -`)**: Sub-item elaboration.
- **Depth 3 (`    -`)**: Sub-item elaboration.

### 2.3 Body Special Rules (Key Concepts Format)
- **Key Concept Definition**
- **Format:**
    ```markdown
    - **Heading (Bold)**
        - Description content (Indentation applied)
    ```
- In this item's format, the **Heading** level follows the same formatting rules as the **Heading Level**.
- **Example:** Refer to <Body Special Rules> in `formattingexample.md`.

---

## 3. Spacing & Layout Rules

### 3.1. Definition of Spacing Zone
- **Spacing Zone:** `[Enter + <br> tag + Enter]` set.
- **Values:** `<br>` (1 line break), `<br><br>` (2 line breaks).

### 3.2. General Placement Matrix
- AI applies line break rules according to the situations below.
    - However, if it falls under **[3.3 Special Pattern Rules]**, that rule is followed as top priority.

| Relation | Context | Applied Rule | Note |
| :--- | :--- | :--- | :--- |
| **Inside Heading** | **When Body Text comes right below Heading (`##`~)** | **None (0 times)** | Heading and description are one body (paragraph), so write them attached. |
| **Heading-Content Split** | **When Content (Elements defined in 1.2) comes right below Heading (`##`~)** | **Simple 1 Line Break ([Enter])** | Minimize space between heading and material (No `<br>`). |
| **Paragraph Split** | **Between Paragraph ↔ Paragraph/Heading** | **Apply 1 Line Break Zone** | Basic interval when logical unit changes. |
| **Element Split** | **Between Text ↔ Content** | **Apply 1 Line Break Zone** | Default value. Standard interval between material and explanation. |
| **Content Split** | **Between Content ↔ Content** | **Apply 2 Line Breaks** | Visual separation when different materials are consecutive. `[Enter + <br><br> tag + Enter]` |
| **Session Topic Entry** | **(All Elements) → Session Topic (`# 📝`)** | **Separator Set** | `<br><br>` + `---` + `<br>` |

### 3.3. Special Pattern Rules
*Priority is higher than 3.2 Basic Matrix above.*

1.  **Sandwich Structure (Content Sandwich)**
    - **Context:** When placed in the order of `Content (A)` → `Text/Paragraph (B)` → `Content (C)`.
    - **Rule:** Apply **1 Line Break (`<br>`) ABOVE and 2 Line Breaks (`<br><br>`) BELOW the sandwiched `Text (B)`**.
    - *Purpose:* To clearly emphasize and distinguish the explanation when it intervenes between continuous materials.

2.  **Session Topic Exception**
    - Apply **1 Line Break** right below `# 📝` (Level 1) unless there is a separate rule.

3.  **Consecutive Media Exception**
    - Consecutively listed media (images, videos) are separated only by **`[Enter]`**.

---

## 4. Text & Content Format Rules

### 4.1. Table Style
- **Alignment Rules:**
    - **Center Align (`:--:`):** Header (Row 1), Subject of explanation, Short Attributes.
    - **Left Align (`:--`):** Long prose description.
- **Example:** Refer to <Table Content> in `formattingexample.md`.

### 4.2. Text Alignment
- **Correction:** Use `&nbsp;&nbsp; ` for visual indentation correction.
- **When to apply:**
    - Case 1: Heading Level 4(`####`), Level 5(`#####`).
        - example: `#### &nbsp;&nbsp; ▣ 메시 그래픽의 사용`
    - Case 2: General text with no prefix like `#`, `-`.


---

## 5. Emphasis & Icons Rules

### 5.1. Text Emphasis
- **Bold (`**...**`)**: Emphasis on description.
- **Inline Code (` `...` `)**: Filenames, Shortcuts, Code Snippets.

### 5.2. Semantic Icons
| Icon | Meaning | Usage |
| :---: | :---: | :--- |
| 💡 | **Important** | Linking key concepts |
| ✅ | **Check** | Learning checklist |
| ☑️ | **Emphasis** | Purple emphasis (Secondary) |
| ℹ️ | **Info** | Additional information |
| 💬 | **TMI** | Trivial information |
| 🎮 | **Example** | Practical/Field cases |
| ⚠️ | **Notice** | Precautions |
| ⚙️ | **Practice** | Practice guide |

---

## 6. Workflow
- Perform the following process sequentially.
- Proceed to the next process only after each process is completed.

1.  **Parsing:**
    - Sequentially scan the input original text to identify [1.4 Paragraph] units.
    - Clearly label each paragraph as [1.1 Narrative Elements] and [1.2 Block Elements].

2.  **Drafting & Filtering:**
    - Confirm the placement order of remaining elements.

3.  **Internal Processing & Transformation:**
    - **Step 3-1. Typography Mapping:** Scan all headers and FORCIBLY append specific special characters (`■`, `▣`) assigned to Identify Level 3 (`###`) and Level 4 (`####`). (No exceptions)
    - **Step 3-2. Icon Injection:** Search for keywords in the body (e.g., 'Example:', 'Tip:', 'Caution:') and replace the beginning of that line with a Semantic Icon.
    - **Step 3-3. Indentation Injection:**
        - Case 1: Insert `&nbsp;&nbsp;` after headers of `####` (Level 4) or higher. (e.g., `#### &nbsp;&nbsp; ▣ "Content"`)
        - Case 2: For Lists (`-`) of Depth 2 or higher, or general text lines without prefixes, FORCIBLY insert `&nbsp;&nbsp;` at the beginning to correct visual indentation.
    - **Step 3-4. Layout Application:** Apply [3. Spacing Rules] to the text blocks confirmed afterwards.
        - **Important:** Precisely inspect for [3.3 Special Pattern] 'Sandwich Structure' occurrence and apply exception line breaks.
    - **Step 3-5. Tone & Manner Application:** Apply [6. Tone & Manner] (Refer to `studyplanexample.md`) to finally convert sentences. // Note: Tone rules are in example file.

4.  **Output Generation:**
    - Output only the final version verified through the above process according to [7. Output Method].
