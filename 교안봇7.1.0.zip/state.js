﻿// State & Configuration

// ------------------------------------------------------------------------

// Config variables (apiKey, STORAGE_KEY, TEXT_MODEL, IMAGE_MODEL) moved to data.js

// --- 媛꾨떒??YAML 吏곷젹????쭅?ы솕 ?좏떥 (?몃? ?쇱씠釉뚮윭由?遺덊븘?? ---

function simpleYamlStringify(obj, indent = 0) {
    const pad = '  '.repeat(indent);
    let result = '';
    for (const [key, value] of Object.entries(obj)) {
        if (value === null || value === undefined) {
            result += `${pad}${key}: null\n`;
        } else if (typeof value === 'boolean' || typeof value === 'number') {
            result += `${pad}${key}: ${value}\n`;
        } else if (typeof value === 'string') {
            // 蹂듭옟??臾몄옄??媛쒗뻾, ?뱀닔臾몄옄 ?ы븿)? JSON ?댁뒪耳?댄봽 臾몄옄???ъ슜
            if (value.includes('\n') || value.includes('"') || value.includes(':') || value.includes('#') || value.length > 200) {
                result += `${pad}${key}: ${JSON.stringify(value)}\n`;
            } else {
                result += `${pad}${key}: "${value}"\n`;
            }
        } else if (Array.isArray(value)) {
            // 諛곗뿴? JSON ?몃씪?몄쑝濡?吏곷젹??(援먯븞 ?곗씠?곗쓽 蹂듭옟??援ъ“ 吏??
            result += `${pad}${key}: ${JSON.stringify(value)}\n`;
        } else if (typeof value === 'object') {
            result += `${pad}${key}:\n`;
            result += simpleYamlStringify(value, indent + 1);
        }
    }
    return result;
}

function simpleYamlParse(yamlText) {
    // YAML ?띿뒪?몃? ?뚯떛?섏뿬 ?쒕━?쇰씪?댁쫰 ??JSON.stringify濡??몃씪??泥섎━??媛믩뱾??蹂듭썝
    try {
        const result = {};
        const lines = yamlText.split('\n');
        const stack = [{ obj: result, indent: -1 }];

        for (const line of lines) {
            if (!line.trim() || line.trim().startsWith('#')) continue;

            const indentMatch = line.match(/^(\s*)/);
            const currentIndent = indentMatch ? indentMatch[1].length : 0;
            const trimmed = line.trim();

            const colonIdx = trimmed.indexOf(':');
            if (colonIdx === -1) continue;

            const key = trimmed.substring(0, colonIdx).trim();
            let valueStr = trimmed.substring(colonIdx + 1).trim();

            // ?ㅽ깮?먯꽌 ?꾩옱 ?몃뜶???덈꺼??留욌뒗 遺紐??먯깋
            while (stack.length > 1 && stack[stack.length - 1].indent >= currentIndent) {
                stack.pop();
            }
            const parent = stack[stack.length - 1].obj;

            if (!valueStr) {
                // ?섏쐞 媛앹껜 ?쒖옉
                parent[key] = {};
                stack.push({ obj: parent[key], indent: currentIndent });
            } else if (valueStr === 'null') {
                parent[key] = null;
            } else if (valueStr === 'true') {
                parent[key] = true;
            } else if (valueStr === 'false') {
                parent[key] = false;
            } else if (!isNaN(Number(valueStr)) && valueStr !== '') {
                parent[key] = Number(valueStr);
            } else if (valueStr.startsWith('[') || valueStr.startsWith('{') || valueStr.startsWith('"')) {
                // JSON ?몃씪??媛??뚯떛
                try {
                    parent[key] = JSON.parse(valueStr);
                } catch (e) {
                    parent[key] = valueStr.replace(/^"|"$/g, '');
                }
            } else {
                parent[key] = valueStr;
            }
        }
        return result;
    } catch (e) {
        console.warn('YAML ?뚯떛 ?ㅽ뙣, JSON ?泥??쒕룄:', e);
        return JSON.parse(yamlText); // JSON ?щ㎎ ?대갚
    }
}



// --- Global State ---

let globalState = {

    courseId: "course_" + Date.now(),

    courseTitle: "寃뚯엫 湲고쉷 ?꾨Ц媛 ?묒꽦 怨쇱젙",

    subjects: []

};



let courseData = [];

let currentTopic = '';

let contentHistory = [];

let currentEditingModuleId = null;

let aiCommandMode = 'edit';

let currentSubjectId = null;

// --- 濡쒖뺄 ?대뜑 ?곌껐 ?곹깭 (File System Access API) ---
let projectFolderHandle = null; // FileSystemDirectoryHandle | null



// --- Diagram Pan/Zoom State ---

let diagramScale = 1;

let diagramX = 100;

let diagramY = 100;

let isDraggingDiagram = false;

window.hasDragged = false;

let startDragX = 0;

let startDragY = 0;



// --- State Normalization (諛⑹뼱 濡쒖쭅) ---

function sanitizeState(state) {
    if (!state) return null;
    state.courseId = state.courseId || "course_" + Date.now();
    state.courseTitle = state.courseTitle || "寃뚯엫 湲고쉷 ?꾨Ц媛 ?묒꽦 怨쇱젙";
    state.subjects = Array.isArray(state.subjects) ? state.subjects : [];

    const normalizeTeacherNotes = (notes) => {
        if (!Array.isArray(notes)) return [];
        const seen = new Set();
        const normalized = [];
        notes.forEach(item => {
            if (!item || typeof item !== 'object') return;
            const anchor = String(item.anchor || '').trim();
            const note = String(item.note || '').trim();
            if (!anchor || !note || seen.has(anchor)) return;
            seen.add(anchor);
            normalized.push({ anchor, note });
        });
        return normalized;
    };

    const normalizeQualityEvaluation = (evaluation) => {
        if (!evaluation || typeof evaluation !== 'object' || Array.isArray(evaluation)) return null;
        const dims = Array.isArray(evaluation.dimensions)
            ? evaluation.dimensions
                .filter(item => item && typeof item === 'object')
                .map(item => ({
                    id: String(item.id || '').trim(),
                    label: String(item.label || '').trim(),
                    score: Number.isFinite(Number(item.score)) ? Math.max(0, Math.min(100, Math.round(Number(item.score)))) : 0,
                    reason: String(item.reason || '').trim(),
                    improvement: String(item.improvement || '').trim()
                }))
                .filter(item => item.id && item.label)
            : [];
        if (dims.length === 0) return null;
        return {
            ...evaluation,
            dimensions: dims,
            lowDimensions: Array.isArray(evaluation.lowDimensions)
                ? evaluation.lowDimensions.map(v => String(v || '').trim()).filter(Boolean)
                : []
        };
    };

    state.subjects.forEach(s => {
        s.id = s.id || 'subject_' + Date.now() + Math.random();
        s.title = s.title || '?쒕ぉ ?놁쓬';
        s.description = s.description || '';
        s.namingConvention = s.namingConvention || '';
        s.lessons = Array.isArray(s.lessons) ? s.lessons : [];
        s.mainQuest = s.mainQuest || {
            id: 'mainQuest', title: '메인 퀘스트', description: '최종 평가입니다.', status: 'waiting', content: null, images: {}, teacherNotes: [], qualityEvaluation: null
        };
        s.mainQuest.images = s.mainQuest.images || {};
        s.mainQuest.teacherNotes = normalizeTeacherNotes(s.mainQuest.teacherNotes);
        s.mainQuest.qualityEvaluation = normalizeQualityEvaluation(s.mainQuest.qualityEvaluation);
        s.lessons.forEach(l => {
            l.id = l.id || Date.now() + Math.random();
            l.title = l.title || '李⑥떆';
            l.images = l.images || {};
            l.teacherNotes = normalizeTeacherNotes(l.teacherNotes);
            l.qualityEvaluation = normalizeQualityEvaluation(l.qualityEvaluation);
        });
    });
    return state;
}

function _toSafeFolderName(name, fallback = 'untitled') {
    const raw = typeof name === 'string' ? name : '';
    const cleaned = raw.replace(/[\/\?<>\\:\*\|"]/g, '_').trim();
    return cleaned || fallback;
}

function _sanitizeFileStem(value, fallback = 'module') {
    const raw = typeof value === 'string' ? value : '';
    const stem = raw
        .replace(/\.md$/i, '')
        .replace(/[\/\?<>\\:\*\|"]/g, '_')
        .trim();
    return stem || fallback;
}

function _getLessonIndexByModuleId(subj, moduleId) {
    if (!subj || !Array.isArray(subj.lessons)) return -1;
    return subj.lessons.findIndex(lesson => String(lesson?.id) === String(moduleId));
}

function _resolveNamingToken(moduleId, lessonIndex) {
    if (String(moduleId) === 'mainQuest') return 'MQ';
    const idx = Number.isInteger(lessonIndex) && lessonIndex >= 0 ? lessonIndex : 0;
    return String(idx + 1).padStart(2, '0');
}

function _buildFileStemFromNamingConvention(subj, moduleId, fallbackStem = 'module') {
    const fallback = _sanitizeFileStem(fallbackStem, 'module');
    const patternRaw = _sanitizeFileStem(subj?.namingConvention || '', '');
    if (!patternRaw) return fallback;

    const lessonIndex = _getLessonIndexByModuleId(subj, moduleId);
    const token = _resolveNamingToken(moduleId, lessonIndex);
    const hasTokenSlot = /nn/i.test(patternRaw);
    const withToken = hasTokenSlot
        ? patternRaw.replace(/nn/gi, token)
        : `${patternRaw}_${token}`;
    return _sanitizeFileStem(withToken, fallback);
}

function getModuleExportFileNameByConvention(subj, moduleId, fallbackTitle = 'module', ext = '.md') {
    const stem = _buildFileStemFromNamingConvention(subj, moduleId, fallbackTitle);
    const normalizedExt = String(ext || '.md').startsWith('.') ? String(ext || '.md') : `.${String(ext || 'md')}`;
    return `${stem}${normalizedExt}`;
}

function _buildDefaultModuleFileName(mod, lessonIndex = -1, ext = '.md') {
    const normalizedExt = String(ext || '.md').startsWith('.') ? String(ext || '.md') : `.${String(ext || 'md')}`;
    const safeTitle = _sanitizeFileStem(mod?.title || 'module', 'module');
    if (String(mod?.id) === 'mainQuest') {
        return `MQ_${safeTitle}${normalizedExt}`;
    }
    const seq = Number.isInteger(lessonIndex) && lessonIndex >= 0
        ? String(lessonIndex + 1).padStart(2, '0')
        : '01';
    return `${seq}_${safeTitle}${normalizedExt}`;
}

window.getModuleExportFileNameByConvention = getModuleExportFileNameByConvention;

function _imageExtToMime(ext) {
    const normalized = String(ext || '').toLowerCase();
    if (normalized === 'jpg' || normalized === 'jpeg') return 'image/jpeg';
    if (normalized === 'png') return 'image/png';
    if (normalized === 'webp') return 'image/webp';
    if (normalized === 'gif') return 'image/gif';
    if (normalized === 'svg') return 'image/svg+xml';
    return `image/${normalized || 'png'}`;
}

function _toImageFileRef(imgId, value) {
    if (typeof value !== 'string') return value;
    const m = value.match(/^data:(image\/[^;]+);base64,/i);
    if (!m) return value;

    const mime = m[1].toLowerCase();
    let ext = 'png';
    if (mime === 'image/jpeg') ext = 'jpg';
    else if (mime.startsWith('image/')) ext = mime.split('/')[1] || 'png';

    return `__FILE__:${imgId}.${ext}`;
}

function _compactImagesMap(images) {
    if (!images || typeof images !== 'object' || Array.isArray(images)) return {};

    const next = {};
    for (const [imgId, value] of Object.entries(images)) {
        next[imgId] = _toImageFileRef(imgId, value);
    }
    return next;
}

function buildCompactStateForExternalSave(state) {
    if (!state) return state;
    const cloned = JSON.parse(JSON.stringify(state));
    if (!Array.isArray(cloned.subjects)) return cloned;

    cloned.subjects.forEach(subj => {
        const modules = [];
        if (Array.isArray(subj.lessons)) modules.push(...subj.lessons);
        if (subj.mainQuest) modules.push(subj.mainQuest);

        modules.forEach(mod => {
            if (!mod || typeof mod !== 'object') return;
            mod.images = _compactImagesMap(mod.images);

            // ?낅줈???먮Ц? ?⑸웾 鍮꾩쨷??而ㅼ꽌 ?몃? ?몄씠釉뚯뿉?쒕뒗 ?쒖쇅
            if (typeof mod.uploadedMdContent === 'string' && mod.uploadedMdContent.length > 0) {
                mod.uploadedMdContent = null;
            }
        });
    });

    return cloned;
}

function buildCompactHistoryForExternalSave(history) {
    if (!Array.isArray(history)) return [];
    return history.map(item => ({
        id: item.id,
        title: item.title,
        content: item.content,
        date: item.date,
        metadata: normalizeHistoryMetadata(item.metadata, item.date),
        images: _compactImagesMap(item.images),
        hasImages: item.images ? Object.keys(item.images).length : 0
    }));
}

function normalizeHistoryMetadata(metadata, fallbackDate = '') {
    const source = metadata && typeof metadata === 'object' ? metadata : {};
    const textModel = typeof source.textModel === 'string' ? source.textModel.trim() : '';
    const imageModel = typeof source.imageModel === 'string' ? source.imageModel.trim() : '';
    const subjectId = typeof source.subjectId === 'string' ? source.subjectId.trim() : '';
    const rawModuleId = source.moduleId;
    const moduleId = (typeof rawModuleId === 'string' || typeof rawModuleId === 'number')
        ? String(rawModuleId).trim()
        : '';

    let archivedAt = '';
    if (typeof source.archivedAt === 'string' && source.archivedAt.trim()) {
        archivedAt = source.archivedAt.trim();
    } else if (typeof source.generatedAt === 'string' && source.generatedAt.trim()) {
        archivedAt = source.generatedAt.trim();
    } else if (fallbackDate) {
        const parsed = new Date(fallbackDate);
        if (!Number.isNaN(parsed.getTime())) archivedAt = parsed.toISOString();
    }

    return { textModel, imageModel, archivedAt, subjectId, moduleId };
}

function normalizeHistoryItems(history) {
    if (!Array.isArray(history)) return [];
    return history
        .filter(item => item && typeof item === 'object')
        .map(item => {
            const normalized = {
                id: item.id || Date.now() + Math.random(),
                title: item.title || '제목 없음',
                content: typeof item.content === 'string' ? item.content : '',
                images: (item.images && typeof item.images === 'object' && !Array.isArray(item.images)) ? item.images : {},
                date: item.date || '',
                metadata: normalizeHistoryMetadata(item.metadata, item.date)
            };

            if (!normalized.date) {
                if (normalized.metadata.archivedAt) {
                    const parsed = new Date(normalized.metadata.archivedAt);
                    normalized.date = Number.isNaN(parsed.getTime()) ? normalized.metadata.archivedAt : parsed.toLocaleString();
                } else {
                    normalized.date = new Date().toLocaleString();
                }
            }

            return normalized;
        });
}

function escapeHistoryHtml(value = '') {
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function getHistoryMetadataLabel(item) {
    const metadata = normalizeHistoryMetadata(item?.metadata, item?.date || '');
    const parts = [];
    if (metadata.textModel) parts.push(`Text: ${metadata.textModel}`);
    if (metadata.imageModel) parts.push(`Image: ${metadata.imageModel}`);

    if (metadata.archivedAt) {
        const parsed = new Date(metadata.archivedAt);
        const timeText = Number.isNaN(parsed.getTime()) ? metadata.archivedAt : parsed.toLocaleString();
        parts.push(`시각: ${timeText}`);
    }

    return parts.join(' | ');
}

function _uint8ArrayToBase64(bytes) {
    let binary = '';
    const CHUNK = 0x8000;
    for (let i = 0; i < bytes.length; i += CHUNK) {
        const chunk = bytes.subarray(i, i + CHUNK);
        binary += String.fromCharCode(...chunk);
    }
    return btoa(binary);
}

async function _readImageDataUrlFromFolder(folderHandle, fileName) {
    const fileHandle = await folderHandle.getFileHandle(fileName);
    const file = await fileHandle.getFile();
    const ext = fileName.split('.').pop().toLowerCase();
    const mime = _imageExtToMime(ext);
    const bytes = new Uint8Array(await file.arrayBuffer());
    return `data:${mime};base64,${_uint8ArrayToBase64(bytes)}`;
}

async function _getAttachmentFolderHandle(rootDirHandle, courseTitle) {
    const safeCourseName = _toSafeFolderName(courseTitle, '??援먯븞?꾨줈?앺듃');
    try {
        const courseFolder = await rootDirHandle.getDirectoryHandle(safeCourseName);
        return await courseFolder.getDirectoryHandle('泥⑤??뚯씪');
    } catch (e) {
        return null;
    }
}

async function rehydrateStateImagesFromFileRefs(rootDirHandle, state) {
    if (!rootDirHandle || !state || !Array.isArray(state.subjects)) return;

    const attachFolder = await _getAttachmentFolderHandle(rootDirHandle, state.courseTitle);
    if (!attachFolder) return;

    for (const subj of state.subjects) {
        const modules = [];
        if (Array.isArray(subj.lessons)) modules.push(...subj.lessons);
        if (subj.mainQuest) modules.push(subj.mainQuest);

        for (const mod of modules) {
            if (!mod || !mod.images || typeof mod.images !== 'object' || Array.isArray(mod.images)) continue;

            for (const [imgId, value] of Object.entries(mod.images)) {
                if (typeof value === 'string' && value.startsWith('__FILE__:')) {
                    const fileName = value.substring('__FILE__:'.length);
                    try {
                        mod.images[imgId] = await _readImageDataUrlFromFolder(attachFolder, fileName);
                    } catch (imgErr) {
                        console.warn(`?대?吏 蹂듭썝 ?ㅽ뙣: ${fileName}`, imgErr);
                        delete mod.images[imgId];
                    }
                }
            }
        }
    }
}

async function rehydrateHistoryImagesFromFileRefs(rootDirHandle, state, history) {
    if (!rootDirHandle || !state || !Array.isArray(history)) return;

    const attachFolder = await _getAttachmentFolderHandle(rootDirHandle, state.courseTitle);
    if (!attachFolder) return;

    for (const item of history) {
        if (!item || !item.images || typeof item.images !== 'object' || Array.isArray(item.images)) continue;
        for (const [imgId, value] of Object.entries(item.images)) {
            if (typeof value === 'string' && value.startsWith('__FILE__:')) {
                const fileName = value.substring('__FILE__:'.length);
                try {
                    item.images[imgId] = await _readImageDataUrlFromFolder(attachFolder, fileName);
                } catch (imgErr) {
                    console.warn(`?덉뒪?좊━ ?대?吏 蹂듭썝 ?ㅽ뙣: ${fileName}`, imgErr);
                    delete item.images[imgId];
                }
            }
        }
    }
}

function getEditingModule(id = currentEditingModuleId) {
    if (id === 'mainQuest') {
        const subj = globalState.subjects.find(s => s.id === currentSubjectId);
        return subj ? subj.mainQuest : null;
    }
    return courseData.find(m => String(m.id) === String(id));
}

// =========================================================================
// Phase F8: IndexedDB 湲곕컲 濡쒖뺄 ?ㅽ넗由ъ? 留ㅻ땲? (???ㅽ넗由ъ? ?⑸웾 ?뚰뙆)
// =========================================================================
const DBManager = {
    dbName: 'CourseAgentDB',
    dbVersion: 2, // 踰꾩쟾??(?덈줈??store 異붽?)
    storeName: 'appData',
    cacheStoreName: 'image_cache', // [Phase F10] 罹먯떆 ?꾩슜 ?ㅽ넗??異붽?
    dbInstance: null,

    async init() {
        return new Promise((resolve, reject) => {
            if (this.dbInstance) {
                resolve(this.dbInstance);
                return;
            }
            const request = indexedDB.open(this.dbName, this.dbVersion);
            request.onupgradeneeded = (e) => {
                const db = e.target.result;
                if (!db.objectStoreNames.contains(this.storeName)) {
                    db.createObjectStore(this.storeName);
                }
                // [Phase F10] ?대?吏 罹먯떆 ?ㅽ넗???앹꽦
                if (!db.objectStoreNames.contains(this.cacheStoreName)) {
                    // ?ㅼ썙?쒕? ?ㅺ컪?쇰줈 ?ъ슜
                    db.createObjectStore(this.cacheStoreName, { keyPath: 'keyword' });
                }
            };
            request.onsuccess = (e) => {
                this.dbInstance = e.target.result;
                resolve(this.dbInstance);
            };
            request.onerror = (e) => {
                console.error("IndexedDB 珥덇린???ㅽ뙣:", e);
                reject(e);
            };
        });
    },

    async setItem(key, value) {
        const db = await this.init();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.storeName, 'readwrite');
            const store = tx.objectStore(this.storeName);
            const request = store.put(value, key);
            request.onsuccess = () => resolve();
            request.onerror = (e) => reject(e);
        });
    },

    async getItem(key) {
        const db = await this.init();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.storeName, 'readonly');
            const store = tx.objectStore(this.storeName);
            const request = store.get(key);
            request.onsuccess = (e) => resolve(e.target.result);
            request.onerror = (e) => reject(e);
        });
    },

    async deleteItem(key) {
        const db = await this.init();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.storeName, 'readwrite');
            const store = tx.objectStore(this.storeName);
            const request = store.delete(key);
            request.onsuccess = () => resolve();
            request.onerror = (e) => reject(e);
        });
    },

    // --- [Phase F10] ?대?吏 罹먯떆 愿由?API ---
    async setCache(keyword, base64Data, sourceUrl, formatLabel) {
        const db = await this.init();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.cacheStoreName, 'readwrite');
            const store = tx.objectStore(this.cacheStoreName);
            const payload = {
                keyword: keyword,        // PK
                base64: base64Data,      // ?대?吏
                source: sourceUrl,       // 異쒖쿂 URL (?덈궡??
                format: formatLabel,     // ?쇰꺼 ("??寃???곕룞" ??
                timestamp: Date.now()
            };
            const request = store.put(payload);
            request.onsuccess = () => resolve();
            request.onerror = (e) => reject(e);
        });
    },

    async getCache(keyword) {
        const db = await this.init();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.cacheStoreName, 'readonly');
            const store = tx.objectStore(this.cacheStoreName);
            const request = store.get(keyword);
            request.onsuccess = (e) => resolve(e.target.result);
            request.onerror = (e) => reject(e);
        });
    },

    async getAllCaches() {
        const db = await this.init();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.cacheStoreName, 'readonly');
            const store = tx.objectStore(this.cacheStoreName);
            const request = store.getAll();
            request.onsuccess = (e) => resolve(e.target.result.sort((a, b) => b.timestamp - a.timestamp));
            request.onerror = (e) => reject(e);
        });
    },

    async deleteCache(keyword) {
        const db = await this.init();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.cacheStoreName, 'readwrite');
            const store = tx.objectStore(this.cacheStoreName);
            const request = store.delete(keyword);
            request.onsuccess = () => resolve();
            request.onerror = (e) => reject(e);
        });
    },

    async clearAllCaches() {
        const db = await this.init();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.cacheStoreName, 'readwrite');
            const store = tx.objectStore(this.cacheStoreName);
            const request = store.clear();
            request.onsuccess = () => resolve();
            request.onerror = (e) => reject(e);
        });
    }
};

// Data Management Layer

async function saveState() {
    try {
        if (currentSubjectId) {
            const subject = globalState.subjects.find(s => s.id === currentSubjectId);
            if (subject) {
                subject.lessons = Array.isArray(courseData) ? courseData : [];
            }
        }

        // 1. IndexedDB??臾댁젣??鍮꾨룞湲?????쒕룄
        const stateData = { state: globalState, history: contentHistory };
        await DBManager.setItem(STORAGE_KEY, stateData);

    } catch (e) {
        console.error("IndexedDB ????ㅽ뙣", e);
        window.showAlert('?곗씠?곕쿋?댁뒪 ???以??ㅻ쪟媛 諛쒖깮?덉뒿?덈떎. 釉뚮씪?곗? ??μ냼 ?ㅼ젙???뺤씤?섏꽭??');
    }

    // ?곌껐??濡쒖뺄 ?대뜑 鍮꾨룞湲??숆린??(UI 釉붾줈??諛⑹?)
    if (projectFolderHandle) {
        syncToLinkedFolder().catch(e => console.warn('?대뜑 ?숆린??寃쎄퀬:', e.message));
    }
}

async function restoreState() {
    try {
        // 1. IndexedDB?먯꽌 理쒖슦??濡쒕뱶 (??⑸웾 ?꾨꼍 蹂듭썝)
        let data = await DBManager.getItem(STORAGE_KEY);

        // 2. 留뚯빟 DB媛 鍮꾩뼱?덈떎硫? 湲곗〈 援щ쾭??localStorage ?곗씠??留덉씠洹몃젅?댁뀡 ?쒕룄
        if (!data) {
            const raw = localStorage.getItem(STORAGE_KEY);
            if (raw) {
                data = JSON.parse(raw);
                console.log("湲곗〈 localStorage ?곗씠?곕? IndexedDB濡?留덉씠洹몃젅?댁뀡?⑸땲??");
                await DBManager.setItem(STORAGE_KEY, data); // 留덉씠洹몃젅?댁뀡 ?????                // 留덉씠洹몃젅?댁뀡 ?꾨즺 ??荑쇳꽣 ?뺣낫瑜??꾪빐 ??젣
                localStorage.removeItem(STORAGE_KEY);
            }
        } else {
            // ?대? 留덉씠洹몃젅?댁뀡???앸궗?대룄 ?⑥븘?덈뒗 遺덊븘?뷀븳 localStorage ?붿뿬臾???젣?섏뿬 API Key ?깆쓣 ?꾪븳 荑쇳꽣 怨듦컙 100% ?뺣낫
            localStorage.removeItem(STORAGE_KEY);
        }

        if (data && data.state) {
            const sanitized = sanitizeState(data.state);
            if (sanitized) {
                globalState = sanitized;
            } else {
                await loadMockData();
            }
            contentHistory = normalizeHistoryItems(data.history);
        } else {
            await loadMockData();
        }

    } catch (e) {
        console.error("Failed to restore state from DB", e);
        await loadMockData();
    }
}

async function loadMockData() {
    globalState = sanitizeState(INITIAL_MOCK_STATE);
    await saveState();
}


async function archiveContent(mod) {
    const now = new Date();
    const moduleId = (typeof mod?.id === 'string' || typeof mod?.id === 'number') ? String(mod.id) : '';
    const subjectId = typeof currentSubjectId === 'string' ? currentSubjectId : '';
    contentHistory.push({
        id: Date.now(),
        title: mod.title,
        content: mod.content,
        images: mod.images ? JSON.parse(JSON.stringify(mod.images)) : {}, // ?덉뒪?좊━???대?吏 ?덉??ㅽ듃由щ룄 蹂듭궗
        date: now.toLocaleString(),
        metadata: {
            textModel: (typeof TEXT_MODEL === 'string' ? TEXT_MODEL : ''),
            imageModel: (typeof IMAGE_MODEL === 'string' ? IMAGE_MODEL : ''),
            archivedAt: now.toISOString(),
            subjectId,
            moduleId
        }
    });

    await saveState();

    // 연결된 폴더가 있으면 히스토리도 별도 파일로 동기화
    if (projectFolderHandle) {
        syncHistoryItemToFolder(contentHistory[contentHistory.length - 1]).catch(e => console.warn('히스토리 폴더 동기화 경고:', e.message));
    }
}

// --- History UI ---
const selectedHistoryIds = new Set();
let lastHistoryIdx = -1;

function toggleHistoryPanel() {
    const p = document.getElementById('history-panel');
    if (!p) return;
    let bg = document.getElementById('history-bg');
    const isOpen = !p.classList.contains('hidden');

    if (!isOpen) {
        // ?닿린
        if (!bg) {
            bg = document.createElement('div');
            bg.id = 'history-bg';
            bg.className = 'fixed inset-0 bg-black/50 z-40 animate-fade-in backdrop-blur-sm';
            bg.onclick = toggleHistoryPanel;
            document.body.appendChild(bg);
        }
        bg.style.display = 'block';
        p.classList.remove('hidden');
        p.classList.remove('translate-x-full');
        selectedHistoryIds.clear();
        lastHistoryIdx = -1;
        renderHistoryUI(p);
    } else {
        // ?リ린
        p.classList.add('translate-x-full');
        p.classList.add('hidden');
        if (bg) bg.style.display = 'none';
    }
}

async function renderHistoryUI(area) {
    if (!Array.isArray(contentHistory) || contentHistory.length === 0) {
        area.innerHTML = `<div class="h-full flex items-center justify-center text-textMuted bg-[#12121e]">??λ맂 ?덉뒪?좊━媛 ?놁뒿?덈떎. (紐⑤뱢 ??젣 ???먮룞 ??λ맗?덈떎)</div>`;
        return;
    }

    selectedHistoryIds.clear();
    lastHistoryIdx = -1;

    area.innerHTML = `
        <div class="max-w-[800px] mx-auto p-8 flex flex-col h-full animate-fade-in bg-[#12121e]" style="min-height:100%;">
            <div class="flex justify-between items-end mb-6">
                <h2 class="text-2xl font-bold text-white/90 flex items-center gap-2"><i class="ph-bold ph-clock-counter-clockwise text-accent"></i> 援먯븞 ?꾩뭅?대툕 (?덉뒪?좊━)</h2>
                <div class="text-xs text-textMuted bg-black/30 px-3 py-1.5 rounded-lg border border-white/10 flex items-center gap-2" id="history-capacity-info">
                    <i class="ph ph-spinner animate-spin"></i> DB ?⑸웾 怨꾩궛以?..
                </div>
            </div>
            
            <div class="flex items-center justify-between bg-white/5 p-3 rounded-t-xl border border-white/10 border-b-0">
                <div class="flex items-center gap-3 pl-1">
                    <input type="checkbox" id="history-select-all" onchange="toggleSelectAllHistory(this.checked)" class="w-4 h-4 rounded border-white/20 bg-black/50 accent-accent cursor-pointer">
                    <label for="history-select-all" class="text-sm font-bold text-white/80 cursor-pointer select-none">?꾩껜 ?좏깮</label>
                    <span class="text-xs font-bold text-accent ml-2 bg-accent/10 px-2 py-0.5 rounded" id="history-select-count">0媛??좏깮??/span>
                </div>
                <div class="flex gap-2">
                    <button onclick="exportSelectedHistoryMD()" class="flex items-center gap-1 px-3 py-1.5 text-xs font-bold bg-white/10 hover:bg-white/20 text-white rounded transition-colors"><i class="ph-bold ph-file-text"></i> MD ?ㅼ슫濡쒕뱶</button>
                    <button onclick="exportSelectedHistoryPDF()" class="flex items-center gap-1 px-3 py-1.5 text-xs font-bold bg-white/10 hover:bg-white/20 text-white rounded transition-colors"><i class="ph-bold ph-file-pdf"></i> PDF ?ㅼ슫濡쒕뱶</button>
                    <div class="w-px h-5 bg-white/20 mx-1 self-center"></div>
                    <button onclick="deleteSelectedHistory()" class="flex items-center gap-1 px-3 py-1.5 text-xs font-bold bg-red-500/20 hover:bg-red-500/40 text-red-300 rounded transition-colors"><i class="ph-bold ph-trash"></i> ?좏깮 ??젣</button>
                </div>
            </div>
            
            <div id="history-list-container" class="flex-1 overflow-y-auto editor-scroll border border-white/10 rounded-b-xl bg-black/30 p-2 flex flex-col gap-1 select-none">
                <!-- list injected here -->
            </div>
        </div>
    `;
    renderHistoryList();

    // IndexedDB ?꾩껜 ?⑸웾 鍮꾨룞湲?痢≪젙
    const capInfo = document.getElementById('history-capacity-info');
    try {
        if (navigator.storage && navigator.storage.estimate) {
            const estimation = await navigator.storage.estimate();
            const usageMB = (estimation.usage / (1024 * 1024)).toFixed(1);
            const quotaMB = (estimation.quota / (1024 * 1024)).toFixed(1);
            capInfo.innerHTML = `DB ?ъ슜?? <span class="text-accent font-bold">${usageMB} MB</span> <span class="opacity-50">/ ${quotaMB} MB</span>`;
        } else {
            capInfo.innerHTML = `<span class="text-textMuted">?⑸웾 痢≪젙 API 誘몄???/span>`;
        }
    } catch (e) {
        capInfo.innerHTML = `<span class="text-textMuted text-orange-400">?⑸웾 怨꾩궛 ?ㅽ뙣</span>`;
    }
}

window.renderHistoryList = function () {
    const container = document.getElementById('history-list-container');
    const countSpan = document.getElementById('history-select-count');
    if (!container) return;

    countSpan.innerText = `${selectedHistoryIds.size}개 선택됨`;
    const checkAll = document.getElementById('history-select-all');
    if (checkAll) checkAll.checked = contentHistory.length > 0 && selectedHistoryIds.size === contentHistory.length;

    const reversedHistory = [...contentHistory].reverse();
    container.innerHTML = reversedHistory.map((h, displayIdx) => {
        const isSelected = selectedHistoryIds.has(h.id);
        const metadataLabel = getHistoryMetadataLabel(h);
        return `
            <div class="p-3 rounded-lg border ${isSelected ? 'bg-accent/20 border-accent/50' : 'bg-white/[0.04] border-transparent hover:bg-white/[0.08]'} cursor-pointer flex justify-between items-center transition-colors"
                 onclick="handleHistoryClick(event, ${h.id}, ${displayIdx})">
                <div class="flex items-center gap-3 pl-1">
                    <input type="checkbox" class="w-4 h-4 rounded border-white/20 bg-black/50 accent-accent pointer-events-none" ${isSelected ? 'checked' : ''}>
                    <div>
                        <h4 class="font-bold ${isSelected ? 'text-white' : 'text-white/80'} text-sm">${h.title}</h4>
                        <span class="text-xs text-white/40">${h.date}</span>
                        ${metadataLabel ? `<div class="text-[0.65rem] text-white/45 mt-0.5">${escapeHistoryHtml(metadataLabel)}</div>` : ''}
                    </div>
                </div>
                <button onclick="event.stopPropagation(); viewHistoryItem(${h.id})" class="text-accent hover:text-white hover:bg-accent text-xs font-bold px-3 py-1.5 bg-accent/10 rounded transition-colors border border-accent/20">?댁슜 蹂닿린</button>
            </div>
        `;
    }).join('');
}

window.handleHistoryClick = function (e, id, displayIdx) {
    const reversedHistory = [...contentHistory].reverse();

    if (e.shiftKey && lastHistoryIdx !== -1) {
        const start = Math.min(lastHistoryIdx, displayIdx);
        const end = Math.max(lastHistoryIdx, displayIdx);
        for (let i = start; i <= end; i++) selectedHistoryIds.add(reversedHistory[i].id);
    } else if (e.ctrlKey || e.metaKey) {
        if (selectedHistoryIds.has(id)) selectedHistoryIds.delete(id);
        else selectedHistoryIds.add(id);
        lastHistoryIdx = displayIdx;
    } else {
        selectedHistoryIds.clear();
        selectedHistoryIds.add(id);
        lastHistoryIdx = displayIdx;
    }
    renderHistoryList();
}

window.toggleSelectAllHistory = function (isChecked) {
    if (isChecked) contentHistory.forEach(h => selectedHistoryIds.add(h.id));
    else selectedHistoryIds.clear();
    lastHistoryIdx = -1;
    renderHistoryList();
}

window.deleteSelectedHistory = async function () {
    if (selectedHistoryIds.size === 0) return window.showAlert('??젣????ぉ???좏깮?댁＜?몄슂.');
    showConfirm(`?좏깮??${selectedHistoryIds.size}媛쒖쓽 ?덉뒪?좊━瑜??곴뎄 ??젣?섏떆寃좎뒿?덇퉴?`, async () => {
        contentHistory = contentHistory.filter(h => !selectedHistoryIds.has(h.id));
        selectedHistoryIds.clear();
        await saveState();
        toggleHistoryPanel(); // Refresh view
    });
}



window.clearHistory = function () {
    if (!Array.isArray(contentHistory) || contentHistory.length === 0) {
        return window.showAlert('??젣???덉뒪?좊━媛 ?놁뒿?덈떎.');
    }

    showConfirm(`?꾩껜 ${contentHistory.length}媛쒖쓽 ?덉뒪?좊━瑜???젣?섏떆寃좎뒿?덇퉴?`, async () => {
        contentHistory = [];
        selectedHistoryIds.clear();
        lastHistoryIdx = -1;
        await saveState();

        const panel = document.getElementById('history-panel');
        if (panel && !panel.classList.contains('hidden')) {
            renderHistoryUI(panel);
        }
    });
}

window.exportSelectedHistoryMD = function () {

    if (selectedHistoryIds.size === 0) return window.showAlert('?ㅼ슫濡쒕뱶????ぉ???좏깮?댁＜?몄슂.');

    const text = contentHistory

        .filter(h => selectedHistoryIds.has(h.id))

        .map(h => {
            const metadataLabel = getHistoryMetadataLabel(h);
            const metadataLine = metadataLabel ? `\n\n*메타데이터: ${metadataLabel}*` : '';
            return `# ${h.title}\n\n*??젣?? ${h.date}*${metadataLine}\n\n${resolveMarkdownImages(h.content, h.images)}`;
        })

        .join('\n\n---\n\n');

    downloadFile(text, `?꾩뭅?대툕_?좏깮蹂?${Date.now()}.md`, 'text/markdown');

}



window.exportSelectedHistoryPDF = async function () {

    if (selectedHistoryIds.size === 0) return window.showAlert('?ㅼ슫濡쒕뱶????ぉ???좏깮?댁＜?몄슂.');



    // html2pdf ?쇱씠釉뚮윭由?濡쒕뱶 ?뺤씤 (?ㅽ듃?뚰겕 臾몄젣 諛⑹뼱)

    if (typeof html2pdf === 'undefined') {

        return window.showAlert('PDF 蹂???쇱씠釉뚮윭由щ? 遺덈윭?ㅼ? 紐삵뻽?듬땲?? ?좎떆 ???ㅼ떆 ?쒕룄?섍굅???덈줈怨좎묠 ?댁＜?몄슂.');

    }



    const items = contentHistory.filter(h => selectedHistoryIds.has(h.id));



    const btn = document.querySelector('button[onclick="exportSelectedHistoryPDF()"]');

    const origHTML = btn.innerHTML;

    btn.innerHTML = '<i class="ph-bold ph-spinner animate-spin"></i> 蹂?섏쨷...';

    btn.disabled = true;



    const tempContainer = document.createElement('div');

    tempContainer.className = 'markdown-body';

    // PDF ?뚮뜑留곸슜 ?몃씪???ㅽ???媛뺤젣 二쇱엯 (?ㅽ봽?ㅽ겕由곗뿉?쒕룄 html2canvas媛 ?뺤긽 罹≪쿂?섎룄濡?

    Object.assign(tempContainer.style, {

        padding: '40px',

        background: '#fff',

        color: '#3a3a4a',

        fontFamily: 'Noto Sans KR, Inter, sans-serif',

        lineHeight: '1.8',

        letterSpacing: '-0.01em',

        position: 'fixed',

        left: '0',

        top: '0',

        width: '800px',

        zIndex: '-9999',

        visibility: 'hidden'

    });



    let htmlContent = '';

    items.forEach(h => {

        htmlContent += `<h1 style="border-bottom: 2px solid #e8e6f0; padding-bottom: 10px; color: #1a1a2e;">${h.title}</h1>`;

        htmlContent += `<p style="color:#888; font-size:12px; margin-bottom: 20px;">??젣?? ${h.date}</p>`;
        const metadataLabel = getHistoryMetadataLabel(h);
        if (metadataLabel) {
            htmlContent += `<p style="color:#667; font-size:11px; margin:-12px 0 20px 0;">메타데이터: ${escapeHistoryHtml(metadataLabel)}</p>`;
        }



        try {

            htmlContent += typeof marked !== 'undefined' ? marked.parse(resolveMarkdownImages(h.content, h.images)) : `<pre>${resolveMarkdownImages(h.content, h.images)}</pre>`;

        } catch (e) {

            htmlContent += `<p>蹂???ㅻ쪟 諛쒖깮</p>`;

        }



        htmlContent += `<div style="page-break-after: always; margin-top: 50px;"></div>`;

    });

    tempContainer.innerHTML = htmlContent;

    document.body.appendChild(tempContainer);



    // DOM ?뚮뜑留??꾨즺 ?湲?(html2canvas媛 鍮?罹붾쾭?ㅻ? 罹≪쿂?섎뒗 臾몄젣 諛⑹?)

    await new Promise(resolve => requestAnimationFrame(() => setTimeout(resolve, 200)));



    const opt = {

        margin: 15,

        filename: `?꾩뭅?대툕_?좏깮蹂?${Date.now()}.pdf`,

        image: { type: 'jpeg', quality: 0.98 },

        html2canvas: { scale: 2, useCORS: true, windowWidth: 800 },

        jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }

    };



    try {

        await html2pdf().set(opt).from(tempContainer).save();

    } catch (e) {

        window.showAlert('PDF 蹂??以??ㅻ쪟媛 諛쒖깮?덉뒿?덈떎: ' + e.message);

    } finally {

        document.body.removeChild(tempContainer);

        btn.innerHTML = origHTML;

        btn.disabled = false;

    }

}



// ?대?吏 ?곗씠??移섑솚 ?ы띁 ?⑥닔 (?대낫?닿린 ?⑸룄濡?源붾걫?섍쾶 蹂??

function resolveMarkdownImages(content, images) {

    let md = content || '> ?댁슜 ?놁쓬';



    // 1. 而ㅼ뒪? HTML ?섑띁瑜??쒖? 留덊겕?ㅼ슫 ?대?吏 臾몃쾿?쇰줈 ?섎룎由?(WAF 諛⑹뼱 諛?源붾걫???섏텧)

    md = md.replace(/<div class="image-wrapper">\s*<img src="(local:img_[^"]+)" alt="([^"]*)"[^>]*>[\s\S]*?<\/div>/gi, '![$2]($1)');



    if (images) {

        for (const [imgId, b64] of Object.entries(images)) {

            md = md.split(`local:${imgId}`).join(b64);

        }

    }

    return md;

}



window.viewHistoryItem = function (id) {
    const item = contentHistory.find(h => h.id === id);
    if (!item) { window.showAlert("?대떦 ?덉뒪?좊━ ??ぉ??李얠쓣 ???놁뒿?덈떎."); return; }

    try {
        const rawContent = item.content || '(鍮??댁슜)';
        let resolved = rawContent;
        const metadataLabel = getHistoryMetadataLabel(item);

        // ?대?吏 移섑솚 ?쒕룄 (?ㅽ뙣?대룄 ?먮낯 ?띿뒪?몃줈 吏꾪뻾)
        try {
            resolved = resolveMarkdownImages(rawContent, item.images || {});
        } catch (imgErr) {
            console.warn("?덉뒪?좊━ ?대?吏 移섑솚 寃쎄퀬:", imgErr);
        }

        // marked ?뚯꽌 ?쒕룄 (?ㅽ뙣 ???먮낯 ?띿뒪?몃? pre ?대갚)
        let htmlContent;
        if (typeof marked !== 'undefined') {
            try {
                htmlContent = marked.parse(resolved);
            } catch (parseErr) {
                console.warn("marked.parse ?뚯떛 寃쎄퀬:", parseErr);
                htmlContent = `<pre style="white-space:pre-wrap;word-break:break-word;">${resolved.replace(/</g, '&lt;')}</pre>`;
            }
        } else {
            htmlContent = `<pre style="white-space:pre-wrap;word-break:break-word;">${resolved.replace(/</g, '&lt;')}</pre>`;
        }

        const metadataHtml = metadataLabel
            ? `<div style="font-size:12px;color:#64748b;margin-bottom:12px;">메타데이터: ${escapeHistoryHtml(metadataLabel)}</div>`
            : '';
        showModal(`[蹂듦뎄] ${item.title || '?쒕ぉ ?놁쓬'}`, metadataHtml + htmlContent);

    } catch (e) {
        console.error("?덉뒪?좊━ 蹂듭썝 ?ㅻ쪟:", e);
        window.showAlert("?댁슜??遺덈윭?ㅻ뒗 以??ㅻ쪟媛 諛쒖깮?덉뒿?덈떎: " + e.message);
    }
}



let draggedId = null;

function initDragAndDrop() {

    const cards = document.querySelectorAll('.module-card');

    cards.forEach(card => {

        card.addEventListener('dragstart', (e) => {

            draggedId = card.dataset.id === 'mainQuest' ? 'mainQuest' : parseInt(card.dataset.id);

            card.classList.add('dragging');

            e.dataTransfer.effectAllowed = 'move';

        });

        card.addEventListener('dragend', () => {

            card.classList.remove('dragging');

            draggedId = null;

            document.querySelectorAll('.module-card').forEach(c => c.classList.remove('drag-over'));

        });

        card.addEventListener('dragover', (e) => {

            e.preventDefault();

            e.dataTransfer.dropEffect = 'move';

            card.classList.add('drag-over');

        });

        card.addEventListener('dragleave', () => {

            card.classList.remove('drag-over');

        });

        card.addEventListener('drop', (e) => {

            e.preventDefault();

            card.classList.remove('drag-over');

            const targetId = card.dataset.id === 'mainQuest' ? 'mainQuest' : parseInt(card.dataset.id);



            if (draggedId !== null && draggedId !== targetId && draggedId !== 'mainQuest' && targetId !== 'mainQuest') {

                const fromIdx = courseData.findIndex(m => m.id === draggedId);

                const toIdx = courseData.findIndex(m => m.id === targetId);

                if (fromIdx !== -1 && toIdx !== -1) {

                    const [moved] = courseData.splice(fromIdx, 1);

                    courseData.splice(toIdx, 0, moved);

                    saveState().then(() => {
                        renderSidebar();
                    });

                }

            }

        });

    });

}



function downloadFile(content, fileName, mimeType) {

    const blob = new Blob([content], { type: mimeType });

    const url = URL.createObjectURL(blob);

    const a = document.createElement('a');

    a.href = url;

    a.download = fileName;

    a.click();

    URL.revokeObjectURL(url);

}

function _getNormalizedTeacherNotes(mod) {
    if (!mod || !Array.isArray(mod.teacherNotes)) return [];
    const seen = new Set();
    const notes = [];
    mod.teacherNotes.forEach(item => {
        if (!item || typeof item !== 'object') return;
        const anchor = String(item.anchor || '').trim();
        const note = String(item.note || '').trim();
        if (!anchor || !note || seen.has(anchor)) return;
        seen.add(anchor);
        notes.push({ anchor, note });
    });
    return notes;
}

function _stripTeacherNotesCommentBlock(markdown) {
    const source = typeof markdown === 'string' ? markdown : '';
    return source.replace(/\n*<!--\s*TEACHER:\s*BEGIN[\s\S]*?TEACHER:\s*END\s*-->\s*/gi, '\n').trimEnd();
}

function _extractTeacherNotesFromMarkdown(markdown) {
    const source = typeof markdown === 'string' ? markdown : '';
    const blockMatch = source.match(/<!--\s*TEACHER:\s*BEGIN\s*([\s\S]*?)\s*TEACHER:\s*END\s*-->/i);
    if (!blockMatch) {
        return { cleanMarkdown: source, notes: [] };
    }

    const body = blockMatch[1] || '';
    const notes = [];
    const noteRegex = /\[\d+\]\s*anchor:\s*([^\n]+)\n([\s\S]*?)(?=\n\s*\[\d+\]\s*anchor:|$)/g;
    let match;
    while ((match = noteRegex.exec(body)) !== null) {
        const anchor = String(match[1] || '').trim();
        const note = String(match[2] || '').trim();
        if (!anchor || !note) continue;
        if (!notes.some(item => item.anchor === anchor)) {
            notes.push({ anchor, note });
        }
    }

    return {
        cleanMarkdown: _stripTeacherNotesCommentBlock(source),
        notes
    };
}

function _buildTeacherNotesCommentBlock(mod) {
    const notes = _getNormalizedTeacherNotes(mod);
    if (notes.length === 0) return '';

    const body = notes.map((item, idx) => {
        return `[${idx + 1}] anchor: ${item.anchor}\n${item.note}`;
    }).join('\n\n');

    return `\n\n<!-- TEACHER: BEGIN\n${body}\nTEACHER: END -->`;
}

function _buildMarkdownVariantsForExport(mod, options = {}) {
    const prependTitle = !!options.prependTitle;
    const titleText = prependTitle ? `# ${mod.title}\n\n` : '';
    const coreContent = _stripTeacherNotesCommentBlock(mod.content || '');
    const studentMd = `${titleText}${coreContent}`.trim();
    const teacherBlock = _buildTeacherNotesCommentBlock(mod);
    const teacherMd = `${studentMd}${teacherBlock}`.trim();
    return {
        studentMd: studentMd ? `${studentMd}\n` : '',
        teacherMd: teacherMd ? `${teacherMd}\n` : ''
    };
}

function _splitMarkdownVariantFileNames(baseName) {
    const raw = typeof baseName === 'string' ? baseName : 'module.md';
    const noExt = raw.toLowerCase().endsWith('.md') ? raw.slice(0, -3) : raw;
    return {
        studentFileName: `${noExt}_student.md`,
        teacherFileName: `${noExt}_teacher.md`
    };
}

function _base64StringToUint8Array(base64Text) {
    const text = typeof base64Text === 'string' ? base64Text : '';
    const binaryString = atob(text);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
}

function _rewriteMarkdownImageRefs(markdown, images, onImageExport) {
    let output = typeof markdown === 'string' ? markdown : '';
    if (!images || typeof images !== 'object' || Array.isArray(images)) return output;

    for (const [imgId, value] of Object.entries(images)) {
        let imgFileName = null;
        if (typeof value === 'string') {
            const matches = value.match(/^data:(image\/\w+);base64,(.*)$/);
            if (matches) {
                let ext = matches[1].split('/')[1];
                if (ext === 'jpeg') ext = 'jpg';
                imgFileName = `${imgId}.${ext}`;
                if (typeof onImageExport === 'function') {
                    onImageExport(imgFileName, matches[2], value);
                }
            } else if (value.startsWith('__FILE__:')) {
                imgFileName = value.substring('__FILE__:'.length);
            }
        }
        if (!imgFileName) continue;

        const tagRegex = new RegExp(`<!--\\s*\\[IMG:\\s*"?local:${imgId}"?\\]\\s*-->`, 'g');
        const imgRegex = new RegExp(`src="local:${imgId}"`, 'g');
        output = output.replace(tagRegex, `![${imgId}](../泥⑤??뚯씪/${imgFileName})`);
        output = output.replace(imgRegex, `src="../泥⑤??뚯씪/${imgFileName}"`);
    }

    return output;
}



window.exportCurrentModule = async function () {
    const mod = getEditingModule();
    if (!mod || !mod.content) return window.showAlert('?대낫???댁슜???놁뒿?덈떎.');
    const subj = globalState.subjects.find(s => s.id === currentSubjectId);

    // 과정명(Project Name), 교과명(Subject Name) 안전화
    const rawCourseTitle = globalState.courseTitle || '??援먯븞?꾨줈?앺듃';
    const safeCourseName = _toSafeFolderName(rawCourseTitle, 'course');
    const safeSubjName = _toSafeFolderName(subj ? subj.title : '', 'subject');
    const fallbackFileName = `${_sanitizeFileStem(mod.title || 'module', 'module')}.md`;
    const fileName = getModuleExportFileNameByConvention(subj, mod.id, fallbackFileName, '.md');

    try {
        const zip = new JSZip();

        // 1. 理쒖긽?? 怨쇱젙紐??대뜑 ?앹꽦
        const rootFolder = zip.folder(safeCourseName);

        // 2. 硫뷀??곗씠??猷⑦듃 諛곗튂
        const metaObj = {
            project: rawCourseTitle,
            subject: subj ? subj.title : '',
            module: mod.title,
            timestamp: new Date().toISOString()
        };
        rootFolder.file('save_data.yaml', JSON.stringify(metaObj, null, 2));

        // 3. 由ъ냼??泥⑤??뚯씪) & 援먭낵 ?대뜑 ?앹꽦
        const attachFolder = rootFolder.folder("泥⑤??뚯씪");
        const subjFolder = rootFolder.folder(safeSubjName);

        const variants = _buildMarkdownVariantsForExport(mod, { prependTitle: false });
        const { studentFileName, teacherFileName } = _splitMarkdownVariantFileNames(fileName);
        const writtenImageFiles = new Set();
        const appendImageToZip = (imgFileName, base64Data) => {
            if (writtenImageFiles.has(imgFileName)) return;
            writtenImageFiles.add(imgFileName);
            attachFolder.file(imgFileName, base64Data, { base64: true });
        };

        const studentMd = _rewriteMarkdownImageRefs(variants.studentMd, mod.images, appendImageToZip);
        const teacherMd = _rewriteMarkdownImageRefs(variants.teacherMd, mod.images, appendImageToZip);

        subjFolder.file(studentFileName, studentMd);
        subjFolder.file(teacherFileName, teacherMd);

        const content = await zip.generateAsync({ type: "blob" });
        saveAs(content, `${safeCourseName}_${fileName.replace('.md', '')}_teacher_student.zip`);

    } catch (e) {
        console.error("ZIP ?앹꽦 ?ㅻ쪟:", e);
        window.showAlert('?뺤텞 ?뚯씪 ?앹꽦 以??ㅻ쪟媛 諛쒖깮?덉뒿?덈떎. JSZip ?쇱씠釉뚮윭由ш? 濡쒕뱶?섏뿀?붿? ?뺤씤?섏꽭??');
    }
}



window.exportAllModules = async function () {
    if (!Array.isArray(courseData) || courseData.length === 0) return window.showAlert('?대낫???곗씠?곌? ?놁뒿?덈떎.');
    const subj = globalState.subjects.find(s => s.id === currentSubjectId);

    // 과정명(Project Name) 안전화
    const rawCourseTitle = globalState.courseTitle || '??援먯븞?꾨줈?앺듃';
    const safeCourseName = rawCourseTitle.replace(/[\/\?<>\\:\*\|"]/g, '_').trim();
    // 교과명(Subject Name) 안전화
    const safeSubjName = subj ? subj.title.replace(/[\/\?<>\\:\*\|"]/g, '_').trim() : '湲곕낯_援먭낵';

    try {
        const zip = new JSZip();

        // 1. 理쒖긽?? 怨쇱젙紐??대뜑 ?앹꽦
        const rootFolder = zip.folder(safeCourseName);

        // 2. 硫뷀??곗씠??(save_data.yaml) 猷⑦듃 諛곗튂
        const metaObj = {
            project: rawCourseTitle,
            subject: subj ? subj.title : '',
            timestamp: new Date().toISOString(),
            module_count: courseData.length,
            context: buildCompactStateForExternalSave(globalState) // 전체 설정 및 호환 컨텍스트 직렬화
        };
        rootFolder.file('save_data.yaml', JSON.stringify(metaObj, null, 2)); // ?몄쓽??JSON 吏곷젹?붾? yaml ?뺤옣?먮줈 蹂댁〈

        // 3. 由ъ냼??泥⑤??뚯씪) ?쒕툕?대뜑 & 援먭낵 ?대뜑 ?앹꽦
        const attachFolder = rootFolder.folder("泥⑤??뚯씪");
        const subjFolder = rootFolder.folder(safeSubjName);

        const writtenImageFiles = new Set();
        const appendImageToZip = (imgFileName, base64Data) => {
            if (writtenImageFiles.has(imgFileName)) return;
            writtenImageFiles.add(imgFileName);
            attachFolder.file(imgFileName, base64Data, { base64: true });
        };

        courseData.forEach((m, idx) => {
            if (String(m?.id) === 'mainQuest') return;
            const fallbackFileName = _buildDefaultModuleFileName(m, idx);
            const mdFileName = getModuleExportFileNameByConvention(subj, m.id, fallbackFileName, '.md');

            const variants = _buildMarkdownVariantsForExport(m, { prependTitle: true });
            const { studentFileName, teacherFileName } = _splitMarkdownVariantFileNames(mdFileName);
            const studentMd = _rewriteMarkdownImageRefs(variants.studentMd, m.images, appendImageToZip);
            const teacherMd = _rewriteMarkdownImageRefs(variants.teacherMd, m.images, appendImageToZip);

            subjFolder.file(studentFileName, studentMd);
            subjFolder.file(teacherFileName, teacherMd);
        });

        // 4. mainQuest 별도 내보내기
        if (subj && subj.mainQuest && subj.mainQuest.content) {
            const mq = subj.mainQuest;
            const mqFallbackFileName = _buildDefaultModuleFileName(mq, -1);
            const mqFileName = getModuleExportFileNameByConvention(subj, mq.id, mqFallbackFileName, '.md');

            const variants = _buildMarkdownVariantsForExport(mq, { prependTitle: true });
            const { studentFileName, teacherFileName } = _splitMarkdownVariantFileNames(mqFileName);
            const studentMd = _rewriteMarkdownImageRefs(variants.studentMd, mq.images, appendImageToZip);
            const teacherMd = _rewriteMarkdownImageRefs(variants.teacherMd, mq.images, appendImageToZip);

            subjFolder.file(studentFileName, studentMd);
            subjFolder.file(teacherFileName, teacherMd);
        }

        // 臾띠쓬 ZIP ?앹꽦 (?대쫫? ?꾨줈?앺듃_援먭낵紐?
        const content = await zip.generateAsync({ type: "blob" });
        saveAs(content, `${safeCourseName}_${safeSubjName}.zip`);

    } catch (e) {
        console.error("?꾩껜 ZIP ?앹꽦 ?ㅻ쪟:", e);
        window.showAlert('?뺤텞 ?뚯씪 ?앹꽦 以??ㅻ쪟媛 諛쒖깮?덉뒿?덈떎. JSZip ?쇱씠釉뚮윭由ш? 濡쒕뱶?섏뿀?붿? ?뺤씤?섏꽭??');
    }
}



// =========================================================================
// PDF ?대낫?닿린 (?꾩옱 李⑥떆)
// =========================================================================
window.exportToPDF = async function () {
    if (typeof html2pdf === 'undefined') {
        return window.showAlert('PDF 蹂???쇱씠釉뚮윭由щ? 遺덈윭?ㅼ? 紐삵뻽?듬땲?? ?좎떆 ???ㅼ떆 ?쒕룄?섍굅???덈줈怨좎묠 ?댁＜?몄슂.');
    }

    const mod = getEditingModule();
    if (!mod || !mod.content) {
        return window.showAlert('PDF濡?蹂?섑븷 援먯븞 ?댁슜???놁뒿?덈떎. 李⑥떆瑜??좏깮?섍퀬 援먯븞??癒쇱? ?앹꽦?댁＜?몄슂.');
    }

    const btn = document.getElementById('pdf-dropdown-btn');
    let originalHTML = '';
    if (btn) { originalHTML = btn.innerHTML; btn.innerHTML = '<i class="ph-bold ph-spinner animate-spin"></i> 蹂?섏쨷'; btn.disabled = true; }

    try {
        await _generatePdfFromMarkdown(mod.content, mod.title, mod.images || {});
    } catch (e) {
        window.showAlert('PDF 蹂???ㅻ쪟媛 諛쒖깮?덉뒿?덈떎: ' + e.message);
    } finally {
        if (btn) { btn.innerHTML = originalHTML; btn.disabled = false; }
    }
}

// =========================================================================
// PDF ?대낫?닿린 (?꾩옱 援먭낵 ?꾩껜 - 李⑥떆蹂??섏씠吏)
// =========================================================================
window.exportSubjectToPDF = async function () {
    if (typeof html2pdf === 'undefined') {
        return window.showAlert('PDF 蹂???쇱씠釉뚮윭由щ? 遺덈윭?ㅼ? 紐삵뻽?듬땲??');
    }

    if (!Array.isArray(courseData) || courseData.length === 0) {
        return window.showAlert('?꾩옱 援먭낵??李⑥떆媛 ?놁뒿?덈떎.');
    }

    const contentModules = courseData.filter(m => m.content);
    if (contentModules.length === 0) {
        return window.showAlert('PDF濡?蹂?섑븷 援먯븞???놁뒿?덈떎. 援먯븞??癒쇱? ?앹꽦?댁＜?몄슂.');
    }

    const btn = document.getElementById('pdf-dropdown-btn');
    let originalHTML = '';
    if (btn) { originalHTML = btn.innerHTML; btn.innerHTML = '<i class="ph-bold ph-spinner animate-spin"></i> 蹂?섏쨷'; btn.disabled = true; }

    try {
        // 紐⑤뱺 李⑥떆??Markdown??李⑥떆 援щ텇?좉낵 ?④퍡 ?⑹묠
        let combinedMarkdown = '';
        for (let i = 0; i < contentModules.length; i++) {
            const m = contentModules[i];
            combinedMarkdown += m.content;
            if (i < contentModules.length - 1) {
                combinedMarkdown += '\n\n<div style="page-break-after: always;"></div>\n\n---\n\n';
            }
        }

        // 紐⑤뱺 ?대?吏瑜??⑹묠
        const allImages = {};
        contentModules.forEach(m => {
            if (m.images) Object.assign(allImages, m.images);
        });

        const subj = globalState.subjects.find(s => s.id === currentSubjectId);
        const subjTitle = subj ? subj.title : '援먭낵?꾩껜';

        await _generatePdfFromMarkdown(combinedMarkdown, subjTitle, allImages);
    } catch (e) {
        window.showAlert('PDF 蹂???ㅻ쪟媛 諛쒖깮?덉뒿?덈떎: ' + e.message);
    } finally {
        if (btn) { btn.innerHTML = originalHTML; btn.disabled = false; }
    }
}

// =========================================================================
// PDF 怨듯넻 ?좏떥: Markdown ??HTML ??html2pdf 蹂??// =========================================================================
async function _generatePdfFromMarkdown(markdownContent, title, images) {
    // ??? 1. ?몃? ?쇱씠釉뚮윭由?html2canvas ?? 罹≪쿂 ?쒓퀎濡??명븳 ?ㅼ씠?곕툕 ?꾪솚 ???
    // 湲곗〈??jsPDF/html2canvas??臾몄꽌 蹂듭옟?? CSS 紐⑤뱶???곕씪 吏?띿쟻 諛깆? ?뚮뜑留?諛쒖깮 ?뺤씤.
    // 100% 諛깆?瑜?諛⑹??섍퀬 踰≫꽣 ?띿뒪?몃? 蹂댁〈?섍린 ?꾪빐 ?④꺼吏?iframe???ъ슜??釉뚮씪?곗? ?먯껜 ?몄뇙 ?ъ슜

    try {
        // ??? 2. Markdown ??HTML 蹂?????
        var htmlContent = '';
        if (typeof marked !== 'undefined') {
            htmlContent = marked.parse(markdownContent);
        } else {
            htmlContent = '<pre style="white-space:pre-wrap;">' + markdownContent + '</pre>';
        }

        // ??? 3. ?대?吏 李몄“瑜?base64 data URI濡?援먯껜 ???
        if (images && Object.keys(images).length > 0) {
            for (const [imgId, b64] of Object.entries(images)) {
                htmlContent = htmlContent.replace(new RegExp('src="local:' + imgId + '"', 'g'), 'src="' + b64 + '"');
            }
        }

        // ??? 4. ?④꺼吏?Iframe ?앹꽦 (?꾩옱 ?섏씠吏 ?대????쎌엯) ???
        var iframe = document.createElement('iframe');
        iframe.id = 'pdf-hidden-print-frame';
        // ?붾㈃??蹂댁씠吏 ?딄퀬 怨듦컙??李⑥??섏? ?딅룄濡?泥섎━
        iframe.style.cssText = 'position:fixed; right:0; bottom:0; width:0; height:0; border:none; visibility:hidden; z-index:-9999;';
        document.body.appendChild(iframe);

        // ??? 5. Iframe ?대????몄뇙 ?꾩슜 ?뺥깭???꾩쟾??HTML ?쎌엯 ???
        var doc = iframe.contentWindow || iframe.contentDocument;
        if (doc.document) doc = doc.document;

        doc.open();
        doc.write(`
            <!DOCTYPE html>
            <html lang="ko">
            <head>
                <meta charset="utf-8">
                <title>${title}</title>
                <style>
                    @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@400;600;800&display=swap');
                    
                    * { box-sizing: border-box; }
                    /* ?붾㈃ ?쒖텧??踰좎씠???ㅽ???(紐⑥쓽) */
                    body {
                        margin: 0; padding: 0; background: #fff; color: #111;
                        font-family: 'Noto Sans KR', 'Inter', sans-serif;
                        font-size: 14px; line-height: 1.7;
                    }
                    .pdf-content { padding: 20px 30px; }
                    h1 { font-size: 1.7rem; font-weight: 800; border-bottom: 2px solid #5b4fcc; padding-bottom: 0.5rem; margin-bottom: 1rem; color: #000; }
                    h2 { font-size: 1.35rem; font-weight: 600; margin-top: 1.5rem; margin-bottom: 0.6rem; color: #000; }
                    h3 { font-size: 1.1rem; font-weight: 600; margin-top: 1.2rem; margin-bottom: 0.4rem; color: #222; }
                    p { margin-bottom: 0.8rem; }
                    ul, ol { padding-left: 1.5rem; margin-bottom: 0.8rem; }
                    code { background: #f0f0f0; padding: 0.1rem 0.3rem; border-radius: 3px; color: #5b4fcc; font-family: monospace; }
                    pre { background: #f5f5f5; padding: 1rem; border-radius: 4px; overflow-x: auto; border: 1px solid #ddd; page-break-inside: avoid; }
                    pre code { background: none; color: #333; padding: 0; }
                    blockquote { border-left: 3px solid #5b4fcc; padding: 0.5rem 1rem; background: #f9f9f9; color: #444; margin: 1rem 0; page-break-inside: avoid; }
                    table { border-collapse: collapse; width: 100%; margin: 1rem 0; page-break-inside: avoid; }
                    th, td { border: 1px solid #aaa; padding: 8px 10px; }
                    th { background: #eee; font-weight: 600; }
                    img { max-width: 100%; height: auto; display: block; margin: 1rem auto; page-break-inside: avoid; max-height: 80vh; object-fit: contain; }
                    
                    /* ?먮뵒???꾩슜 媛앹껜 媛뺤젣 ?④? */
                    .image-wrapper button, .image-wrapper span.absolute, .image-regenerate-btn { display: none !important; }

                    /* ??媛??以묒슂???몄뇙(Print) ?꾩슜 理쒖쟻????*/
                    @media print {
                        @page { margin: 1.5cm; } /* A4 湲곕낯 留덉쭊 ?ㅼ젙 */
                        body { width: 100%; background: #ffffff !important; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
                        h1, h2, h3 { page-break-after: avoid; }
                        img, table, pre, blockquote { page-break-inside: avoid; }
                    }
                </style>
            </head>
            <body>
                <div class="pdf-content">${htmlContent}</div>
            </body>
            </html>
        `);
        doc.close();

        // ??? 6. ?대?吏 濡쒕뱶 ?湲?(?몄뇙 ??紐⑤뱺 由ъ냼??諛곗튂 ?꾨즺) ???
        var imgEls = doc.querySelectorAll('img');
        if (imgEls.length > 0) {
            await Promise.all(Array.from(imgEls).map(function (img) {
                if (img.complete) return Promise.resolve();
                return new Promise(function (res) { img.onload = res; img.onerror = res; });
            }));
        }

        // 폰트/레이아웃 렌더 안정화 대기
        await new Promise(function (res) { setTimeout(res, 800); });

        // ??? 7. ?ㅼ씠?곕툕 ?몄뇙 ?ㅼ씠?쇰줈洹??몄텧 ???
        // ??李?Tab) ?대룞 ?놁씠 ?꾩옱 李??꾩뿉 ?앹뾽 ?뺤떇?쇰줈 ?몄텧?⑸땲??
        iframe.contentWindow.focus();
        iframe.contentWindow.print();

        // ??? 8. 泥?냼 ???
        // print()???숆린(李⑤떒) ?⑥닔泥섎읆 ?숈옉?섏?留?釉뚮씪?곗?留덈떎 李⑥씠媛 ?덉쑝誘濡?        // ?몄뇙 李쎌씠 ?ロ엳嫄곕굹 ?쒓컙??異⑸텇??吏????iframe????젣?⑸땲??
        setTimeout(function () {
            if (iframe && iframe.parentNode) {
                iframe.remove();
            }
        }, 10000); // 10珥????먮룞 ?뚮㈇

    } catch (e) {
        console.error('PDF 蹂???ㅻ쪟:', e);
        window.showAlert('PDF (?몄뇙) 李쎌쓣 ?щ뒗 以??쇱떆?곸씤 ?ㅻ쪟媛 諛쒖깮?덉뒿?덈떎.');
    }
}

// =========================================================================
// PDF ?쒕∼?ㅼ슫 ?좉? (?대┃ 湲곕컲)
// =========================================================================
window.togglePdfDropdown = function (event) {
    const dropdown = document.getElementById('pdf-dropdown-menu');
    if (!dropdown) return;
    const isOpen = !dropdown.classList.contains('hidden');
    if (isOpen) {
        dropdown.classList.add('hidden');
        document.removeEventListener('click', _closePdfDropdownOnOutside);
        return;
    }
    const btn = document.getElementById('pdf-dropdown-btn');
    if (btn) {
        const btnRect = btn.getBoundingClientRect();
        const dropW = 160; // w-40 = 10rem = 160px
        const top = btnRect.bottom + 4;
        // ?붾㈃ ?곗륫?먯꽌 ?섏튂硫??ㅻⅨ履?留욎땄, ?꾨땲硫??쇱そ 留욎땄
        const left = (btnRect.left + dropW > window.innerWidth)
            ? window.innerWidth - dropW - 8
            : btnRect.left;
        dropdown.style.top = top + 'px';
        dropdown.style.left = left + 'px';
    }
    dropdown.classList.remove('hidden');
    setTimeout(() => { document.addEventListener('click', _closePdfDropdownOnOutside); }, 0);
    if (event) event.stopPropagation();
}
function _closePdfDropdownOnOutside(e) {
    const dropdown = document.getElementById('pdf-dropdown-menu');
    const btn = document.getElementById('pdf-dropdown-btn');
    if (dropdown && !dropdown.contains(e.target) && btn && !btn.contains(e.target)) {
        dropdown.classList.add('hidden');
        document.removeEventListener('click', _closePdfDropdownOnOutside);
    }
}



function handleImageFileInsertion(file, target) {
    const fileType = file.type; // e.g. 'image/png', 'image/gif'
    const reader = new FileReader();

    reader.onload = (event) => {
        const originalB64 = event.target.result;

        // GIF???뱀닔 ?щ㎎? 罹붾쾭???뺤텞(?뺤쟻 蹂?????쇳븯怨??먮낯 ?좎?
        if (fileType === 'image/gif') {
            const mod = getEditingModule();
            if (!mod.images) mod.images = {};
            const imgId = 'img_' + Date.now() + Math.floor(Math.random() * 1000);
            mod.images[imgId] = originalB64; // ?먮낯 B64 蹂댁〈

            const imgTag = `\n<img src="local:${imgId}" alt="inserted image" style="max-width:100%; border-radius:8px;">\n`;
            insertTextAtCursor(target, imgTag);
            return;
        }

        // ?쇰컲 ?뺤쟻 ?대?吏???댁긽?꾨? ??텛??png(?먮뒗 jpeg) ?듭씪 泥섎━
        const img = new Image();
        img.onload = () => {
            const canvas = document.createElement('canvas');
            let width = img.width;
            let height = img.height;
            const MAX_WIDTH = 800;

            if (width > MAX_WIDTH) {
                height = Math.round((height * MAX_WIDTH) / width);
                width = MAX_WIDTH;
            }

            canvas.width = width;
            canvas.height = height;
            const ctx = canvas.getContext('2d');
            ctx.drawImage(img, 0, 0, width, height);

            // 洹쒖젙???곕씪 ?뺤쟻 ?대?吏??png濡??듭씪
            const compressedBase64 = canvas.toDataURL('image/png');

            const mod = getEditingModule();
            if (!mod.images) mod.images = {};
            const imgId = 'img_' + Date.now() + Math.floor(Math.random() * 1000);
            mod.images[imgId] = compressedBase64;

            const imgTag = `\n<img src="local:${imgId}" alt="inserted image" style="max-width:100%; border-radius:8px;">\n`;
            insertTextAtCursor(target, imgTag);
        };
        img.src = originalB64;
    };
    reader.readAsDataURL(file);
}

function insertTextAtCursor(target, text) {
    const pos = target.selectionStart;
    target.value = target.value.substring(0, pos) + text + target.value.substring(pos);
    target.setSelectionRange(pos + text.length, pos + text.length);

    // 硫붿씤 ?먮뵒?곗씤 寃쎌슦?먮쭔 利됱떆 ?먮Ц ?ㅼ퐫???숆린?붾? ?섑뻾
    // (?몃씪???먮뵒???앹뾽 ?쇱쓽 寃쎌슦 onBlur/Enter ?대깽?몄뿉??吏곸젒 AST濡???ν븯誘濡??ㅽ궢)
    if (target.id === 'raw-view') {
        if (typeof saveRawContent === 'function') saveRawContent();
    }
}

function initImageInsertionHandlers() {
    const isInsertionTarget = (target) => {
        if (!target) return false;
        // 硫붿씤 ?먮뵒??#raw-view) 嫄곕굹 ?몃씪???먮뵒????TEXTAREA)??寃쎌슦 ?덉슜
        return target.id === 'raw-view' || (target.tagName === 'TEXTAREA' && target.closest('#render-view'));
    };

    // Paste Event
    document.addEventListener('paste', (e) => {
        const target = e.target;
        if (isInsertionTarget(target)) {
            const items = (e.clipboardData || window.clipboardData).items;
            for (let i = 0; i < items.length; i++) {
                if (items[i].kind === 'file' && items[i].type.startsWith('image/')) {
                    e.preventDefault();
                    handleImageFileInsertion(items[i].getAsFile(), target);
                    break;
                }
            }
        }
    });

    // Dragover Event (To allow drop)
    document.addEventListener('dragover', (e) => {
        const target = e.target;
        if (isInsertionTarget(target)) {
            e.preventDefault(); // allow drop
            target.classList.add('border-accent', 'bg-accent/10'); // Optional: Add visual cue
        }
    });

    // Dragleave Event
    document.addEventListener('dragleave', (e) => {
        const target = e.target;
        if (isInsertionTarget(target)) {
            target.classList.remove('border-accent', 'bg-accent/10');
        }
    });

    // Drop Event
    document.addEventListener('drop', (e) => {
        const target = e.target;
        if (isInsertionTarget(target)) {
            e.preventDefault();
            target.classList.remove('border-accent', 'bg-accent/10');

            const files = e.dataTransfer.files;
            if (files && files.length > 0) {
                // Handle multiple files if dropped
                for (let i = 0; i < files.length; i++) {
                    if (files[i].type.startsWith('image/')) {
                        handleImageFileInsertion(files[i], target);
                    }
                }
            }
        }
    });
}


// =========================================================================
// ?대?吏 ?뚯씪 ?좏깮 ?쎌엯 ?몃뱾??(?먮뵒???꾧뎄紐⑥쓬 "?대?吏 ?쎌엯" 踰꾪듉)
// =========================================================================
window.handleImageInputSelect = function (event) {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    // ?쎌엯 ??? ?섏젙 紐⑤뱶(raw-view) ?먮뒗 ?쒖꽦 ?몃씪???먮뵒??textarea
    let target = document.getElementById('raw-view');
    if (!target || target.classList.contains('hidden')) {
        // ?몃씪???먮뵒??textarea ?먯깋
        const renderView = document.getElementById('render-view');
        if (renderView) {
            target = renderView.querySelector('textarea');
        }
    }

    if (!target) {
        window.showAlert('?대?吏瑜??쎌엯?섎젮硫??섏젙 紐⑤뱶濡??꾪솚?섍굅?? 釉붾줉???붾툝?대┃?섏뿬 ?몃씪???몄쭛???쒖옉?섏꽭??');
        event.target.value = '';
        return;
    }

    for (let i = 0; i < files.length; i++) {
        if (files[i].type.startsWith('image/')) {
            handleImageFileInsertion(files[i], target);
        }
    }

    // 媛숈? ?뚯씪 ?ъ꽑?앹쓣 ?덉슜?섍린 ?꾪빐 ?명뭼 由ъ뀑
    event.target.value = '';
};

// =========================================================================
// ZIP ?몄씠釉??뚯씪 蹂듭썝 (Load Import) 泥닿퀎
// =========================================================================
window.importProjectZip = async function (event) {
    const file = event.target.files[0];
    if (!file) return;

    if (!file.name.endsWith('.zip')) {
        window.showAlert('吏?먰븯吏 ?딅뒗 ?몄씠釉??뚯씪?낅땲?? (.zip ?뺤떇留?媛??');
        event.target.value = '';
        return;
    }

    try {
        const zip = await JSZip.loadAsync(file);
        let metaObj = null;
        let imageMap = new Map(); // fileName -> base64
        let mdFiles = [];

        // 1회차: 메타데이터/이미지/마크다운 경로 수집
        const entries = Object.keys(zip.files);
        for (const relativePath of entries) {
            const zipEntry = zip.files[relativePath];
            if (zipEntry.dir) continue;

            if (relativePath.includes('save_data.yaml')) {
                const yamlText = await zipEntry.async("string");
                metaObj = safeJSONParse(yamlText); // yaml?대씪 ?쇱?留??댁쟾 ?④퀎?먯꽌 ?몄쓽??JSON 吏곷젹?뷀븿
            } else if (relativePath.includes('泥⑤??뚯씪/')) {
                const binaryData = await zipEntry.async("base64");
                const ext = relativePath.split('.').pop().toLowerCase();
                const mimeType = ext === 'jpg' ? 'image/jpeg' : `image/${ext}`;
                const safeB64 = `data:${mimeType};base64,${binaryData}`;

                // ?뚯씪紐낆쓣 ?ㅻ줈 ?ъ슜 (?? "img_12345.png")
                const fileName = relativePath.split('/').pop();
                imageMap.set(fileName, safeB64);
            } else if (relativePath.endsWith('.md')) {
                const mdContent = await zipEntry.async("string");
                mdFiles.push({ path: relativePath, content: mdContent });
            }
        }

        if (!metaObj) {
            throw new Error("?좏슚??Web Agent ?몄씠釉??뚯씪(save_data.yaml ?뚯떛 ?ㅽ뙣 ?먮뒗 ?꾨씫)???꾨떃?덈떎.");
        }

        let isSingleModule = !metaObj.context;

        if (isSingleModule) {
            // ?⑥씪 李⑥떆(exportCurrentModule) 蹂듭썝 紐⑤뱶: ?꾩옱 援먭낵????紐⑤뱢濡?醫낆냽?쒗궡
            const subj = globalState.subjects.find(s => s.id === currentSubjectId);
            if (!subj) throw new Error("?꾩옱 ?좏깮??援먭낵媛 ?놁뒿?덈떎. 援먭낵瑜?癒쇱? ?앹꽦?댁＜?몄슂.");

            let newMod = {
                id: 'm_' + Date.now() + Math.floor(Math.random() * 1000),
                title: metaObj.module || '遺덈윭??援먯븞',
                description: '',
                status: 'waiting',
                content: '',
                images: {},
                teacherNotes: [],
                qualityEvaluation: null,
                uploadedMdName: null,
                uploadedMdContent: null
            };

            const matchedMd = mdFiles.find(mf => mf.path.endsWith('.md'));
            if (matchedMd) {
                let content = matchedMd.content;
                // YAML 헤더 스트립
                const yamlEndIdx = content.indexOf('---\n\n');
                if (yamlEndIdx !== -1 && content.startsWith('---')) {
                    content = content.substring(yamlEndIdx + 5);
                } else if (content.startsWith('# ' + newMod.title)) {
                    content = content.replace(new RegExp(`^# ${newMod.title}\\n\\n`), '');
                }

                // ?대?吏 寃쎈줈 ??튂??(../泥⑤??뚯씪/img_xxx -> local:img_xxx)
                const revertTagRegex = /!\[([^\]]+)\]\(\.\.\/泥⑤??뚯씪\/([^)]+)\)/g;
                const revertImgRegex = /src="\.\.\/泥⑤??뚯씪\/([^"]+)"/g;

                content = content.replace(revertTagRegex, (match, altStr, fileName) => {
                    const originalId = fileName.split('.')[0];
                    if (imageMap.has(fileName)) newMod.images[originalId] = imageMap.get(fileName);
                    return `<!-- [IMG: "local:${originalId}"] -->`;
                });

                content = content.replace(revertImgRegex, (match, fileName) => {
                    const originalId = fileName.split('.')[0];
                    if (imageMap.has(fileName)) newMod.images[originalId] = imageMap.get(fileName);
                    return `src="local:${originalId}"`;
                });

                const extracted = _extractTeacherNotesFromMarkdown(content);
                newMod.content = extracted.cleanMarkdown;
                if (Array.isArray(extracted.notes) && extracted.notes.length > 0) {
                    newMod.teacherNotes = extracted.notes;
                }
            }

            courseData.push(newMod);

            await saveState(); // 濡쒖뺄?ㅽ넗由ъ? 諛깆뾽
            if (typeof renderSidebar === 'function') renderSidebar();
            if (typeof viewModule === 'function') viewModule(newMod.id);
            window.showAlert('?⑥씪 李⑥떆 援먯븞???꾩옱 援먭낵???깃났?곸쑝濡?媛?몄솕?듬땲??');

        } else {
            // 湲곗〈 援먯븞 ?곗씠?곕? ?덉뒪?좊━??諛깆뾽 (??뼱?곌린 ???덉쟾?μ튂)
            if (Array.isArray(courseData) && courseData.length > 0) {
                courseData.forEach(mod => {
                    if (mod && mod.content) archiveContent(mod);
                });
            }

            // 2?쒗쉶: globalState ?듭㎏ 蹂듭썝 (?꾩껜 肄붿뒪 紐⑤뱶)
            globalState = metaObj.context;
            // API ????釉뚮씪?곗? ?섏〈 ?섎컻??媛?蹂댁〈
            if (typeof apiKey !== 'undefined') globalState.apiKey = apiKey;

            // 3?쒗쉶: courseData ?ш뎄??諛??대?吏 ??튂??(Map?먯꽌 濡쒖뺄 ?먮뵒?꾪듃 硫붾え由щ줈 ?꾩넚)
            const restoredSubj = globalState.subjects.find(s => s.id === currentSubjectId) || globalState.subjects[0];
            if (restoredSubj) {
                currentSubjectId = restoredSubj.id;
                courseData = restoredSubj.lessons || [];

                courseData.forEach(mod => {
                    if (!mod.images) mod.images = {};

                    const matchedMd = mdFiles.find(mf => mf.path.includes(mod.title) || mf.content.includes(`# ${mod.title}`));
                    if (matchedMd) {
                        let content = matchedMd.content;

                        const yamlEndIdx = content.indexOf('---\n\n');
                        if (yamlEndIdx !== -1 && content.startsWith('---')) {
                            content = content.substring(yamlEndIdx + 5);
                        } else if (content.startsWith('# ' + mod.title)) {
                            content = content.replace(new RegExp(`^# ${mod.title}\\n\\n`), '');
                        }

                        const revertTagRegex = /!\[([^\]]+)\]\(\.\.\/泥⑤??뚯씪\/([^)]+)\)/g;
                        const revertImgRegex = /src="\.\.\/泥⑤??뚯씪\/([^"]+)"/g;

                        content = content.replace(revertTagRegex, (match, altStr, fileName) => {
                            const originalId = fileName.split('.')[0]; // img_123
                            if (imageMap.has(fileName)) mod.images[originalId] = imageMap.get(fileName);
                            return `<!-- [IMG: "local:${originalId}"] -->`;
                        });

                        content = content.replace(revertImgRegex, (match, fileName) => {
                            const originalId = fileName.split('.')[0];
                            if (imageMap.has(fileName)) mod.images[originalId] = imageMap.get(fileName);
                            return `src="local:${originalId}"`;
                        });

                        const extracted = _extractTeacherNotesFromMarkdown(content);
                        mod.content = extracted.cleanMarkdown;
                        if ((!Array.isArray(mod.teacherNotes) || mod.teacherNotes.length === 0) && Array.isArray(extracted.notes) && extracted.notes.length > 0) {
                            mod.teacherNotes = extracted.notes;
                        }
                    }
                });
            }

            // 4. UI 및 메모리 싱크
            await saveState(); // 로컬스토리지 증분 백업
            if (typeof renderSidebar === 'function') renderSidebar();
            // SPA ?쇱슦?곕? ?듯빐 媛쒖슂 ?붾㈃?쇰줈 ?덉쟾?섍쾶 ?꾪솚
            location.hash = '#overview';

            window.showAlert('?깃났?곸쑝濡?濡쒖뺄 ?몄씠釉??뚯씪??遺덈윭? ?꾩뿭 蹂듭썝?덉뒿?덈떎!');
        }

    } catch (e) {
        console.error("ZIP 遺덈윭?ㅺ린 ?ㅻ쪟:", e);
        window.showAlert(`遺덈윭?ㅺ린 ?ㅽ뙣: ${e.message}`);
    } finally {
        event.target.value = ''; // ?ъ뾽濡쒕뱶瑜??꾪빐 ?명뭼 由ъ뀑
    }
};


// =========================================================================
// ?곗텧臾?濡쒖뺄 ?붿뒪?????(File System Access API)
// =========================================================================

/**
 * base64 Data URL ??Uint8Array 諛붿씠?덈━ 蹂???ы띁
 */
function base64ToUint8Array(b64DataUrl) {
    const base64 = b64DataUrl.split(',')[1];
    const binaryString = atob(base64);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
}

/**
 * FileSystemDirectoryHandle ???띿뒪???뚯씪 ?곌린 ?ы띁
 */
async function writeTextFile(dirHandle, fileName, content) {
    const fileHandle = await dirHandle.getFileHandle(fileName, { create: true });
    const writable = await fileHandle.createWritable();
    await writable.write(content);
    await writable.close();
}

/**
 * FileSystemDirectoryHandle ??諛붿씠?덈━ ?뚯씪 ?곌린 ?ы띁
 */
async function writeBinaryFile(dirHandle, fileName, uint8Array) {
    const fileHandle = await dirHandle.getFileHandle(fileName, { create: true });
    const writable = await fileHandle.createWritable();
    await writable.write(uint8Array);
    await writable.close();
}


// =========================================================================
// 濡쒖뺄 ?꾨줈?앺듃 ?대뜑 ?ㅼ떆媛??곌껐/?숆린???쒖뒪??(Phase F7)
// =========================================================================

function removeFolderReauthBanner() {
    const banner = document.getElementById('folder-reauth-banner');
    if (banner) banner.remove();
}

function showFolderReauthBanner(folderName, onReauthClick) {
    let banner = document.getElementById('folder-reauth-banner');
    if (!banner) {
        banner = document.createElement('div');
        banner.id = 'folder-reauth-banner';
        banner.className = 'fixed top-[68px] right-4 z-[260] w-[340px] max-w-[calc(100vw-24px)] rounded-xl border border-orange-400/40 bg-[#2a1e15]/95 shadow-[0_14px_30px_rgba(0,0,0,0.5)] backdrop-blur-sm p-3 text-[0.72rem] text-orange-100 animate-fade-in';
        banner.innerHTML = `
            <div class="flex items-start gap-2">
                <i class="ph-fill ph-warning-circle text-orange-300 text-base mt-0.5"></i>
                <div class="min-w-0 flex-1">
                    <p class="font-semibold leading-5">폴더 권한이 만료되었습니다.</p>
                    <p class="text-orange-100/80 leading-5 mt-0.5 truncate"><span data-folder-name></span> 폴더에 다시 접근하려면 재인증이 필요합니다.</p>
                    <div class="mt-2 flex justify-end gap-1.5">
                        <button type="button" data-close-btn class="px-2 py-1 rounded-md border border-orange-300/30 text-orange-100/80 hover:text-white hover:bg-orange-500/20 transition-colors">닫기</button>
                        <button type="button" data-reauth-btn class="px-2.5 py-1 rounded-md bg-orange-500/80 hover:bg-orange-500 text-white font-semibold transition-colors">재인증</button>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(banner);
    }

    const folderNameNode = banner.querySelector('[data-folder-name]');
    if (folderNameNode) folderNameNode.textContent = folderName || '연결된 폴더';

    const closeBtn = banner.querySelector('[data-close-btn]');
    if (closeBtn) {
        closeBtn.onclick = () => removeFolderReauthBanner();
    }

    const reauthBtn = banner.querySelector('[data-reauth-btn]');
    if (reauthBtn) {
        reauthBtn.onclick = () => {
            if (typeof onReauthClick === 'function') onReauthClick();
        };
    }
}

/**
 * ?꾨줈?앺듃 ?대뜑 ?곌껐 ???ъ슜?먭? ?대뜑瑜??좏깮?섎㈃ ?댄썑 紐⑤뱺 saveState() ?몄텧 ?? * ?대떦 ?대뜑???먮룞?쇰줈 ?곗씠?곕? ?숆린?뷀빀?덈떎.
 */
window.connectProjectFolder = async function () {
    if (!('showDirectoryPicker' in window)) {
        return window.showAlert('??釉뚮씪?곗????대뜑 ?곌껐??吏?먰븯吏 ?딆뒿?덈떎.\nChrome ?먮뒗 Edge瑜??ъ슜?댁＜?몄슂.');
    }

    try {
        const dirHandle = await window.showDirectoryPicker({
            mode: 'readwrite'
        });
        projectFolderHandle = dirHandle;

        // IndexedDB에 디렉토리 핸들 저장(가능한 경우)
        if (typeof DBManager !== 'undefined') {
            try {
                await DBManager.setItem('projectFolderHandle', dirHandle);
            } catch (dbErr) {
                console.warn('?대뜑 ?곌껐 ?먯껜???깃났?덉쑝???몃뱾(?덈줈怨좎묠 ?좎??? ??μ뿉 ?ㅽ뙣?덉뒿?덈떎:', dbErr);
            }
        }

        // 연결 직후 현재 상태를 폴더에 즉시 동기화
        await syncToLinkedFolder();

        // UI ?낅뜲?댄듃
        const indicator = document.getElementById('folder-connection-indicator');
        if (indicator) {
            indicator.innerHTML = `
                <i class="ph-fill ph-folder text-cyan-400 text-sm"></i>
                <span class="text-white/90 font-medium truncate max-w-[100px]">${dirHandle.name}</span>
                <i class="ph-bold ph-caret-down text-[0.6rem] text-white/50 ml-1"></i>
            `;
            indicator.title = `연결된 폴더: ${dirHandle.name} (클릭해 메뉴 열기)`;
            indicator.onclick = toggleFolderDropdown;
        }
        removeFolderReauthBanner();

        window.showToast(`[${dirHandle.name}] ?대뜑媛 ?곕룞?섏뿀?듬땲?? ?댄썑 紐⑤뱺 蹂寃쎌궗??씠 ?먮룞 ?숆린?붾맗?덈떎.`);

    } catch (err) {
        if (err.name !== 'AbortError') {
            console.error('?대뜑 ?곌껐 ?ㅻ쪟:', err);
            window.showAlert('?대뜑 ?곌껐 以??ㅻ쪟媛 諛쒖깮?덉뒿?덈떎: ' + err.message);
        }
    }
};

/**
 * ?꾨줈?앺듃 ?대뜑 ?곌껐 ?댁젣
 */
window.disconnectProjectFolder = async function () {
    projectFolderHandle = null;

    // [異붽?] DB?먯꽌 ?몃뱾 ??젣
    if (typeof DBManager !== 'undefined') {
        try {
            await DBManager.deleteItem('projectFolderHandle');
        } catch (dbErr) {
            console.warn('DB?먯꽌 ?대뜑 ?몃뱾????젣?섎뒗 ???ㅽ뙣?덉뒿?덈떎:', dbErr);
        }
    }

    const indicator = document.getElementById('folder-connection-indicator');
    if (indicator) {
        indicator.innerHTML = `
            <i class="ph ph-folder-dashed text-sm text-white/40"></i>
            <span class="text-white/40">?곌껐 ?덈맖</span>
        `;
        indicator.title = '프로젝트 폴더 연결하기';
        // ?대┃ ??諛붾줈 ?곌껐 李??꾩슦湲?(誘몄뿰寃??곹깭)
        indicator.onclick = () => window.connectProjectFolder();
    }
    removeFolderReauthBanner();
    window.showToast('?대뜑 ?곕룞???댁젣?섏뿀?듬땲??');
};

/**
 * FileSystemDirectoryHandle??沅뚰븳???뺤씤?섍퀬 ?꾩슂???붿껌?⑸땲??
 * @param {FileSystemDirectoryHandle} handle
 * @param {boolean} requestIfNotGranted ?대┃ ?대깽??而⑦뀓?ㅽ듃 ?대? ?깆뿉??沅뚰븳??臾쇱뼱遊먮룄 ?섎뒗吏 ?щ?
 * @returns {Promise<boolean>} 沅뚰븳??遺?щ릺?덉쑝硫?true, ?꾨땲硫?false
 */
async function verifyPermission(handle, requestIfNotGranted = false) {
    const options = { mode: 'readwrite' };
    let permission = await handle.queryPermission(options);
    if (permission === 'granted') {
        return true;
    }

    // 사용자 클릭 컨텍스트에서만 requestPermission 호출
    if (requestIfNotGranted) {
        permission = await handle.requestPermission(options);
        return permission === 'granted';
    }
    return false;
}

/**
 * ?섏씠吏 濡쒕뱶 ??IndexedDB????λ맂 ?꾨줈?앺듃 ?대뜑 ?곌껐??蹂듭썝?⑸땲??
 */
window.restoreProjectFolderConnection = async function () {
    if (!('showDirectoryPicker' in window) || typeof DBManager === 'undefined') {
        return;
    }

    try {
        let storedHandle = null;
        try {
            storedHandle = await DBManager.getItem('projectFolderHandle');
        } catch (dbErr) {
            console.warn('DB?먯꽌 ?대뜑 ?몃뱾 ?쎄린 ?ㅽ뙣:', dbErr);
            return; // ?쎄린???ㅽ뙣?덈떎硫?蹂듭썝 以묐떒
        }

        if (storedHandle) {
            // 珥덇린 濡쒕뵫?먮뒗 requestPermission ?앹뾽???꾩슦吏 紐삵븯誘濡??곹깭(query)留?泥댄겕
            const hasPermission = await verifyPermission(storedHandle, false);

            if (hasPermission) {
                // ?대? 沅뚰븳???좎??섏뼱 ?덈떎硫?諛붾줈 蹂듭썝
                projectFolderHandle = storedHandle;
                const indicator = document.getElementById('folder-connection-indicator');
                if (indicator) {
                    indicator.innerHTML = `
                        <i class="ph-fill ph-folder text-cyan-400 text-sm"></i>
                        <span class="text-white/90 font-medium truncate max-w-[100px]">${storedHandle.name}</span>
                        <i class="ph-bold ph-caret-down text-[0.6rem] text-white/50 ml-1"></i>
                    `;
                    indicator.title = `연결된 폴더: ${storedHandle.name} (클릭해 메뉴 열기)`;
                    indicator.onclick = toggleFolderDropdown;
                }
                removeFolderReauthBanner();
                console.log(`[${storedHandle.name}] ?대뜑 ?곌껐???먮룞 蹂듭썝?섏뿀?듬땲??`);
            } else {
                // 沅뚰븳??留뚮즺???곹깭 -> ?ъ슜?먭? 踰꾪듉???뚮????뚮쭔 requestPermission ?몄텧
                console.warn('??λ맂 ?대뜑 ?몃뱾??沅뚰븳??留뚮즺?섏뿀?듬땲?? ?대┃???듯빐 ?ъ씤利앹씠 ?꾩슂?⑸땲??');

                const indicator = document.getElementById('folder-connection-indicator');
                if (!indicator) return;

                const requestReauth = async () => {
                    try {
                        const granted = await verifyPermission(storedHandle, true); // 클릭 이벤트 컨텍스트에서만 팝업 가능
                        if (!granted) {
                            window.showToast('폴더 권한이 아직 허용되지 않았습니다. 다시 시도해 주세요.');
                            return;
                        }

                        projectFolderHandle = storedHandle;
                        indicator.innerHTML = `
                            <i class="ph-fill ph-folder text-cyan-400 text-sm"></i>
                            <span class="text-white/90 font-medium truncate max-w-[100px]">${storedHandle.name}</span>
                            <i class="ph-bold ph-caret-down text-[0.6rem] text-white/50 ml-1"></i>
                        `;
                        indicator.title = `연결된 폴더: ${storedHandle.name} (클릭해 메뉴 열기)`;
                        indicator.onclick = toggleFolderDropdown; // ?쒕∼?ㅼ슫?쇰줈 濡ㅻ갚
                        removeFolderReauthBanner();
                        window.showToast(`[${storedHandle.name}] ?대뜑 ?곌린 沅뚰븳??蹂듭썝?섏뿀?듬땲??`);
                    } catch (permError) {
                        console.error('沅뚰븳 ?붿껌 ?ㅽ뙣', permError);
                        window.showAlert('?대뜑 沅뚰븳 ?띾뱷???ㅽ뙣?덉뒿?덈떎. ?ㅻⅨ ?대뜑 ?곌껐???쒕룄?댁＜?몄슂.');
                    }
                };

                indicator.innerHTML = `
                    <i class="ph-fill ph-folder-lock text-orange-400 text-sm animate-pulse"></i>
                    <span class="text-orange-300 font-medium truncate max-w-[100px]">${storedHandle.name}</span>
                    <span class="text-orange-300/80">재인증 필요</span>
                `;
                indicator.title = `폴더 권한 만료: ${storedHandle.name} (클릭해 재인증)`;
                // 사용자 클릭 시 권한 재요청
                indicator.onclick = requestReauth;
                showFolderReauthBanner(storedHandle.name, requestReauth);
            }
        }
    } catch (e) {
        console.error('?대뜑 ?곌껐 蹂듭썝 以??ㅻ쪟 諛쒖깮:', e);
        await window.disconnectProjectFolder();
    }
}

/**
 * ?곌껐???꾨줈?앺듃 ?대뜑?먯꽌 ?곗씠??遺덈윭?ㅺ린
 */
window.loadFromProjectFolder = async function () {
    if (!('showDirectoryPicker' in window)) {
        return window.showAlert('??釉뚮씪?곗????대뜑 遺덈윭?ㅺ린瑜?吏?먰븯吏 ?딆뒿?덈떎.');
    }

    try {
        const dirHandle = await window.showDirectoryPicker({ mode: 'readwrite' });

        // save_data.yaml 議댁옱 ?щ? ?뺤씤
        let saveDataHandle;
        try {
            saveDataHandle = await dirHandle.getFileHandle('save_data.yaml');
        } catch (e) {
            // JSON ?대갚 (?댁쟾 踰꾩쟾 ?명솚)
            try { saveDataHandle = await dirHandle.getFileHandle('save_data.json'); }
            catch (e2) { return window.showAlert('?좏슚???꾨줈?앺듃 ?대뜑媛 ?꾨떃?덈떎.\nsave_data.yaml ?뚯씪??李얠쓣 ???놁뒿?덈떎.'); }
        }

        const file = await saveDataHandle.getFile();
        const text = await file.text();
        const parsed = simpleYamlParse(text);

        if (!parsed.state) {
            return window.showAlert('save_data.yaml???좏슚???곹깭 ?곗씠?곌? ?놁뒿?덈떎.');
        }

        // ?꾩옱 ?곗씠??諛깆뾽
        if (Array.isArray(courseData) && courseData.length > 0) {
            courseData.forEach(mod => {
                if (mod && mod.content) archiveContent(mod);
            });
        }

        // ?곹깭 蹂듭썝
        const sanitized = sanitizeState(parsed.state);
        if (sanitized) {
            globalState = sanitized;
            await rehydrateStateImagesFromFileRefs(dirHandle, globalState);
        }

        // ?덉뒪?좊━ 蹂듭썝
        if (Array.isArray(parsed.history)) {
            contentHistory = normalizeHistoryItems(parsed.history);
            await rehydrateHistoryImagesFromFileRefs(dirHandle, globalState, contentHistory);
        }

        // 援먭낵 ?곗씠??蹂듭썝
        if (globalState.subjects.length > 0) {
            const firstSubj = globalState.subjects[0];
            currentSubjectId = firstSubj.id;
            courseData = firstSubj.lessons || [];
        }

        // ?대뜑 ?곌껐 ?좎?
        projectFolderHandle = dirHandle; // linkedDirHandle -> projectFolderHandle
        if (typeof DBManager !== 'undefined') {
            try {
                await DBManager.setItem('projectFolderHandle', dirHandle);
            } catch (dbErr) {
                console.warn('湲곗〈 ?묒뾽 ?대뜑 ?곌껐 ?먯껜???깃났?덉쑝???몃뱾(?덈줈怨좎묠 ?좎??? ??μ뿉 ?ㅽ뙣?덉뒿?덈떎:', dbErr);
            }
        }

        // UI 동기화
        await saveState();
        document.getElementById('folder-connection-indicator').innerHTML = `
            <i class="ph-fill ph-folder text-cyan-400 text-sm"></i>
            <span class="text-white/90 font-medium truncate max-w-[100px]">${dirHandle.name}</span>
            <i class="ph-bold ph-caret-down text-[0.6rem] text-white/50 ml-1"></i>
        `;
        document.getElementById('folder-connection-indicator').title = `연결된 폴더: ${dirHandle.name} (클릭해 메뉴 열기)`;
        document.getElementById('folder-connection-indicator').onclick = toggleFolderDropdown;
        removeFolderReauthBanner();


        if (typeof renderSidebar === 'function') renderSidebar();
        location.hash = '#overview';

        window.showAlert(`???꾨줈?앺듃 ?대뜑?먯꽌 ?깃났?곸쑝濡?遺덈윭?붿뒿?덈떎!\n?뱚 ${dirHandle.name}\n\n?대뜑媛 ?먮룞?쇰줈 ?곌껐?섏뼱 ?댄썑 蹂寃쎌궗??룄 ?숆린?붾맗?덈떎.`);

    } catch (e) {
        if (e.name === 'AbortError') return;
        console.error('?대뜑 遺덈윭?ㅺ린 ?ㅻ쪟:', e);
        window.showAlert('?대뜑 遺덈윭?ㅺ린 以??ㅻ쪟媛 諛쒖깮?덉뒿?덈떎: ' + e.message);
    }
}

/**
 * ?곌껐???대뜑???꾩껜 ?곹깭瑜??숆린??(saveState ?꾪겕?먯꽌 ?몄텧)
 */
async function syncToLinkedFolder() {
    if (!projectFolderHandle) return; // linkedDirHandle -> projectFolderHandle

    try {
        // 沅뚰븳 ?ы솗??(???꾪솚 ??沅뚰븳 留뚮즺 諛⑹뼱)
        const permission = await projectFolderHandle.queryPermission({ mode: 'readwrite' }); // linkedDirHandle -> projectFolderHandle
        if (permission !== 'granted') {
            const request = await projectFolderHandle.requestPermission({ mode: 'readwrite' }); // linkedDirHandle -> projectFolderHandle
            if (request !== 'granted') {
                projectFolderHandle = null; // linkedDirHandle -> projectFolderHandle
                // updateFolderConnectionUI(false); // Removed, replaced by direct UI update in disconnect
                console.warn('?대뜑 ?곌린 沅뚰븳??嫄곕??섏뼱 ?곌껐???댁젣?섏뿀?듬땲??');
                await window.disconnectProjectFolder(); // Call the new disconnect function
                return;
            }
        }

        // 1. save_data.yaml (?꾩껜 ?곹깭 + ?덉뒪?좊━)
        const saveData = {
            state: buildCompactStateForExternalSave(globalState),
            history: buildCompactHistoryForExternalSave(contentHistory),
            lastSync: new Date().toISOString()
        };
        await writeTextFile(projectFolderHandle, 'save_data.yaml', simpleYamlStringify(saveData)); // linkedDirHandle -> projectFolderHandle

        // 2. 교과별 md/이미지 동기화
        const subj = globalState.subjects.find(s => s.id === currentSubjectId);
        if (subj && Array.isArray(courseData) && courseData.length > 0) {
            const rawCourseTitle = globalState.courseTitle || '??援먯븞?꾨줈?앺듃';
            const safeCourseName = rawCourseTitle.replace(/[\/\?<>\\:\*\|"]/g, '_').trim();
            const safeSubjName = subj.title.replace(/[\/\?<>\\:\*\|"]/g, '_').trim();

            const courseFolder = await projectFolderHandle.getDirectoryHandle(safeCourseName, { create: true }); // linkedDirHandle -> projectFolderHandle
            const attachFolder = await courseFolder.getDirectoryHandle('泥⑤??뚯씪', { create: true });
            const subjFolder = await courseFolder.getDirectoryHandle(safeSubjName, { create: true });
            const writtenImageFiles = new Set();
            const pendingImageWrites = [];
            const appendImageToFolder = (imgFileName, base64Data) => {
                if (writtenImageFiles.has(imgFileName)) return;
                writtenImageFiles.add(imgFileName);
                pendingImageWrites.push(
                    writeBinaryFile(attachFolder, imgFileName, _base64StringToUint8Array(base64Data))
                );
            };

            for (let idx = 0; idx < courseData.length; idx++) {
                const m = courseData[idx];
                if (String(m?.id) === 'mainQuest') continue;
                if (!m.content) continue;

                const fallbackFileName = _buildDefaultModuleFileName(m, idx);
                const mdFileName = getModuleExportFileNameByConvention(subj, m.id, fallbackFileName, '.md');

                const variants = _buildMarkdownVariantsForExport(m, { prependTitle: true });
                const { studentFileName, teacherFileName } = _splitMarkdownVariantFileNames(mdFileName);
                const studentMd = _rewriteMarkdownImageRefs(variants.studentMd, m.images, appendImageToFolder);
                const teacherMd = _rewriteMarkdownImageRefs(variants.teacherMd, m.images, appendImageToFolder);

                const safeStudentName = studentFileName.replace(/[\/\?<>\\:\*\|"]/g, '_');
                const safeTeacherName = teacherFileName.replace(/[\/\?<>\\:\*\|"]/g, '_');
                await writeTextFile(subjFolder, safeStudentName, studentMd);
                await writeTextFile(subjFolder, safeTeacherName, teacherMd);
            }

            // mainQuest 별도 저장
            if (subj.mainQuest && subj.mainQuest.content) {
                const mq = subj.mainQuest;
                const mqFallbackFileName = _buildDefaultModuleFileName(mq, -1);
                const mqFileName = getModuleExportFileNameByConvention(subj, mq.id, mqFallbackFileName, '.md');

                const variants = _buildMarkdownVariantsForExport(mq, { prependTitle: true });
                const { studentFileName, teacherFileName } = _splitMarkdownVariantFileNames(mqFileName);
                const studentMd = _rewriteMarkdownImageRefs(variants.studentMd, mq.images, appendImageToFolder);
                const teacherMd = _rewriteMarkdownImageRefs(variants.teacherMd, mq.images, appendImageToFolder);

                const safeStudentName = studentFileName.replace(/[\/\?<>\\:\*\|"]/g, '_');
                const safeTeacherName = teacherFileName.replace(/[\/\?<>\\:\*\|"]/g, '_');
                await writeTextFile(subjFolder, safeStudentName, studentMd);
                await writeTextFile(subjFolder, safeTeacherName, teacherMd);
            }

            if (pendingImageWrites.length > 0) {
                await Promise.all(pendingImageWrites);
            }
        }

    } catch (e) {
        console.warn('?대뜑 ?숆린???ㅽ뙣:', e.message);
        // ?곹깭 罹먯떆 ?먮윭 泥섎━ (?щ＼ 踰꾧렇 ?????
        if (e.message && e.message.includes('state cached in an interface object')) {
            console.warn('File System ?몃뱾 留뚮즺 臾몄젣. ?곌껐 ?댁젣 泥섎━?⑸땲??');
            projectFolderHandle = null; // linkedDirHandle -> projectFolderHandle
            // updateFolderConnectionUI(false); // Removed
            await window.disconnectProjectFolder(); // Call the new disconnect function
            return;
        }

        // ?대뜑 ?묎렐 ?ㅽ뙣 ???먮룞 ?곌껐 ?댁젣 (?? ?대뜑 ??젣?? 沅뚰븳 留뚮즺 ??
        if (e.name === 'NotFoundError' || e.name === 'NotAllowedError') {
            projectFolderHandle = null; // linkedDirHandle -> projectFolderHandle
            // updateFolderConnectionUI(false); // Removed
            await window.disconnectProjectFolder(); // Call the new disconnect function
        }
    }
}

/**
 * ?덉뒪?좊━ ??ぉ 1嫄댁쓣 ?곌껐???대뜑???덉뒪?좊━ ?붾젆?좊━????? */
async function syncHistoryItemToFolder(historyItem) {
    if (!projectFolderHandle || !historyItem) return; // linkedDirHandle -> projectFolderHandle

    try {
        const historyFolder = await projectFolderHandle.getDirectoryHandle('?덉뒪?좊━', { create: true }); // linkedDirHandle -> projectFolderHandle
        const metadata = normalizeHistoryMetadata(historyItem.metadata, historyItem.date);
        const targetSubject = metadata.subjectId
            ? globalState.subjects.find(s => String(s?.id) === String(metadata.subjectId))
            : null;
        const historyFallback = _sanitizeFileStem(historyItem.title || 'history', 'history');
        let namingStem = historyFallback;

        if (targetSubject && metadata.moduleId) {
            const named = getModuleExportFileNameByConvention(targetSubject, metadata.moduleId, historyFallback, '.json');
            namingStem = _sanitizeFileStem(named.replace(/\.json$/i, ''), historyFallback);
        }
        const safeStem = namingStem.substring(0, 60) || 'history';
        const fileName = `${historyItem.id}_${safeStem}.json`;

        // ?대?吏 ?쒖쇅??寃쎈웾 硫뷀?留????(?⑸웾 ?덉빟)
        const lightItem = {
            id: historyItem.id,
            title: historyItem.title,
            content: historyItem.content,
            date: historyItem.date,
            metadata,
            hasImages: historyItem.images ? Object.keys(historyItem.images).length : 0
        };

        await writeTextFile(historyFolder, fileName, JSON.stringify(lightItem, null, 2));
    } catch (e) {
        console.warn('?덉뒪?좊━ ????ㅽ뙣:', e.message);
    }
}

/**
 * ?대뜑 ?곌껐 ?곹깭 UI ?낅뜲?댄듃
 */
function updateFolderConnectionUI(connected, folderName = '') {
    const indicator = document.getElementById('folder-connection-indicator');
    if (!indicator) return;

    if (connected) {
        indicator.innerHTML = `<i class="ph-fill ph-folder-open text-sm text-emerald-400"></i> <span class="text-emerald-300">${folderName}</span>`;
        indicator.title = `?곌껐?? ${folderName} (?대┃?섏뿬 ?댁젣)`;
        indicator.onclick = () => window.disconnectProjectFolder(); // Changed to call the new disconnect function
    } else {
        indicator.innerHTML = `<i class="ph ph-folder-dashed text-sm text-white/40"></i> <span class="text-white/40">誘몄뿰寃?/span>`;
        indicator.title = '?꾨줈?앺듃 ?대뜑 ?곌껐?섍린';
        indicator.onclick = () => connectProjectFolder();
    }
}


// =========================================================================
// ?곗씠??愿由??쒕∼?ㅼ슫 (?대┃ 湲곕컲 ?좉?)
// =========================================================================

window.toggleDataManageDropdown = function (event) {
    const dropdown = document.getElementById('data-manage-dropdown');
    if (!dropdown) return;

    const isOpen = !dropdown.classList.contains('hidden');

    if (isOpen) {
        dropdown.classList.add('hidden');
        document.removeEventListener('click', _closeDataManageOnOutside);
        return;
    }

    // 踰꾪듉 ?꾩튂 湲곗??쇰줈 ?쒕∼?ㅼ슫 諛곗튂
    const btn = document.getElementById('data-manage-btn');
    if (btn) {
        const rect = btn.getBoundingClientRect();
        dropdown.style.top = (rect.bottom + 4) + 'px';
        dropdown.style.left = rect.left + 'px';
    }

    dropdown.classList.remove('hidden');

    // ?몃? ?대┃?쇰줈 ?リ린 (?ㅼ쓬 ?깆뿉 ?깅줉?섏뿬 ?꾩옱 ?대┃??利됱떆 ?ロ엳??寃?諛⑹?)
    setTimeout(() => {
        document.addEventListener('click', _closeDataManageOnOutside);
    }, 0);

    if (event) event.stopPropagation();
}

function _closeDataManageOnOutside(e) {
    const dropdown = document.getElementById('data-manage-dropdown');
    const btn = document.getElementById('data-manage-btn');
    if (dropdown && !dropdown.contains(e.target) && btn && !btn.contains(e.target)) {
        dropdown.classList.add('hidden');
        document.removeEventListener('click', _closeDataManageOnOutside);
    }
}

