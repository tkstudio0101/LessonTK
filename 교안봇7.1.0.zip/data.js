// data.js - 설정값, 상수, 프롬프트, 모의 데이터 관리

// 0. 공통 유틸리티 (모든 모듈에서 참조 — 반드시 data.js에 위치)
function extractText(data) {
    try {
        const parts = data?.candidates?.[0]?.content?.parts;
        if (!parts || parts.length === 0) return "";
        // Thinking 파트(thought: true)를 건너뛰고 실제 응답 텍스트만 반환
        const textPart = parts.filter(p => !p.thought).map(p => p.text).join('');
        let text = textPart || parts[parts.length - 1]?.text || "";

        // [방어 코드] AI가 프롬프트를 무시하고 &nbsp; 대신 비가시 특수 공백(U+00A0)을 출력하는 문제 해결
        // 1. 마크다운 리스트(-, *, 1. 등) 들여쓰기에 잘못 사용된 특수 공백이나 일반 공백이 섞인 경우, 리스트 문법을 보존하기 위해 들여쓰기 공백을 일반 공백(스페이스바) 2칸으로 묶어버림 (또는 제거)
        // 리스트 문구 앞에는 원래 '&nbsp;' 사용 자체가 금지입니다.
        text = text.replace(/^[ \u00A0]+([-*+]|\d+\.) /gm, '  $1 ');
        // 2. 그 외(일반 텍스트 단락 등)에 쓰인 비가시 특수 공백은 모두 플랫폼 호환을 위해 명시적인 문자열 '&nbsp;'로 치환함
        text = text.replace(/\u00A0/g, '&nbsp;');

        return text;
    } catch (e) {
        console.error("extractText 실패:", e);
        return "";
    }
}
function safeJSONParse(text) {
    if (!text) return null;
    try {
        let cleaned = text.replace(/^```(?:json)?\s*\n?/i, '').replace(/\n?\s*```$/i, '').trim();
        return JSON.parse(cleaned);
    } catch (e) {
        console.error("JSON 파싱 실패:", e, "\n원본:", text.substring(0, 200));
        return null;
    }
}

// 1. API 설정 및 애플리케이션 상수
let apiKey = "AIzaSyBkNaIE4kxtmquoyAzwuRhDg-3XWWVnVx8";
try {
    apiKey = localStorage.getItem('gemini_api_key') || apiKey;
} catch (e) {
    console.warn("localStorage 접근 불가 (API Key):", e);
}
const STORAGE_KEY = 'agent_curriculum_v4_7';
let TEXT_MODEL = 'gemini-2.5-flash';
let IMAGE_MODEL = 'gemini-3.1-flash-image-preview';


// [Phase F10] Google Custom Search API 설정 (다중 키 롤링용)
let googleSearchCx = '';
let googleSearchApiKeys = [];
let currentSearchKeyIndex = 0;

// [Phase F10] 무료 스톡 이미지(Pixabay) 전역 변수
let pixabayApiKey = '';

// 모델 선택지 목록
const TEXT_MODEL_OPTIONS = [
    { value: 'gemini-3.1-pro-preview', label: 'Gemini 3.1 Pro (Preview)' },
    { value: 'gemini-3-flash-preview', label: 'Gemini 3 Flash (Preview)' },
    { value: 'gemini-2.5-flash', label: 'Gemini 2.5 Flash (권장)' },
    { value: 'gemini-2.5-pro', label: 'Gemini 2.5 Pro' },
];
const IMAGE_MODEL_OPTIONS = [
    { value: 'gemini-3.1-flash-image-preview', label: 'Gemini 3.1 Flash Image (Preview, 권장)' },
    { value: 'gemini-3-pro-image-preview', label: 'Gemini 3 Pro Image (Preview)' },
    { value: 'gemini-2.5-flash-image', label: 'Gemini 2.5 Flash Image' },
];

// 모델 런타임 변경 + localStorage 저장
function updateTextModel(val) {
    if (val) { TEXT_MODEL = val; try { localStorage.setItem('gemini_text_model', val); } catch (e) { } }
}
function updateImageModel(val) {
    if (val) { IMAGE_MODEL = val; try { localStorage.setItem('gemini_image_model', val); } catch (e) { } }
}

// 저장된 모델 복원
try {
    const savedText = localStorage.getItem('gemini_text_model');
    const savedImage = localStorage.getItem('gemini_image_model');
    if (savedText && TEXT_MODEL_OPTIONS.some(o => o.value === savedText)) TEXT_MODEL = savedText;
    if (savedImage && IMAGE_MODEL_OPTIONS.some(o => o.value === savedImage)) IMAGE_MODEL = savedImage;

    // [Phase F10] 구글 검색 상태 복원
    googleSearchCx = localStorage.getItem('google_search_cx') || '';
    const keysStr = localStorage.getItem('google_search_api_keys');
    if (keysStr) googleSearchApiKeys = JSON.parse(keysStr);

    // [Phase F10] 무료 스톡(Pixabay) 검색 상태 복원
    pixabayApiKey = localStorage.getItem('pixabay_api_key') || '';
} catch (e) { console.warn("localStorage 접근 불가 (Model/Search):", e); }

// 1-1. API Key 런타임 관리
function updateApiKey(newKey) {
    if (newKey && newKey.trim()) {
        apiKey = newKey.trim();
        try {
            localStorage.setItem('gemini_api_key', apiKey);
        } catch (e) {
            console.warn("localStorage 접근 불가 (API Key 저장):", e);
        }
        return true;
    }
    return false;
}

// 1-2. [Phase F10] 구글 검색 API 설정 저장
function updateGoogleSearchSettings(cx, keysStr) {
    cx = (cx || '').trim();
    const keysArray = (keysStr || '')
        .split(',')
        .map(k => k.trim())
        .filter(k => k.length > 0);

    googleSearchCx = cx;
    googleSearchApiKeys = keysArray;
    currentSearchKeyIndex = 0; // 설정 바뀌면 인덱스 초기화

    try {
        localStorage.setItem('google_search_cx', googleSearchCx);
        localStorage.setItem('google_search_api_keys', JSON.stringify(googleSearchApiKeys));
        return true;
    } catch (e) {
        console.warn("localStorage 접근 불가 (Google Search 설정):", e);
        return false;
    }
}

// 1-3. [Phase F10] 무료 스톡 이미지(Pixabay) API 설정 저장
function updatePixabaySetting(newKey) {
    if (newKey !== undefined) {
        pixabayApiKey = newKey.trim();
        try {
            localStorage.setItem('pixabay_api_key', pixabayApiKey);
            return true;
        } catch (e) {
            console.warn("localStorage 접근 불가 (Pixabay API Key 저장):", e);
        }
    }
    return false;
}

// 2. 프롬프트 생성용 핵심 컨텍스트 (페르소나 및 룰셋)
const CONTEXT_CORE = {
    personas: {
        orchestrator: "당신은 [AntiGravity Curriculum Orchestrator]입니다. 게임 기획 교육과정 전문 설계자입니다.",
        instructor: "당신은 게임 기획 전문 강사입니다.",
        assistant: "당신은 교안 작성 및 수정 보조 AI입니다."
    },
    rules: {
        json_only: "응답은 반드시 순수한 JSON Array여야 하며 마크다운 코드블록을 포함하지 마십시오. 형식: [{\"id\": 1, \"title\": \"차시명\", \"description\": \"목표\", \"hours\": 4}]",
        blueprint_scope: "5~10개의 모듈로 구성하세요.",
        markdown_structure: "교안 구조를 다음 위계로 반드시 구성하세요: " +
            "1. [개요(Overview)] — 차시 주제 소개, 교육 목적 제시, 흥미 유도 도입부. " +
            "2. [학습 목표(Objectives)] — 이 수업으로 얻을 지식과 역량을 불릿으로 명시. " +
            "3. [핵심 내용(Detailed Content)] — 반드시 다음 하위 흐름을 따를 것: " +
            "(a) 개념 정의(Concepts) → (b) 이론 설명 → (c) 구체적 예시 → (d) 사례 분석. " +
            "각 하위 항목은 ### ■ 레벨 이하 헤딩으로 분리하세요. " +
            "4. [실습/예제(Practice)] — 학생이 자력으로 수행하는 과제. " +
            "각 실습 항목에는 [예상 소요시간], [난이도(초급/중급/고급)], [평가 기준]을 명시하세요. " +
            "5. [심화(Advanced)] — 고성취자를 위한 참고자료, 도전 과제, 추가 팁(TMI/Info 박스).",
        image_tags: "이미지 태그 <!-- [IMG: \"영어 키워드\"] -->를 다음 위치에 반드시 삽입하세요: " +
            "①차시 최상단 — 학습 분위기를 설정하는 대표 이미지. " +
            "②제목 수준 2(##) 마다 — 해당 ## 제목 바로 아래에 섹션 대표 이미지 삽입. " +
            "③절차/프로세스 설명 시 — **다이어그램**으로 출력(mermaid 또는 구조도). " +
            "④교안 내용에 '예시'가 있을 경우 — 해당 단락 제목 바로 아래에 예시 관련 이미지 삽입. " +
            "절대 마크다운 이미지 텍스트(![alt](url))나 html <img src=\"local:...\"> 구문을 직접 출력하지 마세요. " +
            "오직 <!-- [IMG: \"영어 키워드\"] --> 형태의 주석 태그만 허용됩니다. 각 태그 전후에 빈 줄을 반드시 삽입하세요.",
        quiz_format: "정답과 해설을 포함한 4지선다형 객관식 퀴즈 3문제를 만들어주세요. 마크다운 형식으로 출력하세요.",
        concise_edit: "수정된 텍스트만 출력하세요. 부가 설명은 절대 생략합니다.",

        // ── Phase 0: 우선 규칙 + 요소 정의 (formattingrules.md §0~1) ──

        priority_rules: "규칙과 예시가 충돌할 경우, 반드시 이 규칙 문서를 우선하세요. 예시는 톤·스타일 참조용일 뿐입니다. " +
            "요소 관계 식별: 시각적 근접성이 아니라, 각 요소의 정확한 유형(헤딩/본문/블록)을 먼저 판별한 뒤 해당 규칙을 적용하세요. " +
            "예시: 헤딩 아래 이미지 → 텍스트 배치는 '헤딩→본문'이 아니라 '헤딩→블록' + '블록→본문' 두 관계입니다.",

        element_definitions: "[서사 요소] 헤딩(#~): 계층 제목, 본문(Body): 일반 텍스트·리스트(-), 핵심개념(Key Concept): **볼드 헤딩** + 들여쓰기 설명. " +
            "[블록 요소] 이미지(<p align='center'><img>), 코드블록(```), HTML 표(<table>), 인용(>). 블록은 '콘텐츠'로 취급하며 간격 규칙에서 별도 처리. " +
            "[간격 존] [Enter + <br> + Enter] 조합의 물리적 빈 공간. " +
            "[단락] 특정 헤딩(L1~L4) 시작부터 다음 헤딩 직전 간격 존까지의 논리 묶음.",

        // ── Phase 1: 기반 규칙 (handoff_to_antigravity.md §Phase 1) ──

        tone: "헤딩(#, ##, ### 등): 체언종결 또는 명사종결(~음, ~함). 본문: 합쇼체(~합니다, ~입니다). 초보자 수준으로 쉽게 설명하되, 전문 용어는 유지하고 괄호 안에 풀어쓴 정의를 병기하세요.",

        heading_hierarchy: "헤딩 위계를 반드시 준수하세요: Level 1 = '# 📝 [차시 주제]', Level 2 = '## [핵심 섹션]', Level 3 = '### ■ [하위 항목]', Level 4 = '####   ▣ [세부 항목]'. 각 레벨에 지정된 접두 기호(📝, ■, ▣)를 반드시 사용하세요.",

        semantic_icons: "본문 내 핵심 키워드 앞에 시맨틱 아이콘을 삽입하세요: 💡 = 중요 개념/핵심 포인트, ✅ = 학습 체크리스트/확인 사항, 🎮 = 실무·현장 사례/게임 예시, ⚠️ = 주의사항/흔한 실수, ⚙️ = 실습 가이드/따라하기 단계. 아이콘은 해당 문단 또는 불릿의 첫머리에 배치합니다.",

        indentation: "Level 4(####) 이상 헤딩 아래의 접두사가 없는 일반 줄글(텍스트 블록) 첫머리에는 들여쓰기를 위해 명시적으로 '&nbsp;&nbsp;' 문자열을 출력하세요. 주의: 실제 유니코드 특수 공백(U+00A0 등)을 출력하지 말고 문자열 형태를 유지해야 합니다. 단, 일반 줄글 형태 자체를 지양하고 최대한 마크다운 문법(불릿 등)을 활용해 구조화하세요.",

        body_lists: "⚠️ [최우선 강제] 모든 병렬 나열·설명·목록은 반드시 '-' 불릿으로 작성하세요. 줄글(산문) 형태의 병렬 나열은 절대 금지합니다. " +
            "본문 리스트 들여쓰기 규칙: Depth 1(-) = 기본 설명, Depth 2(  -) = 하위 항목 상세, Depth 3(    -) = 추가 세부. 리스트 기호(-) 앞에는 무조건 일반 스페이스바 2칸 들여쓰기만 사용하세요. 마크다운 렌더링이 깨지는 1순위 원인이므로 리스트 구조 앞이나 중간에는 절대 '&nbsp;' 문자열이나 특수 공백을 사용하지 마십시오.",

        numbering_usage: "숫자 넘버링(1. 2. 3. 등)은 '순서를 설명해야 할 때(절차/단계)'와 '중요 개념 몇 가지를 설명할 때(예: ~의 3요소)' 이외에는 절대 쓰지 마세요. 그 외의 모든 병렬적 나열이나 일반 설명에는 반드시 일반 불릿 기호(-)를 사용하세요. " +
            "❌ 잘못된 예(절대 금지): '1. 수익화 모델 개요 2. IAP 분석 3. 광고 모델' → 순서 없는 병렬 나열이므로 넘버링 금지. " +
            "✅ 올바른 예: '- 수익화 모델 개요  - IAP 분석  - 광고 모델'",

        text_emphasis: "텍스트 강조 2종: Bold(**...**) = 개념·키워드 강조, Inline Code(`...`) = 파일명·단축키·코드 스니펫. 두 가지를 일관되게 사용하세요.",

        // ── Phase 3: 이미지 태그 전략 + 에비던스 + HTML 표 ──

        evidence_based: "모든 설명에는 초보자도 이해하기 쉽도록 구체적인 상황을 가장 먼저 제시하세요. '정의 → 이론 설명 → 구체적 예시 → [실무적 팁/해결책/행동 지침]' 흐름을 반드시 지키세요.",

        real_world_references: "교안 본문 작성 시 추상적인 설명에 그치지 말고, 아래 패턴들을 적극 활용하세요.\n" +
            "1. **실무적 행동 패턴 (✅)**: 지표나 수치, 개념에 대해 결과만 말하지 말고 '이 수치가 높으면 ~하므로 기획자는 ~해야 한다' 식의 구체적 액션 아이템을 제안하세요.\n" +
            "2. **조합 분석 예시 표기 (✅ 실무적 조합 예시)**: 두 가지 이상 개념이 있을 경우 표로 묶어서 그 둘의 연관성을 비교 분석하는 파트를 따로 마련하세요.\n" +
            "3. **추가 참고 팁 (💬 TMI/Info)**: 실무 현장에서 자주 오해하거나 간과하는 사항은 별도 정보성 문장으로 분리하세요.",

        table_html_style: "교안 내 표를 생성할 때는 반드시 인라인 스타일 HTML Table을 사용하세요(마크다운 표 사용 금지). " +
            "[기본 구조] <table style=\"border-collapse: collapse; width: 100%;\">. 모든 th, td에 border: 1px solid black; padding: 10px; 내열 적용. th에 background-color: #f2f2f2; text-align: center; padding: 10px; 적용. " +
            "[칼럼 너비 전략] Case A — 1열이 짧은 단어·라벨(번호, 이름, 구분 등): 1열 th에 width: 120px(또는 100~200px) 고정. " +
            "Case B — 1열이 긴 문장·문장형 제목: 1열 th에 width 속성 제거, 자연 확장. " +
            "Case C — 대등 비교(A vs B): 비교 칼럼에 width 미적용, 나머지 칼럼에만 width 적용하여 균등 분배. " +
            "[텍스트 정렬] 1열 td: font-weight: bold; text-align: center;(단, 긴 문장이면 text-align: left; 허용). 나머지 열: 줄글이 길면 text-align: left;, 짧은 단답형이면 text-align: center;. " +
            "[내부 요소] 리스트(<ul>,<ol>) 사용 시 margin: 0; padding-left: 20px; line-height: 1.6; 적용. 표 내부는 마크다운을 혼용해도 됩니다.",

        // ── Phase 4: 간격(Spacing) 규칙 (formattingrules.md §3.2~3.3) ──

        spacing: "교안 작성 시 요소 간 간격을 다음 매트릭스에 따라 적용하세요: " +
            "①헤딩 내부(##~ 바로 아래 본문) → 간격 없음(0). 헤딩과 설명은 하나의 단락이므로 붙여 씁니다. " +
            "②헤딩-블록 분리(##~ 아래 이미지/표/코드) → 줄바꿈 1회([Enter]). <br> 없이 최소 간격. " +
            "③문단 분리(문단↔문단, 문단↔헤딩) → 1줄 간격([Enter + <br> + Enter]). 논리 단위 변경 시. " +
            "④요소 분리(텍스트↔블록) → 1줄 간격([Enter + <br> + Enter]). 설명과 자료 사이. " +
            "⑤블록 연속(블록↔블록) → 2줄 간격([Enter + <br><br> + Enter]). 서로 다른 자료가 연속될 때. " +
            "⑥차시 전환(→ # 📝) → 구분선 세트(<br><br> + --- + <br>). " +
            "특수 패턴(우선 적용): " +
            "(A) 샌드위치 구조: 블록(A)→텍스트(B)→블록(C) 배치 시, B 위에 <br> 1회, B 아래에 <br><br> 2회. " +
            "(B) 차시 제목 예외: # 📝 바로 아래는 별도 규칙 없으면 줄바꿈 1회. " +
            "(C) 연속 미디어 예외: 연속 이미지/영상은 [Enter]만으로 구분.",

        // ── 서식 워크플로우 (formattingrules.md §6) ──

        formatting_workflow: "교안 작성 시 다음 워크플로우를 순차 수행하세요: " +
            "Step 1(파싱): 입력 원문을 스캔하여 단락 단위로 분리하고, 각 요소를 서사(헤딩/본문) 또는 블록(이미지/표/코드/인용)으로 라벨링. " +
            "Step 2(드래프트): 남은 요소의 배치 순서를 확인. " +
            "Step 3-1(타이포 매핑): 모든 헤더를 스캔하여 ###에 ■, ####에 &nbsp;&nbsp; ▣를 강제 부착. " +
            "Step 3-2(아이콘 주입): 본문 키워드(예시, 팁, 주의 등)를 찾아 해당 줄 시작에 시맨틱 아이콘 삽입. " +
            "Step 3-3(들여쓰기 주입): #### 이상 헤딩에 &nbsp;&nbsp; 삽입, Depth 2+ 리스트·접두사 없는 텍스트에 &nbsp;&nbsp; 강제 삽입. " +
            "Step 3-4(간격 적용): spacing 매트릭스 6패턴 + 특수 패턴 3종 적용. 샌드위치 구조 발생 여부를 정밀 검사. " +
            "Step 3-5(톤 적용): 헤딩은 체언종결, 본문은 합쇼체로 최종 변환. " +
            "Step 4(출력): 위 과정을 거친 최종본만 출력.",

        // ── 용어 통일 (glossary.md §1) ──

        glossary_terms: "교안 생성 시 다음 용어를 정확히 구분하여 사용하세요: " +
            "과정(Course) = 학습의 최상위 주제 단위. " +
            "교과(Session) = 과정 내 세부 주제, 1일 수업(8시간) 기준. " +
            "차시(Lesson Plan) = 마크다운 교안, 기본학습/기본실습/심화학습/심화실습 4종. " +
            "레벨테스트(Level Test) = 별칭 '메인 퀘스트', 교과 전체의 최종 과제. " +
            "기본 실습(Basic Practice) = 별칭 '일일 퀘스트', 각 차시 끝 실습 과제."
    },

    // ── Phase 6: Few-Shot 서식 예시 (모든 경우 발췌) ──
    fewshot_cases: `[서식 예시 — 아래 형식을 참조하여 교안을 작성하세요]

■ ❌ 절대 금지 패턴 (넘버링·산문 나열):
1. 수익화 모델의 종류
2. IAP의 특징
3. 광고 모델의 단점
→ 위처럼 순서 없는 병렬 항목에 넘버링을 사용하거나, "수익화 모델에는 IAP, 광고, 구독이 있습니다." 식의 줄글 나열은 금지입니다.

■ ✅ 올바른 패턴 (불릿 나열):
- 수익화 모델의 종류
- IAP의 특징
- 광고 모델의 단점

■ 개요(Overview) 섹션 포맷:
## 개요

이 차시에서는 모바일 게임의 수익화 모델 설계 원리를 학습합니다. 수익화는 게임의 생존을 결정하는 핵심 요소이며, 잘못된 설계는 유저 이탈로 직결됩니다.

<!-- [IMG: "mobile game monetization overview"] -->

■ 학습목표(Objectives) 섹션 포맷:
## 학습 목표

- 💡 **수익화 모델 3종**(IAP·광고·구독)의 차이점을 설명할 수 있습니다.
- ✅ 각 모델의 적합한 적용 상황을 게임 장르와 연결하여 판단할 수 있습니다.
- 🎮 실제 게임 사례에서 수익화 전략을 분석하고 개선안을 제안할 수 있습니다.

■ 헤딩 위계 4단계:
# 📝 3D 씬 구성과 렌더링 기초
## 3D 오브젝트의 구성
### ■ 3D 렌더링의 핵심 3요소
#### &nbsp;&nbsp; ▣ 메쉬 (Mesh) : 기하학적 형상

■ 간격 매트릭스 6패턴:
[①헤딩 내부 — 간격 없음]
## 3D 오브젝트의 구성
- 3D 오브젝트는 세 가지 핵심 요소로 구성됩니다.

[②헤딩-블록 — 줄바꿈 1회]
## 3D 오브젝트의 구성
<p align="center">
    <img src="local:img01" alt="img01.png">
</p>

[③문단 분리 — <br> 1회]
...본문 내용...

<br>

### ■ 다음 하위 항목

[④요소 분리 — <br> 1회]
...설명 텍스트...

<br>

<p align="center">
    <img src="local:img02" alt="img02.png">
</p>

[⑤블록 연속 — <br><br> 2회]
...html 표...

<br><br>

<p align="center">
    <img src="local:img02" alt="img02.png">
</p>

[⑥차시 전환 — 구분선 세트]

<br><br>

---

<br>

# 📝 다음 차시 주제

■ 특수 패턴 3종:
[A] 샌드위치(블록→텍스트→블록):
<p align="center">
    <img src="local:img01" alt="img01.png">
</p>

<br>

- 이 이미지는 메쉬의 구조를 보여줍니다.

<br><br>

<p align="center">
    <img src="local:img02" alt="img02.png">
</p>

[B] 차시 제목 예외: # 📝 바로 아래 줄바꿈 1회

# 📝 3D 씬 구성과 렌더링 기초

<br>

...설명 텍스트...

[C] 연속 미디어: 이미지/영상 사이 [Enter]만

■ 본문 리스트 Depth 3단계:
- 게임 기획의 핵심 3요소
  - 시스템 기획: 수치, 밸런스, 규칙 설계
    - 예: 레벨 디자인, 경제 시스템
  - 콘텐츠 기획: 퀘스트, 아이템, 스토리

■ 텍스트 강조 2종:
**핵심 포인트** = 개념·키워드 강조 (Bold)
\`파일명.txt\` = 파일명·단축키·코드 (Inline Code)

■ 들여쓰기 2종:
#### &nbsp;&nbsp; ▣ L4 헤딩 (&nbsp;&nbsp;+ ▣)
일반 텍스트에도 &nbsp;&nbsp; 로 들여쓰기

■ 시맨틱 아이콘 8종:
💡 **핵심 포인트**: 중요 개념
✅ **체크**: 학습 체크리스트
☑️ **강조**: 보조 강조
ℹ️ **참고**: 추가 정보
💬 **TMI**: 부가 정보
🎮 **게임 예시**: **게임 관련** 실무 사례
⚠️ **주의**: 주의사항
⚙️ **실습**: 따라하기 가이드

■ Key Concept 포맷:
- **버텍스 (Vertex, 정점)**
    - X, Y, Z 좌표를 가진 3D 공간의 점입니다.
`
};

// 2-1. 문체 변환 프리셋 (Tone & Manner)
const TONE_PRESETS = [
    {
        id: 'academic',
        label: '📚 교과서',
        color: 'bg-blue-500/15 text-blue-400 border-blue-500/30',
        prompt: '학술적이고 정제된 교과서 문체로 변환하세요. 존댓말(~합니다, ~입니다)을 사용하고, 전문 용어는 유지하되 정의를 병기하며, 논리적이고 체계적인 서술 구조를 갖추세요. 감정적 표현이나 구어체는 배제합니다.'
    },
    {
        id: 'casual',
        label: '💬 대화형',
        color: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30',
        prompt: '친근한 대화체로 변환하세요. 강사가 학생에게 편하게 설명하듯 ~요, ~죠 같은 종결어미를 사용하고, 질문을 던지며 대화를 이어가는 느낌으로 작성하세요. 딱딱한 서술은 부드럽게 풀어주세요.'
    },
    {
        id: 'gamer',
        label: '🎮 게이머',
        color: 'bg-purple-500/15 text-purple-400 border-purple-500/30',
        prompt: '게이머/게임 개발자 문화에 익숙한 문체로 변환하세요. 게임 용어(버프, 너프, 메타, OP, 밸런스 등)를 적극 활용하고, 열정적이며 에너지 넘치는 톤으로 작성하세요. 비유도 게임 세계관에서 가져오세요.'
    },
    {
        id: 'simple',
        label: '👶 쉬운말',
        color: 'bg-amber-500/15 text-amber-400 border-amber-500/30',
        prompt: '초등학생도 이해할 수 있도록 최대한 쉬운 말로 변환하세요. 전문 용어는 일상 단어로 바꾸고, 짧은 문장 위주로 구성하며, 비유와 예시를 풍부하게 사용하세요. 핵심 개념은 누락하지 마세요.'
    },
    {
        id: 'business',
        label: '🏢 실무형',
        color: 'bg-slate-500/15 text-slate-300 border-slate-500/30',
        prompt: '실무 현업 기획서/보고서 문체로 변환하세요. 간결하고 핵심 중심으로 서술하며, 불릿 포인트와 수치 근거를 활용하세요. "~해야 한다", "~가 필요하다" 형태의 실행 지향적 어조를 사용하세요.'
    },
    {
        id: 'hype',
        label: '🔥 동기부여',
        color: 'bg-red-500/15 text-red-400 border-red-500/30',
        prompt: '학습 의욕을 극대화하는 동기부여 문체로 변환하세요. 열정적이고 긍정적인 톤을 사용하고, 독자를 "당신"으로 호칭하며, 도전의식과 성취감을 자극하는 표현을 적극 사용하세요. 문장 끝에 힘을 주세요.'
    }
];

// 2-2. 분량 조절 프리셋 (Volume Control)
const VOLUME_PRESETS = {
    shorter: {
        label: '⊖ 짧게',
        prompt: '다음 텍스트를 핵심 정의와 결론 위주로 압축하세요. 부연 설명, 반복, 예시 중 불필요한 것을 걷어내고 분량을 약 50~60% 수준으로 줄이세요. 마크다운 구조(#, ##, * 등)는 유지하되, 이미지 태그와 HTML 요소는 절대 수정하지 마세요.'
    },
    longer: {
        label: '⊕ 길게',
        prompt: '다음 텍스트의 핵심 개념은 유지하면서 분량을 약 150~170% 수준으로 늘려주세요. 구체적인 사례, 부가 설명, 실무 팁(TMI/Info 박스 형태)을 추가하세요. 마크다운 구조(#, ##, * 등)는 유지하되, 이미지 태그와 HTML 요소는 절대 수정하지 마세요.'
    }
};

// 3. 모의 데이터 (Mock Data)
const MOCK_IMAGE_B64 = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI4MDAiIGhlaWdodD0iNDAwIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjMWUxZTJlIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJzYW5zLXNlcmlmIiBmb250LXNpemU9IjI0IiBmaWxsPSIjOGE4YWI1IiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iLjNlbSI+R2FtZSBEZXNpZ24gRGlhZ3JhbSBNb2NrPC90ZXh0Pjwvc3ZnPg==";

const MOCK_CONTENT_1 = `# 1. 개요\n게임 기획(Game Design)은 플레이어에게 '재미'를 제공하기 위한 규칙과 시스템을 설계하는 과정입니다. 성공적인 게임은 철저한 기획에서 출발합니다.\n\n# 2. 학습 목표\n* 게임 기획의 핵심 정의와 역할을 설명할 수 있다.\n* 게임 디자이너가 갖춰야 할 기본 소양을 이해한다.\n\n# 3. 핵심 내용\n## 재미의 본질\n재미란 무엇일까요? 플레이어가 게임 내에서 겪는 도전과 보상의 순환 고리입니다.\n\n<div class="image-wrapper"><img src="local:img_mock_123" alt="게임 기획 다이어그램" class="rounded-lg border-2 border-accent/30 shadow-md max-w-full"><span class="absolute bottom-3 left-3 bg-black/80 text-white text-[0.6rem] px-2 py-1 rounded border border-white/20 flex items-center gap-1 pointer-events-none"><i class="ph-fill ph-sparkle text-accent"></i> AI 생성 이미지</span><button class="image-regenerate-btn px-3 py-1.5 text-xs text-white font-bold rounded flex items-center gap-1 border border-accent/50 hover:bg-accent transition-colors" onclick="promptRegenerateImage(this, '게임 기획 다이어그램', 'img_mock_123')"><i class="ph-bold ph-arrows-clockwise"></i> 다시 생성</button></div>\n\n## 기획자의 역할\n* **시스템 기획:** 수치, 밸런스, 규칙 설계\n* **콘텐츠 기획:** 퀘스트, 아이템, 스토리 설계\n* **UI/UX 기획:** 사용자 인터페이스 및 경험 설계\n\n# 4. 요약\n게임 기획은 단순한 아이디어가 아닌, 플레이어의 경험(UX)을 수학적/논리적으로 설계하는 정밀한 엔지니어링 작업입니다.\n\n---\n<!-- 메인 퀘스트가 아직 작성되지 않았습니다. -->`;

const INITIAL_MOCK_STATE = {
    courseId: "course_mock_1",
    courseTitle: "게임 기획 전문가 양성 과정",
    subjects: [
        {
            id: "subject_1",
            title: "1. 게임 기획의 기초",
            description: "게임 기획의 기본 개념과 프레임워크를 이해합니다.",
            namingConvention: '',
            lessonCount: 2,
            hasLevelTest: true,
            mainQuest: {
                id: 'mainQuest',
                title: '👑 메인 퀘스트: 기획의 본질 파악',
                description: '모든 차시의 일일 퀘스트를 종합하여 최종 기획서를 완성합니다.',
                status: 'waiting',
                content: null,
                images: {},
                teacherNotes: [],
                qualityEvaluation: null
            },
            lessons: [
                {
                    id: 101,
                    title: '1차시: 개념 이해',
                    description: '기획이란 무엇인가?',
                    status: 'done',
                    content: MOCK_CONTENT_1,
                    images: { "img_mock_123": MOCK_IMAGE_B64 },
                    teacherNotes: [],
                    qualityEvaluation: null,
                    uploadedMdName: null,
                    uploadedMdContent: null
                },
                {
                    id: 102,
                    title: '2차시: 게임의 구조',
                    description: 'MDA 프레임워크',
                    status: 'waiting',
                    content: null,
                    teacherNotes: [],
                    qualityEvaluation: null,
                    uploadedMdName: null,
                    uploadedMdContent: null
                }
            ]
        }
    ]
};
