﻿async function fetchWithRetry(url, options, retries = 5) {
    // 503 과부하 에러 등을 대비해 기본 재시도 횟수 5회 및 대기 시간 대폭 연장 (1.5s, 3s, 6s, 10s, 15s)
    const delays = [1500, 3000, 6000, 10000, 15000];

    for (let i = 0; i < retries; i++) {
        try {
            const res = await fetch(url, options);
            if (!res.ok) {
                // 400 Bad Request는 변경 없이 재요청해도 실패하므로 별도로 캐치
                if (res.status === 400) {
                    const errText = await res.text();
                    throw new Error(`HTTP error! status: 400, Bad Request: ${errText.substring(0, 150)}`);
                }
                // 401, 429, 500, 503 등은 throw하여 아래 catch 블록에서 지연 재시도를 타게 만듦
                throw new Error(`HTTP error! status: ${res.status}`);
            }
            return await res.json();
        } catch (e) {
            // 마지막 재시도까지 실패하거나 400 에러면 즉시 중단
            if (i === retries - 1 || e.message.includes('status: 400')) {
                throw e;
            }

            console.warn(`[fetchWithRetry] API 오류 또는 지연 발생. ${delays[i] / 1000}초 후 재시도합니다... (${i + 1}/${retries - 1}) | 사유: ${e.message}`);
            await new Promise(r => setTimeout(r, delays[i]));
        }
    }
}



// ------------------------------------------------------------------------
// Marked.js 커스텀 렌더러 설정 (이미지 호버 재생성 UI 주입)
// ------------------------------------------------------------------------
if (typeof marked !== 'undefined') {
    const renderer = {
        code(codeArg, infostringArg, escapedArg) {
            // marked 최신 v8.0.0+ 에서는 첫 번째 인자에 token 객체가 넘어옵니다.
            let codeText = typeof codeArg === 'object' ? codeArg.text : codeArg;
            let infostring = typeof codeArg === 'object' ? codeArg.lang : infostringArg;

            if (infostring === 'mermaid') {
                return `<div class="mermaid">\n${codeText}\n</div>`;
            }
            // mermaid가 아닌 일반 코드 블록 폴백 처리
            const lang = (infostring || '').match(/\S*/)?.[0] || '';
            let escapedCode = codeText.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
            if (!lang) {
                return `<pre><code>${escapedCode}</code></pre>\n`;
            }
            return `<pre><code class="language-${lang}">${escapedCode}</code></pre>\n`;
        },
        image(hrefArg, titleArg, textArg) {
            let href = hrefArg;
            let title = titleArg;
            let text = textArg;
            if (hrefArg && typeof hrefArg === 'object') {
                // marked 최신 버전은 token 객체를 단일 인자로 전달할 수 있음
                href = hrefArg.href || hrefArg.url || '';
                title = hrefArg.title || '';
                text = hrefArg.text || hrefArg.alt || '';
            }
            href = typeof href === 'string' ? href : '';
            title = typeof title === 'string' ? title : '';
            text = typeof text === 'string' ? text : '';
            // 원본 이미지 파싱 결과 (URL 형태)
            // 내부 base64 매핑이 붙은경우, 나중에 renderEditor() 정규식 부분에서 교체될 것이므로 여기서는 그대로 둠

            // 이미지 ID 추적 (보통 local:xxxx-xxxx 형태)
            let imgIdToPass = href;
            if (href.startsWith('local:')) {
                imgIdToPass = href.substring(6); // 'local:' 접두사 제거
            } else {
                imgIdToPass = encodeURIComponent(href); // 외부 URL인 경우
            }
            const safeHref = escapeHtmlAttr(href);
            const safeTitle = escapeHtmlAttr(title || '');
            const safeText = escapeHtmlAttr(text || '');
            const encodedImgId = encodeURIComponent(imgIdToPass || '').replace(/'/g, '%27');

            return `
                <div class="image-wrapper relative group my-6 rounded-xl overflow-hidden shadow-lg border border-accent/20 bg-black/20" data-imgid="${encodedImgId}">
                    <img src="${safeHref}" alt="${safeText}" title="${safeTitle}" class="w-full h-auto object-cover max-h-[400px] transition-transform duration-500 group-hover:scale-[1.02]">
                    <div class="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-[2px]">
                        <button data-img-id="${encodedImgId}" onclick="regenerateImage(decodeURIComponent(this.dataset.imgId || ''), this)" class="px-4 py-2 bg-accent hover:bg-accentHover text-white font-bold rounded-lg shadow-xl shadow-accent/20 flex items-center gap-2 transform translate-y-4 group-hover:translate-y-0 transition-all duration-300">
                            <i class="ph-bold ph-arrows-clockwise text-lg"></i> 이미지 재생성                        </button>
                    </div>
                </div>
            `;
        }
    };
    marked.use({ renderer });
}

// ------------------------------------------------------------------------
// AI Logic & Other Editor Functions
// ------------------------------------------------------------------------

// [Step 3] 퀴즈 생성 로직 (generateQuiz)

window.generateQuiz = async function () {

    const mod = getEditingModule();

    if (!mod || !mod.content) return window.showAlert('교안 내용이 생성되지 않았습니다.');



    const btn = document.getElementById('quiz-btn');

    const origHTML = btn.innerHTML;

    btn.innerHTML = '<i class="ph-bold ph-spinner animate-spin"></i> 생성중...';

    btn.disabled = true;



    const { systemInstruction, userPrompt } = buildTaskContext('quiz', mod.content);



    const payload = {

        contents: [{ parts: [{ text: userPrompt }] }],

        systemInstruction: { parts: [{ text: systemInstruction }] }

    };



    try {

        const data = await fetchWithRetry(

            `https://generativelanguage.googleapis.com/v1beta/models/${TEXT_MODEL}:generateContent?key=${apiKey}`,

            { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }

        );

        const quizMd = extractText(data);

        showModal('AI 생성 퀴즈', marked.parse(quizMd));

    } catch (e) {

        window.showAlert('퀴즈 생성 실패: ' + e.message);

    } finally {

        btn.innerHTML = origHTML;

        btn.disabled = false;

    }

};



// [Step 3] TTS 재생 로직 제거됨 (사용자 요청)



async function handleGenerate() {

    const topic = document.getElementById('topic-input').value.trim();

    if (!topic) return window.showAlert('교육 주제를 입력해주세요.');



    document.getElementById('sidebar-loading').style.display = 'flex';

    document.getElementById('generate-btn').disabled = true;



    const { systemInstruction, userPrompt } = buildTaskContext('blueprint', topic);



    const payload = {

        contents: [{ parts: [{ text: userPrompt }] }],

        systemInstruction: { parts: [{ text: systemInstruction }] },

        generationConfig: { responseMimeType: "application/json" }

    };



    try {

        const data = await fetchWithRetry(

            `https://generativelanguage.googleapis.com/v1beta/models/${TEXT_MODEL}:generateContent?key=${apiKey}`,

            { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }

        );



        const rawText = extractText(data);

        const parsed = safeJSONParse(rawText);



        if (!Array.isArray(parsed)) throw new Error("Invalid format received");



        courseData = parsed.map((item, idx) => ({

            id: Date.now() + idx,

            title: item.title,

            description: item.description,

            hours: item.hours || 2,

            status: 'waiting',

            content: null,

            teacherNotes: [],
            qualityEvaluation: null,

            uploadedMdName: null,

            uploadedMdContent: null

        }));

        currentTopic = topic;



        renderSidebar();

        saveState();

    } catch (err) {

        console.error(err);

        if (err.message && err.message.includes('401')) {

            window.showAlert('API 인증 오류(401)가 발생했습니다. 세션 토큰 갱신 지연일 수 있으니 10초 후 재시도하거나 새로고침(F5) 해주세요.');

        } else {

            window.showAlert('목차 생성 중 오류가 발생했습니다. 다시 시도해주세요.');

        }

    } finally {

        document.getElementById('sidebar-loading').style.display = 'none';

        document.getElementById('generate-btn').disabled = false;

    }

}



async function generateModuleContent(moduleId, keyConcepts) {

    const mod = getEditingModule(moduleId);

    if (!mod) return;

    // F1-2: 핵심개념 저장 (재생성 시 기본값으로 재활용)
    if (Array.isArray(keyConcepts) && keyConcepts.length > 0) {
        mod.keyConcepts = keyConcepts;
    }


    const subj = globalState.subjects.find(s => s.id === currentSubjectId);

    let hasMainQuest = false;

    let mainQuestText = "";

    let otherLessonsText = "";



    if (subj && subj.mainQuest && subj.mainQuest.status === 'done' && subj.mainQuest.content) {

        hasMainQuest = true;

        const cleanMqContent = cleanForAPI(subj.mainQuest.content).substring(0, 300);

        mainQuestText = `${subj.mainQuest.title}: ${subj.mainQuest.description}\n[핵심 내용 요약] ${cleanMqContent}...`;



        const otherQuests = subj.lessons

            .filter(l => String(l.id) !== String(moduleId) && l.status === 'done' && l.content)

            .map(l => {

                const match = l.content.match(/# ⚔️ 일일 퀘스트[\s\S]*/);

                const qText = match ? cleanForAPI(match[0]).substring(0, 150) : '퀘스트 없음';

                return `- [${l.title}]의 일일 퀘스트: ${qText}`;

            });

        otherLessonsText = otherQuests.join('\n');

    }



    const loadingEl = document.getElementById('editor-loading');
    const loadingText = document.getElementById('editor-loading-text');
    loadingEl.style.display = 'flex';
    loadingText.textContent = 'AI가 상세 교안을 작성하고 있습니다...';



    document.querySelectorAll('.module-card').forEach(c => c.classList.remove('border-accent', 'bg-accent/10', 'border-yellow-400', 'bg-yellow-400/10'));

    const card = document.querySelector(`.module-card[data-id="${moduleId}"]`);

    if (card) {

        if (moduleId === 'mainQuest') card.classList.add('border-yellow-400', 'bg-yellow-400/10');

        else card.classList.add('border-accent', 'bg-accent/10');

    }



    // ── F2: 분할 생성 파이프라인 ──
    const MAX_CHUNKS = 5;
    const CONTINUE_MARKER = '<!-- CONTINUE -->';
    const END_MARKER = '<!-- END -->';
    let fullContent = '';
    let chunkCount = 0;

    try {
        // ── Chunk 1: 최초 생성 ──
        const { systemInstruction, userPrompt } = buildTaskContext('module', {
            title: mod.title,
            description: mod.description,
            keyConcepts: mod.keyConcepts || [],
            hasMainQuest: hasMainQuest,
            mainQuestText: mainQuestText,
            otherLessonsText: otherLessonsText,
            uploadedMdContent: mod.uploadedMdContent
        });

        loadingText.textContent = '교안 작성 중... (1단계: 초안 생성)';

        const firstData = await fetchWithRetry(
            `https://generativelanguage.googleapis.com/v1beta/models/${TEXT_MODEL}:generateContent?key=${apiKey}`,
            {
                method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({
                    safetySettings: [
                        { category: "HARM_CATEGORY_HARASSMENT", threshold: "BLOCK_NONE" },
                        { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "BLOCK_NONE" },
                        { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_NONE" },
                        { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_NONE" }
                    ],
                    contents: [{ parts: [{ text: userPrompt }] }],
                    systemInstruction: { parts: [{ text: systemInstruction }] }
                })
            }
        );

        let chunkText = extractText(firstData);
        chunkText = chunkText.replace(/^```\w*\n?/i, '').replace(/\n?```$/i, '').trim();
        fullContent = chunkText;
        chunkCount = 1;

        // ── Chunk 2~N: 이어쓰기 루프 ──
        while (fullContent.includes(CONTINUE_MARKER) && chunkCount < MAX_CHUNKS) {
            chunkCount++;
            // CONTINUE 마커 제거
            fullContent = fullContent.replace(CONTINUE_MARKER, '').trimEnd();

            loadingText.textContent = `교안 이어쓰기 중... (${chunkCount}단계)`;

            // 이전 내용의 마지막 1500자를 컨텍스트로 전달 (토큰 절약)
            const contextTail = fullContent.length > 1500 ? fullContent.slice(-1500) : fullContent;

            const { systemInstruction: contSys, userPrompt: contPrompt } = buildTaskContext('module_continue', {
                title: mod.title,
                description: mod.description,
                keyConcepts: mod.keyConcepts || [],
                hasMainQuest: hasMainQuest,
                chunkIndex: chunkCount,
                previousContent: contextTail
            });

            // API 쿨다운
            await new Promise(r => setTimeout(r, 1500));

            const contData = await fetchWithRetry(
                `https://generativelanguage.googleapis.com/v1beta/models/${TEXT_MODEL}:generateContent?key=${apiKey}`,
                {
                    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({
                        safetySettings: [
                            { category: "HARM_CATEGORY_HARASSMENT", threshold: "BLOCK_NONE" },
                            { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "BLOCK_NONE" },
                            { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_NONE" },
                            { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_NONE" }
                        ],
                        contents: [{ parts: [{ text: contPrompt }] }],
                        systemInstruction: { parts: [{ text: contSys }] }
                    })
                }
            );

            let contText = extractText(contData);
            contText = contText.replace(/^```\w*\n?/i, '').replace(/\n?```$/i, '').trim();

            // 이어쓰기 내용 병합 (중복 헤딩 방지: 이전 마지막 헤딩과 동일하면 제거)
            const lastHeadingMatch = fullContent.match(/^(#{1,4}\s+.+)$/gm);
            if (lastHeadingMatch) {
                const lastHeading = lastHeadingMatch[lastHeadingMatch.length - 1].trim();
                const contLines = contText.split('\n');
                if (contLines[0] && contLines[0].trim() === lastHeading) {
                    contLines.shift();
                    contText = contLines.join('\n');
                }
            }

            fullContent += '\n\n' + contText;
        }

        // END 마커 정리
        fullContent = fullContent.replace(END_MARKER, '').trimEnd();
        // 잔여 CONTINUE 마커 정리 (MAX_CHUNKS 초과 시)
        fullContent = fullContent.replace(new RegExp(CONTINUE_MARKER, 'g'), '').trimEnd();

        // ── 이미지 태그 처리 ──
        loadingText.textContent = chunkCount > 1
            ? `이미지 생성 중... (${chunkCount}단계 완료)`
            : '이미지 생성 중...';

        mod.content = fullContent;
        mod.imageSearchReport = null;
        if (typeof window.invalidateModuleQualityEvaluation === 'function') {
            window.invalidateModuleQualityEvaluation(mod);
        }
        applyAutoTeacherGuides(mod, { force: true });
        mod.status = 'done';
        currentEditingModuleId = mod.id;

        await saveState();
        renderSidebar();
        renderEditor(mod);
        if (typeof window.renderFormatLintBanner === 'function') {
            window.renderFormatLintBanner(mod, { toast: true, forceToast: true });
        }

        if (chunkCount > 1) {
            window.showAlert(`✅ 교안이 ${chunkCount}단계에 걸쳐 생성되었습니다.`);
        }

        // [옵션 B] 이미지 백그라운드 처리 — 교안 텍스트를 즉시 표시한 뒤 이미지를 비동기로 확보
        if (mod.content && mod.content.includes('<!-- [IMG:')) {
            generateAllImagesInModule(mod.id);
        }

    } catch (err) {

        console.error("교안 생성 중 에러 상세 (generateModuleContent):", err, err.stack);

        if (err.message && err.message.includes('401')) {

            window.showAlert('API 인증 오류(401)가 발생했습니다. 시스템 토큰 갱신 지연일 수 있으니 10초 후 시도하거나 새로고침(F5) 해주세요.');

        } else {

            window.showAlert('교안 생성 중 오류가 발생했습니다.\n' + (err.message || ''));

        }

        // 부분 생성 복구: 일부 청크가 성공한 경우 저장
        if (fullContent && fullContent.length > 200) {
            fullContent = fullContent.replace(new RegExp(CONTINUE_MARKER, 'g'), '').replace(END_MARKER, '').trimEnd();
            mod.content = fullContent;
            mod.imageSearchReport = null;
            if (typeof window.invalidateModuleQualityEvaluation === 'function') {
                window.invalidateModuleQualityEvaluation(mod);
            }
            applyAutoTeacherGuides(mod, { force: true });
            mod.status = 'done';
            await saveState();
            renderSidebar();
            renderEditor(mod);
            if (typeof window.renderFormatLintBanner === 'function') {
                window.renderFormatLintBanner(mod, { toast: true, forceToast: true });
            }
            window.showAlert('⚠️ 중간 오류가 발생했지만 작성된 부분까지 저장했습니다.\n수동으로 나머지를 보완하거나 재생성하세요.');
        }

    } finally {

        loadingEl.style.display = 'none';
        loadingText.textContent = 'AI가 상세 교안을 작성하고 있습니다...';

    }

}

// ── F1-2: 핵심개념 팝업을 거쳐 교안 생성하는 래퍼 ──
window.promptAndGenerateModule = function (moduleId) {
    const mod = getEditingModule(moduleId);
    if (!mod) return;
    const existing = Array.isArray(mod.keyConcepts) ? mod.keyConcepts : [];
    const label = mod.status === 'done' ? `재생성: ${mod.title}` : `교안 생성: ${mod.title}`;
    showKeyConceptsPrompt(label, existing, (concepts) => {
        generateModuleContent(moduleId, concepts);
    });
};

// ── F1-2: 메인퀘스트도 핵심개념 팝업 래퍼 ──
window.promptAndGenerateMainQuest = function () {
    const subj = globalState.subjects.find(s => s.id === currentSubjectId);
    if (!subj) return;
    const mq = subj.mainQuest;
    const existing = Array.isArray(mq?.keyConcepts) ? mq.keyConcepts : [];
    showKeyConceptsPrompt('메인 퀘스트 생성', existing, (concepts) => {
        if (concepts.length > 0 && mq) mq.keyConcepts = concepts;
        generateMainQuest();
    });
};



async function generateMainQuest() {

    const subj = globalState.subjects.find(s => s.id === currentSubjectId);

    if (!subj) return;

    const mq = subj.mainQuest;



    document.getElementById('editor-loading').style.display = 'flex';



    document.querySelectorAll('.module-card').forEach(c => c.classList.remove('border-accent', 'bg-accent/10', 'border-yellow-400', 'bg-yellow-400/10'));

    const card = document.querySelector(`.module-card[data-id="mainQuest"]`);

    if (card) card.classList.add('border-yellow-400', 'bg-yellow-400/10');



    let contextStr = subj.lessons
        .map(l => `- ${l.title}: ${l.description}\n  summary: ${l.content ? cleanForAPI(l.content).substring(0, 150) + '...' : 'N/A'}`)
        .join('\n\n');



    const { systemInstruction, userPrompt } = buildTaskContext('main_quest', contextStr);



    const payload = {
        safetySettings: [
            { category: "HARM_CATEGORY_HARASSMENT", threshold: "BLOCK_NONE" },
            { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "BLOCK_NONE" },
            { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_NONE" },
            { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_NONE" }
        ],
        contents: [{ parts: [{ text: userPrompt }] }],
        systemInstruction: { parts: [{ text: systemInstruction }] }
    };



    try {

        const data = await fetchWithRetry(

            `https://generativelanguage.googleapis.com/v1beta/models/${TEXT_MODEL}:generateContent?key=${apiKey}`,

            { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }

        );



        let markdownContent = extractText(data);

        mq.content = markdownContent;
        mq.imageSearchReport = null;
        if (typeof window.invalidateModuleQualityEvaluation === 'function') {
            window.invalidateModuleQualityEvaluation(mq);
        }
        applyAutoTeacherGuides(mq, { force: true });

        mq.status = 'done';

        currentEditingModuleId = 'mainQuest';



        await saveState();

        renderSidebar();

        renderEditor(mq);
        if (typeof window.renderFormatLintBanner === 'function') {
            window.renderFormatLintBanner(mq, { toast: true, forceToast: true });
        }

        // [옵션 B] 메인 퀘스트 이미지 백그라운드 처리
        if (mq.content && mq.content.includes('<!-- [IMG:')) {
            (async () => {
                try {
                    const newContent = await processImageTags(mq, mq.content);
                    mq.content = newContent;
                    if (typeof window.invalidateModuleQualityEvaluation === 'function') {
                        window.invalidateModuleQualityEvaluation(mq);
                    }
                    await saveState();
                    // 현재 메인 퀘스트를 보고 있는 경우에만 리렌더링
                    if (currentEditingModuleId === 'mainQuest') renderEditor(mq);
                } catch (e) {
                    console.warn('[BG Image] 메인 퀘스트 이미지 백그라운드 처리 실패:', e);
                }
            })();
        }

    } catch (err) {

        console.error(err);

        if (err.message && err.message.includes('401')) {

            window.showAlert('API 인증 오류(401)가 발생했습니다. 세션 토큰 갱신 지연일 수 있으니 10초 후 재시도하거나 새로고침(F5) 해주세요.');

        } else {

            window.showAlert('메인 퀘스트 생성 중 오류가 발생했습니다.');

        }

    } finally {

        document.getElementById('editor-loading').style.display = 'none';

    }

}

// --- Phase F10: Deep Research 검색 에이전트 서브루틴 ---

function getContextWindow(text, matchStr, windowSize = 300) {
    const idx = text.indexOf(matchStr);
    if (idx === -1) return "";
    const start = Math.max(0, idx - windowSize);
    const end = Math.min(text.length, idx + matchStr.length + windowSize);
    return text.substring(start, end).replace(/<!--.*?-->/g, '').replace(/[#*`_>]/g, '').trim();
}

async function extractSearchIntent(keyword, context) {
    const systemPrompt = `당신은 게임 기획 및 시장 분석 전문 리서처 AI입니다.
주어진 이미지 키워드의 주변 교안 문맥을 분석하여, 해당 맥락에 가장 적합한 시각 자료를 검색하기 위한 "최적의 검색 쿼리"를 생성하세요.

[중요 지시사항]
1. 텍스트 내 고유명사(게임명, 캐릭터명, 시스템명, 회사명 등)를 추출해 쿼리의 핵심으로 배치하세요.
2. 이미지 종류(일러스트, 게임 스크린샷, UI 목업, 매출 그래프 등)를 반영해 영문 Modifier를 추가하세요. (예: "official art", "gameplay UI", "revenue chart")
3. 검색 품질을 위해 쿼리는 가급적 영문 중심으로 구성하세요.
4. 불필요한 결과 배제를 위해 부정 키워드를 포함하세요. (예: "-fanart -cosplay -reddit")
5. 출력은 반드시 아래 JSON 스키마를 따르세요.

[출력 형식 JSON]
{
  "intent_type": "data_representation (데이터/표/차트인 경우) 또는 visual_asset (일러스트/UI/스크린샷인 경우)",
  "search_query": "최적화된 영문 검색어 (예: Genshin Impact global revenue chart 2023 -fanart)",
  "reasoning": "이 검색어로 결정한 이유 (한국어 짧게)"
}`;

    const userPrompt = `[문맥 추출 대상]\n키워드: ${keyword}\n\n[주변 문맥]\n${context}`;

    const payload = {
        contents: [{ role: "user", parts: [{ text: userPrompt }] }],
        systemInstruction: { parts: [{ text: systemPrompt }] },
        generationConfig: {
            temperature: 0.1, // 일관된 JSON 추출을 위해 낮은 온도값
            responseMimeType: "application/json"
        }
    };

    try {
        const response = await fetchWithRetry(
            `https://generativelanguage.googleapis.com/v1beta/models/${TEXT_MODEL}:generateContent?key=${apiKey}`,
            { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }
        );
        const textResp = extractText(response);
        return JSON.parse(textResp);
    } catch (e) {
        console.error("검색어 의도 추출 에이전트 실패:", e);
        return null; // 실패 시 기존 키워드 Fallback을 위해 Null 반환
    }
}
// [Phase F10] Convert remote image URL to base64 with direct-first strategy.
const IMAGE_BASE64_MAX_WIDTH = 800;
const IMAGE_BASE64_TIMEOUT_MS = 12000;
const IMAGE_FETCH_PROXY_BUILDERS = [
    { label: 'allorigins', build: (url) => `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}` },
    { label: 'weserv', build: (url) => `https://images.weserv.nl/?url=${encodeURIComponent(url.replace(/^https?:\/\//i, ''))}&output=jpg&q=85` },
    { label: 'corsproxy', build: (url) => `https://corsproxy.io/?${encodeURIComponent(url)}` }
];

function normalizeImageSourceUrl(imageUrl) {
    const raw = String(imageUrl || '').trim();
    if (!raw) return '';
    if (/^data:image\//i.test(raw)) return raw;
    if (raw.startsWith('//')) return `https:${raw}`;
    return raw;
}

function loadImageToDataURLViaCanvas(src, { timeoutMs = IMAGE_BASE64_TIMEOUT_MS, maxWidth = IMAGE_BASE64_MAX_WIDTH } = {}) {
    return new Promise((resolve, reject) => {
        const img = new Image();
        let settled = false;

        const clear = () => {
            if (timer) clearTimeout(timer);
            img.onload = null;
            img.onerror = null;
        };
        const fail = (err) => {
            if (settled) return;
            settled = true;
            clear();
            reject(err instanceof Error ? err : new Error(String(err || 'Image load failed')));
        };
        const succeed = (value) => {
            if (settled) return;
            settled = true;
            clear();
            resolve(value);
        };

        const timer = setTimeout(() => fail(new Error('Image load timeout')), Math.max(1000, timeoutMs));

        img.onload = () => {
            try {
                let width = Number(img.width || 0);
                let height = Number(img.height || 0);
                if (width <= 0 || height <= 0) throw new Error('Invalid image size');

                if (width > maxWidth) {
                    height = Math.round((height * maxWidth) / width);
                    width = maxWidth;
                }

                const canvas = document.createElement('canvas');
                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                if (!ctx) throw new Error('Canvas context unavailable');

                ctx.drawImage(img, 0, 0, width, height);
                const dataURL = canvas.toDataURL('image/jpeg', 0.85);
                if (!dataURL || !dataURL.startsWith('data:image/')) {
                    throw new Error('Canvas encode failed');
                }
                succeed(dataURL);
            } catch (err) {
                fail(err);
            }
        };
        img.onerror = () => fail(new Error('Image load failed'));

        if (/^https?:\/\//i.test(src)) {
            img.crossOrigin = 'anonymous';
            img.referrerPolicy = 'no-referrer';
        }
        img.src = src;
    });
}

async function fetchImageToBlob(fetchUrl, timeoutMs = IMAGE_BASE64_TIMEOUT_MS) {
    const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
    const timer = setTimeout(() => {
        if (controller) controller.abort();
    }, Math.max(1000, timeoutMs));

    try {
        const res = await fetch(fetchUrl, {
            method: 'GET',
            mode: 'cors',
            cache: 'no-store',
            signal: controller ? controller.signal : undefined
        });

        if (!res.ok) {
            throw new Error(`HTTP ${res.status}`);
        }

        const blob = await res.blob();
        if (!blob || blob.size <= 0) {
            throw new Error('Empty image blob');
        }
        const type = String(blob.type || '').toLowerCase();
        if (type && !type.startsWith('image/')) {
            throw new Error(`Non-image response: ${type}`);
        }
        return blob;
    } finally {
        clearTimeout(timer);
    }
}

async function loadImageToDataURLViaFetch(fetchUrl, opts = {}) {
    const blob = await fetchImageToBlob(fetchUrl, opts.timeoutMs || IMAGE_BASE64_TIMEOUT_MS);
    const objectUrl = URL.createObjectURL(blob);
    try {
        return await loadImageToDataURLViaCanvas(objectUrl, opts);
    } finally {
        URL.revokeObjectURL(objectUrl);
    }
}

async function fetchImageAsBase64(imageUrl) {
    const normalized = normalizeImageSourceUrl(imageUrl);
    if (!normalized) throw new Error('Empty image URL');
    if (/^data:image\//i.test(normalized)) return normalized;

    const candidates = [{ label: 'direct', url: normalized }];
    IMAGE_FETCH_PROXY_BUILDERS.forEach(proxy => {
        try {
            candidates.push({ label: proxy.label, url: proxy.build(normalized) });
        } catch (e) {
            console.warn(`[Image Convert] proxy URL build failed (${proxy.label}):`, e);
        }
    });

    const errors = [];
    for (const candidate of candidates) {
        try {
            const b64 = await loadImageToDataURLViaCanvas(candidate.url);
            console.log(`[Image Convert] success via ${candidate.label} (canvas)`);
            return b64;
        } catch (canvasErr) {
            errors.push(`${candidate.label}/canvas: ${canvasErr?.message || canvasErr}`);
        }

        try {
            const b64 = await loadImageToDataURLViaFetch(candidate.url);
            console.log(`[Image Convert] success via ${candidate.label} (fetch)`);
            return b64;
        } catch (fetchErr) {
            errors.push(`${candidate.label}/fetch: ${fetchErr?.message || fetchErr}`);
        }
    }

    const reason = errors.slice(0, 8).join(' | ') || 'unknown';
    throw new Error(`Image conversion failed: ${reason}`);
}

// [Phase F10] VLM(Vision-Language Model) 기반 웹 검색 이미지 유효성 검열
async function validateImageWithVLM(base64Image, searchIntent, context) {
    if (!base64Image) return { isValid: false, reason: "이미지 데이터 없음" };

    // "data:image/jpeg;base64,..."에서 데이터 부분만 추출
    const base64Data = base64Image.replace(/^data:image\/(png|jpeg|webp);base64,/, "");
    const mimeType = base64Image.match(/^data:(image\/[^;]+);/)[1] || "image/jpeg";

    const systemPrompt = `당신은 게임/IT 교육 자료 이미지 검수 전문가입니다.
수집된 이미지가 교안 문맥(Context)과 검색 의도(Intent)에 부합하는지 평가하세요.
다음 조건 중 하나라도 해당하면 "isValid": false 로 판단하세요:
1. 워터마크, 과도한 텍스트 합성, 조작/밈(Meme) 요소가 두드러지는 경우
2. 필요한 정보 객체(예: 매출 그래프)를 찾기 어렵거나 핵심 텍스트를 판독하기 어려운 경우
3. 실제 게임 스크린샷/일러스트가 아닌 코스프레, 과도한 모드(Mod) 합성 이미지인 경우
4. 선정성 또는 폭력성이 교육 목적에 부적합한 경우

[출력 형식 JSON]
{
  "isValid": true (적합) 또는 false (부적합),
  "reason": "평가 사유 (한국어 짧게)",
  "confidence": 0.0 ~ 1.0
}`;

    const userPrompt = `[수집된 의도 및 문맥]\n검색 쿼리/의도: ${JSON.stringify(searchIntent)}\n주변 문맥:\n${context}\n\n첨부된 이미지가 위 문맥에 비추어 교육 자료로 적합한지 평가하십시오.`;

    const payload = {
        contents: [
            {
                role: "user",
                parts: [
                    { text: userPrompt },
                    { inlineData: { mimeType: mimeType, data: base64Data } }
                ]
            }
        ],
        systemInstruction: { parts: [{ text: systemPrompt }] },
        generationConfig: {
            temperature: 0.1,
            responseMimeType: "application/json"
        }
    };

    try {
        console.log(`[VLM Validator] 이미지 검열 시작...`);
        // 이미지 검열용 모델은 안전장치가 강한 모델 사용 권장. 설정된 모델(TEXT_MODEL) 재활용
        const response = await fetchWithRetry(
            `https://generativelanguage.googleapis.com/v1beta/models/${TEXT_MODEL}:generateContent?key=${apiKey}`,
            { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }
        );
        const textResp = extractText(response);
        const result = JSON.parse(textResp);
        console.log(`[VLM Validator] 검열 결과:`, result);
        return result;
    } catch (e) {
        console.error("[VLM Validator] 에러 발생 (기본 통과 처리):", e);
        // 검열기 자체 오류면 차단보단 일단 통과시켜 흐름 유지 (False Positive 방어)
        return { isValid: true, reason: "VLM 통신 에러로 자동 패스", confidence: 0 };
    }
}

// [Phase F10] 구글 Custom Search (Key 롤링 방어 적용)
async function searchImageAPI(query) {
    if (!googleSearchCx || !googleSearchApiKeys || googleSearchApiKeys.length === 0) {
        return null; // 설정 안되어있으면 즉시 폴백
    }

    const maxRetries = googleSearchApiKeys.length;
    let attempt = 0;

    while (attempt < maxRetries) {
        const currentKey = googleSearchApiKeys[currentSearchKeyIndex];
        const endpoint = `https://www.googleapis.com/customsearch/v1?q=${encodeURIComponent(query)}&searchType=image&num=1&cx=${encodeURIComponent(googleSearchCx)}&key=${encodeURIComponent(currentKey)}`;

        try {
            const res = await fetch(endpoint);
            if (res.status === 429) {
                // 할당량 초과 -> 다음 키로 롤링 (Rotate)
                console.warn(`[Search API] Key 인덱스 ${currentSearchKeyIndex} 할당량 초과(429). 다음 Key로 롤링합니다.`);
                if (window.showToast) window.showToast(`API 키 할당량 초과! 다음 키로 전환합니다.`, 'warning');

                currentSearchKeyIndex = (currentSearchKeyIndex + 1) % googleSearchApiKeys.length;
                attempt++;
                continue; // 재시도
            }
            if (!res.ok) {
                console.error(`[Search API] HTTP Error: ${res.status}`);
                break; // 다른 에러는 롤백
            }

            const data = await res.json();
            if (data.items && data.items.length > 0) {
                const imgUrl = data.items[0].link;
                // Base64로 가져오기
                console.log(`[Search API] 이미지 찾음: ${imgUrl}`);
                const b64 = await fetchImageAsBase64(imgUrl);
                return { b64, source: imgUrl, vendor: "Google" };
            } else {
                return null; // 검색 결과 없음 -> 롤백
            }
        } catch (e) {
            console.error("[Search API] 네트워크/파싱 에러:", e);
            break; // 예기치 못한 에러 시 폴백
        }
    }

    // 키를 다 소모했거나 검색 실패 시
    if (attempt === maxRetries) {
        console.warn(`[Search API] 등록된 ${maxRetries}개의 Key를 모두 소진했습니다.`);
        if (window.showToast) window.showToast(`등록된 검색 API 키의 일일 한도가 모두 소진되었습니다. AI 이미지 생성으로 자동 전환합니다.`, 'error');
    }
    return null;
}

// [Phase F10] 무료 스톡 이미지 (Pixabay) API 연동 (Fallback)
async function searchPixabayAPI(query) {
    if (!pixabayApiKey) {
        return null; // 설정되어있지 않으면 스킵
    }

    try {
        console.log(`[Pixabay API] 대체 스톡 이미지 검색 시도: ${query}`);
        // pixabay는 기본 영어 검색, 사진(photo) 우선
        const endpoint = `https://pixabay.com/api/?key=${encodeURIComponent(pixabayApiKey)}&q=${encodeURIComponent(query)}&image_type=photo&per_page=3&safesearch=true`;

        const res = await fetch(endpoint);
        if (!res.ok) {
            console.error(`[Pixabay API] HTTP 에러: ${res.status}`);
            return null;
        }

        const data = await res.json();
        if (data.hits && data.hits.length > 0) {
            // 가장 첫번째 결과의 webformatURL 혹은 largeImageURL 사용
            const imgUrl = data.hits[0].webformatURL || data.hits[0].largeImageURL;
            console.log(`[Pixabay API] 스톡 이미지 찾음: ${imgUrl}`);

            // Convert image URL to base64 (direct first, proxy fallback)
            const b64 = await fetchImageAsBase64(imgUrl);
            return { b64, source: imgUrl, vendor: "Pixabay" };
        } else {
            console.log(`[Pixabay API] 결과 없음.`);
            return null;
        }
    } catch (e) {
        console.error("[Pixabay API] 통신 에러:", e);
        return null; // 오류나면 fallback 체인 계속 진행
    }
}
// --------------------------------------------------------


function getVendorIcon(vendorLabel = '') {
    if (vendorLabel.includes('Google') || vendorLabel.includes('검색 이미지') || vendorLabel.includes('web search')) return 'ph-google-logo';
    if (vendorLabel.includes('Pixabay') || vendorLabel.includes('스톡 이미지') || vendorLabel.includes('stock')) return 'ph-camera';
    if (vendorLabel.includes('캐시 이미지') || vendorLabel.includes('cache')) return 'ph-images';
    return 'ph-sparkle';
}

function escapeHtmlAttr(value = '') {
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/"/g, '&quot;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/'/g, '&#39;');
}

function getImageSearchProviderStatus() {
    const hasGoogleCx = typeof googleSearchCx === 'string' && googleSearchCx.trim().length > 0;
    const validGoogleKeys = Array.isArray(googleSearchApiKeys)
        ? googleSearchApiKeys.map(k => String(k || '').trim()).filter(Boolean)
        : [];
    const hasGoogleKeys = validGoogleKeys.length > 0;
    const hasGoogle = hasGoogleCx && hasGoogleKeys;
    const hasPixabay = typeof pixabayApiKey === 'string' && pixabayApiKey.trim().length > 0;
    return {
        hasGoogleCx,
        hasGoogleKeys,
        hasGoogle,
        hasPixabay,
        hasAny: hasGoogle || hasPixabay
    };
}

const formatLintToastCache = new Map();
const statusBannerFoldState = new Map();

function getStatusBannerFoldState(foldKey, defaultCollapsed = true) {
    const key = String(foldKey || '');
    if (!statusBannerFoldState.has(key)) {
        statusBannerFoldState.set(key, !!defaultCollapsed);
    }
    return !!statusBannerFoldState.get(key);
}

function buildFoldableBannerHTML({
    foldKey = '',
    icon = 'ph-info',
    title = '',
    detailHtml = '',
    defaultCollapsed = true,
    headerActionHtml = ''
} = {}) {
    const collapsed = getStatusBannerFoldState(foldKey, defaultCollapsed);
    const toggleLabel = collapsed ? '펼치기' : '접기';
    const caretClass = collapsed ? 'ph-caret-down' : 'ph-caret-up';
    const detailClass = collapsed ? 'hidden' : '';
    const actionHtml = headerActionHtml ? `<div class="shrink-0">${headerActionHtml}</div>` : '';

    return `
        <div data-foldable-banner="1" class="flex items-start gap-2">
            <i class="ph-fill ${icon} text-sm mt-[1px]"></i>
            <div class="min-w-0 flex-1">
                <div class="flex items-center justify-between gap-2">
                    <div class="font-bold">${title}</div>
                    <div class="flex items-center gap-1.5">
                        ${actionHtml}
                        <button type="button"
                            data-fold-key="${escapeHtmlAttr(foldKey)}"
                            onclick="toggleStatusBannerFold(this.dataset.foldKey, this)"
                            class="inline-flex items-center gap-1 px-1.5 py-0.5 rounded border border-current/20 hover:bg-black/5 transition-colors text-[0.65rem] font-semibold"
                            aria-expanded="${collapsed ? 'false' : 'true'}">
                            <span data-banner-toggle-label>${toggleLabel}</span>
                            <i data-banner-caret class="ph-bold ${caretClass} text-[0.7rem]"></i>
                        </button>
                    </div>
                </div>
                <div data-banner-detail class="mt-1 opacity-90 ${detailClass}">
                    ${detailHtml}
                </div>
            </div>
        </div>
    `;
}

window.toggleStatusBannerFold = function (foldKey, btnEl) {
    const wrapper = btnEl && typeof btnEl.closest === 'function'
        ? btnEl.closest('[data-foldable-banner]')
        : null;
    if (!wrapper) return;

    const detail = wrapper.querySelector('[data-banner-detail]');
    const label = wrapper.querySelector('[data-banner-toggle-label]');
    const caret = wrapper.querySelector('[data-banner-caret]');
    if (!detail) return;

    const willCollapse = !detail.classList.contains('hidden');
    detail.classList.toggle('hidden', willCollapse);
    statusBannerFoldState.set(String(foldKey || ''), willCollapse);

    if (label) label.textContent = willCollapse ? '펼치기' : '접기';
    if (caret) {
        caret.classList.toggle('ph-caret-down', willCollapse);
        caret.classList.toggle('ph-caret-up', !willCollapse);
    }
    if (btnEl) btnEl.setAttribute('aria-expanded', String(!willCollapse));
};

const lessonInfoPanelExpandedState = new Map();

function getLessonInfoPanelExpandedState(panelKey, defaultExpanded = false) {
    const key = String(panelKey || '');
    if (!lessonInfoPanelExpandedState.has(key)) {
        lessonInfoPanelExpandedState.set(key, !!defaultExpanded);
    }
    return !!lessonInfoPanelExpandedState.get(key);
}

function applyLessonInfoPanelState(panelKey, panelEl) {
    if (!panelEl) return;
    const body = panelEl.querySelector('#lesson-info-body');
    const toggleBtn = panelEl.querySelector('#lesson-info-toggle-btn');
    if (!body || !toggleBtn) return;

    const expanded = getLessonInfoPanelExpandedState(panelKey, false);
    body.classList.toggle('hidden', !expanded);

    const labelEl = toggleBtn.querySelector('[data-lesson-info-toggle-label]');
    const caretEl = toggleBtn.querySelector('[data-lesson-info-toggle-caret]');
    if (labelEl) labelEl.textContent = expanded ? '접기' : '펼치기';
    if (caretEl) {
        caretEl.classList.toggle('ph-caret-up', expanded);
        caretEl.classList.toggle('ph-caret-down', !expanded);
    }
    toggleBtn.setAttribute('aria-expanded', String(expanded));
}

window.toggleLessonInfoPanel = function (panelKey, btnEl) {
    const key = String(panelKey || '');
    const nextExpanded = !getLessonInfoPanelExpandedState(key, false);
    lessonInfoPanelExpandedState.set(key, nextExpanded);
    const panelEl = btnEl && typeof btnEl.closest === 'function'
        ? btnEl.closest('#lesson-info-panel')
        : document.getElementById('lesson-info-panel');
    applyLessonInfoPanelState(key, panelEl);
};

window.syncLessonInfoPanelState = function (panelKey) {
    applyLessonInfoPanelState(String(panelKey || ''), document.getElementById('lesson-info-panel'));
};

window.renderLessonInfoSummary = function (mod, status = {}) {
    const summaryEl = document.getElementById('lesson-info-summary');
    if (!summaryEl || !mod) return;

    const chips = [];

    if (status.formatReport) {
        const report = status.formatReport;
        let text = '서식: 통과';
        let cls = 'border-emerald-200 bg-emerald-50 text-emerald-700';
        if (report.errors && report.errors.length > 0) {
            text = `서식: 오류 ${report.errors.length}`;
            cls = 'border-rose-200 bg-rose-50 text-rose-700';
        } else if (report.warnings && report.warnings.length > 0) {
            text = `서식: 경고 ${report.warnings.length}`;
            cls = 'border-amber-200 bg-amber-50 text-amber-700';
        }
        chips.push(`<span class="inline-flex items-center rounded px-1.5 py-0.5 border ${cls}">${text}</span>`);
    }

    if (status.imageStatus) {
        const imageStatus = status.imageStatus;
        let text = '이미지: 대기';
        let cls = 'border-slate-200 bg-slate-50 text-slate-700';
        if (imageStatus.report && Number(imageStatus.report.totalTags || 0) > 0) {
            const report = imageStatus.report;
            const searchAssigned = Number(report.searchAssigned || 0);
            const aiGenerated = Number(report.aiGenerated || 0);
            if (searchAssigned === 0 && aiGenerated > 0) {
                text = `이미지: 검색 0 / AI ${aiGenerated}`;
                cls = 'border-rose-200 bg-rose-50 text-rose-700';
            } else {
                text = `이미지: 검색 ${searchAssigned} / AI ${aiGenerated}`;
                cls = 'border-sky-200 bg-sky-50 text-sky-700';
            }
        } else if (Number(imageStatus.pendingTags || 0) > 0) {
            text = `이미지: 대기 ${imageStatus.pendingTags}`;
        }
        chips.push(`<span class="inline-flex items-center rounded px-1.5 py-0.5 border ${cls}">${text}</span>`);
    }

    const quality = status.quality || null;
    if (quality && Number.isFinite(Number(quality.overallScore))) {
        const score = Number(quality.overallScore);
        const lowCount = Array.isArray(quality.lowDimensions) ? quality.lowDimensions.length : 0;
        const cls = quality.pass
            ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
            : (lowCount > 0 ? 'border-amber-200 bg-amber-50 text-amber-700' : 'border-slate-200 bg-slate-50 text-slate-700');
        const text = quality.pass ? `품질: ${score}점 통과` : `품질: ${score}점 / 보완 ${lowCount}`;
        chips.push(`<span class="inline-flex items-center rounded px-1.5 py-0.5 border ${cls}">${text}</span>`);
    } else {
        chips.push(`<span class="inline-flex items-center rounded px-1.5 py-0.5 border border-slate-200 bg-slate-50 text-slate-700">품질: 대기</span>`);
    }

    summaryEl.innerHTML = chips.join('');
};

window.validateCurriculumFormat = function (markdown = '') {
    const content = typeof markdown === 'string' ? markdown : '';

    // 본문 번호 목록 허용 여부(헤딩 라인은 제외)
    const numberedLines = content.match(/^(?!\s*#)\s*\d+\.\s+/gm) || [];
    const pendingImageTags = content.match(/<!--\s*\[IMG:\s*"?[^"\]]+"?\]\s*-->/g) || [];

    // 정규식 키워드는 유니코드 이스케이프를 사용해 인코딩 환경 영향을 줄임
    const hasOverviewHeading = /^(?:##|###|####)\s*(?:\d+\.\s*)?.*(?:\uac1c\uc694|overview)/im.test(content);
    const hasObjectivesHeading = /^(?:##|###|####)\s*(?:\d+\.\s*)?.*(?:\ud559\uc2b5\s*\ubaa9\ud45c|learning\s*objectives?)/im.test(content);

    const warnings = [];
    const errors = [];

    if (numberedLines.length > 8) {
        warnings.push(`번호형 본문 목록이 ${numberedLines.length}개로 많습니다. 본문 병렬 나열은 '-' 불릿 사용을 권장합니다.`);
    }
    if (pendingImageTags.length > 0) {
        warnings.push(`미처리 이미지 태그가 ${pendingImageTags.length}개 남아 있습니다.`);
    }
    if (!hasOverviewHeading) {
        errors.push('개요(## ... 개요) 섹션 헤딩이 없습니다.');
    }
    if (!hasObjectivesHeading) {
        errors.push('학습 목표(## ... 학습 목표) 섹션 헤딩이 없습니다.');
    }

    return {
        isValid: errors.length === 0 && warnings.length === 0,
        errors,
        warnings,
        metrics: {
            numberedLines: numberedLines.length,
            pendingImageTags: pendingImageTags.length,
            hasOverviewHeading,
            hasObjectivesHeading
        }
    };
};

window.renderFormatLintBanner = function (mod, options = {}) {
    const banner = document.getElementById('format-lint-banner');
    if (!banner) return null;

    if (!mod || !mod.content) {
        banner.classList.add('hidden');
        banner.innerHTML = '';
        return null;
    }

    const report = window.validateCurriculumFormat(mod.content);
    const toast = !!options.toast;
    const forceToast = !!options.forceToast;

    let tone = 'success';
    let icon = 'ph-check-circle';
    let title = '서식 점검 통과';
    let detail = `번호형 본문 ${report.metrics.numberedLines}개, 대기 이미지 태그 ${report.metrics.pendingImageTags}개`;
    let bannerClass = 'rounded-md border border-emerald-200 bg-emerald-50 px-2.5 py-1.5 text-[0.72rem] text-emerald-700';

    if (report.errors.length > 0) {
        tone = 'error';
        icon = 'ph-warning-circle';
        title = `서식 점검 오류 (${report.errors.length})`;
        detail = report.errors.join(' / ');
        bannerClass = 'rounded-md border border-red-200 bg-red-50 px-2.5 py-1.5 text-[0.72rem] text-red-700';
    } else if (report.warnings.length > 0) {
        tone = 'warning';
        icon = 'ph-warning';
        title = `서식 점검 경고 (${report.warnings.length})`;
        detail = report.warnings.join(' / ');
        bannerClass = 'rounded-md border border-amber-200 bg-amber-50 px-2.5 py-1.5 text-[0.72rem] text-amber-700';
    }

    const foldKey = `${mod.id || 'unknown'}::format-lint`;
    banner.className = bannerClass;
    banner.innerHTML = buildFoldableBannerHTML({
        foldKey,
        icon,
        title,
        detailHtml: `<div>${escapeHtmlAttr(detail)}</div>`,
        defaultCollapsed: true
    });
    banner.classList.remove('hidden');

    if (toast && window.showToast) {
        const fingerprint = `${tone}|${title}|${detail}`;
        const prev = formatLintToastCache.get(mod.id);
        if (forceToast || prev !== fingerprint) {
            formatLintToastCache.set(mod.id, fingerprint);
            const toastMsg = tone === 'success'
                ? `형식 검사 통과: ${mod.title}`
                : `형식 검사 ${tone === 'error' ? '필요' : '경고'}: ${mod.title}`;
            window.showToast(toastMsg, tone);
        }
    }

    return report;
};

window.renderImageSearchStatusBanner = function (mod) {
    const banner = document.getElementById('image-search-status-banner');
    if (!banner) return null;

    if (!mod || !mod.content) {
        banner.classList.add('hidden');
        banner.innerHTML = '';
        return null;
    }

    const provider = getImageSearchProviderStatus();
    const pendingTags = (mod.content.match(/<!--\s*\[IMG:\s*"?[^"\]]+"?\]\s*-->/g) || []).length;
    const report = (mod.imageSearchReport && typeof mod.imageSearchReport === 'object') ? mod.imageSearchReport : null;
    const foldKey = `${mod.id || 'unknown'}::image-search-status`;

    if (!provider.hasAny) {
        const missing = [];
        if (!provider.hasGoogleCx) missing.push('Google CX');
        if (!provider.hasGoogleKeys) missing.push('Google Search API 키');
        if (!provider.hasPixabay) missing.push('Pixabay API 키');
        const pendingText = pendingTags > 0
            ? `대기 중인 이미지 태그: ${pendingTags}개. 검색 제공자 설정 전까지 AI 생성으로 처리됩니다.`
            : '이미지 검색 제공자가 설정되지 않았습니다.';
        banner.className = 'rounded-md border border-amber-200 bg-amber-50 px-2.5 py-1.5 text-[0.72rem] text-amber-800';
        banner.innerHTML = buildFoldableBannerHTML({
            foldKey,
            icon: 'ph-warning-circle',
            title: '이미지 검색 비활성화',
            detailHtml: `
                <div>${escapeHtmlAttr(pendingText)}</div>
                <div class="mt-1">누락 설정: ${escapeHtmlAttr(missing.join(' / ') || '검색 제공자 키')}</div>
            `,
            defaultCollapsed: true
        });
        banner.classList.remove('hidden');
        return { tone: 'warning', pendingTags, report };
    }

    if (report && Number(report.totalTags || 0) > 0) {
        const total = Number(report.totalTags || 0);
        const searchAssigned = Number(report.searchAssigned || 0);
        const aiGenerated = Number(report.aiGenerated || 0);
        const failed = Number(report.failed || 0);
        const googleAssigned = Number(report.googleAssigned || 0);
        const pixabayAssigned = Number(report.pixabayAssigned || 0);

        if (searchAssigned === 0 && (aiGenerated > 0 || failed > 0)) {
            banner.className = 'rounded-md border border-rose-200 bg-rose-50 px-2.5 py-1.5 text-[0.72rem] text-rose-800';
            banner.innerHTML = buildFoldableBannerHTML({
                foldKey,
                icon: 'ph-warning',
                title: '검색 배정: 0건',
                detailHtml: `
                    <div>총 ${total}개 태그 처리 완료. 검색 배정 0건, AI 생성 ${aiGenerated}건${failed > 0 ? `, 실패 ${failed}건` : ''}.</div>
                    <div class="mt-1">Google/Pixabay에서 결과가 없거나 요청 오류가 발생했을 수 있습니다.</div>
                `,
                defaultCollapsed: true
            });
            banner.classList.remove('hidden');
            return { tone: 'error', pendingTags, report };
        }

        banner.className = 'rounded-md border border-sky-200 bg-sky-50 px-2.5 py-1.5 text-[0.72rem] text-sky-800';
        banner.innerHTML = buildFoldableBannerHTML({
            foldKey,
            icon: 'ph-image-square',
            title: '이미지 처리 요약',
            detailHtml: `<div>총 ${total}개 태그 처리: 검색 ${searchAssigned}건 (Google ${googleAssigned}, Pixabay ${pixabayAssigned}), AI ${aiGenerated}건${failed > 0 ? `, 실패 ${failed}건` : ''}.</div>`,
            defaultCollapsed: true
        });
        banner.classList.remove('hidden');
        return { tone: 'info', pendingTags, report };
    }

    if (pendingTags > 0) {
        banner.className = 'rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-[0.72rem] text-slate-700';
        banner.innerHTML = buildFoldableBannerHTML({
            foldKey,
            icon: 'ph-info',
            title: '이미지 태그 대기 중',
            detailHtml: `<div>${pendingTags}개 태그가 대기 중입니다. 일괄 처리 시 Google/Pixabay 검색을 우선 시도합니다.</div>`,
            defaultCollapsed: true
        });
        banner.classList.remove('hidden');
        return { tone: 'pending', pendingTags, report: null };
    }

    banner.classList.add('hidden');
    banner.innerHTML = '';
    return { tone: 'hidden', pendingTags: 0, report: null };
};

const QUALITY_PASS_SCORE = 85;
const QUALITY_LOW_SCORE = 78;
const QUALITY_DIMENSIONS = [
    { id: 'goal_alignment', label: '목표 정합성' },
    { id: 'difficulty_fit', label: '난이도 적합성' },
    { id: 'factuality', label: '사실 정확성' },
    { id: 'depth_balance', label: '깊이 균형' },
    { id: 'practice_quality', label: '실습 품질' },
    { id: 'module_cohesion', label: '모듈 응집도' }
];
const qualityEvalToastCache = new Map();

function clampScore(value, fallback = 0) {
    const n = Number(value);
    if (!Number.isFinite(n)) return fallback;
    return Math.max(0, Math.min(100, Math.round(n)));
}

function tryParseJSONLoose(text = '') {
    const raw = String(text || '').trim();
    if (!raw) return null;

    let cleaned = raw.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '').trim();
    try {
        return JSON.parse(cleaned);
    } catch (e) {
        const first = cleaned.indexOf('{');
        const last = cleaned.lastIndexOf('}');
        if (first !== -1 && last !== -1 && last > first) {
            cleaned = cleaned.slice(first, last + 1);
            try {
                return JSON.parse(cleaned);
            } catch (ignored) {
                return null;
            }
        }
        return null;
    }
}

function normalizeQualityEvaluationPayload(raw, mod, source = 'manual') {
    const src = raw && typeof raw === 'object' ? raw : {};
    const rawDims = Array.isArray(src.dimensions) ? src.dimensions : [];

    const dimensions = QUALITY_DIMENSIONS.map((def, idx) => {
        const byId = rawDims.find(item => String(item?.id || '').trim().toLowerCase() === def.id);
        const fallback = rawDims[idx] || {};
        const item = byId || fallback || {};
        return {
            id: def.id,
            label: def.label,
            score: clampScore(item.score, 0),
            reason: String(item.reason || '').trim(),
            improvement: String(item.improvement || '').trim()
        };
    });

    const total = dimensions.reduce((sum, d) => sum + d.score, 0);
    const average = dimensions.length > 0 ? Math.round(total / dimensions.length) : 0;
    const overallScore = clampScore(
        src.overall_score ?? src.overallScore ?? src.overall ?? average,
        average
    );
    const lowDimensions = dimensions.filter(d => d.score < QUALITY_LOW_SCORE).map(d => d.id);

    return {
        version: 1,
        source,
        model: typeof TEXT_MODEL === 'string' ? TEXT_MODEL : '',
        evaluatedAt: new Date().toISOString(),
        overallScore,
        pass: overallScore >= QUALITY_PASS_SCORE && lowDimensions.length === 0,
        thresholds: { pass: QUALITY_PASS_SCORE, low: QUALITY_LOW_SCORE },
        dimensions,
        strengths: Array.isArray(src.strengths) ? src.strengths.map(v => String(v || '').trim()).filter(Boolean) : [],
        risks: Array.isArray(src.risks) ? src.risks.map(v => String(v || '').trim()).filter(Boolean) : [],
        lowDimensions,
        moduleId: mod?.id ?? null
    };
}

window.invalidateModuleQualityEvaluation = function (mod) {
    if (!mod || !mod.qualityEvaluation) return false;
    mod.qualityEvaluation = null;
    return true;
};

function updateQualityActionButtonState(mod) {
    const refineBtn = document.getElementById('quality-refine-btn');
    if (!refineBtn) return;

    const lowCount = Array.isArray(mod?.qualityEvaluation?.lowDimensions)
        ? mod.qualityEvaluation.lowDimensions.length
        : 0;
    const canRefine = lowCount > 0;

    refineBtn.disabled = !canRefine;
    refineBtn.innerHTML = `<i class="ph-bold ph-magic-wand"></i> 집중 보완${canRefine ? ` (${lowCount})` : ''}`;
    refineBtn.className = canRefine
        ? 'px-3 py-1.5 text-xs font-bold bg-rose-50 text-rose-600 border border-rose-200 rounded hover:bg-rose-100 flex items-center gap-1 transition-colors'
        : 'px-3 py-1.5 text-xs font-bold bg-gray-100 text-gray-400 border border-gray-200 rounded flex items-center gap-1 cursor-not-allowed';
}

window.renderQualityEvaluationBanner = function (mod, options = {}) {
    const banner = document.getElementById('quality-eval-banner');
    if (!banner) return null;

    if (!mod || !mod.content) {
        banner.classList.add('hidden');
        banner.innerHTML = '';
        updateQualityActionButtonState(mod);
        return null;
    }

    const quality = mod.qualityEvaluation;
    const foldKey = `${mod.id || 'unknown'}::quality-eval`;
    if (!quality || !Array.isArray(quality.dimensions)) {
        banner.className = 'rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-[0.72rem] text-slate-700';
        banner.innerHTML = buildFoldableBannerHTML({
            foldKey,
            icon: 'ph-shield-check',
            title: '품질 점검 대기',
            detailHtml: `<div>편집 후 품질 점검을 실행하면 의미/학습 품질 점수를 확인할 수 있습니다.</div>`,
            defaultCollapsed: true
        });
        banner.classList.remove('hidden');
        updateQualityActionButtonState(mod);
        return null;
    }

    const lowCount = Array.isArray(quality.lowDimensions) ? quality.lowDimensions.length : 0;
    const tone = quality.pass ? 'success' : (lowCount > 0 ? 'warning' : 'info');
    const icon = quality.pass ? 'ph-check-circle' : 'ph-warning-circle';
    const title = quality.pass
        ? `품질 통과 (${quality.overallScore}/100)`
        : `품질 점검 (${quality.overallScore}/100)`;
    const details = quality.dimensions
        .map(d => `<span class="inline-flex items-center rounded-full border border-black/10 px-2 py-0.5">${escapeHtmlAttr(d.label)} ${d.score}</span>`)
        .join(' ');
    const riskText = quality.risks && quality.risks.length > 0
        ? `<div class="mt-1.5 opacity-90">${escapeHtmlAttr(quality.risks[0])}</div>`
        : '';
    const refineAction = lowCount > 0
        ? `<button onclick="runModuleQualityRefinement()" class="px-2.5 py-1 rounded border border-rose-300 bg-rose-100 text-rose-700 font-bold text-[0.65rem] hover:bg-rose-200 transition-colors shrink-0">낮은 점수 보완 (${lowCount})</button>`
        : '';

    banner.className = quality.pass
        ? 'rounded-md border border-emerald-200 bg-emerald-50 px-2.5 py-1.5 text-[0.72rem] text-emerald-700'
        : 'rounded-md border border-amber-200 bg-amber-50 px-2.5 py-1.5 text-[0.72rem] text-amber-700';
    banner.innerHTML = buildFoldableBannerHTML({
        foldKey,
        icon,
        title,
        detailHtml: `<div class="flex flex-wrap gap-1.5">${details}</div>${riskText}`,
        defaultCollapsed: true,
        headerActionHtml: refineAction
    });
    banner.classList.remove('hidden');
    updateQualityActionButtonState(mod);

    if (!!options.toast && window.showToast) {
        const fingerprint = `${tone}|${title}|${lowCount}`;
        const prev = qualityEvalToastCache.get(mod.id);
        if (!!options.forceToast || prev !== fingerprint) {
            qualityEvalToastCache.set(mod.id, fingerprint);
            const msg = quality.pass
                ? `품질 통과: ${mod.title}`
                : `품질 보완 필요: ${mod.title}`;
            window.showToast(msg, quality.pass ? 'success' : 'warning');
        }
    }

    return quality;
};

async function requestCurriculumQualityEvaluation(mod, markdown, source = 'manual') {
    const cleanMarkdown = cleanForAPI(markdown || '').trim();
    const clippedMarkdown = cleanMarkdown.length > 28000
        ? `${cleanMarkdown.slice(0, 28000)}\n\n[TRUNCATED_FOR_REVIEW]`
        : cleanMarkdown;

    const systemPrompt = `You are a curriculum QA reviewer.
Score semantic instructional quality only.
Do not check markdown syntax, heading style, numbering style, image tag syntax, or HTML formatting (handled by separate lint).
Return strict JSON only.

Schema:
{
  "overall_score": 0-100,
  "dimensions": [
    {"id":"goal_alignment","score":0-100,"reason":"...","improvement":"..."},
    {"id":"difficulty_fit","score":0-100,"reason":"...","improvement":"..."},
    {"id":"factuality","score":0-100,"reason":"...","improvement":"..."},
    {"id":"depth_balance","score":0-100,"reason":"...","improvement":"..."},
    {"id":"practice_quality","score":0-100,"reason":"...","improvement":"..."},
    {"id":"module_cohesion","score":0-100,"reason":"...","improvement":"..."}
  ],
  "strengths": ["..."],
  "risks": ["..."]
}`;

    const userPrompt = `[Module]
title: ${mod?.title || ''}
description: ${mod?.description || ''}

[Markdown]
${clippedMarkdown}`;

    const payload = {
        contents: [{ parts: [{ text: userPrompt }] }],
        systemInstruction: { parts: [{ text: systemPrompt }] },
        generationConfig: { responseMimeType: 'application/json', temperature: 0.1 }
    };

    const data = await fetchWithRetry(
        `https://generativelanguage.googleapis.com/v1beta/models/${TEXT_MODEL}:generateContent?key=${apiKey}`,
        { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }
    );
    const parsed = tryParseJSONLoose(extractText(data));
    if (!parsed) {
        throw new Error('Quality evaluation JSON parse failed.');
    }
    return normalizeQualityEvaluationPayload(parsed, mod, source);
}

async function evaluateCurriculumQuality(mod, options = {}) {
    if (!mod || !mod.content) {
        throw new Error('No module content to evaluate.');
    }

    const persist = options.persist !== false;
    const source = options.source || 'manual';
    const quality = await requestCurriculumQualityEvaluation(mod, mod.content, source);

    if (persist) {
        mod.qualityEvaluation = quality;
        await saveState();
    }
    if (typeof window.renderQualityEvaluationBanner === 'function') {
        window.renderQualityEvaluationBanner(mod, { toast: !!options.toast, forceToast: !!options.forceToast });
    }
    return quality;
}

async function runQualityRefinementLoop(mod, options = {}) {
    if (!mod || !mod.content) {
        throw new Error('No module content to refine.');
    }

    let currentEval = mod.qualityEvaluation;
    if (!currentEval || !Array.isArray(currentEval.lowDimensions)) {
        currentEval = await evaluateCurriculumQuality(mod, { persist: true, toast: false, source: 'pre_refine' });
    }

    let lowDimensions = currentEval.dimensions.filter(d => d.score < QUALITY_LOW_SCORE);
    if (lowDimensions.length === 0) {
        return { rounds: 0, before: currentEval, after: currentEval };
    }

    const maxRounds = Math.max(1, Number(options.maxRounds) || 2);
    const beforeEval = currentEval;
    let rounds = 0;

    while (rounds < maxRounds && lowDimensions.length > 0) {
        rounds += 1;

        const focus = lowDimensions.map((d, idx) => {
            const reason = d.reason ? `reason: ${d.reason}` : 'reason: (not provided)';
            const improvement = d.improvement ? `improvement: ${d.improvement}` : 'improvement: improve this dimension';
            return `${idx + 1}. ${d.id} (${d.score}/100)\n${reason}\n${improvement}`;
        }).join('\n');

        const clippedMarkdown = mod.content.length > 28000
            ? `${mod.content.slice(0, 28000)}\n\n[TRUNCATED_FOR_REFINEMENT]`
            : mod.content;

        const systemPrompt = `You are revising a curriculum markdown.
Objective: improve only the low-scoring semantic dimensions.
Do not perform cosmetic markdown lint cleanup (format lint is handled elsewhere).
Preserve existing section structure, image placeholders/tags, and instructional intent.
Return markdown only, without code fences.`;

        const userPrompt = `[Module]
title: ${mod.title || ''}
description: ${mod.description || ''}

[Low-score dimensions]
${focus}

[Current markdown]
${clippedMarkdown}`;

        const payload = {
            contents: [{ parts: [{ text: userPrompt }] }],
            systemInstruction: { parts: [{ text: systemPrompt }] },
            generationConfig: { temperature: 0.2 }
        };

        const data = await fetchWithRetry(
            `https://generativelanguage.googleapis.com/v1beta/models/${TEXT_MODEL}:generateContent?key=${apiKey}`,
            { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }
        );

        let revised = extractText(data);
        revised = revised.replace(/^```\w*\n?/i, '').replace(/\n?```$/i, '').trim();
        if (!revised || revised.length < 80) {
            throw new Error('Refinement output is too short.');
        }

        mod.content = revised;
        mod.qualityEvaluation = null;
        currentEval = await evaluateCurriculumQuality(mod, { persist: false, toast: false, source: `refine_round_${rounds}` });
        lowDimensions = currentEval.dimensions.filter(d => d.score < QUALITY_LOW_SCORE);
    }

    mod.qualityEvaluation = currentEval;
    await saveState();
    return { rounds, before: beforeEval, after: currentEval };
}

window.runModuleQualityEvaluation = async function () {
    const mod = getEditingModule();
    if (!mod || !mod.content) {
        return window.showAlert('품질 점검할 교안 내용이 없습니다.');
    }

    const evalBtn = document.getElementById('quality-eval-btn');
    const refineBtn = document.getElementById('quality-refine-btn');
    const evalOriginal = evalBtn ? evalBtn.innerHTML : '';
    const refineOriginal = refineBtn ? refineBtn.innerHTML : '';

    try {
        if (evalBtn) {
            evalBtn.disabled = true;
            evalBtn.innerHTML = '<i class="ph-bold ph-spinner animate-spin"></i> 점검 중...';
        }
        if (refineBtn) refineBtn.disabled = true;

        await evaluateCurriculumQuality(mod, { persist: true, toast: true, forceToast: true, source: 'manual' });
        window.renderQualityEvaluationBanner(mod, { toast: false });
    } catch (err) {
        console.error('[F15] quality evaluation failed:', err);
        window.showAlert('품질 점검 실패: ' + (err.message || '알 수 없는 오류'));
    } finally {
        if (evalBtn) {
            evalBtn.disabled = false;
            evalBtn.innerHTML = evalOriginal || '<i class="ph-bold ph-shield-check"></i> 품질 점검';
        }
        if (refineBtn) {
            refineBtn.disabled = false;
            refineBtn.innerHTML = refineOriginal || '<i class="ph-bold ph-magic-wand"></i> 집중 보완';
        }
        updateQualityActionButtonState(mod);
    }
};

window.runModuleQualityRefinement = async function () {
    const mod = getEditingModule();
    if (!mod || !mod.content) {
        return window.showAlert('보완할 교안 내용이 없습니다.');
    }

    const evalBtn = document.getElementById('quality-eval-btn');
    const refineBtn = document.getElementById('quality-refine-btn');
    const evalOriginal = evalBtn ? evalBtn.innerHTML : '';
    const refineOriginal = refineBtn ? refineBtn.innerHTML : '';

    try {
        if (evalBtn) {
            evalBtn.disabled = true;
            evalBtn.innerHTML = '<i class="ph-bold ph-spinner animate-spin"></i> 점검 중...';
        }
        if (refineBtn) {
            refineBtn.disabled = true;
            refineBtn.innerHTML = '<i class="ph-bold ph-spinner animate-spin"></i> 보완 중...';
        }

        const result = await runQualityRefinementLoop(mod, { maxRounds: 2 });
        renderEditor(mod);

        const beforeScore = result.before?.overallScore ?? 0;
        const afterScore = result.after?.overallScore ?? beforeScore;
        const delta = afterScore - beforeScore;
        const deltaText = delta >= 0 ? `+${delta}` : `${delta}`;
        window.showAlert(`품질 보완 완료\n라운드: ${result.rounds}\n점수: ${beforeScore} -> ${afterScore} (${deltaText})`);
    } catch (err) {
        console.error('[F15] quality refinement failed:', err);
        window.showAlert('품질 보완 실패: ' + (err.message || '알 수 없는 오류'));
    } finally {
        if (evalBtn) {
            evalBtn.disabled = false;
            evalBtn.innerHTML = evalOriginal || '<i class="ph-bold ph-shield-check"></i> 품질 점검';
        }
        if (refineBtn) {
            refineBtn.disabled = false;
            refineBtn.innerHTML = refineOriginal || '<i class="ph-bold ph-magic-wand"></i> 집중 보완';
        }
        updateQualityActionButtonState(mod);
    }
};

async function resolveImageBySearchChain({ keyword, context = '', fallbackGeneratePrompt = '', intent = null, logPrefix = 'Image Search Chain' } = {}) {
    const baseKeyword = (keyword || '').trim() || '게임 기획 관련 이미지';
    const contextText = (context || '').trim();
    const providerStatus = getImageSearchProviderStatus();
    let searchIntent = intent;

    if (!searchIntent) {
        try {
            searchIntent = await extractSearchIntent(baseKeyword, contextText || baseKeyword);
        } catch (e) {
            console.error(`[${logPrefix}] 검색 의도 추출 실패:`, e);
            searchIntent = null;
        }
    }

    const searchQuery = (searchIntent && searchIntent.search_query) ? searchIntent.search_query : baseKeyword;
    console.log(`[${logPrefix}] 원본 키워드: ${baseKeyword} -> 최적화 쿼리: ${searchQuery}`, searchIntent);

    let b64Image = null;
    let vendorLabel = "AI 생성 이미지";

    let cached = null;
    if (typeof DBManager !== 'undefined' && DBManager && typeof DBManager.getCache === 'function') {
        try {
            cached = await DBManager.getCache(searchQuery);
        } catch (cacheErr) {
            console.warn(`[${logPrefix}] 캐시 조회 실패, 검색 체인을 계속 진행합니다.`, cacheErr);
        }
    }
    if (cached && cached.base64) {
        b64Image = cached.base64;
        vendorLabel = `캐시 이미지 (${cached.format})`;
        console.log(`[Cache Hit] 저장된 검색 결과를 불러왔습니다: ${searchQuery}`);
        if (window.showToast) window.showToast(`로컬 캐시에서 이미지를 로드했습니다: ${searchQuery}`, 'success');
        return { b64Image, vendorLabel, searchQuery, intent: searchIntent, resolvedBy: 'cache', providerStatus, fallbackReason: null };
    }

    const searchResult = providerStatus.hasGoogle ? await searchImageAPI(searchQuery) : null;
    if (searchResult && searchResult.b64) {
        const validationContext = contextText || baseKeyword;
        const validationIntent = searchIntent || { search_query: searchQuery, reasoning: fallbackGeneratePrompt || baseKeyword };
        const validation = await validateImageWithVLM(searchResult.b64, validationIntent, validationContext);

        if (validation && validation.isValid !== false) {
            b64Image = searchResult.b64;
            vendorLabel = '검색 이미지';
            if (typeof DBManager !== 'undefined' && DBManager && typeof DBManager.setCache === 'function') {
                try {
                    await DBManager.setCache(searchQuery, b64Image, searchResult.source, vendorLabel);
                } catch (cacheErr) {
                    console.warn(`[${logPrefix}] 검색 결과 캐시 저장 실패:`, cacheErr);
                }
            }
            console.log(`[Cache Save] 검열을 통과한 새 검색 결과를 저장했습니다: ${searchQuery}`);
            return { b64Image, vendorLabel, searchQuery, intent: searchIntent, resolvedBy: 'google', providerStatus, fallbackReason: null };
        }

        console.warn(`[VLM Validator] 이미지 부적합 판정 (폐기): ${validation?.reason || '이유 불명'}`);
        if (window.showToast) window.showToast(`검색된 이미지가 부적합 판정(${validation?.reason})을 받아 우회합니다.`, 'warning');
    }

    const pixabayResult = providerStatus.hasPixabay ? await searchPixabayAPI(searchQuery) : null;
    if (pixabayResult && pixabayResult.b64) {
        b64Image = pixabayResult.b64;
        vendorLabel = '스톡 이미지 (Pixabay)';
        if (typeof DBManager !== 'undefined' && DBManager && typeof DBManager.setCache === 'function') {
            try {
                await DBManager.setCache(searchQuery, b64Image, pixabayResult.source, vendorLabel);
            } catch (cacheErr) {
                console.warn(`[${logPrefix}] Pixabay 결과 캐시 저장 실패:`, cacheErr);
            }
        }
        console.log(`[Cache Save] Pixabay 검색 결과를 저장했습니다: ${searchQuery}`);
        return { b64Image, vendorLabel, searchQuery, intent: searchIntent, resolvedBy: 'pixabay', providerStatus, fallbackReason: null };
    }

    const fallbackReason = providerStatus.hasAny ? 'search_unavailable_or_no_result' : 'providers_not_configured';
    const generatePrompt = (fallbackGeneratePrompt && fallbackGeneratePrompt.trim())
        ? fallbackGeneratePrompt.trim()
        : ((searchIntent && searchIntent.reasoning) ? `[Context: ${searchIntent.reasoning}]\nQuery: ${searchQuery}` : baseKeyword);
    console.log(`[Fallback] 검색 엔진 결과가 없어 AI 생성으로 최종 대처: ${searchQuery}`);
    b64Image = await generateImageAPI(generatePrompt);
    vendorLabel = fallbackReason === 'providers_not_configured'
        ? "AI 생성 이미지 (검색 API 미설정)"
        : "AI 생성 이미지 (검색 결과 없음/오류)";

    return { b64Image, vendorLabel, searchQuery, intent: searchIntent, resolvedBy: 'ai', providerStatus, fallbackReason };
}


async function processImageTags(mod, markdown) {

    const regex = /<!--\s*\[IMG:\s*"?([^"]+)"?\]\s*-->/g;

    let result = markdown;

    let match;



    const tagsToReplace = [];
    while ((match = regex.exec(markdown)) !== null) {
        tagsToReplace.push({ fullMatch: match[0], keyword: match[1].trim() });
    }

    if (tagsToReplace.length === 0) return result;

    const providerStatus = getImageSearchProviderStatus();
    const processingReport = {
        timestamp: new Date().toISOString(),
        totalTags: tagsToReplace.length,
        searchAssigned: 0,
        googleAssigned: 0,
        pixabayAssigned: 0,
        cacheAssigned: 0,
        aiGenerated: 0,
        failed: 0,
        fallbackNoProvider: 0,
        fallbackNoResult: 0,
        providerStatus
    };
    // Rate Limit(429) 완화를 위해 요청마다 지연 간격을 둡니다.
    const replacements = await Promise.all(tagsToReplace.map(async (tag, index) => {
        try {
            // Rate Limit 방어 스태거링 (순차적으로 0.5초 간격)
            if (index > 0) await new Promise(r => setTimeout(r, index * 500));

            const context = getContextWindow(markdown, tag.fullMatch, 400);
            const chainResult = await resolveImageBySearchChain({
                keyword: tag.keyword,
                context,
                fallbackGeneratePrompt: tag.keyword,
                logPrefix: 'Deep Research Agent'
            });
            const b64Image = chainResult?.b64Image || null;
            const vendorLabel = chainResult?.vendorLabel || "AI 생성 이미지";
            const resolvedBy = chainResult?.resolvedBy || '';
            const fallbackReason = chainResult?.fallbackReason || '';

            if (b64Image) {
                return { fullMatch: tag.fullMatch, keyword: tag.keyword, vendorLabel, b64Image, resolvedBy, fallbackReason };
            } else {
                return { fullMatch: tag.fullMatch, html: `\n> [이미지 영역: ${tag.keyword}]\n` };
            }

        } catch (e) {
            console.error(`이미지 처리 실패 (${tag.keyword}):`, e);
            return { fullMatch: tag.fullMatch, html: `\n> [이미지 확보 실패: ${tag.keyword}]\n` };
        }
    }));

    if (!mod.images || typeof mod.images !== 'object' || Array.isArray(mod.images)) {
        mod.images = {};
    }

    const idBase = Date.now();
    let idSeq = 0;
    const createUniqueImageId = () => {
        let imgId;
        do {
            imgId = `img_${idBase}${String(idSeq++).padStart(3, '0')}`;
        } while (Object.prototype.hasOwnProperty.call(mod.images, imgId));
        return imgId;
    };

    // Promise.all 병렬 처리 결과를 단일 블록에서 병합해 mod.images 경합/충돌을 방지한다.
    for (const rep of replacements) {
        if (rep.b64Image) {
            if (rep.resolvedBy === 'google') {
                processingReport.searchAssigned += 1;
                processingReport.googleAssigned += 1;
            } else if (rep.resolvedBy === 'pixabay') {
                processingReport.searchAssigned += 1;
                processingReport.pixabayAssigned += 1;
            } else if (rep.resolvedBy === 'cache') {
                processingReport.cacheAssigned += 1;
                const label = String(rep.vendorLabel || '');
                if (label.includes('Google') || label.includes('검색 이미지') || label.includes('web search')) {
                    processingReport.searchAssigned += 1;
                    processingReport.googleAssigned += 1;
                } else if (label.includes('Pixabay') || label.includes('스톡 이미지') || label.includes('stock image')) {
                    processingReport.searchAssigned += 1;
                    processingReport.pixabayAssigned += 1;
                } else if (label.includes('AI 생성') || label.includes('AI generated')) {
                    processingReport.aiGenerated += 1;
                }
            } else if (rep.resolvedBy === 'ai') {
                processingReport.aiGenerated += 1;
                if (rep.fallbackReason === 'providers_not_configured') processingReport.fallbackNoProvider += 1;
                else processingReport.fallbackNoResult += 1;
            }

            const imgId = createUniqueImageId();
            mod.images[imgId] = rep.b64Image;

            const vendorIcon = getVendorIcon(rep.vendorLabel);
            const safeKeyword = escapeHtmlAttr(rep.keyword || '');
            const safeVendor = escapeHtmlAttr(rep.vendorLabel || 'AI 생성 이미지');
            const encodedKeyword = encodeURIComponent(rep.keyword || '').replace(/'/g, '%27');

            const imgHTML = `\n<div class="image-wrapper"><img src="local:${imgId}" alt="${safeKeyword}" class="rounded-lg border-2 border-accent/30 shadow-md max-w-full"><span class="absolute bottom-3 left-3 bg-black/80 text-white text-[0.6rem] px-2 py-1 rounded border border-white/20 flex items-center gap-1 pointer-events-none"><i class="ph-fill ${vendorIcon} text-accent"></i> ${safeVendor}</span><button class="image-regenerate-btn px-3 py-1.5 text-xs text-white font-bold rounded flex items-center gap-1 border border-accent/50 hover:bg-accent transition-colors" data-fallback-keyword="${encodedKeyword}" data-img-id="${imgId}" onclick="promptRegenerateImage(this, decodeURIComponent(this.dataset.fallbackKeyword || ''), this.dataset.imgId)"><i class="ph-bold ph-arrows-clockwise"></i> 다시 찾기</button></div>\n`;
            result = result.replace(rep.fullMatch, imgHTML);
            continue;
        }

        processingReport.failed += 1;
        result = result.replace(rep.fullMatch, rep.html);
    }

    mod.imageSearchReport = processingReport;
    window.__lastImageSearchReport = processingReport;
    return result;
}

// [신규] 지연된 이미지를 일괄 생성/검색하는 수동 트리거 함수
async function generateAllImagesInModule(moduleId) {
    const mod = getEditingModule(moduleId);
    if (!mod || !mod.content) return;

    if (!mod.content.includes('<!-- [IMG:')) {
        window.showToast('본문에 처리 대기 중인 이미지 태그가 없습니다.', 'info');
        return;
    }

    const btn = document.getElementById('img-batch-btn');
    const originalText = btn ? btn.innerHTML : '';
    if (btn) {
        btn.innerHTML = '<i class="ph-bold ph-spinner animate-spin"></i> 이미지 일괄 확보 중...';
        btn.disabled = true;
    }

    document.getElementById('editor-loading').style.display = 'flex';
    document.getElementById('editor-loading-text').textContent = '본문 이미지를 수집하고 안전하게 검색을 수행하고 있습니다...';

    try {
        const newContent = await processImageTags(mod, mod.content);
        mod.content = newContent;
        if (typeof window.invalidateModuleQualityEvaluation === 'function') {
            window.invalidateModuleQualityEvaluation(mod);
        }
        await saveState();
        renderEditor(mod); // 최신 내용으로 리렌더링
        const report = mod.imageSearchReport;
        if (report && Number(report.totalTags || 0) > 0 && Number(report.searchAssigned || 0) === 0) {
            window.showToast('검색 이미지 배정이 0건입니다. 설정/API 응답 상태를 확인하세요.', 'warning');
        } else {
            window.showToast('이미지 일괄 처리가 완료되었습니다.', 'success');
        }
    } catch (e) {
        console.error('이미지 일괄 확보 실패:', e);
        window.showAlert('이미지 검색/생성 중 오류가 발생했습니다.');
    } finally {
        document.getElementById('editor-loading').style.display = 'none';
        if (btn) {
            btn.innerHTML = originalText;
            btn.disabled = false;
        }
    }
}



async function generateImageAPI(prompt) {

    const payload = {

        contents: [{ parts: [{ text: prompt + ", digital art style, clean, professional" }] }],

        generationConfig: {

            responseModalities: ["TEXT", "IMAGE"]

        }

    };

    try {

        const data = await fetchWithRetry(

            `https://generativelanguage.googleapis.com/v1beta/models/${IMAGE_MODEL}:generateContent?key=${apiKey}`,

            { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }

        );

        // Gemini Image 응답에서 이미지 파트 추출
        const parts = data?.candidates?.[0]?.content?.parts;
        if (parts) {
            const imgPart = parts.find(p => p.inlineData && p.inlineData.mimeType && p.inlineData.mimeType.startsWith('image/'));
            if (imgPart) {
                return `data:${imgPart.inlineData.mimeType};base64,${imgPart.inlineData.data}`;
            }
        }

        return null;

    } catch (e) {

        console.error("이미지 생성 에러:", e);

        return null;

    }

}



window.promptRegenerateImage = function (btn, fallbackKeyword, imgId) {

    const wrapper = btn.closest('.image-wrapper');
    if (!wrapper) return;

    if (wrapper.querySelector('.prompt-overlay')) return;



    const overlay = document.createElement('div');

    overlay.className = 'prompt-overlay absolute inset-0 bg-black/80 backdrop-blur-sm flex flex-col items-center justify-center p-4 z-20 animate-fade-in rounded-lg';

    overlay.onclick = () => overlay.remove();

    overlay.innerHTML = `

                <div class="w-full max-w-[320px] bg-[#1a1a2e] p-4 rounded-xl border border-white/10 shadow-2xl relative" onclick="event.stopPropagation()">

                    <div class="flex justify-between items-center mb-3">

                        <h4 class="text-sm font-bold text-white flex items-center gap-1.5"><i class="ph-fill ph-sparkle text-accent"></i> 이미지 다시 생성</h4>

                        <button class="text-textMuted hover:text-white transition-colors" onclick="this.closest('.prompt-overlay').remove()"><i class="ph-bold ph-x"></i></button>

                    </div>

                    <textarea class="w-full bg-black/40 border border-white/10 rounded-lg p-3 text-xs text-white focus:border-accent focus:ring-1 focus:ring-accent outline-none resize-none mb-3 placeholder:text-textMuted/40" rows="3" placeholder="프롬프트를 입력하세요.\n(입력하지 않으면 주변 문맥을 분석하여 자동 생성됩니다)"></textarea>

                    <div class="flex justify-end gap-2">

                        <button class="px-3 py-1.5 text-xs font-bold text-white bg-white/10 hover:bg-white/20 rounded-lg transition-colors" onclick="this.closest('.prompt-overlay').remove()">취소</button>

                        <button class="regenerate-submit-btn px-3 py-1.5 text-xs font-bold text-white bg-accent hover:bg-accentHover rounded-lg transition-colors">생성하기</button>

                    </div>

                </div>

            `;

    wrapper.appendChild(overlay);
    const submit = overlay.querySelector('.regenerate-submit-btn');
    if (submit) {
        submit.onclick = () => window.doRegenerateImage(submit, fallbackKeyword, imgId);
    }

};



function extractContextForImage(imgId) {

    const mod = getEditingModule();

    if (!mod || !mod.content) return "게임 기획 관련 이미지";



    const text = mod.content;

    const marker = `local:${imgId}`;

    const idx = text.indexOf(marker);

    if (idx === -1) return "게임 기획 관련 이미지";



    const start = Math.max(0, idx - 300);

    const end = Math.min(text.length, idx + marker.length + 300);

    let context = text.substring(start, end)

        .replace(/local:img_[0-9]+/g, '')

        .replace(/<!--.*?-->/g, '')

        .replace(/[#*`_>]/g, '')

        .trim();



    return context || "게임 기획 관련 이미지";

}



window.doRegenerateImage = async function (submitBtn, fallbackKeyword, imgId) {

    const overlay = submitBtn.closest('.prompt-overlay');
    if (!overlay) return;

    const wrapper = overlay.closest('.image-wrapper');
    if (!wrapper) return;

    const textarea = overlay.querySelector('textarea');

    const userPrompt = textarea ? textarea.value.trim() : '';
    const context = extractContextForImage(imgId);
    const keyword = userPrompt || fallbackKeyword || '게임 기획 관련 이미지';
    const prompt = userPrompt || `다음 문맥에 어울리는 이미지: ${context} (주요 키워드: ${fallbackKeyword || keyword})`;
    const safePrompt = escapeHtmlAttr(prompt);



    overlay.innerHTML = `

                <div class="flex flex-col items-center justify-center h-full">

                    <div class="spinner spinner-large mb-4"></div>

                    <p class="text-sm text-white font-bold animate-pulse drop-shadow-md">새로운 이미지를 검색/생성 중입니다...</p>

                    <p class="text-xs text-textLight/60 mt-2 max-w-[280px] text-center truncate px-4" title="${safePrompt}">프롬프트: ${safePrompt}</p>

                </div>

            `;



    try {

        const chainResult = await resolveImageBySearchChain({
            keyword,
            context,
            fallbackGeneratePrompt: prompt,
            logPrefix: 'Regenerate Chain'
        });
        const newB64 = chainResult?.b64Image;

        if (newB64) {

            const mod = getEditingModule();

            if (mod) {

                if (!mod.images) mod.images = {};
                let targetImgId = imgId;

                if (!mod.content.includes(`local:${targetImgId}`)) {
                    let originalRef = targetImgId;
                    try {
                        originalRef = decodeURIComponent(targetImgId);
                    } catch (decodeErr) {
                        originalRef = targetImgId;
                    }

                    if (originalRef && mod.content.includes(originalRef)) {
                        const newImgId = `img_${Date.now()}${Math.floor(Math.random() * 1000)}`;
                        mod.content = mod.content.split(originalRef).join(`local:${newImgId}`);
                        if (typeof window.invalidateModuleQualityEvaluation === 'function') {
                            window.invalidateModuleQualityEvaluation(mod);
                        }
                        targetImgId = newImgId;
                    }
                }

                mod.images[targetImgId] = newB64;

                const imgEl = wrapper.querySelector('img');
                if (imgEl) imgEl.src = newB64;

                const vendorLabel = chainResult?.vendorLabel || 'AI 생성 이미지';
                const vendorIcon = getVendorIcon(vendorLabel);
                const vendorBadge = wrapper.querySelector('span.absolute.bottom-3.left-3');
                if (vendorBadge) {
                    vendorBadge.innerHTML = `<i class="ph-fill ${vendorIcon} text-accent"></i> ${vendorLabel}`;
                }

                await saveState();

            }

        } else {

            window.showAlert('이미지 재생성에 실패했습니다.');

        }

    } catch (e) {

        window.showAlert('이미지 재생성 중 오류가 발생했습니다.');

        console.error(e);

    } finally {

        if (overlay && overlay.parentNode) overlay.remove();

    }

};



window.updateSubjectMeta = function (field, value) {

    if (!currentSubjectId) return;

    const subj = globalState.subjects.find(s => s.id === currentSubjectId);
    const nextValue = (typeof value === 'string' ? value : '').trim();

    if (subj && subj[field] !== nextValue) {

        subj[field] = nextValue;

        saveState().then(() => {
            renderOverviewLNB();
            renderSidebar();

            if (field === 'namingConvention') {
                const currentMod = getEditingModule();
                const previewEl = document.querySelector('button[title="파일명 컨벤션 편집"] .font-mono');
                if (currentMod && previewEl) {
                    previewEl.textContent = getNamingConventionPreviewFileName(currentMod);
                }
            }

            if (field === 'title') {

                const topicInput = document.getElementById('topic-input');
                if (topicInput) topicInput.value = nextValue;

                renderDiagram();

            }
        });

    }

}

function getNamingConventionPreviewFileName(mod, conventionOverride = null) {
    const moduleRef = mod || getEditingModule();
    if (!moduleRef) return 'module.md';

    const subj = globalState.subjects.find(s => s.id === currentSubjectId);
    const fallbackStem = typeof moduleRef.title === 'string' && moduleRef.title.trim()
        ? moduleRef.title.trim()
        : 'module';
    const currentConvention = subj?.namingConvention || '';
    const overrideApplied = conventionOverride !== null && conventionOverride !== undefined;
    const namingConvention = overrideApplied ? String(conventionOverride).trim() : currentConvention;
    const namingSubject = subj
        ? { ...subj, namingConvention }
        : { namingConvention };

    if (typeof window.getModuleExportFileNameByConvention === 'function') {
        return window.getModuleExportFileNameByConvention(namingSubject, moduleRef.id, fallbackStem, '.md');
    }
    return `${fallbackStem}.md`;
}

window.openNamingConventionEditorModal = function () {
    const subj = globalState.subjects.find(s => s.id === currentSubjectId);
    const mod = getEditingModule();
    if (!subj || !mod) {
        window.showAlert('먼저 교과와 차시를 선택해 주세요.');
        return;
    }

    const currentPattern = String(subj.namingConvention || '');
    const overlay = document.createElement('div');
    overlay.className = 'fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-[9999] animate-fade-in';
    overlay.onclick = () => overlay.remove();

    const safePattern = escapeHtmlAttr(currentPattern);
    const initialPreview = escapeHtmlAttr(getNamingConventionPreviewFileName(mod, currentPattern));
    overlay.innerHTML = `
        <div class="bg-[#1a1a2e] border border-white/10 rounded-2xl w-[520px] max-w-[92vw] p-6 shadow-2xl flex flex-col gap-4" onclick="event.stopPropagation()">
            <div class="flex items-center justify-between">
                <h3 class="font-bold text-white text-sm flex items-center gap-2">
                    <i class="ph-fill ph-file-code text-accent"></i> 파일명 컨벤션                </h3>
                <button class="w-8 h-8 flex items-center justify-center rounded-full hover:bg-white/10 text-textMuted hover:text-white transition-colors" onclick="this.closest('.fixed').remove()">
                    <i class="ph-bold ph-x"></i>
                </button>
            </div>
            <div class="text-xs text-textMuted leading-relaxed">
                <div><code>nn</code> 토큰은 차시 번호(예: <code>01</code>) 또는 메인퀘스트(<code>MQ</code>)로 치환됩니다.</div>
                <div>예: <code>GPlanBasic_nn</code></div>
            </div>
            <label class="text-xs font-bold text-white/70">컨벤션 패턴</label>
            <input id="naming-convention-modal-input" type="text" value="${safePattern}" placeholder="예: GPlanBasic_nn"
                class="w-full bg-black/30 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-accent transition-colors">
            <div class="rounded-lg border border-white/10 bg-black/25 p-3">
                <div class="text-[0.65rem] font-bold text-textMuted mb-1 uppercase tracking-wider">실시간 예시 파일명</div>
                <code id="naming-convention-modal-preview" class="text-sm text-accent break-all">${initialPreview}</code>
            </div>
            <div class="flex justify-end gap-2">
                <button class="px-3 py-1.5 text-xs font-bold text-white bg-white/10 hover:bg-white/20 rounded-lg transition-colors" onclick="this.closest('.fixed').remove()">취소</button>
                <button id="naming-convention-modal-save" class="px-4 py-2 text-xs font-bold text-white bg-accent hover:bg-accentHover rounded-lg transition-colors">저장</button>
            </div>
        </div>
    `;

    document.body.appendChild(overlay);
    const input = overlay.querySelector('#naming-convention-modal-input');
    const preview = overlay.querySelector('#naming-convention-modal-preview');
    const saveBtn = overlay.querySelector('#naming-convention-modal-save');

    const refreshPreview = () => {
        if (!preview) return;
        preview.textContent = getNamingConventionPreviewFileName(mod, input ? input.value : '');
    };

    if (input) {
        input.addEventListener('input', refreshPreview);
        input.addEventListener('keydown', (event) => {
            if (event.key === 'Enter') {
                event.preventDefault();
                if (saveBtn) saveBtn.click();
            } else if (event.key === 'Escape') {
                overlay.remove();
            }
        });
        setTimeout(() => input.focus(), 0);
    }

    if (saveBtn) {
        saveBtn.onclick = () => {
            if (input) {
                window.updateSubjectMeta('namingConvention', input.value);
            }
            overlay.remove();
        };
    }
};



function renderSidebar() {

    const list = document.getElementById('module-list');

    const subj = globalState.subjects.find(s => s.id === currentSubjectId);

    if (!subj) return;



    let html = '';



    // 교과 정보 & 메인 퀘스트 통합 모듈 (가로 분할 - 상하 Layout)

    const mq = subj.mainQuest;

    const allLessonsDone = Array.isArray(subj.lessons) && subj.lessons.length > 0 && subj.lessons.every(l => l.status === 'done');



    html += `

                <div class="mb-6 rounded-xl border border-white/10 bg-bgSidebar overflow-hidden flex flex-col shadow-[0_0_15px_rgba(0,0,0,0.2)]">

                    <div class="bg-white/5 p-2.5 border-b border-white/10 flex items-center gap-2">

                        <i class="ph-fill ph-sliders-horizontal text-accent"></i>

                        <h3 class="text-[0.7rem] font-bold text-textLight tracking-wider">교과 정보 및 메인 퀘스트</h3>

                    </div>

                    <div class="flex flex-col items-stretch">

                        <!-- 상단: 교과 정보 -->

                        <div class="w-full p-3 border-b border-white/10 flex flex-col gap-3">

                            <div>

                                <label class="text-[0.6rem] font-bold text-textMuted mb-1 flex items-center gap-1"><i class="ph-bold ph-file-code"></i> 파일 네이밍 규칙</label>

                                <input type="text" value="${subj.namingConvention || ''}" placeholder="예: GPlanBasic_nn" class="w-full bg-black/20 border border-white/10 rounded px-2 py-1.5 text-xs text-white focus:border-accent outline-none transition-colors" onblur="updateSubjectMeta('namingConvention', this.value)" title="내보내기 시 'nn' 부분이 차시 번호로 자동 치환됩니다.">

                            </div>

                        </div>



                        <!-- 하단: 메인 퀘스트 -->

                        <div class="w-full p-3 flex flex-col">

                            <div class="flex-1 p-3 rounded-lg border-2 ${mq && mq.status === 'done' ? 'border-yellow-500/30 bg-yellow-500/5' : 'border-transparent hover:border-white/10 hover:bg-white/5'} flex flex-col cursor-pointer transition-all group module-card" data-id="mainQuest" onclick="viewModule('mainQuest')">

                                <div class="flex items-center justify-between mb-1.5">

                                    <div class="flex items-center gap-1">

                                        <i class="ph-fill ph-crown text-sm ${mq && mq.status === 'done' ? 'text-yellow-400' : 'text-accent'}"></i>

                                        <span class="text-[0.65rem] font-bold text-textLight group-hover:text-accent transition-colors">메인 퀘스트</span>

                                    </div>

                                    <span class="text-[0.6rem] font-bold px-1.5 py-0.5 rounded ${mq && mq.status === 'done' ? 'bg-yellow-500/20 text-yellow-300' : 'bg-white/10 text-white/50'}">${mq && mq.status === 'done' ? '완료' : '대기중'}</span>

                                </div>

                                <div class="mb-2">

                                    <h4 class="font-bold text-xs text-white mb-0.5 line-clamp-1">${mq ? mq.title : ''}</h4>

                                    <p class="text-[0.6rem] text-textMuted line-clamp-2">${mq ? mq.description : ''}</p>

                                </div>

                                <div class="mt-2 flex justify-between items-center pt-2 border-t border-white/5">

                                    <span class="text-[0.55rem] text-white/50">${allLessonsDone ? '🌟 차시 완료' : '⚠️ 진행 필요'}</span>

                                    <button onclick="event.stopPropagation(); promptAndGenerateMainQuest()" class="text-[0.6rem] font-bold px-2 py-1 rounded ${allLessonsDone ? 'bg-accent hover:bg-accentHover' : 'bg-white/10 hover:bg-white/20'} text-white transition-colors" ${!allLessonsDone && mq && mq.status !== 'done' ? 'title="모든 차시를 먼저 생성하는 것을 권장합니다."' : ''}>

                                        ${mq && mq.status === 'done' ? '재생성' : '생성하기'}

                                    </button>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

                

                <div class="flex items-center gap-2 mb-3 px-1">

                    <i class="ph-fill ph-flag-pennant text-textMuted"></i>

                    <h3 class="text-xs font-bold text-textMuted uppercase tracking-wider">차시 목록</h3>

                </div>

            `;



    if (!Array.isArray(courseData) || courseData.length === 0) {

        html += `<div class="text-center pt-5 text-textMuted/60 text-sm leading-relaxed">차시 모듈이 없습니다.</div>`;

    } else {

        html += courseData.map((mod, idx) => `

                    <div class="module-card bg-white/5 border ${mod.status === 'done' ? 'border-green-500/30' : 'border-white/10'} rounded-xl p-4 mb-3 cursor-pointer hover:-translate-y-0.5 hover:shadow-lg transition-all" 

                         data-id="${mod.id}" draggable="true" onclick="viewModule(${mod.id})" style="animation-delay: ${idx * 0.05}s">

                        <div class="flex justify-between items-start mb-2">

                            <span class="inline-flex items-center justify-center w-6 h-6 rounded bg-accent/20 text-accent font-bold text-xs">${idx + 1}</span>

                            <div class="flex gap-2">

                                <button class="text-white/40 hover:text-white cursor-grab drag-handle" title="순서 변경"><i class="ph-bold ph-list"></i></button>

                                <button onclick="event.stopPropagation(); deleteModule(${mod.id})" class="text-red-400/70 hover:text-red-400" title="삭제"><i class="ph-bold ph-x"></i></button>

                            </div>

                        </div>

                        <h3 class="font-bold text-sm text-white mb-1 outline-none focus:bg-white/10 rounded px-1 -ml-1" contenteditable="true" spellcheck="false" onblur="updateModuleMeta(${mod.id}, 'title', this.innerText)" onclick="event.stopPropagation()">${mod.title}</h3>

                        <p class="text-xs text-textMuted line-clamp-2 outline-none focus:bg-white/10 rounded px-1 -ml-1" contenteditable="true" spellcheck="false" onblur="updateModuleMeta(${mod.id}, 'description', this.innerText)" onclick="event.stopPropagation()">${mod.description}</p>

                        

                        <div class="mt-3 flex items-center justify-between">

                            <span class="text-[0.65rem] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${mod.status === 'done' ? 'bg-green-500/20 text-green-400' : 'bg-white/10 text-white/50'}">${mod.status === 'done' ? '작성완료' : '대기중'}</span>

                            <div class="flex gap-1.5 items-center">

                                ${mod.uploadedMdName

                ? `<div class="flex items-center gap-1 bg-blue-500/20 text-blue-300 px-2 py-1 rounded text-[0.65rem] border border-blue-500/30">

                                           <i class="ph-bold ph-file-md"></i> <span class="max-w-[50px] truncate" title="${mod.uploadedMdName}">${mod.uploadedMdName}</span>

                                           <button onclick="event.stopPropagation(); cancelFileUpload(${mod.id})" class="ml-1 hover:text-white" title="업로드 취소"><i class="ph-bold ph-x"></i></button>

                                       </div>`

                : `<label class="cursor-pointer text-[0.65rem] font-bold px-2 py-1.5 rounded bg-white/5 hover:bg-white/10 text-white transition-colors border border-white/10 flex items-center gap-1" onclick="event.stopPropagation();" title="기존 마크다운 파일 업로드">

                                           <i class="ph-bold ph-upload-simple"></i> MD 업로드

                                           <input type="file" accept=".md" class="hidden" onchange="handleFileUpload(event, ${mod.id})">

                                       </label>`

            }

                                <button onclick="event.stopPropagation(); promptAndGenerateModule(${mod.id})" class="text-xs font-bold px-3 py-1.5 rounded bg-white/10 hover:bg-accent text-white transition-colors">

                                    ${mod.status === 'done'
                                        ? '<i class="ph-bold ph-arrows-clockwise mr-1"></i>재생성'
                                        : '<i class="ph-bold ph-sparkle mr-1"></i>생성하기'}

                                </button>

                            </div>

                        </div>

                    </div>

                `).join('');

    }



    html += `

                <button onclick="addModule()" class="w-full py-3 border-2 border-dashed border-white/10 rounded-xl text-white/50 text-sm font-bold hover:border-accent/50 hover:text-accent transition-colors flex items-center justify-center gap-2 mt-4">

                    <i class="ph-bold ph-plus"></i> 새 차시 추가

                </button>

            `;



    list.innerHTML = html;

    initDragAndDrop();

}



window.viewModule = function (id) {

    document.querySelectorAll('.module-card').forEach(c => c.classList.remove('border-accent', 'bg-accent/10', 'border-yellow-400', 'bg-yellow-400/5'));

    const card = document.querySelector(`.module-card[data-id="${id}"]`);

    if (card) {

        if (id === 'mainQuest') card.classList.add('border-yellow-400', 'bg-yellow-400/5');

        else card.classList.add('border-accent', 'bg-accent/10');

    }



    const mod = getEditingModule(id);

    if (mod) {

        currentEditingModuleId = id;

        renderEditor(mod);

    }

}



window.updateModuleMeta = function (id, field, value) {

    const mod = getEditingModule(id);

    if (mod && mod[field] !== value.trim()) {

        mod[field] = value.trim();

        saveState().then(() => {
            if (id !== 'mainQuest') renderSidebar();
        });

    }

}



window.deleteModule = function (id) {

    if (id === 'mainQuest') return;

    showConfirm('차시 모듈을 삭제하시겠습니까?', () => {

        const mod = getEditingModule(id);

        if (mod && mod.content) archiveContent(mod);

        courseData = courseData.filter(m => String(m.id) !== String(id));

        if (String(currentEditingModuleId) === String(id)) {

            currentEditingModuleId = null;

            document.getElementById('editor-content-area').innerHTML = '<div class="h-full flex items-center justify-center text-textMuted text-sm">모듈이 삭제되었습니다.</div>';

            document.getElementById('ai-command-bar').classList.add('hidden'); // 삭제 시 커맨드 바도 숨김 처리

        }

        saveState().then(() => renderSidebar());

    });

}



window.addModule = function () {

    const newId = Date.now();

    if (!Array.isArray(courseData)) courseData = [];

    courseData.push({
        id: newId,
        title: '새 차시',
        description: '차시 설명을 입력하세요.',
        status: 'waiting',
        content: null,
        images: {},
        imageSearchReport: null,
        teacherNotes: [],
        qualityEvaluation: null,
        uploadedMdName: null,
        uploadedMdContent: null
    });

    saveState().then(() => renderSidebar());

}

// =========================================================================
// MD 파일 업로드 / 취소 핸들러 (사이드바 차시 카드)
// =========================================================================

window.handleFileUpload = function (event, moduleId) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
        const mod = getEditingModule(moduleId);
        if (mod) {
            mod.uploadedMdName = file.name;
            mod.uploadedMdContent = e.target.result;
            saveState().then(() => renderSidebar());
        }
    };
    reader.readAsText(file, 'UTF-8');
    event.target.value = ''; // 리셋
}

window.cancelFileUpload = function (moduleId) {
    const mod = getEditingModule(moduleId);
    if (mod) {
        mod.uploadedMdName = null;
        mod.uploadedMdContent = null;
        saveState().then(() => renderSidebar());
    }
}

let activeEditorRenderJob = 0;
let teacherNotesScrollCleanup = null;

function nextAnimationFrame() {
    return new Promise(resolve => requestAnimationFrame(() => resolve()));
}

function escapeRegExp(value) {
    return String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function cleanupTeacherNotesScrollSync() {
    if (typeof teacherNotesScrollCleanup === 'function') {
        teacherNotesScrollCleanup();
    }
    teacherNotesScrollCleanup = null;
}

function ensureTeacherNotesArray(mod) {
    if (!mod || typeof mod !== 'object') return [];
    if (!Array.isArray(mod.teacherNotes)) mod.teacherNotes = [];
    const seen = new Set();
    mod.teacherNotes = mod.teacherNotes
        .map(item => {
            if (!item || typeof item !== 'object') return null;
            const anchor = String(item.anchor || '').trim();
            const note = String(item.note || '').trim();
            if (!anchor || !note || seen.has(anchor)) return null;
            seen.add(anchor);
            return { anchor, note };
        })
        .filter(Boolean);
    return mod.teacherNotes;
}

function decodeCommonHtmlEntities(rawText) {
    const source = String(rawText || '');
    const decoded = source
        .replace(/&nbsp;|&#160;/gi, ' ')
        .replace(/&amp;/gi, '&')
        .replace(/&lt;/gi, '<')
        .replace(/&gt;/gi, '>')
        .replace(/&quot;/gi, '"')
        .replace(/&#39;|&apos;/gi, "'");
    return decoded;
}

function normalizeHeadingText(rawText) {
    return decodeCommonHtmlEntities(rawText)
        .replace(/[`*_~]/g, '')
        .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
        .replace(/<[^>]+>/g, '')
        .replace(/\s+/g, ' ')
        .trim();
}

function sanitizeTeacherGuideSentence(rawText, maxLength = 96) {
    let cleaned = decodeCommonHtmlEntities(rawText)
        .replace(/<!--[\s\S]*?-->/g, ' ')
        .replace(/<[^>]+>/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();

    if (!cleaned) return '';
    if (cleaned.length > maxLength) cleaned = `${cleaned.slice(0, maxLength).trim()}...`;
    if (!/[.!?]$/.test(cleaned)) cleaned += '.';
    return cleaned;
}

function stripMarkdownForGuide(markdownText) {
    return decodeCommonHtmlEntities(markdownText)
        .replace(/<!--[\s\S]*?-->/g, ' ')
        .replace(/```[\s\S]*?```/g, ' ')
        .replace(/!\[[^\]]*\]\([^)]+\)/g, ' ')
        .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
        .replace(/^#{1,6}\s+/gm, '')
        .replace(/^\s*[-*+]\s+/gm, '')
        .replace(/^\s*\d+\.\s+/gm, '')
        .replace(/[*_`>]/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
}

function extractHeadingSectionsForGuide(markdownText) {
    const source = typeof markdownText === 'string' ? markdownText : '';
    const lines = source.split('\n');
    const sections = [];
    const used = new Map();
    let inCodeFence = false;
    let current = null;

    const flushCurrent = () => {
        if (!current) return;
        const body = stripMarkdownForGuide(current.lines.join('\n'));
        const summaryMatch = body.match(/[^.!?\n]{14,}[.!?]?/);
        const summary = sanitizeTeacherGuideSentence(summaryMatch ? summaryMatch[0] : body, 92);
        sections.push({
            level: current.level,
            title: current.title,
            anchor: current.anchor,
            summary
        });
        current = null;
    };

    for (const line of lines) {
        const trimmed = line.trim();
        if (trimmed.startsWith('```')) {
            inCodeFence = !inCodeFence;
            if (current) current.lines.push(line);
            continue;
        }
        if (inCodeFence) {
            if (current) current.lines.push(line);
            continue;
        }

        const match = trimmed.match(/^(#{1,6})\s+(.+)$/);
        if (match) {
            flushCurrent();
            const level = match[1].length;
            const title = normalizeHeadingText(match[2]);
            if (!title) continue;
            const baseAnchor = toHeadingAnchor(title);
            const count = used.get(baseAnchor) || 0;
            used.set(baseAnchor, count + 1);
            const anchor = count > 0 ? `${baseAnchor}-${count + 1}` : baseAnchor;
            current = { level, title, anchor, lines: [] };
            continue;
        }

        if (current) current.lines.push(line);
    }

    flushCurrent();
    return sections;
}

function buildTeacherGuideHint(title, summary) {
    const key = `${title} ${summary}`.toLowerCase();
    if (/(practice|exercise|quest|assignment|workshop)/.test(key)) {
        return 'When teaching, state the objective first, then demonstrate steps and let learners follow immediately.';
    }
    if (/(risk|warning|mistake|pitfall)/.test(key)) {
        return 'When teaching, show a common failure case first, then summarize with a prevention checklist.';
    }
    if (/(compare|difference|trade[- ]?off|selection|option)/.test(key)) {
        return 'When teaching, present 2-3 comparison criteria first, then explain selection rationale with examples.';
    }
    if (/(concept|definition|principle|overview|intro|fundamental)/.test(key)) {
        return 'When teaching, define the key term first, then connect it to one game-focused example.';
    }
    return 'When teaching, open with one key sentence and anchor understanding with a player-experience example.';
}

function buildAutoTeacherGuideNotes(markdownText) {
    const sections = extractHeadingSectionsForGuide(markdownText);
    return sections.map(section => {
        const conceptSentence = section.summary
            ? `${section.summary}`
            : sanitizeTeacherGuideSentence(`${section.title} core concept summary.`, 88);
        const hint = buildTeacherGuideHint(section.title, section.summary || '');
        return {
            anchor: section.anchor,
            note: `${conceptSentence} ${hint}`.trim()
        };
    });
}

function applyAutoTeacherGuides(mod, options = {}) {
    if (!mod || typeof mod !== 'object') return [];
    const force = !!options.force;
    const existing = ensureTeacherNotesArray(mod);
    if (!force && existing.length > 0) return existing;

    const generated = buildAutoTeacherGuideNotes(mod.content || '');
    mod.teacherNotes = generated;
    return generated;
}

window.buildAutoTeacherGuideNotes = buildAutoTeacherGuideNotes;
window.applyAutoTeacherGuides = applyAutoTeacherGuides;

function toHeadingAnchor(text) {
    const normalized = normalizeHeadingText(text)
        .toLowerCase()
        .replace(/[^\w\u3131-\u318e\uac00-\ud7a3\s-]/g, '')
        .replace(/\s+/g, '-')
        .replace(/-+/g, '-')
        .replace(/^-|-$/g, '');
    return normalized || 'section';
}

function cssEscape(value) {
    const raw = String(value || '');
    if (typeof CSS !== 'undefined' && typeof CSS.escape === 'function') {
        return CSS.escape(raw);
    }
    return raw.replace(/["\\]/g, '\\$&');
}

function extractMarkdownHeadingAnchors(markdownText) {
    const source = typeof markdownText === 'string' ? markdownText : '';
    const lines = source.split('\n');
    const anchors = [];
    const used = new Map();
    let inCodeFence = false;

    for (const line of lines) {
        const trimmed = line.trim();
        if (trimmed.startsWith('```')) {
            inCodeFence = !inCodeFence;
            continue;
        }
        if (inCodeFence) continue;

        const match = trimmed.match(/^(#{1,6})\s+(.+)$/);
        if (!match) continue;

        const level = match[1].length;
        const title = normalizeHeadingText(match[2]);
        if (!title) continue;

        const baseAnchor = toHeadingAnchor(title);
        const count = used.get(baseAnchor) || 0;
        used.set(baseAnchor, count + 1);
        const anchor = count > 0 ? `${baseAnchor}-${count + 1}` : baseAnchor;

        anchors.push({ level, title, anchor });
    }

    return anchors;
}

function applyRenderedHeadingAnchors() {
    const renderView = document.getElementById('render-view');
    if (!renderView) return [];

    const headings = Array.from(renderView.querySelectorAll('h1, h2, h3, h4, h5, h6'));
    const used = new Map();
    return headings.map(el => {
        const title = normalizeHeadingText(el.textContent || '');
        const baseAnchor = toHeadingAnchor(title);
        const count = used.get(baseAnchor) || 0;
        used.set(baseAnchor, count + 1);
        const anchor = count > 0 ? `${baseAnchor}-${count + 1}` : baseAnchor;

        el.dataset.noteAnchor = anchor;
        if (!el.id || el.id.startsWith('note-anchor-')) {
            el.id = `note-anchor-${anchor}`;
        }

        return { anchor, element: el };
    });
}

function setActiveTeacherNoteCard(anchor) {
    const panel = document.getElementById('teacher-notes-panel');
    if (!panel) return;
    panel.querySelectorAll('[data-note-card]').forEach(card => {
        const isActive = card.dataset.anchor === anchor;
        card.classList.toggle('border-accent/60', isActive);
        card.classList.toggle('bg-accent/10', isActive);
        card.classList.toggle('border-gray-200', !isActive);
        card.classList.toggle('bg-white', !isActive);
    });
}

function bindTeacherNotesScrollSync() {
    cleanupTeacherNotesScrollSync();

    const area = document.getElementById('editor-content-area');
    const renderView = document.getElementById('render-view');
    const panel = document.getElementById('teacher-notes-panel');
    if (!area || !renderView || !panel || panel.classList.contains('hidden')) return;

    const keepActiveCardVisible = (anchor) => {
        if (!anchor) return;
        const card = panel.querySelector(`[data-note-card][data-anchor="${cssEscape(anchor)}"]`);
        if (!card) return;
        const panelRect = panel.getBoundingClientRect();
        const cardRect = card.getBoundingClientRect();
        const topBuffer = panelRect.top + 54;
        const bottomBuffer = panelRect.bottom - 18;
        if (cardRect.top < topBuffer || cardRect.bottom > bottomBuffer) {
            card.scrollIntoView({ block: 'center', behavior: 'auto' });
        }
    };

    const updateActiveCard = () => {
        const headingEls = Array.from(renderView.querySelectorAll('h1[data-note-anchor], h2[data-note-anchor], h3[data-note-anchor], h4[data-note-anchor], h5[data-note-anchor], h6[data-note-anchor]'));
        if (headingEls.length === 0) return;

        const threshold = 170;
        let activeAnchor = headingEls[0].dataset.noteAnchor || '';
        for (const el of headingEls) {
            if (el.getBoundingClientRect().top <= threshold) {
                activeAnchor = el.dataset.noteAnchor || activeAnchor;
            } else {
                break;
            }
        }
        setActiveTeacherNoteCard(activeAnchor);
        keepActiveCardVisible(activeAnchor);
    };

    const onPanelWheel = (event) => {
        if (Math.abs(event.deltaY) < Math.abs(event.deltaX)) return;
        if (area.scrollHeight <= area.clientHeight) return;
        event.preventDefault();
        area.scrollTop += event.deltaY;
    };

    area.addEventListener('scroll', updateActiveCard, { passive: true });
    panel.addEventListener('wheel', onPanelWheel, { passive: false });
    window.addEventListener('resize', updateActiveCard);
    teacherNotesScrollCleanup = () => {
        area.removeEventListener('scroll', updateActiveCard);
        panel.removeEventListener('wheel', onPanelWheel);
        window.removeEventListener('resize', updateActiveCard);
    };
    updateActiveCard();
}

function renderTeacherNotesPanel(mod) {
    const panel = document.getElementById('teacher-notes-panel');
    if (!panel || !mod || !mod.content) return;

    ensureTeacherNotesArray(mod);
    const headings = extractMarkdownHeadingAnchors(mod.content);
    const notesByAnchor = new Map(mod.teacherNotes.map(item => [item.anchor, item.note]));
    const headingAnchorSet = new Set(headings.map(h => h.anchor));
    const staleNotes = mod.teacherNotes.filter(item => !headingAnchorSet.has(item.anchor));

    if (headings.length === 0) {
        panel.innerHTML = `
            <div class="p-4 text-xs text-gray-500">
                <div class="font-semibold text-gray-700 mb-1">교사용 노트</div>
                <p>헤딩이 없는 문서입니다. 먼저 섹션 헤딩을 추가해 주세요.</p>
            </div>
        `;
        return;
    }

    panel.innerHTML = `
        <div class="p-3 border-b border-gray-200 bg-gradient-to-r from-slate-50 to-indigo-50 sticky top-0 z-10">
            <div class="text-[0.68rem] font-semibold tracking-wide text-indigo-700 uppercase">교사용 노트</div>
            <p class="mt-1 text-[0.68rem] text-gray-600 leading-relaxed">섹션별 설명을 적어두시면 내보내기 시 교사용 문서에만 포함됩니다.</p>
        </div>
        <div class="p-3 space-y-2.5" id="teacher-notes-list">
            ${headings.map(item => {
        const safeAnchor = escapeHtmlAttr(item.anchor);
        const safeTitle = escapeHtmlAttr(item.title);
        const safeNote = escapeHtmlAttr(notesByAnchor.get(item.anchor) || '');
        return `
                    <section data-note-card data-anchor="${safeAnchor}" class="rounded-lg border border-gray-200 bg-white p-2.5 transition-colors">
                        <button type="button" data-jump-anchor="${safeAnchor}" class="w-full text-left text-[0.68rem] font-semibold text-gray-700 hover:text-accent transition-colors">
                            H${item.level}. ${safeTitle}
                        </button>
                        <textarea data-note-input="${safeAnchor}" class="mt-2 w-full min-h-[84px] rounded-md border border-gray-200 bg-gray-50 p-2 text-[0.68rem] leading-relaxed text-gray-700 focus:bg-white focus:border-accent/40 focus:ring-1 focus:ring-accent/30 outline-none resize-y" placeholder="이 섹션에서 강조할 포인트를 입력해 주세요...">${safeNote}</textarea>
                        <div class="mt-2 flex items-center justify-end gap-1.5">
                            <button type="button" data-save-note="${safeAnchor}" class="px-2 py-1 text-[0.62rem] font-semibold rounded border border-emerald-300 text-emerald-700 bg-emerald-50 hover:bg-emerald-100 transition-colors">저장</button>
                            <button type="button" data-delete-note="${safeAnchor}" class="px-2 py-1 text-[0.62rem] font-semibold rounded border border-rose-300 text-rose-700 bg-rose-50 hover:bg-rose-100 transition-colors">삭제</button>
                        </div>
                    </section>
                `;
    }).join('')}
            ${staleNotes.length > 0 ? `
                <div class="mt-3 border-t border-dashed border-orange-300 pt-3">
                    <div class="text-[0.62rem] font-semibold text-orange-700 mb-1">연결 끊긴 노트</div>
                    <div class="space-y-1.5">
                        ${staleNotes.map(item => `
                            <div class="rounded-md border border-orange-200 bg-orange-50 px-2 py-1.5 text-[0.62rem] text-orange-800">
                                <div class="font-semibold">${escapeHtmlAttr(item.anchor)}</div>
                                <div class="mt-0.5 whitespace-pre-wrap">${escapeHtmlAttr(item.note)}</div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            ` : ''}
        </div>
    `;

    panel.querySelectorAll('[data-jump-anchor]').forEach(btn => {
        btn.onclick = () => {
            const anchor = btn.dataset.jumpAnchor || '';
            const headingEl = document.querySelector(`#render-view [data-note-anchor="${cssEscape(anchor)}"]`);
            if (headingEl) {
                headingEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
                setActiveTeacherNoteCard(anchor);
            }
        };
    });

    panel.querySelectorAll('[data-save-note]').forEach(btn => {
        btn.onclick = () => {
            const anchor = btn.dataset.saveNote || '';
            const textarea = panel.querySelector(`[data-note-input="${cssEscape(anchor)}"]`);
            if (!textarea) return;

            const noteText = textarea.value.trim();
            ensureTeacherNotesArray(mod);
            const existingIdx = mod.teacherNotes.findIndex(item => item.anchor === anchor);
            if (noteText) {
                if (existingIdx >= 0) mod.teacherNotes[existingIdx].note = noteText;
                else mod.teacherNotes.push({ anchor, note: noteText });
                window.showToast('교사용 노트를 저장했습니다.');
            } else if (existingIdx >= 0) {
                mod.teacherNotes.splice(existingIdx, 1);
                window.showToast('빈 노트를 삭제했습니다.');
            } else {
                return;
            }

            saveState();
            renderTeacherNotesPanel(mod);
            bindTeacherNotesScrollSync();
        };
    });

    panel.querySelectorAll('[data-delete-note]').forEach(btn => {
        btn.onclick = () => {
            const anchor = btn.dataset.deleteNote || '';
            ensureTeacherNotesArray(mod);
            const existingIdx = mod.teacherNotes.findIndex(item => item.anchor === anchor);
            if (existingIdx === -1) return;
            mod.teacherNotes.splice(existingIdx, 1);
            saveState();
            window.showToast('교사용 노트를 삭제했습니다.');
            renderTeacherNotesPanel(mod);
            bindTeacherNotesScrollSync();
        };
    });
}

function collectReferencedLocalImageIds(text) {
    const ids = new Set();
    const regex = /local:([a-zA-Z0-9_\-%:.]+)/g;
    let match;
    while ((match = regex.exec(text)) !== null) {
        const rawId = match[1] || '';
        const cleanId = rawId.replace(/[)\]"'>]+$/g, '');
        if (cleanId) ids.add(cleanId);
    }
    return Array.from(ids);
}

async function buildRenderTextAsync(rawText, images, jobId) {
    let renderText = rawText || '';
    if (!renderText) return '';

    if (images && typeof images === 'object' && !Array.isArray(images) && renderText.includes('local:')) {
        const referencedIds = collectReferencedLocalImageIds(renderText);
        const needsChunk = referencedIds.length > 30;

        for (let i = 0; i < referencedIds.length; i++) {
            if (jobId !== activeEditorRenderJob) return null;
            const imgId = referencedIds[i];
            const b64 = images[imgId];
            if (typeof b64 === 'string' && b64.length > 0) {
                const regex = new RegExp(`local:${escapeRegExp(imgId)}`, 'g');
                renderText = renderText.replace(regex, b64);
            }
            if (needsChunk && i % 15 === 14) {
                await nextAnimationFrame();
            }
        }
    }

    // 잔존 미처리 local: 마크업은 렌더 단계에서 방어
    renderText = renderText.replace(/src="local:[^"]+"/g, 'src="" alt="[이미지 생성 필요]"');
    renderText = renderText.replace(/\(local:[^\)]+\)/g, '()');

    return renderText;
}

async function renderMarkdownInView(mod, rawText, options = {}) {
    const renderView = document.getElementById('render-view');
    if (!renderView || !mod) return;

    const jobId = ++activeEditorRenderJob;
    const source = typeof rawText === 'string' ? rawText : (mod.content || '');
    const isHeavy = source.length > 25000 || Object.keys(mod.images || {}).length > 40;

    if (isHeavy) {
        renderView.innerHTML = `<div class="p-4 bg-slate-500/20 border border-slate-500 text-slate-100 rounded">대용량 문서를 렌더링 중입니다...</div>`;
        await nextAnimationFrame();
    }

    const renderText = await buildRenderTextAsync(source, mod.images, jobId);
    if (renderText === null || jobId !== activeEditorRenderJob) return;

    let htmlContent = '';
    try {
        htmlContent = typeof marked !== 'undefined'
            ? marked.parse(renderText)
            : `<pre class="text-gray-200 whitespace-pre-wrap">${renderText.replace(/</g, '&lt;')}</pre>`;
    } catch (e) {
        htmlContent = `<div class="p-4 bg-red-500/20 border border-red-500 text-red-400 rounded">마크다운 파싱 오류: ${e.message}</div><pre class="text-gray-200 mt-4">${renderText.replace(/</g, '&lt;')}</pre>`;
    }

    if (jobId !== activeEditorRenderJob) return;
    renderView.innerHTML = htmlContent;

    applyRenderedHeadingAnchors();
    renderTeacherNotesPanel(mod);
    bindTeacherNotesScrollSync();

    if (window.mermaid) {
        setTimeout(() => {
            try {
                window.mermaid.init(undefined, renderView.querySelectorAll('.mermaid'));
            } catch (err) {
                console.warn('Mermaid rendering failed:', err);
            }
        }, 50);
    }

    const formatReport = typeof window.renderFormatLintBanner === 'function'
        ? window.renderFormatLintBanner(mod, { toast: !!options.showLintToast })
        : null;
    const imageStatus = typeof window.renderImageSearchStatusBanner === 'function'
        ? window.renderImageSearchStatusBanner(mod)
        : null;
    const qualityState = typeof window.renderQualityEvaluationBanner === 'function'
        ? window.renderQualityEvaluationBanner(mod, { toast: !!options.showQualityToast })
        : null;
    if (typeof window.renderLessonInfoSummary === 'function') {
        window.renderLessonInfoSummary(mod, {
            formatReport,
            imageStatus,
            quality: qualityState
        });
    }
    if (typeof window.syncLessonInfoPanelState === 'function') {
        window.syncLessonInfoPanelState(String(mod.id || 'unknown'));
    }
}

function renderEditor(mod) {

    const area = document.getElementById('editor-content-area');

    const cmdBar = document.getElementById('ai-command-bar');
    const namingPreviewFileName = escapeHtmlAttr(getNamingConventionPreviewFileName(mod));
    const lessonInfoPanelKey = escapeHtmlAttr(String(mod.id || 'unknown'));



    if (!mod.content) {
        // 현재 렌더 작업 취소 (이전 비동기 렌더 결과가 뒤늦게 덮어쓰는 것 방지)
        activeEditorRenderJob++;
        cleanupTeacherNotesScrollSync();

        area.innerHTML = `

                    <div class="h-full flex flex-col items-center justify-center text-center animate-fade-in p-8">

                        <i class="ph-duotone ${mod.id === 'mainQuest' ? 'ph-crown text-yellow-400/30' : 'ph-file-dashed text-white/20'} text-6xl mb-4"></i>

                        <h2 class="text-xl font-bold text-white mb-2">${mod.title}</h2>

                        <p class="text-textMuted text-sm mb-6">아직 교안 내용이 생성되지 않았습니다</p>

                        <button onclick="${mod.id === 'mainQuest' ? 'promptAndGenerateMainQuest()' : `promptAndGenerateModule(${mod.id})`}" class="px-6 py-2.5 bg-accent hover:bg-accentHover text-white font-bold rounded-lg shadow-lg transition-colors flex items-center gap-2">

                            <i class="ph-bold ph-sparkle"></i> AI 교안 생성 시작하기

                        </button>

                    </div>

                `;

        cmdBar.classList.add('hidden');

        return;

    }

    ensureTeacherNotesArray(mod);
    cleanupTeacherNotesScrollSync();
    const lowQualityCount = Array.isArray(mod.qualityEvaluation?.lowDimensions) ? mod.qualityEvaluation.lowDimensions.length : 0;
    const canRunTargetedRefine = lowQualityCount > 0;
    const refineBtnClass = canRunTargetedRefine
        ? 'px-3 py-1.5 text-xs font-bold bg-rose-50 text-rose-600 border border-rose-200 rounded hover:bg-rose-100 flex items-center gap-1 transition-colors'
        : 'px-3 py-1.5 text-xs font-bold bg-gray-100 text-gray-400 border border-gray-200 rounded flex items-center gap-1 cursor-not-allowed';

    area.innerHTML = `

                <div class="sticky top-0 bg-bgEditor/95 backdrop-blur-sm border-b border-gray-200 z-30 shadow-sm">

                    <div class="p-4 flex justify-between items-center gap-3">

                        <div class="flex items-center gap-2 min-w-0">
                            <h2 class="font-bold text-gray-800 truncate pr-1">${mod.title}</h2>
                            <button type="button" onclick="openNamingConventionEditorModal()" title="파일명 컨벤션 편집"
                                class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md border border-gray-200 bg-white text-[0.68rem] text-gray-700 hover:border-accent hover:text-accent transition-colors shrink-0">
                                <i class="ph-bold ph-file-code text-[0.72rem]"></i>
                                <span class="font-mono">${namingPreviewFileName}</span>
                            </button>
                        </div>

                        <div class="flex items-center gap-2 shrink-0">

                            <button onclick="generateQuiz()" id="quiz-btn" class="px-3 py-1.5 text-xs font-bold bg-emerald-50 text-emerald-600 border border-emerald-200 rounded hover:bg-emerald-100 flex items-center gap-1 transition-colors"><i class="ph-fill ph-question"></i> 퀴즈 생성</button>
                            <button onclick="generateAllImagesInModule('${mod.id}')" id="img-batch-btn" class="px-3 py-1.5 text-xs font-bold bg-purple-50 text-purple-600 border border-purple-200 rounded hover:bg-purple-100 flex items-center gap-1 transition-colors hover:-translate-y-0.5"><i class="ph-bold ph-image-square"></i> 검색 이미지 찾기</button>
                            
                            <label class="cursor-pointer px-3 py-1.5 text-xs font-bold bg-blue-50 text-blue-600 border border-blue-200 rounded hover:bg-blue-100 flex items-center gap-1 transition-colors" title="에디터에 이미지 삽입">
                                <i class="ph-bold ph-image"></i> 이미지 삽입
                                <input type="file" accept="image/*" class="hidden" multiple onchange="handleImageInputSelect(event)">
                            </label>
                            <button onclick="runModuleQualityEvaluation()" id="quality-eval-btn" class="px-3 py-1.5 text-xs font-bold bg-indigo-50 text-indigo-600 border border-indigo-200 rounded hover:bg-indigo-100 flex items-center gap-1 transition-colors"><i class="ph-bold ph-shield-check"></i> 품질 점검</button>
                            <button onclick="runModuleQualityRefinement()" id="quality-refine-btn" ${canRunTargetedRefine ? '' : 'disabled'} class="${refineBtnClass}"><i class="ph-bold ph-magic-wand"></i> 집중 보완${canRunTargetedRefine ? ` (${lowQualityCount})` : ''}</button>

                            <div class="w-px h-4 bg-gray-300 mx-1"></div>

                            <div class="flex bg-gray-100 rounded p-1 border border-gray-200">

                                <button onclick="toggleEditorMode('view')" id="toggle-view" class="px-3 py-1 text-xs font-bold rounded bg-white text-gray-800 shadow-sm transition-all">보기</button>

                                <button onclick="toggleEditorMode('edit')" id="toggle-edit" class="px-3 py-1 text-xs font-bold rounded text-gray-500 hover:text-gray-800 transition-all">수정</button>

                            </div>

                        </div>

                    </div>

                    <div id="lesson-info-panel" class="mx-4 mb-3 border-t border-gray-100 pt-2">
                        <div class="rounded-lg border border-gray-200 bg-white overflow-hidden">
                            <div class="px-3 py-1.5 flex items-center justify-between gap-2">
                                <div class="inline-flex items-center gap-1.5 text-[0.68rem] font-bold text-gray-700 shrink-0">
                                    <i class="ph-fill ph-list-checks text-accent"></i>
                                    차시 정보
                                </div>
                                <div id="lesson-info-summary" class="min-w-0 flex-1 flex items-center justify-end gap-1 text-[0.62rem]"></div>
                                <button id="lesson-info-toggle-btn"
                                    type="button"
                                    data-lesson-info-key="${lessonInfoPanelKey}"
                                    onclick="toggleLessonInfoPanel(this.dataset.lessonInfoKey, this)"
                                    class="inline-flex items-center gap-1 px-2 py-0.5 rounded border border-gray-200 text-[0.65rem] font-semibold text-gray-600 hover:text-gray-800 hover:border-gray-300 transition-colors"
                                    aria-expanded="false">
                                    <span data-lesson-info-toggle-label>펼치기</span>
                                    <i data-lesson-info-toggle-caret class="ph-bold ph-caret-down text-[0.72rem]"></i>
                                </button>
                            </div>
                            <div id="lesson-info-body" class="hidden border-t border-gray-100 px-3 py-2 space-y-1.5">
                                <div id="tone-toolbar" class="flex items-center gap-2 flex-wrap">
                                    <span class="text-[0.6rem] font-bold text-gray-500 uppercase tracking-wider shrink-0 mr-1">문체</span>
                                    ${typeof TONE_PRESETS !== 'undefined' ? TONE_PRESETS.map(t =>
        `<button onclick="applyToneConversion('${t.id}')" data-tone="${t.id}" class="tone-btn px-2 py-1 text-[0.63rem] font-bold rounded-md border transition-all hover:scale-[1.02] hover:shadow-sm ${t.color}">${t.label}</button>`
    ).join('') : ''}
                                    <div class="w-px h-4 bg-gray-200 mx-1 shrink-0"></div>
                                    <span class="text-[0.6rem] font-bold text-gray-500 uppercase tracking-wider shrink-0 mr-1">분량</span>
                                    <button onclick="applyVolumeControl('shorter')" class="px-2 py-1 text-[0.63rem] font-bold rounded-md border transition-all hover:scale-[1.02] bg-cyan-500/10 text-cyan-600 border-cyan-500/25 hover:shadow-sm">짧게</button>
                                    <button onclick="applyVolumeControl('longer')" class="px-2 py-1 text-[0.63rem] font-bold rounded-md border transition-all hover:scale-[1.02] bg-orange-500/10 text-orange-600 border-orange-500/25 hover:shadow-sm">길게</button>
                                    <div id="tone-loading" class="hidden items-center gap-1.5 ml-1.5">
                                        <div class="w-3 h-3 border-2 border-accent/30 border-t-accent rounded-full animate-spin"></div>
                                        <span class="text-[0.62rem] font-bold text-accent" id="tone-loading-text">변환 중...</span>
                                    </div>
                                </div>
                                <div id="format-lint-banner" class="hidden"></div>
                                <div id="image-search-status-banner" class="hidden"></div>
                                <div id="quality-eval-banner" class="hidden"></div>
                            </div>
                        </div>
                    </div>

                </div>

                

                <div class="max-w-[1260px] mx-auto p-8 pb-32">
                    <div class="grid grid-cols-1 xl:grid-cols-[minmax(0,1fr)_320px] gap-6 items-start">
                        <div class="min-w-0">
                            <div id="render-view" class="markdown-body animate-fade-in"></div>
                            <textarea id="raw-view" class="hidden w-full h-[600px] p-6 font-mono text-sm bg-gray-900 text-gray-100 rounded-xl outline-none focus:ring-2 focus:ring-accent resize-y" spellcheck="false" onchange="saveRawContent()"></textarea>
                        </div>
                        <aside id="teacher-notes-panel" class="rounded-xl border border-gray-200 bg-white shadow-sm overflow-y-auto max-h-[calc(100vh-180px)] xl:sticky xl:top-24"></aside>
                    </div>
                </div>

            `;

    const rawView = document.getElementById('raw-view');
    if (rawView) rawView.value = mod.content || '';
    if (typeof window.renderLessonInfoSummary === 'function') {
        window.renderLessonInfoSummary(mod, {});
    }
    if (typeof window.syncLessonInfoPanelState === 'function') {
        window.syncLessonInfoPanelState(String(mod.id || 'unknown'));
    }

    cmdBar.classList.remove('hidden');
    toggleEditorMode('view');

    // 인라인 에디팅 기능 활성화 (약간의 지연 후 렌더 트리가 안전할 때)
    setTimeout(() => initInlineEditing(), 100);
}

window.initInlineEditing = function () {
    const renderView = document.getElementById('render-view');
    if (!renderView) return;

    // 중복 바인딩 방지
    renderView.removeEventListener('dblclick', handleInlineEditDblClick);
    renderView.addEventListener('dblclick', handleInlineEditDblClick);
};

function handleInlineEditDblClick(e) {
    const mod = getEditingModule();
    if (!mod || !mod.content || typeof marked === 'undefined') return;

    // 최상위 블록 엘리먼트 찾기 (p, h1~6, ul/ol, blockquote, table 등)
    const topLevelTarget = e.target.closest('#render-view > *');
    if (!topLevelTarget || topLevelTarget.isEditing) return;

    // 클릭된 DOM 자식 요소의 인덱스 추적 (마크다운 AST 토큰과의 매핑 목적)
    const children = Array.from(document.getElementById('render-view').children);
    const targetIndex = children.indexOf(topLevelTarget);
    if (targetIndex === -1) return;

    try {
        const tokens = marked.lexer(mod.content);
        let blockIndex = 0;
        let targetToken = null;

        // Space 및 주석(Comment) 등 렌더 뷰에 표시되지 않는 토큰 필터링 인덱스 추적
        for (let i = 0; i < tokens.length; i++) {
            const t = tokens[i];
            let generatesElement = t.type !== 'space';
            if (t.type === 'html' && t.raw.trim().startsWith('<!--')) generatesElement = false;

            if (generatesElement) {
                if (blockIndex === targetIndex) {
                    targetToken = t;
                    break;
                }
                blockIndex++;
            }
        }

        if (!targetToken) return;

        // 원시 마크다운(Raw Markdown) 기반으로 Textarea 생성
        const rawMarkdownText = targetToken.raw.trimEnd();

        topLevelTarget.classList.add('hidden');
        const ta = document.createElement('textarea');
        ta.className = 'w-full p-4 font-mono text-sm bg-gray-900 border border-accent/40 shadow-xl shadow-accent/10 text-gray-100 rounded-xl outline-none focus:ring-2 focus:ring-accent resize-y min-h-[100px] my-2 animate-fade-in';
        ta.value = rawMarkdownText;

        const saveAndRestore = () => {
            if (!topLevelTarget.isEditing) return;
            topLevelTarget.isEditing = false;

            const newMarkdown = ta.value.trimEnd();
            if (newMarkdown !== rawMarkdownText && newMarkdown) {
                // 원문을 AST 기반으로 완벽 재구성 (해당 블록만 새 문구로 치환)
                let newContent = "";
                let bIdx = 0;
                for (let t of tokens) {
                    let generatesElem = t.type !== 'space';
                    if (t.type === 'html' && t.raw.trim().startsWith('<!--')) generatesElem = false;

                    if (generatesElem) {
                        if (bIdx === targetIndex) {
                            newContent += newMarkdown + (t.raw.endsWith('\\n') ? '' : '\\n');
                        } else {
                            newContent += t.raw;
                        }
                        bIdx++;
                    } else {
                        newContent += t.raw;
                    }
                }

                mod.content = newContent;
                mod.imageSearchReport = null;
                if (typeof window.invalidateModuleQualityEvaluation === 'function') {
                    window.invalidateModuleQualityEvaluation(mod);
                }
                saveState().then(() => renderEditor(mod)); // 전체 리렌더링
                return;
            }

            // 변경사항 없으면 복구
            ta.remove();
            topLevelTarget.classList.remove('hidden');
        };

        ta.onblur = saveAndRestore;
        ta.onkeydown = (ev) => {
            // Shift + Enter 를 허용하고, 그냥 Enter 는 저장
            if (ev.key === 'Enter' && !ev.shiftKey) {
                ev.preventDefault();
                ta.blur();
            } else if (ev.key === 'Escape') {
                ta.value = rawMarkdownText;
                ta.blur();
            }
        };

        topLevelTarget.parentNode.insertBefore(ta, topLevelTarget.nextSibling);
        topLevelTarget.isEditing = true;
        ta.focus();

    } catch (err) {
        console.error("인라인 편집 매핑 오류:", err);
    }
}


window.toggleEditorMode = function (mode) {

    const renderView = document.getElementById('render-view');

    const rawView = document.getElementById('raw-view');

    const btnView = document.getElementById('toggle-view');

    const btnEdit = document.getElementById('toggle-edit');
    const notesPanel = document.getElementById('teacher-notes-panel');



    if (!renderView || !rawView) return;



    if (mode === 'edit') {
        // 보기 모드에서 진행 중인 비동기 렌더 작업을 즉시 취소
        activeEditorRenderJob++;
        cleanupTeacherNotesScrollSync();

        renderView.classList.add('hidden');

        rawView.classList.remove('hidden');
        if (notesPanel) notesPanel.classList.add('hidden');

        btnEdit.classList.add('bg-white', 'text-gray-800', 'shadow-sm');

        btnEdit.classList.remove('text-gray-500');

        btnView.classList.remove('bg-white', 'text-gray-800', 'shadow-sm');

        btnView.classList.add('text-gray-500');

    } else {

        renderView.classList.remove('hidden');

        rawView.classList.add('hidden');
        if (notesPanel) notesPanel.classList.remove('hidden');

        btnView.classList.add('bg-white', 'text-gray-800', 'shadow-sm');

        btnView.classList.remove('text-gray-500');

        btnEdit.classList.remove('bg-white', 'text-gray-800', 'shadow-sm');

        btnEdit.classList.add('text-gray-500');



        const mod = getEditingModule();

        if (mod) {
            renderMarkdownInView(mod, rawView.value, { showLintToast: false });

        } else {
            cleanupTeacherNotesScrollSync();
        }

    }

}



window.saveRawContent = function () {

    const rawView = document.getElementById('raw-view');

    const mod = getEditingModule();

    if (mod && rawView) {

        const prevContent = typeof mod.content === 'string' ? mod.content : '';
        mod.content = rawView.value;
        if (prevContent !== mod.content && typeof window.invalidateModuleQualityEvaluation === 'function') {
            window.invalidateModuleQualityEvaluation(mod);
        }



        // [가비지 컬렉션] 텍스트에서 삭제된 이미지 데이터 찌꺼기를 찾아 완전 삭제 (용량 확보)

        if (mod.images) {

            for (const imgId in mod.images) {

                if (!mod.content.includes(`local:${imgId}`)) {

                    delete mod.images[imgId];

                }

            }

        }

        saveState();

    }

}



window.switchAIMode = function (mode) {

    aiCommandMode = mode;

    const btnEdit = document.getElementById('mode-btn-edit');

    const btnImg = document.getElementById('mode-btn-image');

    const input = document.getElementById('ai-command-input');



    if (mode === 'edit') {

        btnEdit.className = 'px-3 py-1.5 text-xs font-bold rounded-md transition-all bg-accent text-white';

        btnImg.className = 'px-3 py-1.5 text-xs font-bold rounded-md transition-all text-gray-400 hover:text-white';

        input.placeholder = '텍스트를 드래그하여 선택 후 요청사항을 입력하세요...';

    } else {

        btnImg.className = 'px-3 py-1.5 text-xs font-bold rounded-md transition-all bg-accent text-white';

        btnEdit.className = 'px-3 py-1.5 text-xs font-bold rounded-md transition-all text-gray-400 hover:text-white';

        input.placeholder = '생성할 이미지에 대한 설명을 입력하세요...';

    }

}



window.executeAICommand = async function () {

    const input = document.getElementById('ai-command-input');
    const btn = document.getElementById('ai-command-send');
    const command = input.value.trim();
    if (!command) return;

    const renderView = document.getElementById('render-view');
    const rawView = document.getElementById('raw-view');
    if (!rawView) return;

    // ── 1. 실행 전 선택 텍스트 캡처 (보기 모드 / 수정 모드 양쪽 지원) ──
    let capturedSelection = '';
    let selStart = -1;
    let selEnd = -1;
    const isViewMode = renderView && !renderView.classList.contains('hidden');

    if (aiCommandMode === 'edit') {
        if (isViewMode) {
            // 보기 모드: UI에서 캡처해둔 텍스트 우선 사용, 없으면 현재 드래그 영역 사용
            if (window.currentCapturedSelection) {
                capturedSelection = window.currentCapturedSelection;
            } else {
                const sel = window.getSelection();
                capturedSelection = sel ? sel.toString().trim() : '';
            }
        } else {
            // 수정 모드: raw-view textarea 선택 범위 직접 사용
            selStart = rawView.selectionStart;
            selEnd = rawView.selectionEnd;
            capturedSelection = rawView.value.substring(selStart, selEnd).trim();
        }
        if (!capturedSelection) {
            return window.showAlert('수정할 텍스트를 먼저 드래그하여 선택해주세요.');
        }
    }

    // ── 2. 수정 모드로 전환하여 raw-view 접근 확보 ──
    toggleEditorMode('edit');

    // 보기 모드에서 캡처한 선택 텍스트를 raw 원문에서 위치 매핑
    if (aiCommandMode === 'edit' && isViewMode && capturedSelection) {
        const rawText = rawView.value;
        // HTML 태그/엔티티 제거된 순수 텍스트로 검색 (렌더링 산물 차이 보정)
        const plainCapture = capturedSelection.replace(/\s+/g, ' ');

        // 1차: 원문에서 그대로 검색
        let idx = rawText.indexOf(capturedSelection);

        // 2차: 공백 정규화 후 재시도
        if (idx === -1) {
            const normalizedRaw = rawText.replace(/\s+/g, ' ');
            const normIdx = normalizedRaw.indexOf(plainCapture);
            if (normIdx !== -1) {
                // 정규화 인덱스를 원본 인덱스로 역변환 (근사치)
                let count = 0, origIdx = 0;
                for (let i = 0; i < rawText.length && count < normIdx; i++) {
                    if (rawText[i] === normalizedRaw[count]) count++;
                    origIdx = i + 1;
                }
                idx = origIdx > 0 ? origIdx - 1 : 0;
            }
        }

        if (idx !== -1) {
            selStart = idx;
            // 원본에서 캡처 텍스트의 실제 끝 위치 (줄바꿈 포함 원본 기준)
            const remaining = rawText.substring(idx);
            // 캡처 텍스트의 각 단어를 순서대로 매칭하여 끝 위치 산출
            let endSearch = idx + capturedSelection.length;
            // 보수적 확장: 마크다운 기호 등으로 인한 오프셋 보정
            const snippet = rawText.substring(idx, Math.min(idx + capturedSelection.length + 50, rawText.length));
            const lastWordMatch = capturedSelection.split(/\s+/).pop();
            if (lastWordMatch) {
                const lwIdx = snippet.lastIndexOf(lastWordMatch);
                if (lwIdx !== -1) endSearch = idx + lwIdx + lastWordMatch.length;
            }
            selEnd = Math.min(endSearch, rawText.length);
        } else {
            // 매핑 실패 시 사용자에게 수정 모드 안내
            return window.showAlert('선택한 텍스트를 원문에서 찾지 못했습니다.\n"수정" 탭에서 직접 텍스트를 선택한 뒤 다시 시도해주세요.');
        }
    }

    input.disabled = true;
    btn.innerHTML = '<i class="ph-bold ph-spinner animate-spin"></i>';

    try {
        if (aiCommandMode === 'edit') {
            if (selStart === selEnd || selStart < 0) throw new Error("수정할 텍스트를 영역 선택해주세요.");

            const text = rawView.value;
            const selectedText = text.substring(selStart, selEnd);
            const context = text.substring(Math.max(0, selStart - 300), selStart);

            const { systemInstruction, userPrompt } = buildTaskContext('edit', { context, selectedText, command });

            const res = await fetchWithRetry(
                `https://generativelanguage.googleapis.com/v1beta/models/${TEXT_MODEL}:generateContent?key=${apiKey}`,
                {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        contents: [{ parts: [{ text: userPrompt }] }],
                        systemInstruction: { parts: [{ text: systemInstruction }] }
                    })
                }
            );

            let newText = extractText(res);
            newText = newText.replace(/^```\w*\n?/i, '').replace(/\n?```$/i, '').trim();

            rawView.value = text.substring(0, selStart) + newText + text.substring(selEnd);

            if (typeof clearAISelection === 'function') clearAISelection();

        } else if (aiCommandMode === 'image') {
            const b64 = await generateImageAPI(command);
            if (b64) {
                const mod = getEditingModule();
                if (!mod.images) mod.images = {};
                const imgId = 'img_' + Date.now() + Math.floor(Math.random() * 1000);
                mod.images[imgId] = b64;
                const safeCommand = escapeHtmlAttr(command || '');
                const encodedCommand = encodeURIComponent(command || '').replace(/'/g, '%27');
                const imgTag = `\n<div class="image-wrapper"><img src="local:${imgId}" alt="${command}" class="rounded-lg border-2 border-accent/30 shadow-md max-w-full"><span class="absolute bottom-3 left-3 bg-black/80 text-white text-[0.6rem] px-2 py-1 rounded border border-white/20 flex items-center gap-1 pointer-events-none"><i class="ph-fill ph-sparkle text-accent"></i> AI 생성 이미지</span><button class="image-regenerate-btn px-3 py-1.5 text-xs text-white font-bold rounded flex items-center gap-1 border border-accent/50 hover:bg-accent transition-colors" onclick="promptRegenerateImage(this, '${command}', '${imgId}')"><i class="ph-bold ph-arrows-clockwise"></i> 다시 생성</button></div>\n`;

                const text = rawView.value;
                // 보기 모드에서 진입한 경우 커서가 0이므로 문서 끝에 삽입
                const pos = (isViewMode || rawView.selectionStart === 0) ? text.length : rawView.selectionStart;
                rawView.value = text.substring(0, pos) + imgTag + text.substring(pos);
            } else {
                window.showAlert('이미지 생성에 실패했습니다.');
            }
        }

        // 저장 후 보기 모드로 복귀하여 렌더링 결과 표시
        saveRawContent();
        toggleEditorMode('view');
        input.value = '';
        window.showAlert(aiCommandMode === 'edit' ? '✅ 텍스트 수정 완료!' : '✅ 이미지 삽입 완료!');

    } catch (err) {
        window.showAlert(err.message || '명령 실행 중 오류 발생');
    } finally {
        input.disabled = false;
        btn.innerHTML = '실행';
        input.focus();
    }
}



// ===== 문체 변환 (Tone Conversion) =====
window.applyToneConversion = async function (toneId) {
    const mod = getEditingModule();
    if (!mod || !mod.content) {
        return window.showAlert('변환할 교안 콘텐츠가 없습니다.');
    }

    const preset = typeof TONE_PRESETS !== 'undefined' ? TONE_PRESETS.find(t => t.id === toneId) : null;
    if (!preset) return window.showAlert('알 수 없는 문체입니다.');

    window.showConfirm(
        `"${preset.label}" 문체로 전체 교안을 변환합니다.\n원본은 히스토리에 자동 저장됩니다. 계속할까요?`,
        async () => {
            const loadingEl = document.getElementById('tone-loading');
            const loadingText = document.getElementById('tone-loading-text');
            const allBtns = document.querySelectorAll('#tone-toolbar button');

            if (loadingEl) { loadingEl.classList.remove('hidden'); loadingEl.classList.add('flex'); }
            if (loadingText) loadingText.textContent = `${preset.label} 변환 중...`;
            allBtns.forEach(b => { b.disabled = true; b.style.opacity = '0.4'; b.style.pointerEvents = 'none'; });

            try {
                if (typeof archiveContent === 'function') archiveContent(mod, '문체 변환 전 백업');

                const { systemInstruction, userPrompt } = buildTaskContext('tone', {
                    tonePrompt: preset.prompt,
                    content: mod.content
                });

                const payload = {
                    contents: [{ parts: [{ text: userPrompt }] }],
                    systemInstruction: { parts: [{ text: systemInstruction }] }
                };

                const data = await fetchWithRetry(
                    `https://generativelanguage.googleapis.com/v1beta/models/${TEXT_MODEL}:generateContent?key=${apiKey}`,
                    { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }
                );

                let resultText = extractText(data);
                if (resultText && resultText.trim().length > 50) {
                    // 모델이 마크다운 블록(```)으로 감싸서 리턴할 경우 제거하는 전처리 로직
                    resultText = resultText.replace(/^```\w*\n?/i, '').replace(/\n?```$/i, '').trim();
                    mod.content = resultText;
                    if (typeof window.invalidateModuleQualityEvaluation === 'function') {
                        window.invalidateModuleQualityEvaluation(mod);
                    }
                    await saveState();
                    renderEditor(mod);
                    window.showAlert(`✅ "${preset.label}" 문체로 변환 완료!`);
                } else {
                    window.showAlert('변환 결과가 너무 짧습니다. 다시 시도해 주세요.');
                }
            } catch (err) {
                console.error('문체 변환 실패:', err);
                window.showAlert('문체 변환 중 오류: ' + (err.message || '알 수 없는 오류'));
            } finally {
                if (loadingEl) { loadingEl.classList.add('hidden'); loadingEl.classList.remove('flex'); }
                allBtns.forEach(b => { b.disabled = false; b.style.opacity = '1'; b.style.pointerEvents = ''; });
            }
        }
    );
}


// ===== 분량 조절 (Volume Control) =====
window.applyVolumeControl = async function (direction) {
    const mod = getEditingModule();
    if (!mod || !mod.content) {
        return window.showAlert('조절할 교안 콘텐츠가 없습니다.');
    }

    const preset = typeof VOLUME_PRESETS !== 'undefined' ? VOLUME_PRESETS[direction] : null;
    if (!preset) return window.showAlert('알 수 없는 분량 옵션입니다.');

    window.showConfirm(
        `교안을 "${preset.label}" 방향으로 조절합니다.\n원본은 히스토리에 자동 저장됩니다. 계속할까요?`,
        async () => {
            const loadingEl = document.getElementById('tone-loading');
            const loadingText = document.getElementById('tone-loading-text');
            const allBtns = document.querySelectorAll('#tone-toolbar button');

            if (loadingEl) { loadingEl.classList.remove('hidden'); loadingEl.classList.add('flex'); }
            if (loadingText) loadingText.textContent = `${preset.label} 조절 중...`;
            allBtns.forEach(b => { b.disabled = true; b.style.opacity = '0.4'; b.style.pointerEvents = 'none'; });

            try {
                if (typeof archiveContent === 'function') archiveContent(mod, '분량 조절 전 백업');

                const { systemInstruction, userPrompt } = buildTaskContext('volume', {
                    volumePrompt: preset.prompt,
                    content: mod.content
                });

                const payload = {
                    contents: [{ parts: [{ text: userPrompt }] }],
                    systemInstruction: { parts: [{ text: systemInstruction }] }
                };

                const data = await fetchWithRetry(
                    `https://generativelanguage.googleapis.com/v1beta/models/${TEXT_MODEL}:generateContent?key=${apiKey}`,
                    { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }
                );

                let resultText = extractText(data);
                if (resultText && resultText.trim().length > 30) {
                    resultText = resultText.replace(/^```\w*\n?/i, '').replace(/\n?```$/i, '').trim();
                    const before = mod.content.length;
                    mod.content = resultText;
                    if (typeof window.invalidateModuleQualityEvaluation === 'function') {
                        window.invalidateModuleQualityEvaluation(mod);
                    }
                    const after = resultText.length;
                    const ratio = Math.round((after / before) * 100);
                    await saveState();
                    renderEditor(mod);
                    window.showAlert(`✅ 분량 조절 완료! (${before.toLocaleString()}자 → ${after.toLocaleString()}자, ${ratio}%)`);
                } else {
                    window.showAlert('분량 조절 결과가 비어 있습니다. 다시 시도해 주세요.');
                }
            } catch (err) {
                console.error('분량 조절 실패:', err);
                window.showAlert('분량 조절 중 오류: ' + (err.message || '알 수 없는 오류'));
            } finally {
                if (loadingEl) { loadingEl.classList.add('hidden'); loadingEl.classList.remove('flex'); }
                allBtns.forEach(b => { b.disabled = false; b.style.opacity = '1'; b.style.pointerEvents = ''; });
            }
        }
    );
}

// ===== 개별 이미지 문맥 파악 및 재생성 (Context-Aware Image Regeneration) =====
window.regenerateImage = function (imgId, btnEl) {
    if (!btnEl) return;
    const wrapper = btnEl.closest('.group');
    if (!wrapper) return;
    if (!wrapper.classList.contains('image-wrapper')) {
        wrapper.classList.add('image-wrapper');
    }

    let normalizedImgId = imgId;
    try {
        normalizedImgId = decodeURIComponent(imgId);
    } catch (e) {
        normalizedImgId = imgId;
    }

    const fallbackKeyword = extractContextForImage(normalizedImgId);
    window.promptRegenerateImage(btnEl, fallbackKeyword, normalizedImgId);
}


// ── Phase F3: 최종 서식 변환 (local: → 웹 URL 일괄) ──

window.showFormatConvertModal = function () {
    const subj = globalState.subjects.find(s => s.id === currentSubjectId);
    if (!subj) return window.showAlert('교과를 먼저 선택해 주세요.');

    // local: 이미지가 있는지 체크
    const allMods = [...(subj.lessons || [])];
    if (subj.mainQuest) allMods.push(subj.mainQuest);
    const hasLocal = allMods.some(m => m.content && m.content.includes('local:'));
    if (!hasLocal) return window.showAlert('변환할 local: 이미지 참조가 없습니다.');

    const modalHTML = `
        <div class="p-4 space-y-4">
            <p class="text-sm text-textMuted">현재 교과의 모든 차시 교안에서 <code>local:</code> 이미지 참조를 웹 URL로 일괄 변환합니다.</p>
            <div>
                <label class="block text-xs font-bold text-white/70 mb-1">① 이미지 폴더 URL (끝에 / 포함)</label>
                <input id="convert-base-url" type="text" placeholder="https://example.com/images/course01/"
                    class="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-accent transition-colors"
                    value="">
            </div>
            <div>
                <label class="block text-xs font-bold text-white/70 mb-1">② 파일명 컨벤션</label>
                <select id="convert-naming" class="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-accent">
                    <option value="sequential">순번 (image01.png, image02.png, ...)</option>
                    <option value="keep">원본 ID 유지 (img_xxxxx.png)</option>
                </select>
            </div>
            <div class="flex gap-2 justify-end mt-4">
                <button onclick="this.closest('.fixed').remove()"
                    class="px-4 py-2 text-sm text-white/60 bg-white/5 border border-white/10 rounded-lg hover:bg-white/10 transition-colors">취소</button>
                <button onclick="executeFormatConvert(this)"
                    class="px-4 py-2 text-sm font-bold text-white bg-accent hover:bg-accentHover rounded-lg transition-colors">변환 실행</button>
            </div>
        </div>
    `;
    window.showModal('🔄 최종 서식 변환 (local: → 웹 URL)', modalHTML);
};

window.executeFormatConvert = function (triggerEl) {
    const baseUrl = document.getElementById('convert-base-url').value.trim();
    const naming = document.getElementById('convert-naming').value;

    if (!baseUrl) return window.showAlert('이미지 웹 폴더 URL을 입력해 주세요.');
    const safeBaseUrl = baseUrl.endsWith('/') ? baseUrl : baseUrl + '/';

    const subj = globalState.subjects.find(s => s.id === currentSubjectId);
    if (!subj) return;

    const allMods = [...(subj.lessons || [])];
    if (subj.mainQuest) allMods.push(subj.mainQuest);

    let totalReplaced = 0;
    let imgCounter = 1;

    allMods.forEach(mod => {
        if (!mod.content || !mod.content.includes('local:')) return;
        const prevContent = mod.content;

        // local:imgId 패턴 추출
        const localRefs = [...new Set(mod.content.match(/local:img_[a-zA-Z0-9_]+/g) || [])];

        localRefs.forEach(ref => {
            const imgId = ref.substring(6); // 'local:' 제거
            let fileName;

            if (naming === 'sequential') {
                fileName = `image${String(imgCounter).padStart(2, '0')}.png`;
                imgCounter++;
            } else {
                fileName = `${imgId}.png`;
            }

            const webUrl = safeBaseUrl + fileName;

            // local:imgId → 웹 URL 교체
            mod.content = mod.content.split(`local:${imgId}`).join(webUrl);

            // image-wrapper div 구조를 최종 서식으로 변환
            // <div class="image-wrapper"><img src="URL" ...>...</div> -> <p align="center"><img></p>
            const wrapperRegex = new RegExp(
                `<div class="image-wrapper">\\s*<img src="${webUrl.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}"[^>]*alt="([^"]*)"[^>]*>[\\s\\S]*?</div>`,
                'g'
            );
            mod.content = mod.content.replace(wrapperRegex, (match, alt) => {
                return `\n<p align="center">\n  <img src="${webUrl}" alt="${alt}">\n</p>\n`;
            });

            totalReplaced++;
        });

        if (prevContent !== mod.content && typeof window.invalidateModuleQualityEvaluation === 'function') {
            window.invalidateModuleQualityEvaluation(mod);
        }
    });

    saveState().then(() => {
        if (currentEditingModuleId) {
            const mod = getEditingModule(currentEditingModuleId);
            if (mod) renderEditor(mod);
        }

        const overlay = triggerEl && typeof triggerEl.closest === 'function'
            ? triggerEl.closest('.fixed')
            : null;
        if (overlay) overlay.remove();
        window.showAlert(`✅ ${totalReplaced}개의 이미지 참조가 웹 URL로 변환되었습니다.`);
    });
};
