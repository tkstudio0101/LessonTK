﻿﻿



// ------------------------------------------------------------------------
// Marked.js 커스텀 렌더러 설정 (이미지 호버 재생성 UI 주입)
// ------------------------------------------------------------------------
if (typeof marked !== 'undefined') {
    const renderer = {
        code(codeArg, infostringArg, escapedArg) {
            // marked 최신 v8.0.0+ 에서는 첫 번째 인자에 token 객체가 넘어옵니다.
            let codeText = typeof codeArg === 'object' ? codeArg.text : codeArg;
            let infostring = typeof codeArg === 'object' ? codeArg.lang : infostringArg;

            if (infostring === 'mermaid') {
                return `<div class="mermaid">\n${codeText}\n</div>`;
            }
            // mermaid가 아닌 일반 코드 블록 폴백 처리
            const lang = (infostring || '').match(/\S*/)?.[0] || '';
            let escapedCode = codeText.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
            if (!lang) {
                return `<pre><code>${escapedCode}</code></pre>\n`;
            }
            return `<pre><code class="language-${lang}">${escapedCode}</code></pre>\n`;
        },
        image(hrefArg, titleArg, textArg) {
            let href = hrefArg;
            let title = titleArg;
            let text = textArg;
            if (hrefArg && typeof hrefArg === 'object') {
                // marked 최신 버전은 token 객체를 단일 인자로 전달할 수 있음
                href = hrefArg.href || hrefArg.url || '';
                title = hrefArg.title || '';
                text = hrefArg.text || hrefArg.alt || '';
            }
            href = typeof href === 'string' ? href : '';
            title = typeof title === 'string' ? title : '';
            text = typeof text === 'string' ? text : '';
            // 원본 이미지 파싱 결과 (URL 형태)
            // 내부 base64 매핑이 붙은경우, 나중에 renderEditor() 정규식 부분에서 교체될 것이므로 여기서는 그대로 둠

            // 이미지 ID 추적 (보통 local:xxxx-xxxx 형태)
            let imgIdToPass = href;
            if (href.startsWith('local:')) {
                imgIdToPass = href.substring(6); // 'local:' 접두사 제거
            } else {
                imgIdToPass = encodeURIComponent(href); // 외부 URL인 경우
            }
            const safeHref = escapeHtmlAttr(href);
            const safeTitle = escapeHtmlAttr(title || '');
            const safeText = escapeHtmlAttr(text || '');
            const encodedImgId = encodeURIComponent(imgIdToPass || '').replace(/'/g, '%27');

            return `
                <div class="image-wrapper relative group my-6 rounded-xl overflow-hidden shadow-lg border border-accent/20 bg-black/20" data-imgid="${encodedImgId}">
                    <img src="${safeHref}" alt="${safeText}" title="${safeTitle}" class="w-full h-auto object-cover max-h-[400px] transition-transform duration-500 group-hover:scale-[1.02]">
                    <div class="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-[2px]">
                        <button data-img-id="${encodedImgId}" onclick="regenerateImage(decodeURIComponent(this.dataset.imgId || ''), this)" class="px-4 py-2 bg-accent hover:bg-accentHover text-white font-bold rounded-lg shadow-xl shadow-accent/20 flex items-center gap-2 transform translate-y-4 group-hover:translate-y-0 transition-all duration-300">
                            <i class="ph-bold ph-arrows-clockwise text-lg"></i> 이미지 재생성                        </button>
                    </div>
                </div>
            `;
        }
    };
    marked.use({ renderer });
}

// ------------------------------------------------------------------------
// AI Logic & Other Editor Functions
// ------------------------------------------------------------------------

// [Step 3] 퀴즈 생성 로직 (generateQuiz)

window.generateQuiz = async function () {
    const mod = getEditingModule();
    if (!mod || !mod.content) return window.showAlert('교안 내용이 생성되지 않았습니다.');

    const view = document.getElementById('quiz-view');
    if (!view) return;

    view.innerHTML = `<div class="flex flex-col items-center justify-center py-16 gap-3 text-textMuted">
        <i class="ph-bold ph-spinner animate-spin text-3xl text-accent"></i>
        <span class="text-sm">학습 이해도 문항 생성 중...</span>
    </div>`;

    const { systemInstruction, userPrompt } = buildTaskContext('quiz', mod.content);
    const payload = {
        contents: [{ parts: [{ text: userPrompt }] }],
        systemInstruction: { parts: [{ text: systemInstruction }] }
    };

    try {
        const data = await fetchWithRetry(
            `https://generativelanguage.googleapis.com/v1beta/models/${TEXT_MODEL}:generateContent?key=${apiKey}`,
            { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }
        );
        const quizMd = extractText(data);
        mod.quizContent = quizMd;
        await saveState();
        renderQuizView(mod);
    } catch (e) {
        view.innerHTML = `<div class="text-center py-16 text-red-400 text-sm">생성 실패: ${e.message}</div>`;
    }
};

function renderQuizView(mod) {
    const view = document.getElementById('quiz-view');
    if (!view) return;
    if (!mod || !mod.quizContent) {
        view.innerHTML = `<div class="flex flex-col items-center justify-center py-20 gap-4 text-textMuted">
            <i class="ph-bold ph-question text-5xl opacity-30"></i>
            <p class="text-sm">아직 생성된 학습 이해도 문항이 없습니다.</p>
            <button onclick="generateQuiz()" class="mt-2 px-5 py-2 text-sm font-bold bg-emerald-600 text-white rounded-lg hover:bg-emerald-500 transition-colors flex items-center gap-2">
                <i class="ph-fill ph-question"></i> 학습 이해도 생성
            </button>
        </div>`;
        return;
    }
    view.innerHTML = `
        <div class="flex items-center justify-between mb-5">
            <h2 class="font-bold text-white text-base flex items-center gap-2">
                <i class="ph-fill ph-question text-emerald-400"></i> 학습 이해도
            </h2>
            <button onclick="generateQuiz()" class="px-3 py-1.5 text-xs font-bold bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 rounded hover:bg-emerald-600/40 transition-colors flex items-center gap-1">
                <i class="ph-bold ph-arrows-clockwise"></i> 재생성
            </button>
        </div>
        <div class="markdown-body prose prose-invert max-w-none text-sm leading-relaxed">
            ${marked.parse(mod.quizContent)}
        </div>`;
}
window.renderQuizView = renderQuizView;



// [Step 3] TTS 재생 로직 제거됨 (사용자 요청)









// ── F1-2: 핵심개념 팝업을 거쳐 교안 생성하는 래퍼 ──
window.promptAndGenerateModule = function (moduleId) {
    const mod = getEditingModule(moduleId);
    if (!mod) return;

    let existing = Array.isArray(mod.keyConcepts) ? [...mod.keyConcepts] : [];

    // 교사카드 별점 연동: importance 있는 항목이 있으면 티어 태그로 변환해 pre-fill
    if (mod.content && Array.isArray(mod.teacherNotes) && mod.teacherNotes.some(n => n.importance !== undefined)) {
        const headings = extractMarkdownHeadingAnchors(mod.content);
        const anchorToTitle = new Map(headings.map(h => [h.anchor, h.title]));
        const tiered = [];
        mod.teacherNotes.forEach(note => {
            if (note.importance === undefined) return;
            const title = anchorToTitle.get(note.anchor);
            if (!title) return;
            const imp = parseInt(note.importance, 10);
            tiered.push(`[★${imp}]${title}`);
        });
        if (tiered.length > 0) existing = tiered;
    }

    const label = mod.status === 'done' ? `재생성: ${mod.title}` : `교안 생성: ${mod.title}`;
    showKeyConceptsPrompt(label, existing, (concepts) => {
        generateModuleContent(moduleId, concepts);
    });
};

// ── F1-2: 메인퀘스트도 핵심개념 팝업 래퍼 ──
window.promptAndGenerateMainQuest = function () {
    const subj = globalState.subjects.find(s => s.id === currentSubjectId);
    if (!subj) return;
    const mq = subj.mainQuest;
    const existing = Array.isArray(mq?.keyConcepts) ? mq.keyConcepts : [];
    showKeyConceptsPrompt('메인 퀘스트 생성', existing, (concepts) => {
        if (concepts.length > 0 && mq) mq.keyConcepts = concepts;
        generateMainQuest();
    });
};





// --- Phase F10: Deep Research 검색 에이전트 서브루틴 ---

function getContextWindow(text, matchStr, windowSize = 300) {
    const idx = text.indexOf(matchStr);
    if (idx === -1) return "";
    const start = Math.max(0, idx - windowSize);
    const end = Math.min(text.length, idx + matchStr.length + windowSize);
    return text.substring(start, end).replace(/<!--.*?-->/g, '').replace(/[#*`_>]/g, '').trim();
}

async function extractSearchIntent(keyword, context) {
    const systemPrompt = `당신은 게임 기획 및 시장 분석 전문 리서처 AI입니다.
주어진 이미지 키워드의 주변 교안 문맥을 분석하여, 해당 맥락에 가장 적합한 시각 자료를 검색하기 위한 "최적의 검색 쿼리"를 생성하세요.

[중요 지시사항]
1. 텍스트 내 고유명사(게임명, 캐릭터명, 시스템명, 회사명 등)를 추출해 쿼리의 핵심으로 배치하세요.
2. 이미지 종류(일러스트, 게임 스크린샷, UI 목업, 매출 그래프 등)를 반영한 Modifier를 추가하세요.
3. 게임명 등 고유명사는 반드시 공식 번역명/표기를 사용하세요. 절대 직역하지 마세요.
   예: League of Legends → 리그 오브 레전드, Minecraft → 마인크래프트, Genshin Impact → 원신,
       Stardew Valley → 스타듀 밸리, Elden Ring → 엘든 링, Overwatch → 오버워치
4. 부정 연산자(-, NOT 등)는 절대 사용하지 마세요.
5. 쿼리는 핵심 키워드 2~4개로 간결하게 구성하세요.
6. 출력은 반드시 아래 JSON 스키마를 따르세요.

[출력 형식 JSON]
{
  "intent_type": "data_representation (데이터/표/차트인 경우) 또는 visual_asset (일러스트/UI/스크린샷인 경우)",
  "search_query_ko": "한국어 검색어 (공식 번역명 사용. 예: 리그 오브 레전드 팀파이트 스크린샷)",
  "search_query_en": "영문 검색어 (예: League of Legends teamfight gameplay screenshot)",
  "reasoning": "이 검색어로 결정한 이유 (한국어 짧게)"
}`;

    const userPrompt = `[문맥 추출 대상]\n키워드: ${keyword}\n\n[주변 문맥]\n${context}`;

    const payload = {
        contents: [{ role: "user", parts: [{ text: userPrompt }] }],
        systemInstruction: { parts: [{ text: systemPrompt }] },
        generationConfig: {
            temperature: 0.1, // 일관된 JSON 추출을 위해 낮은 온도값
            responseMimeType: "application/json"
        }
    };

    try {
        const response = await fetchWithRetry(
            `https://generativelanguage.googleapis.com/v1beta/models/${TEXT_MODEL}:generateContent?key=${apiKey}`,
            { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }
        );
        const textResp = extractText(response);
        return JSON.parse(textResp);
    } catch (e) {
        console.error("검색어 의도 추출 에이전트 실패:", e);
        return null; // 실패 시 기존 키워드 Fallback을 위해 Null 반환
    }
}
// [Phase F10] Convert remote image URL to base64 with direct-first strategy.
const IMAGE_BASE64_MAX_WIDTH = 800;
const IMAGE_BASE64_TIMEOUT_MS = 12000;
const IMAGE_FETCH_PROXY_BUILDERS = [
    { label: 'local-proxy', build: (url) => `http://localhost:3000/api/image-proxy?url=${encodeURIComponent(url)}` },
    { label: 'allorigins', build: (url) => `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}` },
    { label: 'weserv', build: (url) => `https://images.weserv.nl/?url=${encodeURIComponent(url.replace(/^https?:\/\//i, ''))}&output=jpg&q=85` },
    { label: 'corsproxy', build: (url) => `https://corsproxy.io/?${encodeURIComponent(url)}` }
];

function normalizeImageSourceUrl(imageUrl) {
    const raw = String(imageUrl || '').trim();
    if (!raw) return '';
    if (/^data:image\//i.test(raw)) return raw;
    if (raw.startsWith('//')) return `https:${raw}`;
    return raw;
}

function loadImageToDataURLViaCanvas(src, { timeoutMs = IMAGE_BASE64_TIMEOUT_MS, maxWidth = IMAGE_BASE64_MAX_WIDTH } = {}) {
    return new Promise((resolve, reject) => {
        const img = new Image();
        let settled = false;

        const clear = () => {
            if (timer) clearTimeout(timer);
            img.onload = null;
            img.onerror = null;
        };
        const fail = (err) => {
            if (settled) return;
            settled = true;
            clear();
            reject(err instanceof Error ? err : new Error(String(err || 'Image load failed')));
        };
        const succeed = (value) => {
            if (settled) return;
            settled = true;
            clear();
            resolve(value);
        };

        const timer = setTimeout(() => fail(new Error('Image load timeout')), Math.max(1000, timeoutMs));

        img.onload = () => {
            try {
                let width = Number(img.width || 0);
                let height = Number(img.height || 0);
                if (width <= 0 || height <= 0) throw new Error('Invalid image size');

                if (width > maxWidth) {
                    height = Math.round((height * maxWidth) / width);
                    width = maxWidth;
                }

                const canvas = document.createElement('canvas');
                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                if (!ctx) throw new Error('Canvas context unavailable');

                ctx.drawImage(img, 0, 0, width, height);
                const dataURL = canvas.toDataURL('image/jpeg', 0.85);
                if (!dataURL || !dataURL.startsWith('data:image/')) {
                    throw new Error('Canvas encode failed');
                }
                succeed(dataURL);
            } catch (err) {
                fail(err);
            }
        };
        img.onerror = () => fail(new Error('Image load failed'));

        if (/^https?:\/\//i.test(src)) {
            img.crossOrigin = 'anonymous';
            img.referrerPolicy = 'no-referrer';
        }
        img.src = src;
    });
}



async function loadImageToDataURLViaFetch(fetchUrl, opts = {}) {
    const blob = await fetchImageToBlob(fetchUrl, opts.timeoutMs || IMAGE_BASE64_TIMEOUT_MS);
    const objectUrl = URL.createObjectURL(blob);
    try {
        return await loadImageToDataURLViaCanvas(objectUrl, opts);
    } finally {
        URL.revokeObjectURL(objectUrl);
    }
}



// [Phase F10] VLM(Vision-Language Model) 기반 웹 검색 이미지 유효성 검열
async function validateImageWithVLM(base64Image, searchIntent, context) {
    if (!base64Image) return { isValid: false, reason: "이미지 데이터 없음" };

    // "data:image/jpeg;base64,..."에서 데이터 부분만 추출
    const base64Data = base64Image.replace(/^data:image\/(png|jpeg|webp);base64,/, "");
    const mimeType = base64Image.match(/^data:(image\/[^;]+);/)[1] || "image/jpeg";

    const systemPrompt = `당신은 게임/IT 교육 자료 이미지 검수 전문가입니다.
수집된 이미지가 교안 문맥(Context)과 검색 의도(Intent)에 부합하는지 평가하세요.
다음 조건 중 하나라도 해당하면 "isValid": false 로 판단하세요:
1. 워터마크나 광고 텍스트가 이미지 내용을 완전히 가리는 경우
2. 필요한 정보 객체(예: 매출 그래프)를 찾기 어렵거나 핵심 텍스트를 판독하기 어려운 경우
3. 선정성 또는 폭력성이 교육 목적에 부적합한 경우
참고: 게임 밈, 짤방, 커뮤니티 이미지, 팬아트 등은 게임 트렌드 교육 자료로 적합하므로 허용합니다.

[출력 형식 JSON]
{
  "isValid": true (적합) 또는 false (부적합),
  "reason": "평가 사유 (한국어 짧게)",
  "confidence": 0.0 ~ 1.0
}`;

    const userPrompt = `[수집된 의도 및 문맥]\n검색 쿼리/의도: ${JSON.stringify(searchIntent)}\n주변 문맥:\n${context}\n\n첨부된 이미지가 위 문맥에 비추어 교육 자료로 적합한지 평가하십시오.`;

    const payload = {
        contents: [
            {
                role: "user",
                parts: [
                    { text: userPrompt },
                    { inlineData: { mimeType: mimeType, data: base64Data } }
                ]
            }
        ],
        systemInstruction: { parts: [{ text: systemPrompt }] },
        generationConfig: {
            temperature: 0.1,
            responseMimeType: "application/json"
        }
    };

    try {
        console.log(`[VLM Validator] 이미지 검열 시작...`);
        // 이미지 검열용 모델은 안전장치가 강한 모델 사용 권장. 설정된 모델(TEXT_MODEL) 재활용
        const response = await fetchWithRetry(
            `https://generativelanguage.googleapis.com/v1beta/models/${TEXT_MODEL}:generateContent?key=${apiKey}`,
            { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }
        );
        const textResp = extractText(response);
        const result = JSON.parse(textResp);
        console.log(`[VLM Validator] 검열 결과:`, result);
        return result;
    } catch (e) {
        console.error("[VLM Validator] 에러 발생 (기본 통과 처리):", e);
        // 검열기 자체 오류면 차단보단 일단 통과시켜 흐름 유지 (False Positive 방어)
        return { isValid: true, reason: "VLM 통신 에러로 자동 패스", confidence: 0 };
    }
}

// [Phase F10] 구글 Custom Search (Key 롤링 방어 적용)


function getVendorIcon(vendorLabel = '') {
    if (vendorLabel.includes('Naver') || vendorLabel.includes('검색 이미지') || vendorLabel.includes('web search')) return 'ph-magnifying-glass';
    if (vendorLabel.includes('캐시 이미지') || vendorLabel.includes('cache')) return 'ph-images';
    return 'ph-sparkle';
}

function escapeHtmlAttr(value = '') {
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/"/g, '&quot;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/'/g, '&#39;');
}

function getImageSearchProviderStatus() {
    const hasNaver = typeof naverClientId === 'string' && naverClientId.trim().length > 0
        && typeof naverClientSecret === 'string' && naverClientSecret.trim().length > 0;
    return {
        hasNaver,
        hasAny: hasNaver
    };
}

const formatLintToastCache = new Map();
const statusBannerFoldState = new Map();

function getStatusBannerFoldState(foldKey, defaultCollapsed = true) {
    const key = String(foldKey || '');
    if (!statusBannerFoldState.has(key)) {
        statusBannerFoldState.set(key, !!defaultCollapsed);
    }
    return !!statusBannerFoldState.get(key);
}

function buildFoldableBannerHTML({
    foldKey = '',
    icon = 'ph-info',
    title = '',
    detailHtml = '',
    defaultCollapsed = true,
    headerActionHtml = ''
} = {}) {
    const collapsed = getStatusBannerFoldState(foldKey, defaultCollapsed);
    const toggleLabel = collapsed ? '펼치기' : '접기';
    const caretClass = collapsed ? 'ph-caret-down' : 'ph-caret-up';
    const detailClass = collapsed ? 'hidden' : '';
    const actionHtml = headerActionHtml ? `<div class="shrink-0">${headerActionHtml}</div>` : '';

    return `
        <div data-foldable-banner="1" class="flex items-start gap-2">
            <i class="ph-fill ${icon} text-sm mt-[1px]"></i>
            <div class="min-w-0 flex-1">
                <div class="flex items-center justify-between gap-2">
                    <div class="font-bold">${title}</div>
                    <div class="flex items-center gap-1.5">
                        ${actionHtml}
                        <button type="button"
                            data-fold-key="${escapeHtmlAttr(foldKey)}"
                            onclick="toggleStatusBannerFold(this.dataset.foldKey, this)"
                            class="inline-flex items-center gap-1 px-1.5 py-0.5 rounded border border-current/20 hover:bg-black/5 transition-colors text-[0.65rem] font-semibold"
                            aria-expanded="${collapsed ? 'false' : 'true'}">
                            <span data-banner-toggle-label>${toggleLabel}</span>
                            <i data-banner-caret class="ph-bold ${caretClass} text-[0.7rem]"></i>
                        </button>
                    </div>
                </div>
                <div data-banner-detail class="mt-1 opacity-90 ${detailClass}">
                    ${detailHtml}
                </div>
            </div>
        </div>
    `;
}

window.toggleStatusBannerFold = function (foldKey, btnEl) {
    const wrapper = btnEl && typeof btnEl.closest === 'function'
        ? btnEl.closest('[data-foldable-banner]')
        : null;
    if (!wrapper) return;

    const detail = wrapper.querySelector('[data-banner-detail]');
    const label = wrapper.querySelector('[data-banner-toggle-label]');
    const caret = wrapper.querySelector('[data-banner-caret]');
    if (!detail) return;

    const willCollapse = !detail.classList.contains('hidden');
    detail.classList.toggle('hidden', willCollapse);
    statusBannerFoldState.set(String(foldKey || ''), willCollapse);

    if (label) label.textContent = willCollapse ? '펼치기' : '접기';
    if (caret) {
        caret.classList.toggle('ph-caret-down', willCollapse);
        caret.classList.toggle('ph-caret-up', !willCollapse);
    }
    if (btnEl) btnEl.setAttribute('aria-expanded', String(!willCollapse));
};

const lessonInfoPanelExpandedState = new Map();

function getLessonInfoPanelExpandedState(panelKey, defaultExpanded = false) {
    const key = String(panelKey || '');
    if (!lessonInfoPanelExpandedState.has(key)) {
        lessonInfoPanelExpandedState.set(key, !!defaultExpanded);
    }
    return !!lessonInfoPanelExpandedState.get(key);
}

function applyLessonInfoPanelState(panelKey, panelEl) {
    if (!panelEl) return;
    const body = panelEl.querySelector('#lesson-info-body');
    const toggleBtn = panelEl.querySelector('#lesson-info-toggle-btn');
    if (!body || !toggleBtn) return;

    const expanded = getLessonInfoPanelExpandedState(panelKey, false);
    if (expanded) {
        body.classList.remove('max-h-0', 'opacity-0', 'py-0', 'border-transparent');
        body.classList.add('max-h-screen', 'opacity-100', 'py-2', 'border-gray-100');
    } else {
        body.classList.remove('max-h-screen', 'opacity-100', 'py-2', 'border-gray-100');
        body.classList.add('max-h-0', 'opacity-0', 'py-0', 'border-transparent');
    }

    const labelEl = toggleBtn.querySelector('[data-lesson-info-toggle-label]');
    if (labelEl) labelEl.textContent = '서식 조절';
    toggleBtn.setAttribute('aria-expanded', String(expanded));
}

function isLessonInfoPanelExpanded(panelEl) {
    if (!panelEl) return false;
    const body = panelEl.querySelector('#lesson-info-body');
    if (!body) return false;
    return !body.classList.contains('max-h-0');
}

window.toggleLessonInfoPanel = function (panelKey, btnEl) {
    const key = String(panelKey || '');
    const panelEl = btnEl && typeof btnEl.closest === 'function'
        ? btnEl.closest('#lesson-info-panel')
        : document.getElementById('lesson-info-panel');
    const fallbackExpanded = getLessonInfoPanelExpandedState(key, false);
    const currentExpanded = panelEl ? isLessonInfoPanelExpanded(panelEl) : fallbackExpanded;
    const nextExpanded = !currentExpanded;
    lessonInfoPanelExpandedState.set(key, nextExpanded);
    applyLessonInfoPanelState(key, panelEl);
};

window.syncLessonInfoPanelState = function (panelKey) {
    applyLessonInfoPanelState(String(panelKey || ''), document.getElementById('lesson-info-panel'));
};

window.renderLessonInfoSummary = function (mod, status = {}) {
    const summaryEl = document.getElementById('lesson-info-summary');
    if (!summaryEl || !mod) return;

    const chips = [];

    if (mod.content) {
        let totalTime = 0;
        if (typeof window.calculateRunningTimeData === 'function') {
            const timeData = window.calculateRunningTimeData(mod);
            totalTime = timeData.total;
        }
        chips.push(`<span class="inline-flex items-center rounded px-1.5 py-0.5 border border-indigo-200 bg-indigo-50 text-indigo-700" title="예상 소요 시간 (별점 가중치 반영)"><i class="ph-bold ph-clock flex-shrink-0 mr-1 mt-[1px]"></i>약 ${totalTime}분</span>`);
    }

    if (status.formatReport) {
        const report = status.formatReport;
        let text = '서식: 통과';
        let cls = 'border-emerald-200 bg-emerald-50 text-emerald-700';
        if (report.errors && report.errors.length > 0) {
            text = `서식: 오류 ${report.errors.length}`;
            cls = 'border-rose-200 bg-rose-50 text-rose-700';
        } else if (report.warnings && report.warnings.length > 0) {
            text = `서식: 경고 ${report.warnings.length}`;
            cls = 'border-amber-200 bg-amber-50 text-amber-700';
        }
        chips.push(`<span class="inline-flex items-center rounded px-1.5 py-0.5 border ${cls}">${text}</span>`);
    }

    if (status.imageStatus) {
        const imageStatus = status.imageStatus;
        let text = '이미지: 대기';
        let cls = 'border-slate-200 bg-slate-50 text-slate-700';
        if (imageStatus.report && Number(imageStatus.report.totalTags || 0) > 0) {
            const report = imageStatus.report;
            const searchAssigned = Number(report.searchAssigned || 0);
            const aiGenerated = Number(report.aiGenerated || 0);
            if (searchAssigned === 0 && aiGenerated > 0) {
                text = `이미지: 검색 0 / AI ${aiGenerated}`;
                cls = 'border-rose-200 bg-rose-50 text-rose-700';
            } else {
                text = `이미지: 검색 ${searchAssigned} / AI ${aiGenerated}`;
                cls = 'border-sky-200 bg-sky-50 text-sky-700';
            }
        } else if (Number(imageStatus.pendingTags || 0) > 0) {
            text = `이미지: 대기 ${imageStatus.pendingTags}`;
        }
        chips.push(`<span class="inline-flex items-center rounded px-1.5 py-0.5 border ${cls}">${text}</span>`);
    }

    const quality = status.quality || null;
    if (quality && Number.isFinite(Number(quality.overallScore))) {
        const score = Number(quality.overallScore);
        const lowCount = Array.isArray(quality.lowDimensions) ? quality.lowDimensions.length : 0;
        const cls = quality.pass
            ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
            : (lowCount > 0 ? 'border-amber-200 bg-amber-50 text-amber-700' : 'border-slate-200 bg-slate-50 text-slate-700');
        const text = quality.pass ? `품질: ${score}점 통과` : `품질: ${score}점 / 보완 ${lowCount}`;
        chips.push(`<span class="inline-flex items-center rounded px-1.5 py-0.5 border ${cls}">${text}</span>`);
    } else {
        chips.push(`<span class="inline-flex items-center rounded px-1.5 py-0.5 border border-slate-200 bg-slate-50 text-slate-700">품질: 대기</span>`);
    }

    summaryEl.innerHTML = chips.join('');
};



window.renderFormatLintBanner = function (mod, options = {}) {
    const banner = document.getElementById('format-lint-banner');
    if (!banner) return null;

    if (!mod || !mod.content) {
        banner.classList.add('hidden');
        banner.innerHTML = '';
        return null;
    }

    const report = window.validateCurriculumFormat(mod.content);
    const toast = !!options.toast;
    const forceToast = !!options.forceToast;

    let tone = 'success';
    let icon = 'ph-check-circle';
    let title = '서식 점검 통과';
    let detail = `번호형 본문 ${report.metrics.numberedLines}개, 대기 이미지 태그 ${report.metrics.pendingImageTags}개`;
    let bannerClass = 'rounded-md border border-emerald-200 bg-emerald-50 px-2.5 py-1.5 text-[0.72rem] text-emerald-700';

    if (report.errors.length > 0) {
        tone = 'error';
        icon = 'ph-warning-circle';
        title = `서식 점검 오류 (${report.errors.length})`;
        detail = report.errors.join(' / ');
        bannerClass = 'rounded-md border border-red-200 bg-red-50 px-2.5 py-1.5 text-[0.72rem] text-red-700';
    } else if (report.warnings.length > 0) {
        tone = 'warning';
        icon = 'ph-warning';
        title = `서식 점검 경고 (${report.warnings.length})`;
        detail = report.warnings.join(' / ');
        bannerClass = 'rounded-md border border-amber-200 bg-amber-50 px-2.5 py-1.5 text-[0.72rem] text-amber-700';
    }

    const foldKey = `${mod.id || 'unknown'}::format-lint`;
    banner.className = bannerClass;
    banner.innerHTML = buildFoldableBannerHTML({
        foldKey,
        icon,
        title,
        detailHtml: `<div>${escapeHtmlAttr(detail)}</div>`,
        defaultCollapsed: true
    });
    banner.classList.remove('hidden');

    if (toast && window.showToast) {
        const fingerprint = `${tone}|${title}|${detail}`;
        const prev = formatLintToastCache.get(mod.id);
        if (forceToast || prev !== fingerprint) {
            formatLintToastCache.set(mod.id, fingerprint);
            const toastMsg = tone === 'success'
                ? `형식 검사 통과: ${mod.title}`
                : `형식 검사 ${tone === 'error' ? '필요' : '경고'}: ${mod.title}`;
            window.showToast(toastMsg, tone);
        }
    }

    return report;
};

// ------------------------------------------------------------------------
// ADD-5: 교안 완성도 체크리스트
// ------------------------------------------------------------------------



window.renderCompletenessChecklist = function (mod) {
    const el = document.getElementById('completeness-checklist');
    if (!el) return;
    if (!mod || !mod.content) { el.innerHTML = ''; return; }

    const checks = window.checkModuleCompleteness(mod.content);
    const items = [
        { key: 'objectives', label: '\ud559\uc2b5\ubaa9\ud45c', icon: 'ph-target',
          presentTitle: '\ud559\uc2b5\ubaa9\ud45c \uc139\uc158 \uc788\uc74c', missingTitle: '\ud559\uc2b5\ubaa9\ud45c \ub204\ub77d \u2014 \ud074\ub9ad\ud574 \uc774\ub3d9' },
        { key: 'examples', label: '\uc0ac\ub840', icon: 'ph-book-open-text',
          presentTitle: '\uc0ac\ub840/\uc608\uc2dc \uc139\uc158 \uc788\uc74c', missingTitle: '\uc0ac\ub840/\uc608\uc2dc \ub204\ub77d \u2014 \ud074\ub9ad\ud574 \uc774\ub3d9' },
        { key: 'quiz', label: '\uc2e4\uc2b5', icon: 'ph-pencil-simple-line',
          presentTitle: '\uc2e4\uc2b5/\ud034\uc988 \uc139\uc158 \uc788\uc74c', missingTitle: '\uc2e4\uc2b5/\ud034\uc988 \ub204\ub77d \u2014 \ud074\ub9ad\ud574 \uc774\ub3d9' },
        { key: 'images', label: '\uc774\ubbf8\uc9c0', icon: 'ph-image',
          presentTitle: '\uc774\ubbf8\uc9c0 \uc788\uc74c', missingTitle: '\uc774\ubbf8\uc9c0 \ub204\ub77d \u2014 \ud074\ub9ad\ud574 \uc774\ub3d9' },
    ];

    el.innerHTML = items.map(item => {
        const present = checks[item.key];
        const colorCls = present
            ? 'text-emerald-600 border-emerald-200 bg-emerald-50'
            : 'text-rose-500 border-rose-200 bg-rose-50 cursor-pointer hover:bg-rose-100';
        const iconCls = present ? `ph-fill ${item.icon}` : `ph-bold ${item.icon}`;
        const onclickAttr = present ? '' : `onclick="focusCompletenessItem('${item.key}')"`;
        const title = present ? item.presentTitle : item.missingTitle;
        return `<span ${onclickAttr} class="inline-flex items-center gap-0.5 rounded px-1.5 py-0.5 border text-[0.62rem] font-bold ${colorCls}" title="${title}"><i class="${iconCls} mr-0.5"></i>${item.label}</span>`;
    }).join('');
};

window.focusCompletenessItem = function (type) {
    const renderView = document.getElementById('render-view');
    if (!renderView) return;

    const patterns = {
        objectives: /\ud559\uc2b5\s*\ubaa9\ud45c|learning\s*objectives?/i,
        examples: /\uc0ac\ub840|\uc608\uc2dc|\uc2e4\ubb34\s*\uc0ac\ub840|\ucf00\uc774\uc2a4|example|case\s*study/i,
        quiz: /\ud034\uc988|\uc2e4\uc2b5|\uae30\ubcf8\s*\uc2e4\uc2b5|\uc2ec\ud654|quiz|practice|exercise/i,
    };
    const labels = {
        objectives: '\ud559\uc2b5\ubaa9\ud45c', examples: '\uc0ac\ub840/\uc608\uc2dc',
        quiz: '\uc2e4\uc2b5/\ud034\uc988', images: '\uc774\ubbf8\uc9c0',
    };

    if (type === 'images') {
        const firstImg = renderView.querySelector('img, .image-wrapper');
        if (firstImg) {
            firstImg.scrollIntoView({ behavior: 'smooth', block: 'center' });
        } else {
            window.showToast('\uc774\ubbf8\uc9c0\uac00 \uc5c6\uc2b5\ub2c8\ub2e4. \uc774\ubbf8\uc9c0 \uc0bd\uc785 \ubc84\ud2bc\uc774\ub098 AI \uc774\ubbf8\uc9c0 \uac80\uc0c9\uc744 \uc2e4\ud589\ud574 \uc8fc\uc138\uc694.', 'warning');
        }
        return;
    }

    const pattern = patterns[type];
    if (!pattern) return;

    const headings = Array.from(renderView.querySelectorAll('h1,h2,h3,h4,h5,h6'));
    const target = headings.find(h => pattern.test(h.textContent));
    if (target) {
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        const prev = target.style.transition;
        target.style.transition = 'background 0.3s';
        target.style.background = '#fef9c3';
        setTimeout(() => { target.style.background = ''; target.style.transition = prev; }, 1600);
    } else {
        window.showToast(`${labels[type]} \uc139\uc158\uc744 \ucc3e\uc744 \uc218 \uc5c6\uc2b5\ub2c8\ub2e4. \uc218\uc815 \ubaa8\ub4dc\uc5d0\uc11c \uc9c1\uc811 \ucd94\uac00\ud574 \uc8fc\uc138\uc694.`, 'warning');
    }
};

window.renderImageSearchStatusBanner = function (mod) {
    const banner = document.getElementById('image-search-status-banner');
    if (!banner) return null;

    if (!mod || !mod.content) {
        banner.classList.add('hidden');
        banner.innerHTML = '';
        return null;
    }

    const provider = getImageSearchProviderStatus();
    const pendingTags = (mod.content.match(/<!--\s*\[IMG:\s*"?[^"\]]+"?\]\s*-->/g) || []).length;
    const report = (mod.imageSearchReport && typeof mod.imageSearchReport === 'object') ? mod.imageSearchReport : null;
    const foldKey = `${mod.id || 'unknown'}::image-search-status`;

    if (!provider.hasAny) {
        const missing = [];
        if (!provider.hasNaver) {
            missing.push('Naver Client ID');
            missing.push('Naver Client Secret');
        }
        const pendingText = pendingTags > 0
            ? `대기 중인 이미지 태그: ${pendingTags}개. 검색 제공자 설정 전까지 AI 생성으로 처리됩니다.`
            : '이미지 검색 제공자가 설정되지 않았습니다.';
        banner.className = 'rounded-md border border-amber-200 bg-amber-50 px-2.5 py-1.5 text-[0.72rem] text-amber-800';
        banner.innerHTML = buildFoldableBannerHTML({
            foldKey,
            icon: 'ph-warning-circle',
            title: '이미지 검색 비활성화',
            detailHtml: `
                <div>${escapeHtmlAttr(pendingText)}</div>
                <div class="mt-1">누락 설정: ${escapeHtmlAttr(missing.join(' / ') || '검색 제공자 키')}</div>
            `,
            defaultCollapsed: true
        });
        banner.classList.remove('hidden');
        return { tone: 'warning', pendingTags, report };
    }

    if (report && Number(report.totalTags || 0) > 0) {
        const total = Number(report.totalTags || 0);
        const searchAssigned = Number(report.searchAssigned || 0);
        const aiGenerated = Number(report.aiGenerated || 0);
        const failed = Number(report.failed || 0);
        const naverAssigned = Number(report.naverAssigned || 0);

        if (searchAssigned === 0 && (aiGenerated > 0 || failed > 0)) {
            banner.className = 'rounded-md border border-rose-200 bg-rose-50 px-2.5 py-1.5 text-[0.72rem] text-rose-800';
            banner.innerHTML = buildFoldableBannerHTML({
                foldKey,
                icon: 'ph-warning',
                title: '검색 배정: 0건',
                detailHtml: `
                    <div>총 ${total}개 태그 처리 완료. 검색 배정 0건, AI 생성 ${aiGenerated}건${failed > 0 ? `, 실패 ${failed}건` : ''}.</div>
                    <div class="mt-1">Naver에서 결과가 없거나 요청 오류가 발생했을 수 있습니다.</div>
                `,
                defaultCollapsed: true
            });
            banner.classList.remove('hidden');
            return { tone: 'error', pendingTags, report };
        }

        banner.className = 'rounded-md border border-sky-200 bg-sky-50 px-2.5 py-1.5 text-[0.72rem] text-sky-800';
        banner.innerHTML = buildFoldableBannerHTML({
            foldKey,
            icon: 'ph-image-square',
            title: '이미지 처리 요약',
            detailHtml: `<div>총 ${total}개 태그 처리: 검색 ${searchAssigned}건 (Naver ${naverAssigned}), AI ${aiGenerated}건${failed > 0 ? `, 실패 ${failed}건` : ''}.</div>`,
            defaultCollapsed: true
        });
        banner.classList.remove('hidden');
        return { tone: 'info', pendingTags, report };
    }

    if (pendingTags > 0) {
        banner.className = 'rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-[0.72rem] text-slate-700';
        banner.innerHTML = buildFoldableBannerHTML({
            foldKey,
            icon: 'ph-info',
            title: '이미지 태그 대기 중',
            detailHtml: `<div>${pendingTags}개 태그가 대기 중입니다. 일괄 처리 시 Naver 검색을 우선 시도합니다.</div>`,
            defaultCollapsed: true
        });
        banner.classList.remove('hidden');
        return { tone: 'pending', pendingTags, report: null };
    }

    banner.classList.add('hidden');
    banner.innerHTML = '';
    return { tone: 'hidden', pendingTags: 0, report: null };
};

const QUALITY_PASS_SCORE = 85;
const QUALITY_LOW_SCORE = 78;
const QUALITY_DIMENSIONS = [
    { id: 'goal_alignment', label: '목표 정합성' },
    { id: 'difficulty_fit', label: '난이도 적합성' },
    { id: 'factuality', label: '사실 정확성' },
    { id: 'depth_balance', label: '깊이 균형' },
    { id: 'practice_quality', label: '실습 품질' },
    { id: 'module_cohesion', label: '모듈 응집도' }
];
const qualityEvalToastCache = new Map();

function clampScore(value, fallback = 0) {
    const n = Number(value);
    if (!Number.isFinite(n)) return fallback;
    return Math.max(0, Math.min(100, Math.round(n)));
}

function tryParseJSONLoose(text = '') {
    const raw = String(text || '').trim();
    if (!raw) return null;

    let cleaned = raw.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '').trim();
    try {
        return JSON.parse(cleaned);
    } catch (e) {
        const first = cleaned.indexOf('{');
        const last = cleaned.lastIndexOf('}');
        if (first !== -1 && last !== -1 && last > first) {
            cleaned = cleaned.slice(first, last + 1);
            try {
                return JSON.parse(cleaned);
            } catch (ignored) {
                return null;
            }
        }
        return null;
    }
}

function normalizeQualityEvaluationPayload(raw, mod, source = 'manual') {
    const src = raw && typeof raw === 'object' ? raw : {};
    const rawDims = Array.isArray(src.dimensions) ? src.dimensions : [];

    const dimensions = QUALITY_DIMENSIONS.map((def, idx) => {
        const byId = rawDims.find(item => String(item?.id || '').trim().toLowerCase() === def.id);
        const fallback = rawDims[idx] || {};
        const item = byId || fallback || {};
        return {
            id: def.id,
            label: def.label,
            score: clampScore(item.score, 0),
            reason: String(item.reason || '').trim(),
            improvement: String(item.improvement || '').trim()
        };
    });

    const total = dimensions.reduce((sum, d) => sum + d.score, 0);
    const average = dimensions.length > 0 ? Math.round(total / dimensions.length) : 0;
    const overallScore = clampScore(
        src.overall_score ?? src.overallScore ?? src.overall ?? average,
        average
    );
    const lowDimensions = dimensions.filter(d => d.score < QUALITY_LOW_SCORE).map(d => d.id);

    return {
        version: 1,
        source,
        model: typeof TEXT_MODEL === 'string' ? TEXT_MODEL : '',
        evaluatedAt: new Date().toISOString(),
        overallScore,
        pass: overallScore >= QUALITY_PASS_SCORE && lowDimensions.length === 0,
        thresholds: { pass: QUALITY_PASS_SCORE, low: QUALITY_LOW_SCORE },
        dimensions,
        strengths: Array.isArray(src.strengths) ? src.strengths.map(v => String(v || '').trim()).filter(Boolean) : [],
        risks: Array.isArray(src.risks) ? src.risks.map(v => String(v || '').trim()).filter(Boolean) : [],
        lowDimensions,
        moduleId: mod?.id ?? null
    };
}

window.invalidateModuleQualityEvaluation = function (mod) {
    if (!mod || !mod.qualityEvaluation) return false;
    mod.qualityEvaluation = null;
    return true;
};

function updateQualityActionButtonState(mod) {
    const refineBtn = document.getElementById('quality-refine-btn');
    if (!refineBtn) return;

    const lowCount = Array.isArray(mod?.qualityEvaluation?.lowDimensions)
        ? mod.qualityEvaluation.lowDimensions.length
        : 0;
    const canRefine = lowCount > 0;

    refineBtn.disabled = !canRefine;
    refineBtn.innerHTML = `<i class="ph-bold ph-magic-wand"></i> 집중 보완${canRefine ? ` (${lowCount})` : ''}`;
    refineBtn.className = canRefine
        ? 'px-3 py-1.5 text-xs font-bold bg-rose-50 text-rose-600 border border-rose-200 rounded hover:bg-rose-100 flex items-center gap-1 transition-colors'
        : 'px-3 py-1.5 text-xs font-bold bg-gray-100 text-gray-400 border border-gray-200 rounded flex items-center gap-1 cursor-not-allowed';
}

window.renderQualityEvaluationBanner = function (mod, options = {}) {
    const banner = document.getElementById('quality-eval-banner');
    if (!banner) return null;

    if (!mod || !mod.content) {
        banner.classList.add('hidden');
        banner.innerHTML = '';
        updateQualityActionButtonState(mod);
        return null;
    }

    const quality = mod.qualityEvaluation;
    const foldKey = `${mod.id || 'unknown'}::quality-eval`;
    if (!quality || !Array.isArray(quality.dimensions)) {
        banner.className = 'rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-[0.72rem] text-slate-700';
        banner.innerHTML = buildFoldableBannerHTML({
            foldKey,
            icon: 'ph-shield-check',
            title: '품질 점검 대기',
            detailHtml: `<div>편집 후 품질 점검을 실행하면 의미/학습 품질 점수를 확인할 수 있습니다.</div>`,
            defaultCollapsed: true
        });
        banner.classList.remove('hidden');
        updateQualityActionButtonState(mod);
        return null;
    }

    const lowCount = Array.isArray(quality.lowDimensions) ? quality.lowDimensions.length : 0;
    const tone = quality.pass ? 'success' : (lowCount > 0 ? 'warning' : 'info');
    const icon = quality.pass ? 'ph-check-circle' : 'ph-warning-circle';
    const title = quality.pass
        ? `품질 통과 (${quality.overallScore}/100)`
        : `품질 점검 (${quality.overallScore}/100)`;
    const details = quality.dimensions
        .map(d => `<span class="inline-flex items-center rounded-full border border-black/10 px-2 py-0.5">${escapeHtmlAttr(d.label)} ${d.score}</span>`)
        .join(' ');
    const riskText = quality.risks && quality.risks.length > 0
        ? `<div class="mt-1.5 opacity-90">${escapeHtmlAttr(quality.risks[0])}</div>`
        : '';
    const refineAction = lowCount > 0
        ? `<button onclick="runModuleQualityRefinement()" class="px-2.5 py-1 rounded border border-rose-300 bg-rose-100 text-rose-700 font-bold text-[0.65rem] hover:bg-rose-200 transition-colors shrink-0">낮은 점수 보완 (${lowCount})</button>`
        : '';

    banner.className = quality.pass
        ? 'rounded-md border border-emerald-200 bg-emerald-50 px-2.5 py-1.5 text-[0.72rem] text-emerald-700'
        : 'rounded-md border border-amber-200 bg-amber-50 px-2.5 py-1.5 text-[0.72rem] text-amber-700';
    banner.innerHTML = buildFoldableBannerHTML({
        foldKey,
        icon,
        title,
        detailHtml: `<div class="flex flex-wrap gap-1.5">${details}</div>${riskText}`,
        defaultCollapsed: true,
        headerActionHtml: refineAction
    });
    banner.classList.remove('hidden');
    updateQualityActionButtonState(mod);

    if (!!options.toast && window.showToast) {
        const fingerprint = `${tone}|${title}|${lowCount}`;
        const prev = qualityEvalToastCache.get(mod.id);
        if (!!options.forceToast || prev !== fingerprint) {
            qualityEvalToastCache.set(mod.id, fingerprint);
            const msg = quality.pass
                ? `품질 통과: ${mod.title}`
                : `품질 보완 필요: ${mod.title}`;
            window.showToast(msg, quality.pass ? 'success' : 'warning');
        }
    }

    return quality;
};

async function requestCurriculumQualityEvaluation(mod, markdown, source = 'manual') {
    const cleanMarkdown = cleanForAPI(markdown || '').trim();
    const clippedMarkdown = cleanMarkdown.length > 28000
        ? `${cleanMarkdown.slice(0, 28000)}\n\n[TRUNCATED_FOR_REVIEW]`
        : cleanMarkdown;

    const systemPrompt = `You are a curriculum QA reviewer.
Score semantic instructional quality only.
Do not check markdown syntax, heading style, numbering style, image tag syntax, or HTML formatting (handled by separate lint).
Return strict JSON only.

Schema:
{
  "overall_score": 0-100,
  "dimensions": [
    {"id":"goal_alignment","score":0-100,"reason":"...","improvement":"..."},
    {"id":"difficulty_fit","score":0-100,"reason":"...","improvement":"..."},
    {"id":"factuality","score":0-100,"reason":"...","improvement":"..."},
    {"id":"depth_balance","score":0-100,"reason":"...","improvement":"..."},
    {"id":"practice_quality","score":0-100,"reason":"...","improvement":"..."},
    {"id":"module_cohesion","score":0-100,"reason":"...","improvement":"..."}
  ],
  "strengths": ["..."],
  "risks": ["..."]
}`;

    const userPrompt = `[Module]
title: ${mod?.title || ''}
description: ${mod?.description || ''}

[Markdown]
${clippedMarkdown}`;

    const payload = {
        contents: [{ parts: [{ text: userPrompt }] }],
        systemInstruction: { parts: [{ text: systemPrompt }] },
        generationConfig: { responseMimeType: 'application/json', temperature: 0.1 }
    };

    const data = await fetchWithRetry(
        `https://generativelanguage.googleapis.com/v1beta/models/${TEXT_MODEL}:generateContent?key=${apiKey}`,
        { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }
    );
    const parsed = tryParseJSONLoose(extractText(data));
    if (!parsed) {
        throw new Error('Quality evaluation JSON parse failed.');
    }
    return normalizeQualityEvaluationPayload(parsed, mod, source);
}



async function runQualityRefinementLoop(mod, options = {}) {
    if (!mod || !mod.content) {
        throw new Error('No module content to refine.');
    }

    let currentEval = mod.qualityEvaluation;
    if (!currentEval || !Array.isArray(currentEval.lowDimensions)) {
        currentEval = await evaluateCurriculumQuality(mod, { persist: true, toast: false, source: 'pre_refine' });
    }

    let lowDimensions = currentEval.dimensions.filter(d => d.score < QUALITY_LOW_SCORE);
    if (lowDimensions.length === 0) {
        return { rounds: 0, before: currentEval, after: currentEval };
    }

    const maxRounds = Math.max(1, Number(options.maxRounds) || 2);
    const beforeEval = currentEval;
    let rounds = 0;

    while (rounds < maxRounds && lowDimensions.length > 0) {
        rounds += 1;

        const focus = lowDimensions.map((d, idx) => {
            const reason = d.reason ? `reason: ${d.reason}` : 'reason: (not provided)';
            const improvement = d.improvement ? `improvement: ${d.improvement}` : 'improvement: improve this dimension';
            return `${idx + 1}. ${d.id} (${d.score}/100)\n${reason}\n${improvement}`;
        }).join('\n');

        const clippedMarkdown = mod.content.length > 28000
            ? `${mod.content.slice(0, 28000)}\n\n[TRUNCATED_FOR_REFINEMENT]`
            : mod.content;

        const systemPrompt = `You are revising a curriculum markdown.
Objective: improve only the low-scoring semantic dimensions.
Do not perform cosmetic markdown lint cleanup (format lint is handled elsewhere).
Preserve existing section structure, image placeholders/tags, and instructional intent.
Return markdown only, without code fences.`;

        const userPrompt = `[Module]
title: ${mod.title || ''}
description: ${mod.description || ''}

[Low-score dimensions]
${focus}

[Current markdown]
${clippedMarkdown}`;

        const payload = {
            contents: [{ parts: [{ text: userPrompt }] }],
            systemInstruction: { parts: [{ text: systemPrompt }] },
            generationConfig: { temperature: 0.2 }
        };

        const data = await fetchWithRetry(
            `https://generativelanguage.googleapis.com/v1beta/models/${TEXT_MODEL}:generateContent?key=${apiKey}`,
            { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }
        );

        let revised = extractText(data);
        revised = revised.replace(/^```\w*\n?/i, '').replace(/\n?```$/i, '').trim();
        if (!revised || revised.length < 80) {
            throw new Error('Refinement output is too short.');
        }

        mod.content = revised;
        mod.qualityEvaluation = null;
        currentEval = await evaluateCurriculumQuality(mod, { persist: false, toast: false, source: `refine_round_${rounds}` });
        lowDimensions = currentEval.dimensions.filter(d => d.score < QUALITY_LOW_SCORE);
    }

    mod.qualityEvaluation = currentEval;
    await saveState();
    return { rounds, before: beforeEval, after: currentEval };
}

window.runModuleQualityEvaluation = async function () {
    const mod = getEditingModule();
    if (!mod || !mod.content) {
        return window.showAlert('품질 점검할 교안 내용이 없습니다.');
    }

    const evalBtn = document.getElementById('quality-eval-btn');
    const refineBtn = document.getElementById('quality-refine-btn');
    const evalOriginal = evalBtn ? evalBtn.innerHTML : '';
    const refineOriginal = refineBtn ? refineBtn.innerHTML : '';

    try {
        if (evalBtn) {
            evalBtn.disabled = true;
            evalBtn.innerHTML = '<i class="ph-bold ph-spinner animate-spin"></i> 점검 중...';
        }
        if (refineBtn) refineBtn.disabled = true;

        await evaluateCurriculumQuality(mod, { persist: true, toast: true, forceToast: true, source: 'manual' });
        window.renderQualityEvaluationBanner(mod, { toast: false });
    } catch (err) {
        console.error('[F15] quality evaluation failed:', err);
        window.showAlert('품질 점검 실패: ' + (err.message || '알 수 없는 오류'));
    } finally {
        if (evalBtn) {
            evalBtn.disabled = false;
            evalBtn.innerHTML = evalOriginal || '<i class="ph-bold ph-shield-check"></i> 품질 점검';
        }
        if (refineBtn) {
            refineBtn.disabled = false;
            refineBtn.innerHTML = refineOriginal || '<i class="ph-bold ph-magic-wand"></i> 집중 보완';
        }
        updateQualityActionButtonState(mod);
    }
};

window.runModuleQualityRefinement = async function () {
    const mod = getEditingModule();
    if (!mod || !mod.content) {
        return window.showAlert('보완할 교안 내용이 없습니다.');
    }

    const evalBtn = document.getElementById('quality-eval-btn');
    const refineBtn = document.getElementById('quality-refine-btn');
    const evalOriginal = evalBtn ? evalBtn.innerHTML : '';
    const refineOriginal = refineBtn ? refineBtn.innerHTML : '';

    try {
        if (evalBtn) {
            evalBtn.disabled = true;
            evalBtn.innerHTML = '<i class="ph-bold ph-spinner animate-spin"></i> 점검 중...';
        }
        if (refineBtn) {
            refineBtn.disabled = true;
            refineBtn.innerHTML = '<i class="ph-bold ph-spinner animate-spin"></i> 보완 중...';
        }

        const result = await runQualityRefinementLoop(mod, { maxRounds: 2 });
        renderEditor(mod);

        const beforeScore = result.before?.overallScore ?? 0;
        const afterScore = result.after?.overallScore ?? beforeScore;
        const delta = afterScore - beforeScore;
        const deltaText = delta >= 0 ? `+${delta}` : `${delta}`;
        window.showAlert(`품질 보완 완료\n라운드: ${result.rounds}\n점수: ${beforeScore} -> ${afterScore} (${deltaText})`);
    } catch (err) {
        console.error('[F15] quality refinement failed:', err);
        window.showAlert('품질 보완 실패: ' + (err.message || '알 수 없는 오류'));
    } finally {
        if (evalBtn) {
            evalBtn.disabled = false;
            evalBtn.innerHTML = evalOriginal || '<i class="ph-bold ph-shield-check"></i> 품질 점검';
        }
        if (refineBtn) {
            refineBtn.disabled = false;
            refineBtn.innerHTML = refineOriginal || '<i class="ph-bold ph-magic-wand"></i> 집중 보완';
        }
        updateQualityActionButtonState(mod);
    }
};




async function processImageTags(mod, markdown) {

    const regex = /<!--\s*\[IMG:\s*"?([^"]+)"?\]\s*-->/g;

    let result = markdown;

    let match;



    const tagsToReplace = [];
    while ((match = regex.exec(markdown)) !== null) {
        tagsToReplace.push({ fullMatch: match[0], keyword: match[1].trim() });
    }

    if (tagsToReplace.length === 0) return result;

    const providerStatus = getImageSearchProviderStatus();
    const processingReport = {
        timestamp: new Date().toISOString(),
        totalTags: tagsToReplace.length,
        searchAssigned: 0,
        naverAssigned: 0,
        cacheAssigned: 0,
        aiGenerated: 0,
        failed: 0,
        fallbackNoProvider: 0,
        fallbackNoResult: 0,
        providerStatus
    };
    // Rate Limit(429) 완화를 위해 요청마다 지연 간격을 둡니다.
    const replacements = await Promise.all(tagsToReplace.map(async (tag, index) => {
        try {
            // Rate Limit 방어 스태거링 (순차적으로 0.5초 간격)
            if (index > 0) await new Promise(r => setTimeout(r, index * 500));

            const context = getContextWindow(markdown, tag.fullMatch, 400);
            const chainResult = await resolveImageBySearchChain({
                keyword: tag.keyword,
                context,
                fallbackGeneratePrompt: tag.keyword,
                logPrefix: 'Deep Research Agent'
            });
            const b64Image = chainResult?.b64Image || null;
            const vendorLabel = chainResult?.vendorLabel || "AI 생성 이미지";
            const resolvedBy = chainResult?.resolvedBy || '';
            const fallbackReason = chainResult?.fallbackReason || '';

            if (b64Image) {
                return { fullMatch: tag.fullMatch, keyword: tag.keyword, vendorLabel, b64Image, resolvedBy, fallbackReason };
            } else {
                return { fullMatch: tag.fullMatch, html: `\n<figure style="border:2px dashed #444;border-radius:8px;padding:1.2rem;text-align:center;color:#888;background:rgba(0,0,0,0.2);margin:1rem 0;"><div style="font-size:1.5rem;margin-bottom:0.4rem;">🖼️</div><figcaption style="font-size:0.8rem;">이미지 없음: ${tag.keyword}</figcaption></figure>\n` };
            }

        } catch (e) {
            console.error(`이미지 처리 실패 (${tag.keyword}):`, e);
            return { fullMatch: tag.fullMatch, html: `\n<figure style="border:2px dashed #444;border-radius:8px;padding:1.2rem;text-align:center;color:#888;background:rgba(0,0,0,0.2);margin:1rem 0;"><div style="font-size:1.5rem;margin-bottom:0.4rem;">🖼️</div><figcaption style="font-size:0.8rem;">이미지 오류: ${tag.keyword}</figcaption></figure>\n` };
        }
    }));

    if (!mod.images || typeof mod.images !== 'object' || Array.isArray(mod.images)) {
        mod.images = {};
    }

    const idBase = Date.now();
    let idSeq = 0;
    const createUniqueImageId = () => {
        let imgId;
        do {
            imgId = `img_${idBase}${String(idSeq++).padStart(3, '0')}`;
        } while (Object.prototype.hasOwnProperty.call(mod.images, imgId));
        return imgId;
    };

    // Promise.all 병렬 처리 결과를 단일 블록에서 병합해 mod.images 경합/충돌을 방지한다.
    for (const rep of replacements) {
        if (rep.b64Image) {
            if (rep.resolvedBy === 'naver') {
                processingReport.searchAssigned += 1;
                processingReport.naverAssigned += 1;
            } else if (rep.resolvedBy === 'cache') {
                processingReport.cacheAssigned += 1;
                const label = String(rep.vendorLabel || '');
                if (label.includes('Naver') || label.includes('검색 이미지') || label.includes('web search')) {
                    processingReport.searchAssigned += 1;
                    processingReport.naverAssigned += 1;
                } else if (label.includes('AI 생성') || label.includes('AI generated')) {
                    processingReport.aiGenerated += 1;
                }
            } else if (rep.resolvedBy === 'ai') {
                processingReport.aiGenerated += 1;
                if (rep.fallbackReason === 'providers_not_configured') processingReport.fallbackNoProvider += 1;
                else processingReport.fallbackNoResult += 1;
            }

            const imgId = createUniqueImageId();
            mod.images[imgId] = rep.b64Image;

            const vendorIcon = getVendorIcon(rep.vendorLabel);
            const safeKeyword = escapeHtmlAttr(rep.keyword || '');
            const safeVendor = escapeHtmlAttr(rep.vendorLabel || 'AI 생성 이미지');
            const encodedKeyword = encodeURIComponent(rep.keyword || '').replace(/'/g, '%27');

            const imgHTML = `\n<div class="image-wrapper"><img src="local:${imgId}" alt="${safeKeyword}" class="rounded-lg border-2 border-accent/30 shadow-md max-w-full"><span class="absolute bottom-3 left-3 bg-black/80 text-white text-[0.6rem] px-2 py-1 rounded border border-white/20 flex items-center gap-1 pointer-events-none"><i class="ph-fill ${vendorIcon} text-accent"></i> ${safeVendor}</span><button class="image-regenerate-btn px-3 py-1.5 text-xs text-white font-bold rounded flex items-center gap-1 border border-accent/50 hover:bg-accent transition-colors" data-fallback-keyword="${encodedKeyword}" data-img-id="${imgId}" onclick="promptRegenerateImage(this, decodeURIComponent(this.dataset.fallbackKeyword || ''), this.dataset.imgId)"><i class="ph-bold ph-arrows-clockwise"></i> 다시 찾기</button></div>\n`;
            result = result.replace(rep.fullMatch, imgHTML);
            continue;
        }

        processingReport.failed += 1;
        result = result.replace(rep.fullMatch, rep.html);
    }

    mod.imageSearchReport = processingReport;
    window.__lastImageSearchReport = processingReport;
    return result;
}

// [신규] 지연된 이미지를 일괄 생성/검색하는 수동 트리거 함수
async function generateAllImagesInModule(moduleId) {
    const mod = getEditingModule(moduleId);
    if (!mod || !mod.content) return;

    if (!mod.content.includes('<!-- [IMG:')) {
        window.showToast('본문에 처리 대기 중인 이미지 태그가 없습니다.', 'info');
        return;
    }

    const btn = document.getElementById('img-batch-btn');
    const originalText = btn ? btn.innerHTML : '';
    if (btn) {
        btn.innerHTML = '<i class="ph-bold ph-spinner animate-spin"></i> 이미지 일괄 확보 중...';
        btn.disabled = true;
    }

    if (window.EditorLoading) {
        window.EditorLoading.show([
            "본문 이미지를 수집하고 안전하게 검색을 수행하고 있습니다...",
            "최적의 시각 자료를 선별 중입니다...",
            "이미지 배치를 마무리하고 있습니다..."
        ]);
    }

    try {
        const newContent = await processImageTags(mod, mod.content);
        mod.content = newContent;
        if (typeof window.invalidateModuleQualityEvaluation === 'function') {
            window.invalidateModuleQualityEvaluation(mod);
        }
        await saveState();
        renderEditor(mod); // 최신 내용으로 리렌더링
        const report = mod.imageSearchReport;
        if (report && Number(report.totalTags || 0) > 0 && Number(report.searchAssigned || 0) === 0) {
            window.showToast('검색 이미지 배정이 0건입니다. 설정/API 응답 상태를 확인하세요.', 'warning');
        } else {
            window.showToast('이미지 일괄 처리가 완료되었습니다.', 'success');
        }
    } catch (e) {
        console.error('이미지 일괄 확보 실패:', e);
        window.showAlert('이미지 검색/생성 중 오류가 발생했습니다.');
    } finally {
        if (window.EditorLoading) window.EditorLoading.hide();
        if (btn) {
            btn.innerHTML = originalText;
            btn.disabled = false;
        }
    }
}



async function generateImageAPI(prompt) {

    const payload = {

        contents: [{ parts: [{ text: prompt + ", digital art style, clean, professional" }] }],

        generationConfig: {

            responseModalities: ["TEXT", "IMAGE"]

        }

    };

    try {

        const data = await fetchWithRetry(

            `https://generativelanguage.googleapis.com/v1beta/models/${IMAGE_MODEL}:generateContent?key=${apiKey}`,

            { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }

        );

        // Gemini Image 응답에서 이미지 파트 추출
        const parts = data?.candidates?.[0]?.content?.parts;
        if (parts) {
            const imgPart = parts.find(p => p.inlineData && p.inlineData.mimeType && p.inlineData.mimeType.startsWith('image/'));
            if (imgPart) {
                return `data:${imgPart.inlineData.mimeType};base64,${imgPart.inlineData.data}`;
            }
        }

        return null;

    } catch (e) {

        console.error("이미지 생성 에러:", e);

        return null;

    }

}



window.promptRegenerateImage = function (btn, fallbackKeyword, imgId) {

    const wrapper = btn.closest('.image-wrapper');
    if (!wrapper) return;

    if (wrapper.querySelector('.prompt-overlay')) return;



    const overlay = document.createElement('div');

    overlay.className = 'prompt-overlay absolute inset-0 bg-black/80 backdrop-blur-sm flex flex-col items-center justify-center p-4 z-20 animate-fade-in rounded-lg';

    overlay.onclick = () => overlay.remove();

    overlay.innerHTML = `

                <div class="w-full max-w-[320px] bg-[#1a1a2e] p-4 rounded-xl border border-white/10 shadow-2xl relative" onclick="event.stopPropagation()">

                    <div class="flex justify-between items-center mb-3">

                        <h4 class="text-sm font-bold text-white flex items-center gap-1.5"><i class="ph-fill ph-sparkle text-accent"></i> 이미지 다시 생성</h4>

                        <button class="text-textMuted hover:text-white transition-colors" onclick="this.closest('.prompt-overlay').remove()"><i class="ph-bold ph-x"></i></button>

                    </div>

                    <textarea class="w-full bg-black/40 border border-white/10 rounded-lg p-3 text-xs text-white focus:border-accent focus:ring-1 focus:ring-accent outline-none resize-none mb-3 placeholder:text-textMuted/40" rows="3" placeholder="프롬프트를 입력하세요.\n(입력하지 않으면 주변 문맥을 분석하여 자동 생성됩니다)"></textarea>

                    <div class="flex justify-end gap-2">

                        <button class="px-3 py-1.5 text-xs font-bold text-white bg-white/10 hover:bg-white/20 rounded-lg transition-colors" onclick="this.closest('.prompt-overlay').remove()">취소</button>

                        <button class="regenerate-submit-btn px-3 py-1.5 text-xs font-bold text-white bg-accent hover:bg-accentHover rounded-lg transition-colors">생성하기</button>

                    </div>

                </div>

            `;

    wrapper.appendChild(overlay);
    const submit = overlay.querySelector('.regenerate-submit-btn');
    if (submit) {
        submit.onclick = () => window.doRegenerateImage(submit, fallbackKeyword, imgId);
    }

};



function extractContextForImage(imgId) {

    const mod = getEditingModule();

    if (!mod || !mod.content) return "게임 기획 관련 이미지";



    const text = mod.content;

    const marker = `local:${imgId}`;

    const idx = text.indexOf(marker);

    if (idx === -1) return "게임 기획 관련 이미지";



    const start = Math.max(0, idx - 300);

    const end = Math.min(text.length, idx + marker.length + 300);

    let context = text.substring(start, end)

        .replace(/local:img_[0-9]+/g, '')

        .replace(/<!--.*?-->/g, '')

        .replace(/[#*`_>]/g, '')

        .trim();



    return context || "게임 기획 관련 이미지";

}



window.doRegenerateImage = async function (submitBtn, fallbackKeyword, imgId) {

    const overlay = submitBtn.closest('.prompt-overlay');
    if (!overlay) return;

    const wrapper = overlay.closest('.image-wrapper');
    if (!wrapper) return;

    const textarea = overlay.querySelector('textarea');

    const userPrompt = textarea ? textarea.value.trim() : '';
    const context = extractContextForImage(imgId);
    const keyword = userPrompt || fallbackKeyword || '게임 기획 관련 이미지';
    const prompt = userPrompt || `다음 문맥에 어울리는 이미지: ${context} (주요 키워드: ${fallbackKeyword || keyword})`;
    const safePrompt = escapeHtmlAttr(prompt);



    overlay.innerHTML = `

                <div class="flex flex-col items-center justify-center h-full">

                    <div class="spinner spinner-large mb-4"></div>

                    <p class="text-sm text-white font-bold animate-pulse drop-shadow-md">새로운 이미지를 검색/생성 중입니다...</p>

                    <p class="text-xs text-textLight/60 mt-2 max-w-[280px] text-center truncate px-4" title="${safePrompt}">프롬프트: ${safePrompt}</p>

                </div>

            `;



    try {

        const chainResult = await resolveImageBySearchChain({
            keyword,
            context,
            fallbackGeneratePrompt: prompt,
            logPrefix: 'Regenerate Chain'
        });
        const newB64 = chainResult?.b64Image;

        if (newB64) {

            const mod = getEditingModule();

            if (mod) {

                if (!mod.images) mod.images = {};
                let targetImgId = imgId;

                if (!mod.content.includes(`local:${targetImgId}`)) {
                    let originalRef = targetImgId;
                    try {
                        originalRef = decodeURIComponent(targetImgId);
                    } catch (decodeErr) {
                        originalRef = targetImgId;
                    }

                    if (originalRef && mod.content.includes(originalRef)) {
                        const newImgId = `img_${Date.now()}${Math.floor(Math.random() * 1000)}`;
                        mod.content = mod.content.split(originalRef).join(`local:${newImgId}`);
                        if (typeof window.invalidateModuleQualityEvaluation === 'function') {
                            window.invalidateModuleQualityEvaluation(mod);
                        }
                        targetImgId = newImgId;
                    }
                }

                mod.images[targetImgId] = newB64;

                const imgEl = wrapper.querySelector('img');
                if (imgEl) imgEl.src = newB64;

                const vendorLabel = chainResult?.vendorLabel || 'AI 생성 이미지';
                const vendorIcon = getVendorIcon(vendorLabel);
                const vendorBadge = wrapper.querySelector('span.absolute.bottom-3.left-3');
                if (vendorBadge) {
                    vendorBadge.innerHTML = `<i class="ph-fill ${vendorIcon} text-accent"></i> ${vendorLabel}`;
                }

                await saveState();

            }

        } else {

            window.showAlert('이미지 재생성에 실패했습니다.');

        }

    } catch (e) {

        window.showAlert('이미지 재생성 중 오류가 발생했습니다.');

        console.error(e);

    } finally {

        if (overlay && overlay.parentNode) overlay.remove();

    }

};



window.updateSubjectMeta = function (field, value) {

    if (!currentSubjectId) return;

    const subj = globalState.subjects.find(s => s.id === currentSubjectId);
    const nextValue = (typeof value === 'string' ? value : '').trim();

    if (subj && subj[field] !== nextValue) {

        subj[field] = nextValue;

        saveState().then(() => {
            renderOverviewLNB();
            renderSidebar();

            if (field === 'namingConvention') {
                const currentMod = getEditingModule();
                const previewEl = document.querySelector('button[title="파일명 컨벤션 편집"] .font-mono');
                if (currentMod && previewEl) {
                    previewEl.textContent = getNamingConventionPreviewFileName(currentMod);
                }
            }

            if (field === 'title') {

                const topicInput = document.getElementById('topic-input');
                if (topicInput) topicInput.value = nextValue;



            }
        });

    }

}

function getNamingConventionPreviewFileName(mod, conventionOverride = null) {
    const moduleRef = mod || getEditingModule();
    if (!moduleRef) return 'module.md';

    const subj = globalState.subjects.find(s => s.id === currentSubjectId);
    const fallbackStem = typeof moduleRef.title === 'string' && moduleRef.title.trim()
        ? moduleRef.title.trim()
        : 'module';
    const currentConvention = subj?.namingConvention || '';
    const overrideApplied = conventionOverride !== null && conventionOverride !== undefined;
    const namingConvention = overrideApplied ? String(conventionOverride).trim() : currentConvention;
    const namingSubject = subj
        ? { ...subj, namingConvention }
        : { namingConvention };

    if (typeof window.getModuleExportFileNameByConvention === 'function') {
        return window.getModuleExportFileNameByConvention(namingSubject, moduleRef.id, fallbackStem, '.md');
    }
    return `${fallbackStem}.md`;
}

window.openNamingConventionEditorModal = function () {
    const subj = globalState.subjects.find(s => s.id === currentSubjectId);
    const mod = getEditingModule();
    if (!subj || !mod) {
        window.showAlert('먼저 교과와 차시를 선택해 주세요.');
        return;
    }

    const currentPattern = String(subj.namingConvention || '');
    const overlay = document.createElement('div');
    overlay.className = 'fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-[9999] animate-fade-in';
    overlay.onclick = () => overlay.remove();

    const safePattern = escapeHtmlAttr(currentPattern);
    const initialPreview = escapeHtmlAttr(getNamingConventionPreviewFileName(mod, currentPattern));
    overlay.innerHTML = `
        <div class="bg-[#1a1a2e] border border-white/10 rounded-2xl w-[520px] max-w-[92vw] p-6 shadow-2xl flex flex-col gap-4" onclick="event.stopPropagation()">
            <div class="flex items-center justify-between">
                <h3 class="font-bold text-white text-sm flex items-center gap-2">
                    <i class="ph-fill ph-file-code text-accent"></i> 파일명 컨벤션                </h3>
                <button class="w-8 h-8 flex items-center justify-center rounded-full hover:bg-white/10 text-textMuted hover:text-white transition-colors" onclick="this.closest('.fixed').remove()">
                    <i class="ph-bold ph-x"></i>
                </button>
            </div>
            <div class="text-xs text-textMuted leading-relaxed">
                <div><code>nn</code> 토큰은 차시 번호(예: <code>01</code>) 또는 메인퀘스트(<code>MQ</code>)로 치환됩니다.</div>
                <div>예: <code>GPlanBasic_nn</code></div>
            </div>
            <label class="text-xs font-bold text-white/70">컨벤션 패턴</label>
            <input id="naming-convention-modal-input" type="text" value="${safePattern}" placeholder="예: GPlanBasic_nn"
                class="w-full bg-black/30 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-accent transition-colors">
            <div class="rounded-lg border border-white/10 bg-black/25 p-3">
                <div class="text-[0.65rem] font-bold text-textMuted mb-1 uppercase tracking-wider">실시간 예시 파일명</div>
                <code id="naming-convention-modal-preview" class="text-sm text-accent break-all">${initialPreview}</code>
            </div>
            <div class="flex justify-end gap-2">
                <button class="px-3 py-1.5 text-xs font-bold text-white bg-white/10 hover:bg-white/20 rounded-lg transition-colors" onclick="this.closest('.fixed').remove()">취소</button>
                <button id="naming-convention-modal-save" class="px-4 py-2 text-xs font-bold text-white bg-accent hover:bg-accentHover rounded-lg transition-colors">저장</button>
            </div>
        </div>
    `;

    document.body.appendChild(overlay);
    const input = overlay.querySelector('#naming-convention-modal-input');
    const preview = overlay.querySelector('#naming-convention-modal-preview');
    const saveBtn = overlay.querySelector('#naming-convention-modal-save');

    const refreshPreview = () => {
        if (!preview) return;
        preview.textContent = getNamingConventionPreviewFileName(mod, input ? input.value : '');
    };

    if (input) {
        input.addEventListener('input', refreshPreview);
        input.addEventListener('keydown', (event) => {
            if (event.key === 'Enter') {
                event.preventDefault();
                if (saveBtn) saveBtn.click();
            } else if (event.key === 'Escape') {
                overlay.remove();
            }
        });
        setTimeout(() => input.focus(), 0);
    }

    if (saveBtn) {
        saveBtn.onclick = () => {
            if (input) {
                window.updateSubjectMeta('namingConvention', input.value);
            }
            overlay.remove();
        };
    }
};



function renderSidebar() {

    const list = document.getElementById('module-list');

    const subj = globalState.subjects.find(s => s.id === currentSubjectId);

    if (!subj) return;



    let html = '';



    // 교과 정보 & 메인 퀘스트 통합 모듈 (가로 분할 - 상하 Layout)

    const mq = subj.mainQuest;

    const allLessonsDone = Array.isArray(subj.lessons) && subj.lessons.length > 0 && subj.lessons.every(l => l.status === 'done');



    html += `

                <div class="mb-6 rounded-xl border border-white/10 bg-bgSidebar overflow-hidden flex flex-col shadow-[0_0_15px_rgba(0,0,0,0.2)]">

                    <div class="bg-white/5 p-2.5 border-b border-white/10 flex items-center gap-2">

                        <i class="ph-fill ph-sliders-horizontal text-accent"></i>

                        <h3 class="text-[0.7rem] font-bold text-textLight tracking-wider">교과 정보 및 메인 퀘스트</h3>

                    </div>

                    <div class="flex flex-col items-stretch">

                        <!-- 상단: 교과 정보 -->

                        <div class="w-full p-3 border-b border-white/10 flex flex-col gap-3">

                            <div>

                                <label class="text-[0.6rem] font-bold text-textMuted mb-1 flex items-center gap-1"><i class="ph-bold ph-file-code"></i> 파일 네이밍 규칙</label>

                                <input type="text" value="${subj.namingConvention || ''}" placeholder="예: GPlanBasic_nn" class="w-full bg-black/20 border border-white/10 rounded px-2 py-1.5 text-xs text-white focus:border-accent outline-none transition-colors" onblur="updateSubjectMeta('namingConvention', this.value)" title="내보내기 시 'nn' 부분이 차시 번호로 자동 치환됩니다.">

                            </div>

                        </div>



                        <!-- 하단: 메인 퀘스트 -->

                        <div class="w-full p-3 flex flex-col">

                            <div class="flex-1 p-3 rounded-lg border-2 ${mq && mq.status === 'done' ? 'border-yellow-500/30 bg-yellow-500/5' : 'border-transparent hover:border-white/10 hover:bg-white/5'} flex flex-col cursor-pointer transition-all group module-card" data-id="mainQuest" onclick="viewModule('mainQuest')">

                                <div class="flex items-center justify-between mb-1.5">

                                    <div class="flex items-center gap-1">

                                        <i class="ph-fill ph-crown text-sm ${mq && mq.status === 'done' ? 'text-yellow-400' : 'text-accent'}"></i>

                                        <span class="text-[0.65rem] font-bold text-textLight group-hover:text-accent transition-colors">메인 퀘스트</span>

                                    </div>

                                    <span class="text-[0.6rem] font-bold px-1.5 py-0.5 rounded ${mq && mq.status === 'done' ? 'bg-yellow-500/20 text-yellow-300' : 'bg-white/10 text-white/50'}">${mq && mq.status === 'done' ? '완료' : '대기중'}</span>

                                </div>

                                <div class="mb-2">

                                    <h4 class="font-bold text-xs text-white mb-0.5 line-clamp-1">${mq ? mq.title : ''}</h4>

                                    <p class="text-[0.6rem] text-textMuted line-clamp-2">${mq ? mq.description : ''}</p>

                                </div>

                                <div class="mt-2 flex justify-between items-center pt-2 border-t border-white/5">

                                    <span class="text-[0.55rem] text-white/50">${allLessonsDone ? '🌟 차시 완료' : '⚠️ 진행 필요'}</span>

                                    <button onclick="event.stopPropagation(); promptAndGenerateMainQuest()" class="text-[0.6rem] font-bold px-2 py-1 rounded ${allLessonsDone ? 'bg-accent hover:bg-accentHover' : 'bg-white/10 hover:bg-white/20'} text-white transition-colors" ${!allLessonsDone && mq && mq.status !== 'done' ? 'title="모든 차시를 먼저 생성하는 것을 권장합니다."' : ''}>

                                        ${mq && mq.status === 'done' ? '재생성' : '생성하기'}

                                    </button>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

                

                <div class="flex items-center gap-2 mb-3 px-1">

                    <i class="ph-fill ph-flag-pennant text-textMuted"></i>

                    <h3 class="text-xs font-bold text-textMuted uppercase tracking-wider">차시 목록</h3>

                </div>

            `;



    if (!Array.isArray(courseData) || courseData.length === 0) {

        html += `<div class="text-center pt-5 text-textMuted/60 text-sm leading-relaxed">차시 모듈이 없습니다.</div>`;

    } else {

        html += courseData.map((mod, idx) => `

                    <div class="module-card bg-white/5 border ${mod.status === 'done' ? 'border-green-500/30' : 'border-white/10'} rounded-xl p-4 mb-3 cursor-pointer hover:-translate-y-0.5 hover:shadow-lg transition-all" 

                         data-id="${mod.id}" draggable="true" onclick="viewModule(${mod.id})" style="animation-delay: ${idx * 0.05}s">

                        <div class="flex justify-between items-start mb-2">

                            <span class="inline-flex items-center justify-center w-6 h-6 rounded bg-accent/20 text-accent font-bold text-xs">${idx + 1}</span>

                            <div class="flex gap-2">

                                <button class="text-white/40 hover:text-white cursor-grab drag-handle" title="순서 변경"><i class="ph-bold ph-list"></i></button>

                                <button onclick="event.stopPropagation(); deleteModule(${mod.id})" class="text-red-400/70 hover:text-red-400" title="삭제"><i class="ph-bold ph-x"></i></button>

                            </div>

                        </div>

                        <h3 class="font-bold text-sm text-white mb-1 outline-none focus:bg-white/10 rounded px-1 -ml-1" contenteditable="true" spellcheck="false" onblur="updateModuleMeta(${mod.id}, 'title', this.innerText)" onclick="event.stopPropagation()">${mod.title}</h3>

                        <p class="text-xs text-textMuted line-clamp-2 outline-none focus:bg-white/10 rounded px-1 -ml-1" contenteditable="true" spellcheck="false" onblur="updateModuleMeta(${mod.id}, 'description', this.innerText)" onclick="event.stopPropagation()">${mod.description}</p>

                        

                        <div class="mt-3 flex items-center justify-between">

                            <span class="text-[0.65rem] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${mod.status === 'done' ? 'bg-green-500/20 text-green-400' : 'bg-white/10 text-white/50'}">${mod.status === 'done' ? '작성완료' : '대기중'}</span>

                            <div class="flex gap-1.5 items-center">

                                ${mod.uploadedMdName

                ? `<div class="flex items-center gap-1 bg-blue-500/20 text-blue-300 px-2 py-1 rounded text-[0.65rem] border border-blue-500/30">

                                           <i class="ph-bold ph-file-md"></i> <span class="max-w-[50px] truncate" title="${mod.uploadedMdName}">${mod.uploadedMdName}</span>

                                           <button onclick="event.stopPropagation(); cancelFileUpload(${mod.id})" class="ml-1 hover:text-white" title="업로드 취소"><i class="ph-bold ph-x"></i></button>

                                       </div>`

                : `<label class="cursor-pointer text-[0.65rem] font-bold px-2 py-1.5 rounded bg-white/5 hover:bg-white/10 text-white transition-colors border border-white/10 flex items-center gap-1" onclick="event.stopPropagation();" title="기존 마크다운 파일 업로드">

                                           <i class="ph-bold ph-upload-simple"></i> MD 업로드

                                           <input type="file" accept=".md" class="hidden" onchange="handleFileUpload(event, ${mod.id})">

                                       </label>`

            }

                                <button onclick="event.stopPropagation(); promptAndGenerateModule(${mod.id})" class="text-xs font-bold px-3 py-1.5 rounded bg-white/10 hover:bg-accent text-white transition-colors">

                                    ${mod.status === 'done'
                ? '<i class="ph-bold ph-arrows-clockwise mr-1"></i>재생성'
                : '<i class="ph-bold ph-sparkle mr-1"></i>생성하기'}

                                </button>

                            </div>

                        </div>

                    </div>

                `).join('');

    }



    html += `

                <button onclick="addModule()" class="w-full py-3 border-2 border-dashed border-white/10 rounded-xl text-white/50 text-sm font-bold hover:border-accent/50 hover:text-accent transition-colors flex items-center justify-center gap-2 mt-4">

                    <i class="ph-bold ph-plus"></i> 새 차시 추가

                </button>

            `;



    list.innerHTML = html;

    initDragAndDrop();

}







window.updateModuleMeta = function (id, field, value) {

    const mod = getEditingModule(id);

    if (mod && mod[field] !== value.trim()) {

        mod[field] = value.trim();

        saveState().then(() => {
            if (id !== 'mainQuest') renderSidebar();
        });

    }

}



window.deleteModule = function (id) {

    if (id === 'mainQuest') return;

    showConfirm('차시 모듈을 삭제하시겠습니까?', () => {

        const mod = getEditingModule(id);

        if (mod && mod.content) archiveContent(mod);

        courseData = courseData.filter(m => String(m.id) !== String(id));

        if (String(currentEditingModuleId) === String(id)) {

            currentEditingModuleId = null;

            document.getElementById('editor-content-area').innerHTML = '<div class="h-full flex items-center justify-center text-textMuted text-sm">모듈이 삭제되었습니다.</div>';

            document.getElementById('ai-command-bar').classList.add('hidden'); // 삭제 시 커맨드 바도 숨김 처리

        }

        saveState().then(() => renderSidebar());

    });

}



window.addModule = function () {

    const newId = Date.now();

    if (!Array.isArray(courseData)) courseData = [];

    courseData.push({
        id: newId,
        title: '새 차시',
        description: '차시 설명을 입력하세요.',
        status: 'waiting',
        content: null,
        images: {},
        imageSearchReport: null,
        teacherNotes: [],
        qualityEvaluation: null,
        uploadedMdName: null,
        uploadedMdContent: null
    });

    saveState().then(() => renderSidebar());

}

// =========================================================================
// MD 파일 업로드 / 취소 핸들러 (사이드바 차시 카드)
// =========================================================================

window.handleFileUpload = function (event, moduleId) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
        const mod = getEditingModule(moduleId);
        if (mod) {
            mod.uploadedMdName = file.name;
            mod.uploadedMdContent = e.target.result;
            saveState().then(() => renderSidebar());
        }
    };
    reader.readAsText(file, 'UTF-8');
    event.target.value = ''; // 리셋
}

window.cancelFileUpload = function (moduleId) {
    const mod = getEditingModule(moduleId);
    if (mod) {
        mod.uploadedMdName = null;
        mod.uploadedMdContent = null;
        saveState().then(() => renderSidebar());
    }
}

let activeEditorRenderJob = 0;
let teacherNotesScrollCleanup = null;

function nextAnimationFrame() {
    return new Promise(resolve => requestAnimationFrame(() => resolve()));
}

function escapeRegExp(value) {
    return String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function cleanupTeacherNotesScrollSync() {
    if (typeof teacherNotesScrollCleanup === 'function') {
        teacherNotesScrollCleanup();
    }
    teacherNotesScrollCleanup = null;
}

function ensureTeacherNotesArray(mod) {
    if (!mod || typeof mod !== 'object') return [];
    if (!Array.isArray(mod.teacherNotes)) mod.teacherNotes = [];
    const seen = new Set();
    mod.teacherNotes = mod.teacherNotes
        .map(item => {
            if (!item || typeof item !== 'object') return null;
            const anchor = String(item.anchor || '').trim();
            if (!anchor || seen.has(anchor)) return null;
            const note = String(item.note || '').trim();
            // importance 또는 manualTime 또는 note 중 하나라도 있어야 유효
            const hasContent = note || item.importance !== undefined || item.manualTime !== undefined;
            if (!hasContent) return null;
            seen.add(anchor);
            const result = { anchor, note };
            if (item.importance !== undefined) result.importance = item.importance;
            if (item.manualTime !== undefined) result.manualTime = item.manualTime;
            return result;
        })
        .filter(Boolean);
    return mod.teacherNotes;
}

function decodeCommonHtmlEntities(rawText) {
    const source = String(rawText || '');
    const decoded = source
        .replace(/&nbsp;|&#160;/gi, ' ')
        .replace(/&amp;/gi, '&')
        .replace(/&lt;/gi, '<')
        .replace(/&gt;/gi, '>')
        .replace(/&quot;/gi, '"')
        .replace(/&#39;|&apos;/gi, "'");
    return decoded;
}

function normalizeHeadingText(rawText) {
    return decodeCommonHtmlEntities(rawText)
        .replace(/[`*_~]/g, '')
        .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
        .replace(/<[^>]+>/g, '')
        .replace(/\s+/g, ' ')
        .trim();
}

function sanitizeTeacherGuideSentence(rawText, maxLength = 96) {
    let cleaned = decodeCommonHtmlEntities(rawText)
        .replace(/<!--[\s\S]*?-->/g, ' ')
        .replace(/<[^>]+>/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();

    if (!cleaned) return '';
    if (cleaned.length > maxLength) cleaned = `${cleaned.slice(0, maxLength).trim()}...`;
    if (!/[.!?]$/.test(cleaned)) cleaned += '.';
    return cleaned;
}

function stripMarkdownForGuide(markdownText) {
    return decodeCommonHtmlEntities(markdownText)
        .replace(/<!--[\s\S]*?-->/g, ' ')
        .replace(/<[^>]*>?/g, ' ')
        .replace(/```[\s\S]*?```/g, ' ')
        .replace(/!\[[^\]]*\]\([^)]+\)/g, ' ')
        .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
        .replace(/^#{1,6}\s+/gm, '')
        .replace(/^\s*[-*+]\s+/gm, '')
        .replace(/^\s*\d+\.\s+/gm, '')
        .replace(/[*_`>]/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
}

function extractHeadingSectionsForGuide(markdownText) {
    const source = typeof markdownText === 'string' ? markdownText : '';
    const lines = source.split('\n');
    const sections = [];
    const used = new Map();
    let inCodeFence = false;
    let current = null;

    const flushCurrent = () => {
        if (!current) return;
        const body = stripMarkdownForGuide(current.lines.join('\n'));
        const summaryMatch = body.match(/[^.!?\n]{14,}[.!?]?/);
        const summary = sanitizeTeacherGuideSentence(summaryMatch ? summaryMatch[0] : body, 92);
        sections.push({
            level: current.level,
            title: current.title,
            anchor: current.anchor,
            summary
        });
        current = null;
    };

    for (const line of lines) {
        const trimmed = line.trim();
        if (trimmed.startsWith('```')) {
            inCodeFence = !inCodeFence;
            if (current) current.lines.push(line);
            continue;
        }
        if (inCodeFence) {
            if (current) current.lines.push(line);
            continue;
        }

        const match = trimmed.match(/^(#{1,6})\s+(.+)$/);
        if (match) {
            flushCurrent();
            const level = match[1].length;
            const title = normalizeHeadingText(match[2]);
            if (!title) continue;
            const baseAnchor = toHeadingAnchor(title);
            const count = used.get(baseAnchor) || 0;
            used.set(baseAnchor, count + 1);
            const anchor = count > 0 ? `${baseAnchor}-${count + 1}` : baseAnchor;
            current = { level, title, anchor, lines: [] };
            continue;
        }

        if (current) current.lines.push(line);
    }

    flushCurrent();
    return sections;
}

function buildTeacherGuideHint(title, summary) {
    const key = `${title} ${summary}`.toLowerCase();
    if (/(practice|exercise|quest|assignment|workshop|실습|퀘스트|과제|워크숍)/.test(key)) {
        return '지도 시 학습 목표를 먼저 제시하고, 단계별 시범을 보인 뒤 학습자가 즉시 따라 할 수 있도록 유도하세요.';
    }
    if (/(risk|warning|mistake|pitfall|주의|실수|오류|위험)/.test(key)) {
        return '지도 시 흔한 실패 사례를 먼저 제시하고, 예방 체크리스트로 마무리하세요.';
    }
    if (/(compare|difference|trade[- ]?off|selection|option|비교|차이|선택)/.test(key)) {
        return '지도 시 2~3가지 비교 기준을 먼저 제시하고, 사례와 함께 선택 근거를 설명하세요.';
    }
    if (/(concept|definition|principle|overview|intro|fundamental|개념|정의|원리|개요|기초)/.test(key)) {
        return '지도 시 핵심 용어를 먼저 정의하고, 게임 사례 한 가지와 연결하여 설명하세요.';
    }
    return '지도 시 핵심 문장 하나로 시작하고, 플레이어 경험 사례로 이해를 고정하세요.';
}

function buildAutoTeacherGuideNotes(markdownText) {
    const sections = extractHeadingSectionsForGuide(markdownText);
    return sections.map(section => {
        const conceptSentence = section.summary
            ? `${section.summary}`
            : sanitizeTeacherGuideSentence(`${section.title} 핵심 개념을 학습자에게 명확히 전달합니다.`, 88);
        const hint = buildTeacherGuideHint(section.title, section.summary || '');
        return {
            anchor: section.anchor,
            note: `${conceptSentence} ${hint}`.trim()
        };
    });
}

function applyAutoTeacherGuides(mod, options = {}) {
    if (!mod || typeof mod !== 'object') return [];
    const force = !!options.force;
    const existing = ensureTeacherNotesArray(mod);
    if (!force && existing.length > 0) return existing;

    const generated = buildAutoTeacherGuideNotes(mod.content || '');
    mod.teacherNotes = generated;
    return generated;
}

window.buildAutoTeacherGuideNotes = buildAutoTeacherGuideNotes;
window.applyAutoTeacherGuides = applyAutoTeacherGuides;

function toHeadingAnchor(text) {
    const normalized = normalizeHeadingText(text)
        .toLowerCase()
        .replace(/[^\w\u3131-\u318e\uac00-\ud7a3\s-]/g, '')
        .replace(/\s+/g, '-')
        .replace(/-+/g, '-')
        .replace(/^-|-$/g, '');
    return normalized || 'section';
}

function cssEscape(value) {
    const raw = String(value || '');
    if (typeof CSS !== 'undefined' && typeof CSS.escape === 'function') {
        return CSS.escape(raw);
    }
    return raw.replace(/["\\]/g, '\\$&');
}

function extractMarkdownHeadingAnchors(markdownText) {
    const source = typeof markdownText === 'string' ? markdownText : '';
    const lines = source.split('\n');
    const anchors = [];
    const used = new Map();
    let inCodeFence = false;

    for (const line of lines) {
        const trimmed = line.trim();
        if (trimmed.startsWith('```')) {
            inCodeFence = !inCodeFence;
            continue;
        }
        if (inCodeFence) continue;

        const match = trimmed.match(/^(#{1,6})\s+(.+)$/);
        if (!match) continue;

        const level = match[1].length;
        const title = normalizeHeadingText(match[2]);
        if (!title) continue;

        const baseAnchor = toHeadingAnchor(title);
        const count = used.get(baseAnchor) || 0;
        used.set(baseAnchor, count + 1);
        const anchor = count > 0 ? `${baseAnchor}-${count + 1}` : baseAnchor;

        anchors.push({ level, title, anchor });
    }

    return anchors;
}

function applyRenderedHeadingAnchors() {
    const renderView = document.getElementById('render-view');
    if (!renderView) return [];

    const headings = Array.from(renderView.querySelectorAll('h1, h2, h3, h4, h5, h6'));
    const used = new Map();
    return headings.map(el => {
        const title = normalizeHeadingText(el.textContent || '');
        const baseAnchor = toHeadingAnchor(title);
        const count = used.get(baseAnchor) || 0;
        used.set(baseAnchor, count + 1);
        const anchor = count > 0 ? `${baseAnchor}-${count + 1}` : baseAnchor;

        el.dataset.noteAnchor = anchor;
        if (!el.id || el.id.startsWith('note-anchor-')) {
            el.id = `note-anchor-${anchor}`;
        }

        return { anchor, element: el };
    });
}

function setActiveTeacherNoteCard(anchor) {
    const panel = document.getElementById('teacher-notes-panel');
    if (!panel) return;
    panel.querySelectorAll('[data-note-card]').forEach(card => {
        const isActive = card.dataset.anchor === anchor;
        card.classList.toggle('border-accent/60', isActive);
        card.classList.toggle('bg-accent/10', isActive);
        card.classList.toggle('border-gray-200', !isActive);
        card.classList.toggle('bg-white', !isActive);
    });
}

function bindTeacherNotesScrollSync() {
    cleanupTeacherNotesScrollSync();

    const area = document.getElementById('editor-content-area');
    const renderView = document.getElementById('render-view');
    const panel = document.getElementById('teacher-notes-panel');
    if (!area || !renderView || !panel || panel.classList.contains('hidden')) return;

    const keepActiveCardVisible = (anchor) => {
        if (!anchor) return;
        const card = panel.querySelector(`[data-note-card][data-anchor="${cssEscape(anchor)}"]`);
        if (!card) return;
        const panelRect = panel.getBoundingClientRect();
        const cardRect = card.getBoundingClientRect();
        const topBuffer = panelRect.top + 54;
        const bottomBuffer = panelRect.bottom - 18;
        if (cardRect.top < topBuffer || cardRect.bottom > bottomBuffer) {
            card.scrollIntoView({ block: 'center', behavior: 'auto' });
        }
    };

    const updateActiveCard = () => {
        // 카드 클릭으로 이동 중일 때는 scroll 이벤트에 의한 재계산 차단
        if (window._teacherJumpLock) return;

        const headingEls = Array.from(renderView.querySelectorAll('h1[data-note-anchor], h2[data-note-anchor], h3[data-note-anchor], h4[data-note-anchor], h5[data-note-anchor], h6[data-note-anchor]'));
        if (headingEls.length === 0) return;

        const stickyToolbar = area.querySelector('.sticky.top-0');
        const threshold = (stickyToolbar ? stickyToolbar.offsetHeight : 0) + 24;
        const areaTop = area.getBoundingClientRect().top;
        let activeAnchor = headingEls[0].dataset.noteAnchor || '';
        for (const el of headingEls) {
            if (el.getBoundingClientRect().top - areaTop <= threshold) {
                activeAnchor = el.dataset.noteAnchor || activeAnchor;
            } else {
                break;
            }
        }
        setActiveTeacherNoteCard(activeAnchor);
        keepActiveCardVisible(activeAnchor);
    };

    const onPanelWheel = (event) => {
        if (Math.abs(event.deltaY) < Math.abs(event.deltaX)) return;
        // 패널 자체가 스크롤 가능한 범위 내이면 패널을 스크롤 (기본 동작 허용)
        const atTop = panel.scrollTop <= 0 && event.deltaY < 0;
        const atBottom = panel.scrollTop + panel.clientHeight >= panel.scrollHeight - 1 && event.deltaY > 0;
        if (!atTop && !atBottom) return; // 패널 내부 스크롤 — preventDefault 없이 반환
        // 패널 경계 도달 시 메인 에디터 스크롤로 전달
        if (area.scrollHeight <= area.clientHeight) return;
        event.preventDefault();
        area.scrollTop += event.deltaY;
    };

    area.addEventListener('scroll', updateActiveCard, { passive: true });
    panel.addEventListener('wheel', onPanelWheel, { passive: false });
    window.addEventListener('resize', updateActiveCard);
    teacherNotesScrollCleanup = () => {
        area.removeEventListener('scroll', updateActiveCard);
        panel.removeEventListener('wheel', onPanelWheel);
        window.removeEventListener('resize', updateActiveCard);
    };
    updateActiveCard();
}

window.calculateRunningTimeData = function (mod) {
    if (!mod || !mod.content) return { total: 0, sections: {} };

    const source = typeof mod.content === 'string' ? mod.content : '';
    const lines = source.split('\n');
    const sections = [];
    const used = new Map();
    let inCodeFence = false;

    let currentAnchor = 'intro';
    let currentText = [];

    const userImportances = new Map();
    if (Array.isArray(mod.teacherNotes)) {
        mod.teacherNotes.forEach(note => {
            if (note.importance !== undefined) {
                userImportances.set(note.anchor, parseInt(note.importance, 10));
            }
        });
    }

    const headingRegex = /^(#{1,6})\s+(.+)$/;
    for (const line of lines) {
        const trimmed = line.trim();
        if (trimmed.startsWith('```')) {
            inCodeFence = !inCodeFence;
            currentText.push(line);
            continue;
        }
        if (inCodeFence) {
            currentText.push(line);
            continue;
        }

        const match = trimmed.match(headingRegex);
        if (match) {
            if (currentText.length > 0 || currentAnchor === 'intro') {
                sections.push({ anchor: currentAnchor, text: currentText.join('\n') });
            }

            const title = window.normalizeHeadingText ? window.normalizeHeadingText(match[2]) : match[2];
            const baseAnchor = window.toHeadingAnchor ? window.toHeadingAnchor(title) : title;
            const count = used.get(baseAnchor) || 0;
            used.set(baseAnchor, count + 1);
            currentAnchor = count > 0 ? `${baseAnchor}-${count + 1}` : baseAnchor;
            currentText = [line];
        } else {
            currentText.push(line);
        }
    }
    if (currentText.length > 0) {
        sections.push({ anchor: currentAnchor, text: currentText.join('\n') });
    }

    let totalCalculatedTime = 0;
    const sectionData = {};

    sections.forEach(sec => {
        const textOnly = sec.text.replace(/<!--[\s\S]*?-->/g, '');
        const readTime = Math.ceil(textOnly.length / 400);
        let practiceTime = 0;
        const regex = /(?:소요|실습)\s*시간\s*:\s*(\d+)\s*분/g;
        let pMatch;
        while ((pMatch = regex.exec(sec.text)) !== null) {
            practiceTime += parseInt(pMatch[1], 10);
        }

        const importance = userImportances.has(sec.anchor) ? userImportances.get(sec.anchor) : 3;
        let multiplier = 2.5;
        if (importance === 1) multiplier = 1.0;
        else if (importance === 2) multiplier = 1.5;
        else if (importance === 3) multiplier = 2.5;
        else if (importance === 4) multiplier = 3.5;
        else if (importance === 5) multiplier = 5.0;

        // manualTime이 설정된 경우 자동 계산 대신 사용
        const noteEntry = Array.isArray(mod.teacherNotes) ? mod.teacherNotes.find(n => n.anchor === sec.anchor) : null;
        const autoTime = Math.ceil(readTime * multiplier) + practiceTime;
        const finalTime = (noteEntry && noteEntry.manualTime !== undefined) ? noteEntry.manualTime : autoTime;

        sectionData[sec.anchor] = { readTime, practiceTime, importance, finalTime, manualTime: noteEntry && noteEntry.manualTime !== undefined ? noteEntry.manualTime : undefined };
        totalCalculatedTime += finalTime;
    });

    return { total: totalCalculatedTime, sections: sectionData };
};

function renderTeacherNotesPanel(mod) {
    const panel = document.getElementById('teacher-notes-panel');
    if (!panel || !mod || !mod.content) return;

    ensureTeacherNotesArray(mod);
    const headings = extractMarkdownHeadingAnchors(mod.content);
    const notesByAnchor = new Map(mod.teacherNotes.map(item => [item.anchor, item.note]));
    const headingAnchorSet = new Set(headings.map(h => h.anchor));
    const staleNotes = mod.teacherNotes.filter(item => !headingAnchorSet.has(item.anchor));

    if (headings.length === 0) {
        panel.innerHTML = `
            <div class="p-4 text-xs text-gray-500">
                <div class="font-semibold text-gray-700 mb-1">교사용 노트</div>
                <p>헤딩이 없는 문서입니다. 먼저 섹션 헤딩을 추가해 주세요.</p>
            </div>
        `;
        return;
    }

    const timeData = window.calculateRunningTimeData(mod);

    panel.innerHTML = `
        <div class="p-3 border-b border-gray-200 bg-gradient-to-r from-slate-50 to-indigo-50 sticky top-0 z-10">
            <div class="text-[0.68rem] font-semibold tracking-wide text-indigo-700 uppercase">교사용 노트</div>
            <p class="mt-1 text-[0.68rem] text-gray-600 leading-relaxed">섹션별 설명을 적어두시면 내보내기 시 교사용 문서에만 포함됩니다.</p>
        </div>
        <div class="p-3 space-y-2.5" id="teacher-notes-list">
            ${headings.map(item => {
        const safeAnchor = escapeHtmlAttr(item.anchor);
        const safeTitle = escapeHtmlAttr(item.title);
        const safeNote = escapeHtmlAttr(notesByAnchor.get(item.anchor) || '');
        const secData = timeData.sections[item.anchor] || { importance: 3, finalTime: 0 };
        const importance = secData.importance;

        const STAR_TOOLTIP = '[설명 중요도]\n⭐⭐⭐⭐⭐ 5점: 풍부한 사례, 긴 Q&A (5.0x)\n⭐⭐⭐⭐ 4점: 깊은 이해 요구 (3.5x)\n⭐⭐⭐ 3점: 핵심 개념 - 디폴트 (2.5x)\n⭐⭐ 2점: 부연 설명 (1.5x)\n⭐ 1점: 가벼운 리딩 (1.0x)';

        return `
            <section data-note-card data-anchor="${safeAnchor}" class="rounded-lg border border-gray-200 bg-white p-2.5 transition-colors">
                <!-- 헤더 행: 제목 + 별점/시간 -->
                <div class="flex items-center gap-2 mb-2">
                    <button type="button" data-jump-anchor="${safeAnchor}" class="flex-1 text-left text-[0.68rem] font-semibold text-gray-700 hover:text-accent transition-colors truncate min-w-0 flex items-center gap-1">
                        <span class="inline-block shrink-0 bg-indigo-100 text-indigo-600 text-[0.6rem] font-bold px-1.5 py-0.5 rounded">H${item.level}</span>
                        <span class="truncate">${safeTitle}</span>
                    </button>
                    <div class="flex items-center gap-1 shrink-0 px-1.5 py-0.5 rounded border border-indigo-100 bg-indigo-50/50">
                        <div class="flex items-center" data-star-rating="${safeAnchor}" title="${STAR_TOOLTIP}">
                            <i class="ph-fill ph-star text-[0.75rem] ${importance >= 1 ? 'text-yellow-400' : 'text-gray-200'} cursor-pointer hover:scale-125 transition-transform" data-score="1"></i>
                            <i class="ph-fill ph-star text-[0.75rem] ${importance >= 2 ? 'text-yellow-400' : 'text-gray-200'} cursor-pointer hover:scale-125 transition-transform" data-score="2"></i>
                            <i class="ph-fill ph-star text-[0.75rem] ${importance >= 3 ? 'text-yellow-400' : 'text-gray-200'} cursor-pointer hover:scale-125 transition-transform" data-score="3"></i>
                            <i class="ph-fill ph-star text-[0.75rem] ${importance >= 4 ? 'text-yellow-400' : 'text-gray-200'} cursor-pointer hover:scale-125 transition-transform" data-score="4"></i>
                            <i class="ph-fill ph-star text-[0.75rem] ${importance >= 5 ? 'text-yellow-400' : 'text-gray-200'} cursor-pointer hover:scale-125 transition-transform" data-score="5"></i>
                        </div>
                        <div class="w-px h-3 bg-indigo-200 mx-1"></div>
                        <input type="number" data-time-input="${safeAnchor}"
                            class="text-[0.65rem] font-bold text-indigo-700 w-9 text-right bg-transparent border-b border-transparent hover:border-indigo-300 focus:border-indigo-500 outline-none cursor-pointer [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                            value="${secData.manualTime !== undefined ? secData.manualTime : secData.finalTime}"
                            min="0" max="999" title="소요 시간 직접 입력 (분)">
                        <span class="text-[0.6rem] text-indigo-600">분</span>
                    </div>
                </div>
                <textarea data-note-input="${safeAnchor}" class="w-full min-h-[84px] rounded-md border border-gray-200 bg-gray-50 p-2 text-[0.68rem] leading-relaxed text-gray-700 focus:bg-white focus:border-accent/40 focus:ring-1 focus:ring-accent/30 outline-none resize-y" placeholder="이 섹션에서 강조할 포인트를 입력해 주세요...">${safeNote}</textarea>
                <div class="mt-2 flex items-center justify-end gap-1.5">
                    <button type="button" data-save-note="${safeAnchor}" class="px-2 py-1 text-[0.62rem] font-semibold rounded border border-emerald-300 text-emerald-700 bg-emerald-50 hover:bg-emerald-100 transition-colors">저장</button>
                    <button type="button" data-delete-note="${safeAnchor}" class="px-2 py-1 text-[0.62rem] font-semibold rounded border border-rose-300 text-rose-700 bg-rose-50 hover:bg-rose-100 transition-colors">삭제</button>
                </div>
            </section>
        `;
    }).join('')}
            ${staleNotes.length > 0 ? `
                <div class="mt-3 border-t border-dashed border-orange-300 pt-3">
                    <div class="text-[0.62rem] font-semibold text-orange-700 mb-1">연결 끊긴 노트</div>
                    <div class="space-y-1.5">
                        ${staleNotes.map(item => `
                            <div class="rounded-md border border-orange-200 bg-orange-50 px-2 py-1.5 text-[0.62rem] text-orange-800">
                                <div class="font-semibold">${escapeHtmlAttr(item.anchor)}</div>
                                <div class="mt-0.5 whitespace-pre-wrap">${escapeHtmlAttr(item.note)}</div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            ` : ''}
        </div>
    `;

    panel.querySelectorAll('[data-jump-anchor]').forEach(btn => {
        btn.onclick = () => {
            const anchor = btn.dataset.jumpAnchor || '';
            const headingEl = document.querySelector(`#render-view [data-note-anchor="${cssEscape(anchor)}"]`);
            if (headingEl) {
                // 툴바 높이 보정 스크롤 (scrollIntoView는 sticky 툴바를 고려하지 않음)
                const scrollContainer = document.getElementById('editor-content-area');
                const stickyToolbar = scrollContainer && scrollContainer.querySelector('.sticky.top-0');
                const toolbarHeight = stickyToolbar ? stickyToolbar.offsetHeight : 0;
                const PADDING = 20;

                // scroll 이벤트에 의한 카드 재계산 차단 (smooth scroll 완료까지)
                window._teacherJumpLock = true;
                clearTimeout(window._teacherJumpLockTimer);
                window._teacherJumpLockTimer = setTimeout(() => { window._teacherJumpLock = false; }, 900);

                if (scrollContainer) {
                    const containerTop = scrollContainer.getBoundingClientRect().top;
                    const elementTop = headingEl.getBoundingClientRect().top;
                    const targetScrollTop = scrollContainer.scrollTop + (elementTop - containerTop) - toolbarHeight - PADDING;
                    scrollContainer.scrollTo({ top: targetScrollTop, behavior: 'smooth' });
                } else {
                    headingEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }

                // 도착 후 파란색 하이라이트 플래시 UX
                if (!document.getElementById('_teacher-jump-style')) {
                    const s = document.createElement('style');
                    s.id = '_teacher-jump-style';
                    s.textContent = `
                        @keyframes _teacherJumpPulse {
                            0%   { background-color: transparent; }
                            25%  { background-color: rgba(59,130,246,0.22); outline: 2px solid rgba(59,130,246,0.5); outline-offset: 3px; border-radius: 4px; }
                            100% { background-color: transparent; outline-color: transparent; }
                        }
                        ._teacher-jump-highlight { animation: _teacherJumpPulse 1.4s ease-out forwards; }
                    `;
                    document.head.appendChild(s);
                }
                headingEl.classList.remove('_teacher-jump-highlight');
                // 스크롤 완료 후 하이라이트 (smooth scroll ~600ms)
                setTimeout(() => {
                    headingEl.classList.add('_teacher-jump-highlight');
                    setTimeout(() => headingEl.classList.remove('_teacher-jump-highlight'), 1500);
                }, 650);

                setActiveTeacherNoteCard(anchor);
            }
        };
    });

    panel.querySelectorAll('[data-star-rating]').forEach(container => {
        const anchor = container.dataset.starRating;
        container.querySelectorAll('i[data-score]').forEach(star => {
            star.onclick = (e) => {
                const score = parseInt(star.dataset.score, 10);
                ensureTeacherNotesArray(mod);
                let existingIdx = mod.teacherNotes.findIndex(item => item.anchor === anchor);
                if (existingIdx >= 0) {
                    mod.teacherNotes[existingIdx].importance = score;
                } else {
                    mod.teacherNotes.push({ anchor, note: '', importance: score });
                }
                saveState();
                renderTeacherNotesPanel(mod);
                if (typeof window.renderLessonInfoSummary === 'function') {
                    window.renderLessonInfoSummary(mod, {});
                }
            };
        });
    });

    panel.querySelectorAll('[data-save-note]').forEach(btn => {
        btn.onclick = () => {
            const anchor = btn.dataset.saveNote || '';
            const textarea = panel.querySelector(`[data-note-input="${cssEscape(anchor)}"]`);
            if (!textarea) return;

            const noteText = textarea.value.trim();
            ensureTeacherNotesArray(mod);
            const existingIdx = mod.teacherNotes.findIndex(item => item.anchor === anchor);
            if (noteText) {
                if (existingIdx >= 0) mod.teacherNotes[existingIdx].note = noteText;
                else mod.teacherNotes.push({ anchor, note: noteText });
                window.showToast('교사용 노트를 저장했습니다.');
            } else if (existingIdx >= 0 && !mod.teacherNotes[existingIdx].importance) {
                mod.teacherNotes.splice(existingIdx, 1);
                window.showToast('빈 노트를 삭제했습니다.');
            } else if (existingIdx >= 0 && mod.teacherNotes[existingIdx].importance) {
                mod.teacherNotes[existingIdx].note = '';
                window.showToast('노트 내용이 삭제되었습니다 (별점 유지).');
            } else {
                return;
            }

            saveState();
            renderTeacherNotesPanel(mod);
            bindTeacherNotesScrollSync();
        };
    });

    panel.querySelectorAll('[data-delete-note]').forEach(btn => {
        btn.onclick = () => {
            const anchor = btn.dataset.deleteNote || '';
            ensureTeacherNotesArray(mod);
            const existingIdx = mod.teacherNotes.findIndex(item => item.anchor === anchor);
            if (existingIdx === -1) return;
            mod.teacherNotes.splice(existingIdx, 1);
            saveState();
            window.showToast('교사용 노트를 완전히 삭제했습니다.');
            renderTeacherNotesPanel(mod);
            if (typeof window.renderLessonInfoSummary === 'function') {
                window.renderLessonInfoSummary(mod, {});
            }
            bindTeacherNotesScrollSync();
        };
    });

    panel.querySelectorAll('[data-time-input]').forEach(input => {
        input.addEventListener('change', () => {
            const anchor = input.dataset.timeInput;
            const val = parseInt(input.value, 10);
            ensureTeacherNotesArray(mod);
            let idx = mod.teacherNotes.findIndex(n => n.anchor === anchor);
            const manualTime = isNaN(val) || val < 0 ? undefined : val;
            if (idx >= 0) {
                if (manualTime !== undefined) {
                    mod.teacherNotes[idx].manualTime = manualTime;
                } else {
                    delete mod.teacherNotes[idx].manualTime;
                }
            } else if (manualTime !== undefined) {
                mod.teacherNotes.push({ anchor, note: '', manualTime });
            }
            saveState();
            if (typeof window.renderLessonInfoSummary === 'function') window.renderLessonInfoSummary(mod, {});
        });
    });
}

function renderScriptView(mod) {
    const scriptView = document.getElementById('script-view');
    if (!scriptView) return;

    const content = (mod && typeof mod.content === 'string') ? mod.content : '';
    if (!content.trim()) {
        scriptView.innerHTML = '<div class="p-8 text-gray-400 text-sm">교안 내용이 없습니다.</div>';
        return;
    }

    // Parse sections
    const lines = content.split('\n');
    const sections = [];
    let current = null;
    let inFence = false;
    for (const line of lines) {
        if (line.trim().startsWith('```')) { inFence = !inFence; if (current) current.bodyLines.push(line); continue; }
        if (!inFence) {
            const m = line.match(/^(#{1,6})\s+(.+)$/);
            if (m) { current = { level: m[1].length, rawTitle: m[2].replace(/\*\*/g, '').replace(/`/g, ''), bodyLines: [] }; sections.push(current); continue; }
        }
        if (current) current.bodyLines.push(line);
    }

    // Build lookup maps
    const headingAnchors = extractMarkdownHeadingAnchors(content);
    const anchorForSection = (idx) => headingAnchors[idx] ? headingAnchors[idx].anchor : '';
    const notes = (mod.teacherNotes && Array.isArray(mod.teacherNotes)) ? mod.teacherNotes : [];
    const notesByAnchor = new Map(notes.map(n => [n.anchor, n]));
    const timeData = (typeof window.calculateRunningTimeData === 'function') ? window.calculateRunningTimeData(mod) : { total: 0, sections: {} };

    // Strip helper: remove image tags and HTML, keep plain text
    function stripForScript(text) {
        return text
            .replace(/<!--\s*\[IMG:[^\]]*\]\s*-->/g, '')
            .replace(/!\[[^\]]*\]\([^)]*\)/g, '')
            .replace(/<img[^>]*>/gi, '')
            .replace(/<[^>]+>/g, '')
            .replace(/\*\*([^*]+)\*\*/g, '$1')
            .replace(/\*([^*]+)\*/g, '$1')
            .replace(/`([^`]+)`/g, '$1')
            .trim();
    }

    const starsHTML = (n) => '★'.repeat(n) + '☆'.repeat(5 - n);

    const levelStyles = ['', 'text-2xl font-bold', 'text-xl font-bold', 'text-lg font-semibold', 'text-base font-semibold', 'text-sm font-semibold', 'text-xs font-semibold'];
    const levelColors = ['', 'text-gray-900', 'text-gray-800', 'text-indigo-800', 'text-indigo-700', 'text-indigo-600', 'text-indigo-500'];

    const totalTime = timeData.total || 0;
    const safeTitle = escapeHtmlAttr(mod.title || '차시');

    let html = `
        <div class="max-w-3xl mx-auto px-6 py-8 font-sans">
            <div class="mb-8 pb-4 border-b-2 border-gray-300">
                <div class="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">강의 대본</div>
                <h1 class="text-3xl font-bold text-gray-900 mb-2">${safeTitle}</h1>
                <div class="flex items-center gap-3 text-sm text-gray-500">
                    <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-200 font-medium">
                        <i class="ph-bold ph-clock"></i> 총 ${totalTime}분
                    </span>
                    <span class="text-gray-400">· PDF 인쇄 시 이 뷰를 사용하세요</span>
                </div>
            </div>
    `;

    sections.forEach((sec, idx) => {
        const anchor = anchorForSection(idx);
        const secData = (anchor && timeData.sections[anchor]) ? timeData.sections[anchor] : null;
        const noteItem = anchor ? notesByAnchor.get(anchor) : null;
        const bodyText = stripForScript(sec.bodyLines.join('\n'));
        const bodyParas = bodyText.split('\n').filter(l => l.trim());

        const headingClass = (levelStyles[sec.level] || 'text-base font-semibold') + ' ' + (levelColors[sec.level] || 'text-gray-800');
        const badgeHTML = secData ? `
            <span class="ml-3 text-[0.7rem] font-medium text-indigo-600 bg-indigo-50 border border-indigo-200 rounded px-2 py-0.5">
                약 ${secData.finalTime}분 · ${starsHTML(secData.importance)}
            </span>` : '';

        const noteHTML = (noteItem && noteItem.note && noteItem.note.trim()) ? `
            <div class="mt-3 border-l-4 border-amber-400 bg-amber-50 rounded-r-lg px-4 py-3">
                <div class="text-[0.7rem] font-bold text-amber-700 uppercase tracking-wider mb-1">강사 메모</div>
                <div class="text-sm text-amber-900 whitespace-pre-wrap leading-relaxed">${escapeHtmlAttr(noteItem.note)}</div>
            </div>` : '';

        html += `
            <div class="mb-8 pb-6 border-b border-gray-100">
                <div class="flex items-baseline flex-wrap gap-1 mb-3">
                    <span class="text-[0.65rem] font-mono text-gray-400 mr-1">H${sec.level}</span>
                    <span class="${headingClass}">${escapeHtmlAttr(sec.rawTitle)}</span>
                    ${badgeHTML}
                </div>
                ${bodyParas.length > 0 ? '<div class="space-y-2 text-[0.95rem] text-gray-700 leading-relaxed">' + bodyParas.map(p => `<p>${escapeHtmlAttr(p)}</p>`).join('') + '</div>' : ''}
                ${noteHTML}
            </div>
        `;
    });

    html += '</div>';
    scriptView.innerHTML = html;
}

function collectReferencedLocalImageIds(text) {
    const ids = new Set();
    const regex = /local:([a-zA-Z0-9_\-%:.]+)/g;
    let match;
    while ((match = regex.exec(text)) !== null) {
        const rawId = match[1] || '';
        const cleanId = rawId.replace(/[)\]"'>]+$/g, '');
        if (cleanId) ids.add(cleanId);
    }
    return Array.from(ids);
}

async function buildRenderTextAsync(rawText, images, jobId) {
    let renderText = rawText || '';
    if (!renderText) return '';

    if (images && typeof images === 'object' && !Array.isArray(images) && renderText.includes('local:')) {
        const referencedIds = collectReferencedLocalImageIds(renderText);
        const needsChunk = referencedIds.length > 30;

        for (let i = 0; i < referencedIds.length; i++) {
            if (jobId !== activeEditorRenderJob) return null;
            const imgId = referencedIds[i];
            const b64 = images[imgId];
            if (typeof b64 === 'string' && b64.length > 0) {
                const regex = new RegExp(`local:${escapeRegExp(imgId)}`, 'g');
                renderText = renderText.replace(regex, b64);
            }
            if (needsChunk && i % 15 === 14) {
                await nextAnimationFrame();
            }
        }
    }

    // 잔존 미처리 local: 마크업은 렌더 단계에서 방어
    renderText = renderText.replace(/src="local:[^"]+"/g, 'src="" alt="[이미지 생성 필요]"');
    renderText = renderText.replace(/\(local:[^\)]+\)/g, '()');

    return renderText;
}







function handleInlineEditDblClick(e) {
    const mod = getEditingModule();
    if (!mod || !mod.content || typeof marked === 'undefined') return;

    // 최상위 블록 엘리먼트 찾기 (p, h1~6, ul/ol, blockquote, table 등)
    const topLevelTarget = e.target.closest('#render-view > *');
    if (!topLevelTarget || topLevelTarget.isEditing) return;

    // 클릭된 DOM 자식 요소의 인덱스 추적 (마크다운 AST 토큰과의 매핑 목적)
    const children = Array.from(document.getElementById('render-view').children);
    const targetIndex = children.indexOf(topLevelTarget);
    if (targetIndex === -1) return;

    try {
        const tokens = marked.lexer(mod.content);
        let blockIndex = 0;
        let targetToken = null;

        // Space 및 주석(Comment) 등 렌더 뷰에 표시되지 않는 토큰 필터링 인덱스 추적
        for (let i = 0; i < tokens.length; i++) {
            const t = tokens[i];
            let generatesElement = t.type !== 'space';
            if (t.type === 'html' && t.raw.trim().startsWith('<!--')) generatesElement = false;

            if (generatesElement) {
                if (blockIndex === targetIndex) {
                    targetToken = t;
                    break;
                }
                blockIndex++;
            }
        }

        if (!targetToken) return;

        // 원시 마크다운(Raw Markdown) 기반으로 Textarea 생성
        const rawMarkdownText = targetToken.raw.trimEnd();

        topLevelTarget.classList.add('hidden');
        const ta = document.createElement('textarea');
        ta.className = 'w-full p-4 font-mono text-sm bg-gray-900 border border-accent/40 shadow-xl shadow-accent/10 text-gray-100 rounded-xl outline-none focus:ring-2 focus:ring-accent resize-y min-h-[100px] my-2 animate-fade-in';
        ta.value = rawMarkdownText;

        const saveAndRestore = () => {
            if (!topLevelTarget.isEditing) return;
            topLevelTarget.isEditing = false;

            const newMarkdown = ta.value.trimEnd();
            if (newMarkdown !== rawMarkdownText && newMarkdown) {
                // 원문을 AST 기반으로 완벽 재구성 (해당 블록만 새 문구로 치환)
                let newContent = "";
                let bIdx = 0;
                for (let t of tokens) {
                    let generatesElem = t.type !== 'space';
                    if (t.type === 'html' && t.raw.trim().startsWith('<!--')) generatesElem = false;

                    if (generatesElem) {
                        if (bIdx === targetIndex) {
                            newContent += newMarkdown + (t.raw.endsWith('\\n') ? '' : '\\n');
                        } else {
                            newContent += t.raw;
                        }
                        bIdx++;
                    } else {
                        newContent += t.raw;
                    }
                }

                mod.content = newContent;
                mod.imageSearchReport = null;
                if (typeof window.invalidateModuleQualityEvaluation === 'function') {
                    window.invalidateModuleQualityEvaluation(mod);
                }
                saveState().then(() => renderEditor(mod)); // 전체 리렌더링
                return;
            }

            // 변경사항 없으면 복구
            ta.remove();
            topLevelTarget.classList.remove('hidden');
        };

        ta.onblur = saveAndRestore;
        ta.onkeydown = (ev) => {
            // Shift + Enter 를 허용하고, 그냥 Enter 는 저장
            if (ev.key === 'Enter' && !ev.shiftKey) {
                ev.preventDefault();
                ta.blur();
            } else if (ev.key === 'Escape') {
                ta.value = rawMarkdownText;
                ta.blur();
            }
        };

        topLevelTarget.parentNode.insertBefore(ta, topLevelTarget.nextSibling);
        topLevelTarget.isEditing = true;
        ta.focus();

    } catch (err) {
        console.error("인라인 편집 매핑 오류:", err);
    }
}






window.saveRawContent = function () {

    const rawView = document.getElementById('raw-view');

    const mod = getEditingModule();

    if (mod && rawView) {

        const prevContent = typeof mod.content === 'string' ? mod.content : '';
        mod.content = rawView.value;
        if (prevContent !== mod.content && typeof window.invalidateModuleQualityEvaluation === 'function') {
            window.invalidateModuleQualityEvaluation(mod);
        }



        // [가비지 컬렉션] 텍스트에서 삭제된 이미지 데이터 찌꺼기를 찾아 완전 삭제 (용량 확보)

        if (mod.images) {

            for (const imgId in mod.images) {

                if (!mod.content.includes(`local:${imgId}`)) {

                    delete mod.images[imgId];

                }

            }

        }

        saveState();

    }

}



window.switchAIMode = function (mode) {

    aiCommandMode = mode;

    const btnEdit = document.getElementById('mode-btn-edit');

    const btnImg = document.getElementById('mode-btn-image');

    const input = document.getElementById('ai-command-input');



    if (mode === 'edit') {

        btnEdit.className = 'px-3 py-1.5 text-xs font-bold rounded-md transition-all bg-accent text-white';

        btnImg.className = 'px-3 py-1.5 text-xs font-bold rounded-md transition-all text-gray-400 hover:text-white';

        input.placeholder = '텍스트를 드래그하여 선택 후 요청사항을 입력하세요...';

    } else {

        btnImg.className = 'px-3 py-1.5 text-xs font-bold rounded-md transition-all bg-accent text-white';

        btnEdit.className = 'px-3 py-1.5 text-xs font-bold rounded-md transition-all text-gray-400 hover:text-white';

        input.placeholder = '생성할 이미지에 대한 설명을 입력하세요...';

    }

}







// ===== 문체 변환 (Tone Conversion) =====
window.applyToneConversion = async function (toneId) {
    const mod = getEditingModule();
    if (!mod || !mod.content) {
        return window.showAlert('변환할 교안 콘텐츠가 없습니다.');
    }

    const preset = typeof TONE_PRESETS !== 'undefined' ? TONE_PRESETS.find(t => t.id === toneId) : null;
    if (!preset) return window.showAlert('알 수 없는 문체입니다.');

    window.showConfirm(
        `"${preset.label}" 문체로 전체 교안을 변환합니다.\n원본은 히스토리에 자동 저장됩니다. 계속할까요?`,
        async () => {
            const loadingEl = document.getElementById('tone-loading');
            const loadingText = document.getElementById('tone-loading-text');
            const allBtns = document.querySelectorAll('#tone-toolbar button');

            if (loadingEl) { loadingEl.classList.remove('hidden'); loadingEl.classList.add('flex'); }
            if (loadingText) loadingText.textContent = `${preset.label} 변환 중...`;
            allBtns.forEach(b => { b.disabled = true; b.style.opacity = '0.4'; b.style.pointerEvents = 'none'; });

            try {
                if (typeof archiveContent === 'function') archiveContent(mod, '문체 변환 전 백업');

                const { systemInstruction, userPrompt } = buildTaskContext('tone', {
                    tonePrompt: preset.prompt,
                    content: mod.content
                });

                const payload = {
                    contents: [{ parts: [{ text: userPrompt }] }],
                    systemInstruction: { parts: [{ text: systemInstruction }] }
                };

                const data = await fetchWithRetry(
                    `https://generativelanguage.googleapis.com/v1beta/models/${TEXT_MODEL}:generateContent?key=${apiKey}`,
                    { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }
                );

                let resultText = extractText(data);
                if (resultText && resultText.trim().length > 50) {
                    // 모델이 마크다운 블록(```)으로 감싸서 리턴할 경우 제거하는 전처리 로직
                    resultText = resultText.replace(/^```\w*\n?/i, '').replace(/\n?```$/i, '').trim();
                    mod.content = resultText;
                    if (typeof window.invalidateModuleQualityEvaluation === 'function') {
                        window.invalidateModuleQualityEvaluation(mod);
                    }
                    await saveState();
                    renderEditor(mod);
                    window.showAlert(`✅ "${preset.label}" 문체로 변환 완료!`);
                } else {
                    window.showAlert('변환 결과가 너무 짧습니다. 다시 시도해 주세요.');
                }
            } catch (err) {
                console.error('문체 변환 실패:', err);
                window.showAlert('문체 변환 중 오류: ' + (err.message || '알 수 없는 오류'));
            } finally {
                if (loadingEl) { loadingEl.classList.add('hidden'); loadingEl.classList.remove('flex'); }
                allBtns.forEach(b => { b.disabled = false; b.style.opacity = '1'; b.style.pointerEvents = ''; });
            }
        }
    );
}


// ===== 분량 조절 (Volume Control) =====
window.applyVolumeControl = async function (direction) {
    const mod = getEditingModule();
    if (!mod || !mod.content) {
        return window.showAlert('조절할 교안 콘텐츠가 없습니다.');
    }

    const preset = typeof VOLUME_PRESETS !== 'undefined' ? VOLUME_PRESETS[direction] : null;
    if (!preset) return window.showAlert('알 수 없는 분량 옵션입니다.');

    window.showConfirm(
        `교안을 "${preset.label}" 방향으로 조절합니다.\n원본은 히스토리에 자동 저장됩니다. 계속할까요?`,
        async () => {
            const loadingEl = document.getElementById('tone-loading');
            const loadingText = document.getElementById('tone-loading-text');
            const allBtns = document.querySelectorAll('#tone-toolbar button');

            if (loadingEl) { loadingEl.classList.remove('hidden'); loadingEl.classList.add('flex'); }
            if (loadingText) loadingText.textContent = `${preset.label} 조절 중...`;
            allBtns.forEach(b => { b.disabled = true; b.style.opacity = '0.4'; b.style.pointerEvents = 'none'; });

            try {
                if (typeof archiveContent === 'function') archiveContent(mod, '분량 조절 전 백업');

                const { systemInstruction, userPrompt } = buildTaskContext('volume', {
                    volumePrompt: preset.prompt,
                    content: mod.content
                });

                const payload = {
                    contents: [{ parts: [{ text: userPrompt }] }],
                    systemInstruction: { parts: [{ text: systemInstruction }] }
                };

                const data = await fetchWithRetry(
                    `https://generativelanguage.googleapis.com/v1beta/models/${TEXT_MODEL}:generateContent?key=${apiKey}`,
                    { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }
                );

                let resultText = extractText(data);
                if (resultText && resultText.trim().length > 30) {
                    resultText = resultText.replace(/^```\w*\n?/i, '').replace(/\n?```$/i, '').trim();
                    const before = mod.content.length;
                    mod.content = resultText;
                    if (typeof window.invalidateModuleQualityEvaluation === 'function') {
                        window.invalidateModuleQualityEvaluation(mod);
                    }
                    const after = resultText.length;
                    const ratio = Math.round((after / before) * 100);
                    await saveState();
                    renderEditor(mod);
                    window.showAlert(`✅ 분량 조절 완료! (${before.toLocaleString()}자 → ${after.toLocaleString()}자, ${ratio}%)`);
                } else {
                    window.showAlert('분량 조절 결과가 비어 있습니다. 다시 시도해 주세요.');
                }
            } catch (err) {
                console.error('분량 조절 실패:', err);
                window.showAlert('분량 조절 중 오류: ' + (err.message || '알 수 없는 오류'));
            } finally {
                if (loadingEl) { loadingEl.classList.add('hidden'); loadingEl.classList.remove('flex'); }
                allBtns.forEach(b => { b.disabled = false; b.style.opacity = '1'; b.style.pointerEvents = ''; });
            }
        }
    );
}

// ===== 개별 이미지 문맥 파악 및 재생성 (Context-Aware Image Regeneration) =====
window.regenerateImage = function (imgId, btnEl) {
    if (!btnEl) return;
    const wrapper = btnEl.closest('.group');
    if (!wrapper) return;
    if (!wrapper.classList.contains('image-wrapper')) {
        wrapper.classList.add('image-wrapper');
    }

    let normalizedImgId = imgId;
    try {
        normalizedImgId = decodeURIComponent(imgId);
    } catch (e) {
        normalizedImgId = imgId;
    }

    const fallbackKeyword = extractContextForImage(normalizedImgId);
    window.promptRegenerateImage(btnEl, fallbackKeyword, normalizedImgId);
}


// ── Phase F3: 최종 서식 변환 (local: → 웹 URL 일괄) ──

window.showFormatConvertModal = function () {
    const subj = globalState.subjects.find(s => s.id === currentSubjectId);
    if (!subj) return window.showAlert('교과를 먼저 선택해 주세요.');

    // local: 이미지가 있는지 체크
    const allMods = [...(subj.lessons || [])];
    if (subj.mainQuest) allMods.push(subj.mainQuest);
    const hasLocal = allMods.some(m => m.content && m.content.includes('local:'));
    if (!hasLocal) return window.showAlert('변환할 local: 이미지 참조가 없습니다.');

    const modalHTML = `
        <div class="p-4 space-y-4">
            <p class="text-sm text-textMuted">현재 교과의 모든 차시 교안에서 <code>local:</code> 이미지 참조를 웹 URL로 일괄 변환합니다.</p>
            <div>
                <label class="block text-xs font-bold text-white/70 mb-1">① 이미지 폴더 URL (끝에 / 포함)</label>
                <input id="convert-base-url" type="text" placeholder="https://example.com/images/course01/"
                    class="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-accent transition-colors"
                    value="">
            </div>
            <div>
                <label class="block text-xs font-bold text-white/70 mb-1">② 파일명 컨벤션</label>
                <select id="convert-naming" class="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-accent">
                    <option value="sequential">순번 (image01.png, image02.png, ...)</option>
                    <option value="keep">원본 ID 유지 (img_xxxxx.png)</option>
                </select>
            </div>
            <div class="flex gap-2 justify-end mt-4">
                <button onclick="this.closest('.fixed').remove()"
                    class="px-4 py-2 text-sm text-white/60 bg-white/5 border border-white/10 rounded-lg hover:bg-white/10 transition-colors">취소</button>
                <button onclick="executeFormatConvert(this)"
                    class="px-4 py-2 text-sm font-bold text-white bg-accent hover:bg-accentHover rounded-lg transition-colors">변환 실행</button>
            </div>
        </div>
    `;
    window.showModal('🔄 최종 서식 변환 (local: → 웹 URL)', modalHTML);
};

window.executeFormatConvert = function (triggerEl) {
    const baseUrl = document.getElementById('convert-base-url').value.trim();
    const naming = document.getElementById('convert-naming').value;

    if (!baseUrl) return window.showAlert('이미지 웹 폴더 URL을 입력해 주세요.');
    const safeBaseUrl = baseUrl.endsWith('/') ? baseUrl : baseUrl + '/';

    const subj = globalState.subjects.find(s => s.id === currentSubjectId);
    if (!subj) return;

    const allMods = [...(subj.lessons || [])];
    if (subj.mainQuest) allMods.push(subj.mainQuest);

    let totalReplaced = 0;
    let imgCounter = 1;

    allMods.forEach(mod => {
        if (!mod.content || !mod.content.includes('local:')) return;
        const prevContent = mod.content;

        // local:imgId 패턴 추출
        const localRefs = [...new Set(mod.content.match(/local:img_[a-zA-Z0-9_]+/g) || [])];

        localRefs.forEach(ref => {
            const imgId = ref.substring(6); // 'local:' 제거
            let fileName;

            if (naming === 'sequential') {
                fileName = `image${String(imgCounter).padStart(2, '0')}.png`;
                imgCounter++;
            } else {
                fileName = `${imgId}.png`;
            }

            const webUrl = safeBaseUrl + fileName;

            // local:imgId → 웹 URL 교체
            mod.content = mod.content.split(`local:${imgId}`).join(webUrl);

            // image-wrapper div 구조를 최종 서식으로 변환
            // <div class="image-wrapper"><img src="URL" ...>...</div> -> <p align="center"><img></p>
            const wrapperRegex = new RegExp(
                `<div class="image-wrapper">\\s*<img src="${webUrl.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}"[^>]*alt="([^"]*)"[^>]*>[\\s\\S]*?</div>`,
                'g'
            );
            mod.content = mod.content.replace(wrapperRegex, (match, alt) => {
                return `\n<p align="center">\n  <img src="${webUrl}" alt="${alt}">\n</p>\n`;
            });

            totalReplaced++;
        });

        if (prevContent !== mod.content && typeof window.invalidateModuleQualityEvaluation === 'function') {
            window.invalidateModuleQualityEvaluation(mod);
        }
    });

    saveState().then(() => {
        if (currentEditingModuleId) {
            const mod = getEditingModule(currentEditingModuleId);
            if (mod) renderEditor(mod);
        }

        const overlay = triggerEl && typeof triggerEl.closest === 'function'
            ? triggerEl.closest('.fixed')
            : null;
        if (overlay) overlay.remove();
        window.showAlert(`✅ ${totalReplaced}개의 이미지 참조가 웹 URL로 변환되었습니다.`);
    });
};
