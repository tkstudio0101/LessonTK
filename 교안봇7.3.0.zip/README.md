# 교안 봇 (디벨로켓 교안 도우미) — V7.2.0

AI 기반 게임 기획 교안 자동 생성 도구 배포본입니다.

## 실행 방법

### 사전 준비
- **Node.js 필수** — Naver 이미지 검색 API CORS 우회 프록시 서버 사용

### 실행
1. **`실행.bat` 더블클릭** (권장) — 서버 시작 + 브라우저 자동 오픈 (`http://localhost:3000`)
2. 또는 터미널에서 `node server.js` 실행 후 `http://localhost:3000` 접속

> `combined_app.html`을 직접 열면 이미지 검색이 동작하지 않습니다. 반드시 서버를 통해 실행하세요.

## 폴더 구조

```text
ReleaseV/
├── index.html              ← 메인 앱 (브라우저 진입점)
├── server.js               ← Node.js HTTP 서버 (포트 3000, Naver/이미지 CORS 프록시)
├── 실행.bat                ← 원클릭 서버 시작 + 브라우저 오픈
├── data.js                 ← 상수·프롬프트·API Key·모델 설정
├── state.js                ← 전역 상태·IndexedDB·ZIP 임포트/내보내기
├── api.js                  ← 오케스트레이터 (설정 관련 잔여 로직)
├── ui.js                   ← 오케스트레이터 (커맨드 팔레트·전역 초기화)
├── tutorial.js             ← 온보딩 튜토리얼 (현재 비활성)
├── utils/
│   └── validation.js       서식 린트·품질 평가·완성도 체크
├── services/
│   ├── llm.js              외부 API 통신 (Gemini·Naver 이미지 검색)
│   ├── prompts.js          프롬프트 조립
│   └── generation.js       교안 생성 비즈니스 로직·이미지 파이프라인
├── ui/
│   ├── modals.js           전역 모달·토스트
│   ├── overview.js         홈 대시보드·LNB
│   └── editor.js           에디터 렌더링·인라인 편집
├── combined_app.html       ← (구버전 단일 파일 번들, 미사용)
└── README.md
```

## 주요 기능

- **AI 교안 생성**: Google Gemini API 기반 자동 교안 생성 (분할 생성·일괄 생성)
- **교과·차시 관리**: 커리큘럼 설계 → 단원/차시 구조 관리 + D&D 편집
- **인라인 에디팅**: 텍스트 블록 클릭 편집 + 플로팅 툴바 (문체 변환·분량 조절)
- **교사 카드**: 섹션 앵커 기반 교사용 지도 메모 패널 (AI 생성 지원)
- **내보내기**: Markdown / HTML / PDF (`window.print()`) / ZIP
- **이미지 삽입**: Naver 이미지 검색(투트랙 ko+en) → VLM 검증 → AI 생성 3단계 체인
- **Notion 연동**: `url_context` 기반 교안 컨벤션·예시 실시간 참조
- **학습 이해도**: 퀴즈 생성 및 렌더링
- **커맨드 팔레트**: `Ctrl+K` 12개 액션

## 기술 스택

| 분류 | 기술 |
|------|------|
| AI | Google Gemini API (url_context 지원) |
| 이미지 검색 | Naver 이미지 검색 API (25,000건/일 무료) |
| UI 프레임워크 | 바닐라 JS + Tailwind CSS |
| 마크다운 | marked.js |
| 저장 | IndexedDB + ZIP (JSZip + FileSaver) |
| PDF | Iframe + `window.print()` |
| 서버 | Node.js HTTP (`server.js`, 포트 3000) |
