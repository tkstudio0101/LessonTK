// State & Configuration

// ------------------------------------------------------------------------

// Config variables (apiKey, STORAGE_KEY, TEXT_MODEL, IMAGE_MODEL) moved to data.js

// --- 간단한 YAML 직렬화/역직렬화 유틸 (외부 라이브러리 불필요) ---

function simpleYamlStringify(obj, indent = 0) {
    const pad = '  '.repeat(indent);
    let result = '';
    for (const [key, value] of Object.entries(obj)) {
        if (value === null || value === undefined) {
            result += `${pad}${key}: null\n`;
        } else if (typeof value === 'boolean' || typeof value === 'number') {
            result += `${pad}${key}: ${value}\n`;
        } else if (typeof value === 'string') {
            // 복잡한 문자열(개행, 특수문자 포함)은 JSON 이스케이프 문자를 사용
            if (value.includes('\n') || value.includes('"') || value.includes(':') || value.includes('#') || value.length > 200) {
                result += `${pad}${key}: ${JSON.stringify(value)}\n`;
            } else {
                result += `${pad}${key}: "${value}"\n`;
            }
        } else if (Array.isArray(value)) {
            // 배열은 JSON 문자열로 직렬화 (교안 데이터의 복잡한 구조 지원)
            result += `${pad}${key}: ${JSON.stringify(value)}\n`;
        } else if (typeof value === 'object') {
            result += `${pad}${key}:\n`;
            result += simpleYamlStringify(value, indent + 1);
        }
    }
    return result;
}

function simpleYamlParse(yamlText) {
    // YAML 텍스트를 파싱해 직렬화 시 JSON.stringify로 저장한 값들을 복원
    try {
        const result = {};
        const lines = yamlText.split('\n');
        const stack = [{ obj: result, indent: -1 }];

        for (const line of lines) {
            if (!line.trim() || line.trim().startsWith('#')) continue;

            const indentMatch = line.match(/^(\s*)/);
            const currentIndent = indentMatch ? indentMatch[1].length : 0;
            const trimmed = line.trim();

            const colonIdx = trimmed.indexOf(':');
            if (colonIdx === -1) continue;

            const key = trimmed.substring(0, colonIdx).trim();
            let valueStr = trimmed.substring(colonIdx + 1).trim();

            // 스택에서 현재 들여쓰기에 맞는 부모 객체 탐색
            while (stack.length > 1 && stack[stack.length - 1].indent >= currentIndent) {
                stack.pop();
            }
            const parent = stack[stack.length - 1].obj;

            if (!valueStr) {
                // 새 객체 시작
                parent[key] = {};
                stack.push({ obj: parent[key], indent: currentIndent });
            } else if (valueStr === 'null') {
                parent[key] = null;
            } else if (valueStr === 'true') {
                parent[key] = true;
            } else if (valueStr === 'false') {
                parent[key] = false;
            } else if (!isNaN(Number(valueStr)) && valueStr !== '') {
                parent[key] = Number(valueStr);
            } else if (valueStr.startsWith('[') || valueStr.startsWith('{') || valueStr.startsWith('"')) {
                // JSON 문자열 값 파싱
                try {
                    parent[key] = JSON.parse(valueStr);
                } catch (e) {
                    parent[key] = valueStr.replace(/^"|"$/g, '');
                }
            } else {
                parent[key] = valueStr;
            }
        }
        return result;
    } catch (e) {
    console.warn('YAML 파싱 실패, JSON으로 재시도:', e);
        return JSON.parse(yamlText); // JSON 포맷 폴백
    }
}



// --- Global State ---

let globalState = {

    courseId: "course_" + Date.now(),

    courseTitle: "게임 기획 전문가 양성 과정",

    subjects: []

};



let courseData = [];

let currentTopic = '';

let contentHistory = [];

let currentEditingModuleId = null;

let aiCommandMode = 'edit';

let currentSubjectId = null;

// --- 로컬 파일 시스템 상태 (File System Access API) ---
let projectFolderHandle = null; // FileSystemDirectoryHandle | null



// --- State Normalization (방어 로직) ---

function sanitizeState(state) {
    if (!state) return null;
    state.courseId = state.courseId || "course_" + Date.now();
    state.courseTitle = state.courseTitle || "게임 기획 전문가 양성 과정";
    state.subjects = Array.isArray(state.subjects) ? state.subjects : [];

    const normalizeTeacherNotes = (notes) => {
        if (!Array.isArray(notes)) return [];
        const seen = new Set();
        const normalized = [];
        notes.forEach(item => {
            if (!item || typeof item !== 'object') return;
            const anchor = String(item.anchor || '').trim();
            const note = String(item.note || '').trim();
            if (!anchor || !note || seen.has(anchor)) return;
            seen.add(anchor);
            normalized.push({ anchor, note });
        });
        return normalized;
    };

    const normalizeQualityEvaluation = (evaluation) => {
        if (!evaluation || typeof evaluation !== 'object' || Array.isArray(evaluation)) return null;
        const dims = Array.isArray(evaluation.dimensions)
            ? evaluation.dimensions
                .filter(item => item && typeof item === 'object')
                .map(item => ({
                    id: String(item.id || '').trim(),
                    label: String(item.label || '').trim(),
                    score: Number.isFinite(Number(item.score)) ? Math.max(0, Math.min(100, Math.round(Number(item.score)))) : 0,
                    reason: String(item.reason || '').trim(),
                    improvement: String(item.improvement || '').trim()
                }))
                .filter(item => item.id && item.label)
            : [];
        if (dims.length === 0) return null;
        return {
            ...evaluation,
            dimensions: dims,
            lowDimensions: Array.isArray(evaluation.lowDimensions)
                ? evaluation.lowDimensions.map(v => String(v || '').trim()).filter(Boolean)
                : []
        };
    };

    state.subjects.forEach(s => {
        s.id = s.id || 'subject_' + Date.now() + Math.random();
        s.title = s.title || '제목 없음';
        s.description = s.description || '';
        s.namingConvention = s.namingConvention || '';
        s.lessons = Array.isArray(s.lessons) ? s.lessons : [];
        s.mainQuest = s.mainQuest || {
            id: 'mainQuest', title: '메인 퀘스트', description: '최종 평가입니다.', status: 'waiting', content: null, images: {}, teacherNotes: [], qualityEvaluation: null
        };
        s.mainQuest.images = s.mainQuest.images || {};
        s.mainQuest.teacherNotes = normalizeTeacherNotes(s.mainQuest.teacherNotes);
        s.mainQuest.qualityEvaluation = normalizeQualityEvaluation(s.mainQuest.qualityEvaluation);
        if (!('quizContent' in s.mainQuest)) s.mainQuest.quizContent = null;
        s.lessons.forEach(l => {
            l.id = l.id || Date.now() + Math.random();
        l.title = l.title || '차시';
            l.images = l.images || {};
            l.teacherNotes = normalizeTeacherNotes(l.teacherNotes);
            l.qualityEvaluation = normalizeQualityEvaluation(l.qualityEvaluation);
            if (!('quizContent' in l)) l.quizContent = null;
        });
    });
    return state;
}

function _toSafeFolderName(name, fallback = 'untitled') {
    const raw = typeof name === 'string' ? name : '';
    const cleaned = raw.replace(/[\/\?<>\\:\*\|"]/g, '_').trim();
    return cleaned || fallback;
}

function _sanitizeFileStem(value, fallback = 'module') {
    const raw = typeof value === 'string' ? value : '';
    const stem = raw
        .replace(/\.md$/i, '')
        .replace(/[\/\?<>\\:\*\|"]/g, '_')
        .trim();
    return stem || fallback;
}

function _getLessonIndexByModuleId(subj, moduleId) {
    if (!subj || !Array.isArray(subj.lessons)) return -1;
    return subj.lessons.findIndex(lesson => String(lesson?.id) === String(moduleId));
}

function _resolveNamingToken(moduleId, lessonIndex) {
    if (String(moduleId) === 'mainQuest') return 'MQ';
    const idx = Number.isInteger(lessonIndex) && lessonIndex >= 0 ? lessonIndex : 0;
    return String(idx + 1).padStart(2, '0');
}

function _buildFileStemFromNamingConvention(subj, moduleId, fallbackStem = 'module') {
    const fallback = _sanitizeFileStem(fallbackStem, 'module');
    const patternRaw = _sanitizeFileStem(subj?.namingConvention || '', '');
    if (!patternRaw) return fallback;

    const lessonIndex = _getLessonIndexByModuleId(subj, moduleId);
    const token = _resolveNamingToken(moduleId, lessonIndex);
    const hasTokenSlot = /nn/i.test(patternRaw);
    const withToken = hasTokenSlot
        ? patternRaw.replace(/nn/gi, token)
        : `${patternRaw}_${token}`;
    return _sanitizeFileStem(withToken, fallback);
}

function getModuleExportFileNameByConvention(subj, moduleId, fallbackTitle = 'module', ext = '.md') {
    const stem = _buildFileStemFromNamingConvention(subj, moduleId, fallbackTitle);
    const normalizedExt = String(ext || '.md').startsWith('.') ? String(ext || '.md') : `.${String(ext || 'md')}`;
    return `${stem}${normalizedExt}`;
}

function _buildDefaultModuleFileName(mod, lessonIndex = -1, ext = '.md') {
    const normalizedExt = String(ext || '.md').startsWith('.') ? String(ext || '.md') : `.${String(ext || 'md')}`;
    const safeTitle = _sanitizeFileStem(mod?.title || 'module', 'module');
    if (String(mod?.id) === 'mainQuest') {
        return `MQ_${safeTitle}${normalizedExt}`;
    }
    const seq = Number.isInteger(lessonIndex) && lessonIndex >= 0
        ? String(lessonIndex + 1).padStart(2, '0')
        : '01';
    return `${seq}_${safeTitle}${normalizedExt}`;
}

window.getModuleExportFileNameByConvention = getModuleExportFileNameByConvention;

function _imageExtToMime(ext) {
    const normalized = String(ext || '').toLowerCase();
    if (normalized === 'jpg' || normalized === 'jpeg') return 'image/jpeg';
    if (normalized === 'png') return 'image/png';
    if (normalized === 'webp') return 'image/webp';
    if (normalized === 'gif') return 'image/gif';
    if (normalized === 'svg') return 'image/svg+xml';
    return `image/${normalized || 'png'}`;
}

function _toImageFileRef(imgId, value) {
    if (typeof value !== 'string') return value;
    const m = value.match(/^data:(image\/[^;]+);base64,/i);
    if (!m) return value;

    const mime = m[1].toLowerCase();
    let ext = 'png';
    if (mime === 'image/jpeg') ext = 'jpg';
    else if (mime.startsWith('image/')) ext = mime.split('/')[1] || 'png';

    return `__FILE__:${imgId}.${ext}`;
}

function _compactImagesMap(images) {
    if (!images || typeof images !== 'object' || Array.isArray(images)) return {};

    const next = {};
    for (const [imgId, value] of Object.entries(images)) {
        next[imgId] = _toImageFileRef(imgId, value);
    }
    return next;
}

function buildCompactStateForExternalSave(state) {
    if (!state) return state;
    const cloned = JSON.parse(JSON.stringify(state));
    if (!Array.isArray(cloned.subjects)) return cloned;

    cloned.subjects.forEach(subj => {
        const modules = [];
        if (Array.isArray(subj.lessons)) modules.push(...subj.lessons);
        if (subj.mainQuest) modules.push(subj.mainQuest);

        modules.forEach(mod => {
            if (!mod || typeof mod !== 'object') return;
            mod.images = _compactImagesMap(mod.images);

            // uploadedMdContent는 용량 비중이 커서 외부 저장에서는 제외
            if (typeof mod.uploadedMdContent === 'string' && mod.uploadedMdContent.length > 0) {
                mod.uploadedMdContent = null;
            }
        });
    });

    return cloned;
}

function buildCompactHistoryForExternalSave(history) {
    if (!Array.isArray(history)) return [];
    return history.map(item => ({
        id: item.id,
        title: item.title,
        content: item.content,
        date: item.date,
        metadata: normalizeHistoryMetadata(item.metadata, item.date),
        images: _compactImagesMap(item.images),
        hasImages: item.images ? Object.keys(item.images).length : 0
    }));
}

function normalizeHistoryMetadata(metadata, fallbackDate = '') {
    const source = metadata && typeof metadata === 'object' ? metadata : {};
    const textModel = typeof source.textModel === 'string' ? source.textModel.trim() : '';
    const imageModel = typeof source.imageModel === 'string' ? source.imageModel.trim() : '';
    const subjectId = typeof source.subjectId === 'string' ? source.subjectId.trim() : '';
    const rawModuleId = source.moduleId;
    const moduleId = (typeof rawModuleId === 'string' || typeof rawModuleId === 'number')
        ? String(rawModuleId).trim()
        : '';

    let archivedAt = '';
    if (typeof source.archivedAt === 'string' && source.archivedAt.trim()) {
        archivedAt = source.archivedAt.trim();
    } else if (typeof source.generatedAt === 'string' && source.generatedAt.trim()) {
        archivedAt = source.generatedAt.trim();
    } else if (fallbackDate) {
        const parsed = new Date(fallbackDate);
        if (!Number.isNaN(parsed.getTime())) archivedAt = parsed.toISOString();
    }

    return { textModel, imageModel, archivedAt, subjectId, moduleId };
}

function normalizeHistoryItems(history) {
    if (!Array.isArray(history)) return [];
    return history
        .filter(item => item && typeof item === 'object')
        .map(item => {
            const normalized = {
                id: item.id || Date.now() + Math.random(),
                title: item.title || '제목 없음',
                content: typeof item.content === 'string' ? item.content : '',
                images: (item.images && typeof item.images === 'object' && !Array.isArray(item.images)) ? item.images : {},
                date: item.date || '',
                metadata: normalizeHistoryMetadata(item.metadata, item.date)
            };

            if (!normalized.date) {
                if (normalized.metadata.archivedAt) {
                    const parsed = new Date(normalized.metadata.archivedAt);
                    normalized.date = Number.isNaN(parsed.getTime()) ? normalized.metadata.archivedAt : parsed.toLocaleString();
                } else {
                    normalized.date = new Date().toLocaleString();
                }
            }

            return normalized;
        });
}

function escapeHistoryHtml(value = '') {
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function getHistoryMetadataLabel(item) {
    const metadata = normalizeHistoryMetadata(item?.metadata, item?.date || '');
    const parts = [];
    if (metadata.textModel) parts.push(`Text: ${metadata.textModel}`);
    if (metadata.imageModel) parts.push(`Image: ${metadata.imageModel}`);

    if (metadata.archivedAt) {
        const parsed = new Date(metadata.archivedAt);
        const timeText = Number.isNaN(parsed.getTime()) ? metadata.archivedAt : parsed.toLocaleString();
        parts.push(`시각: ${timeText}`);
    }

    return parts.join(' | ');
}

function _uint8ArrayToBase64(bytes) {
    let binary = '';
    const CHUNK = 0x8000;
    for (let i = 0; i < bytes.length; i += CHUNK) {
        const chunk = bytes.subarray(i, i + CHUNK);
        binary += String.fromCharCode(...chunk);
    }
    return btoa(binary);
}

async function _readImageDataUrlFromFolder(folderHandle, fileName) {
    const fileHandle = await folderHandle.getFileHandle(fileName);
    const file = await fileHandle.getFile();
    const ext = fileName.split('.').pop().toLowerCase();
    const mime = _imageExtToMime(ext);
    const bytes = new Uint8Array(await file.arrayBuffer());
    return `data:${mime};base64,${_uint8ArrayToBase64(bytes)}`;
}

async function _getAttachmentFolderHandle(rootDirHandle, courseTitle) {
    const safeCourseName = _toSafeFolderName(courseTitle, '내 교안 프로젝트');
    try {
        const courseFolder = await rootDirHandle.getDirectoryHandle(safeCourseName);
    return await courseFolder.getDirectoryHandle('첨부파일');
    } catch (e) {
        return null;
    }
}

async function rehydrateStateImagesFromFileRefs(rootDirHandle, state) {
    if (!rootDirHandle || !state || !Array.isArray(state.subjects)) return;

    const attachFolder = await _getAttachmentFolderHandle(rootDirHandle, state.courseTitle);
    if (!attachFolder) return;

    for (const subj of state.subjects) {
        const modules = [];
        if (Array.isArray(subj.lessons)) modules.push(...subj.lessons);
        if (subj.mainQuest) modules.push(subj.mainQuest);

        for (const mod of modules) {
            if (!mod || !mod.images || typeof mod.images !== 'object' || Array.isArray(mod.images)) continue;

            for (const [imgId, value] of Object.entries(mod.images)) {
                if (typeof value === 'string' && value.startsWith('__FILE__:')) {
                    const fileName = value.substring('__FILE__:'.length);
                    try {
                        mod.images[imgId] = await _readImageDataUrlFromFolder(attachFolder, fileName);
                    } catch (imgErr) {
        console.warn(`이미지 복원 실패: ${fileName}`, imgErr);
                        delete mod.images[imgId];
                    }
                }
            }
        }
    }
}

async function rehydrateHistoryImagesFromFileRefs(rootDirHandle, state, history) {
    if (!rootDirHandle || !state || !Array.isArray(history)) return;

    const attachFolder = await _getAttachmentFolderHandle(rootDirHandle, state.courseTitle);
    if (!attachFolder) return;

    for (const item of history) {
        if (!item || !item.images || typeof item.images !== 'object' || Array.isArray(item.images)) continue;
        for (const [imgId, value] of Object.entries(item.images)) {
            if (typeof value === 'string' && value.startsWith('__FILE__:')) {
                const fileName = value.substring('__FILE__:'.length);
                try {
                    item.images[imgId] = await _readImageDataUrlFromFolder(attachFolder, fileName);
                } catch (imgErr) {
            console.warn(`히스토리 이미지 복원 실패: ${fileName}`, imgErr);
                    delete item.images[imgId];
                }
            }
        }
    }
}

function getEditingModule(id = currentEditingModuleId) {
    if (id === 'mainQuest') {
        const subj = globalState.subjects.find(s => s.id === currentSubjectId);
        return subj ? subj.mainQuest : null;
    }
    return courseData.find(m => String(m.id) === String(id));
}

// =========================================================================
// Phase F8: IndexedDB 기반 로컬 스토리지 매니저 (localStorage 용량 한계 완화)
// =========================================================================
const DBManager = {
    dbName: 'CourseAgentDB',
    dbVersion: 2, // 버전업 (새로운 store 추가)
    storeName: 'appData',
    cacheStoreName: 'image_cache', // [Phase F10] 캐시 전용 스토어 추가
    dbInstance: null,

    async init() {
        return new Promise((resolve, reject) => {
            if (this.dbInstance) {
                resolve(this.dbInstance);
                return;
            }
            const request = indexedDB.open(this.dbName, this.dbVersion);
            request.onupgradeneeded = (e) => {
                const db = e.target.result;
                if (!db.objectStoreNames.contains(this.storeName)) {
                    db.createObjectStore(this.storeName);
                }
                // [Phase F10] 이미지 캐시 스토어 생성
                if (!db.objectStoreNames.contains(this.cacheStoreName)) {
                    // 키워드를 키로 사용
                    db.createObjectStore(this.cacheStoreName, { keyPath: 'keyword' });
                }
            };
            request.onsuccess = (e) => {
                this.dbInstance = e.target.result;
                resolve(this.dbInstance);
            };
            request.onerror = (e) => {
                console.error('IndexedDB 초기화 오류:', e);
                reject(e);
            };
        });
    },

    async setItem(key, value) {
        const db = await this.init();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.storeName, 'readwrite');
            const store = tx.objectStore(this.storeName);
            const request = store.put(value, key);
            request.onsuccess = () => resolve();
            request.onerror = (e) => reject(e);
        });
    },

    async getItem(key) {
        const db = await this.init();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.storeName, 'readonly');
            const store = tx.objectStore(this.storeName);
            const request = store.get(key);
            request.onsuccess = (e) => resolve(e.target.result);
            request.onerror = (e) => reject(e);
        });
    },

    async deleteItem(key) {
        const db = await this.init();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.storeName, 'readwrite');
            const store = tx.objectStore(this.storeName);
            const request = store.delete(key);
            request.onsuccess = () => resolve();
            request.onerror = (e) => reject(e);
        });
    },

    // --- [Phase F10] 이미지 캐시 관리 API ---
    async setCache(keyword, base64Data, sourceUrl, formatLabel) {
        const db = await this.init();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.cacheStoreName, 'readwrite');
            const store = tx.objectStore(this.cacheStoreName);
            const payload = {
                keyword: keyword,        // PK
                base64: base64Data,      // 이미지
                source: sourceUrl,       // 출처 URL (안내용)
                format: formatLabel,     // 포맷 라벨 ("자동 검색/수동" 등)
                timestamp: Date.now()
            };
            const request = store.put(payload);
            request.onsuccess = () => resolve();
            request.onerror = (e) => reject(e);
        });
    },

    async getCache(keyword) {
        const db = await this.init();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.cacheStoreName, 'readonly');
            const store = tx.objectStore(this.cacheStoreName);
            const request = store.get(keyword);
            request.onsuccess = (e) => resolve(e.target.result);
            request.onerror = (e) => reject(e);
        });
    },

    async getAllCaches() {
        const db = await this.init();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.cacheStoreName, 'readonly');
            const store = tx.objectStore(this.cacheStoreName);
            const request = store.getAll();
            request.onsuccess = (e) => resolve(e.target.result.sort((a, b) => b.timestamp - a.timestamp));
            request.onerror = (e) => reject(e);
        });
    },

    async deleteCache(keyword) {
        const db = await this.init();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.cacheStoreName, 'readwrite');
            const store = tx.objectStore(this.cacheStoreName);
            const request = store.delete(keyword);
            request.onsuccess = () => resolve();
            request.onerror = (e) => reject(e);
        });
    },

    async clearAllCaches() {
        const db = await this.init();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.cacheStoreName, 'readwrite');
            const store = tx.objectStore(this.cacheStoreName);
            const request = store.clear();
            request.onsuccess = () => resolve();
            request.onerror = (e) => reject(e);
        });
    }
};

// Data Management Layer

async function saveState() {
    try {
        if (currentSubjectId) {
            const subject = globalState.subjects.find(s => s.id === currentSubjectId);
            if (subject) {
                subject.lessons = Array.isArray(courseData) ? courseData : [];
            }
        }

        // 1. IndexedDB에 무제한 비동기 저장 시도
        const stateData = { state: globalState, history: contentHistory };
        await DBManager.setItem(STORAGE_KEY, stateData);

    } catch (e) {
        console.error('IndexedDB 저장 실패', e);
        window.showAlert('데이터베이스 저장 중 오류가 발생했습니다. 브라우저의 저장소 설정을 확인해주세요.');
    }

    // 연결된 로컬 폴더 비동기 동기화 (UI 블로킹 방지)
    if (projectFolderHandle) {
        syncToLinkedFolder().catch(e => console.warn('폴더 동기화 경고:', e.message));
    }
}

async function restoreState() {
    try {
        // 1. IndexedDB에서 최우선 로드 (대용량 환경 복원)
        let data = await DBManager.getItem(STORAGE_KEY);

        // 2. DB가 비어있으면 기존 localStorage 데이터 마이그레이션 시도
        if (!data) {
            const raw = localStorage.getItem(STORAGE_KEY);
            if (raw) {
                data = JSON.parse(raw);
            console.log('기존 localStorage 데이터를 IndexedDB로 마이그레이션합니다.');
                await DBManager.setItem(STORAGE_KEY, data); // 마이그레이션 데이터 저장
                localStorage.removeItem(STORAGE_KEY);
            }
        } else {
            // 이미 마이그레이션이 끝났어도 남아있는 localStorage 항목을 제거해 쿼터 공간 확보
            localStorage.removeItem(STORAGE_KEY);
        }

        if (data && data.state) {
            const sanitized = sanitizeState(data.state);
            if (sanitized) {
                globalState = sanitized;
            } else {
                await loadMockData();
            }
            contentHistory = normalizeHistoryItems(data.history);
        } else {
            await loadMockData();
        }

    } catch (e) {
        console.error("Failed to restore state from DB", e);
        await loadMockData();
    }
}

async function loadMockData() {
    globalState = sanitizeState(INITIAL_MOCK_STATE);
    await saveState();
}


async function archiveContent(mod) {
    const now = new Date();
    const moduleId = (typeof mod?.id === 'string' || typeof mod?.id === 'number') ? String(mod.id) : '';
    const subjectId = typeof currentSubjectId === 'string' ? currentSubjectId : '';
    contentHistory.push({
        id: Date.now(),
        title: mod.title,
        content: mod.content,
        images: mod.images ? JSON.parse(JSON.stringify(mod.images)) : {}, // 히스토리용 이미지 엔트리도 복사
        date: now.toLocaleString(),
        metadata: {
            textModel: (typeof TEXT_MODEL === 'string' ? TEXT_MODEL : ''),
            imageModel: (typeof IMAGE_MODEL === 'string' ? IMAGE_MODEL : ''),
            archivedAt: now.toISOString(),
            subjectId,
            moduleId
        }
    });

    await saveState();

    // 연결된 폴더가 있으면 히스토리도 별도 파일로 동기화
    if (projectFolderHandle) {
        syncHistoryItemToFolder(contentHistory[contentHistory.length - 1]).catch(e => console.warn('히스토리 폴더 동기화 경고:', e.message));
    }
}

// --- History UI ---
const selectedHistoryIds = new Set();
let lastHistoryIdx = -1;

function toggleHistoryPanel() {
    const p = document.getElementById('history-panel');
    if (!p) return;
    let bg = document.getElementById('history-bg');
    const isOpen = !p.classList.contains('hidden');

    if (!isOpen) {
        // 열기
        if (!bg) {
            bg = document.createElement('div');
            bg.id = 'history-bg';
            bg.className = 'fixed inset-0 bg-black/50 z-40 animate-fade-in backdrop-blur-sm';
            bg.onclick = toggleHistoryPanel;
            document.body.appendChild(bg);
        }
        bg.style.display = 'block';
        p.classList.remove('hidden');
        p.classList.remove('translate-x-full');
        selectedHistoryIds.clear();
        lastHistoryIdx = -1;
        renderHistoryUI(p);
    } else {
        // 닫기
        p.classList.add('translate-x-full');
        p.classList.add('hidden');
        if (bg) bg.style.display = 'none';
    }
}

async function renderHistoryUI(area) {
    if (!area) return;
    selectedHistoryIds.clear();
    lastHistoryIdx = -1;

    const countBadge = document.getElementById('history-count-badge');
    const storageBadge = document.getElementById('history-storage-badge');
    const list = document.getElementById('history-list');
    const historyCount = Array.isArray(contentHistory) ? contentHistory.length : 0;

    if (countBadge) countBadge.textContent = String(historyCount);
    if (storageBadge) storageBadge.textContent = 'DB 사용량 계산중..';
    if (!list) return;

    if (historyCount === 0) {
        list.innerHTML = `<div class="h-full flex items-center justify-center px-4 text-center text-sm text-textMuted">저장된 히스토리가 없습니다. (새 차시 완료 시 자동으로 저장됩니다)</div>`;
    } else {
        renderHistoryList();
    }

    // IndexedDB 저장 용량 계산 중
    try {
        if (storageBadge && navigator.storage && navigator.storage.estimate) {
            const estimation = await navigator.storage.estimate();
            const usageMB = (((typeof estimation?.usage === 'number' ? estimation.usage : 0)) / (1024 * 1024)).toFixed(1);
            storageBadge.textContent = `${usageMB} MB`;
        } else if (storageBadge) {
            storageBadge.textContent = '저장 용량 API 미지원';
        }
    } catch (e) {
        if (storageBadge) storageBadge.textContent = '용량 계산 실패';
    }
}

function renderHistoryList() {
    const container = document.getElementById('history-list');
    const countSpan = document.getElementById('history-select-count');
    if (!container) return;

    if (countSpan) countSpan.innerText = `${selectedHistoryIds.size}개 선택됨`;
    const checkAll = document.getElementById('history-select-all');
    if (checkAll) checkAll.checked = contentHistory.length > 0 && selectedHistoryIds.size === contentHistory.length;

    const reversedHistory = [...contentHistory].reverse();
    container.innerHTML = reversedHistory.map((h, displayIdx) => {
        const isSelected = selectedHistoryIds.has(h.id);
        const metadataLabel = getHistoryMetadataLabel(h);
        return `
            <div class="p-3 rounded-lg border ${isSelected ? 'bg-accent/20 border-accent/50' : 'bg-white/[0.04] border-transparent hover:bg-white/[0.08]'} cursor-pointer flex justify-between items-center transition-colors"
                 onclick="handleHistoryClick(event, ${h.id}, ${displayIdx})">
                <div class="flex items-center gap-3 pl-1">
                    <input type="checkbox" class="w-4 h-4 rounded border-white/20 bg-black/50 accent-accent pointer-events-none" ${isSelected ? 'checked' : ''}>
                    <div>
                        <h4 class="font-bold ${isSelected ? 'text-white' : 'text-white/80'} text-sm">${h.title}</h4>
                        <span class="text-xs text-white/40">${h.date}</span>
                        ${metadataLabel ? `<div class="text-[0.65rem] text-white/45 mt-0.5">${escapeHistoryHtml(metadataLabel)}</div>` : ''}
                    </div>
                </div>
                <button onclick="event.stopPropagation(); viewHistoryItem(${h.id})" class="text-accent hover:text-white hover:bg-accent text-xs font-bold px-3 py-1.5 bg-accent/10 rounded transition-colors border border-accent/20">내용 보기</button>
            </div>
        `;
    }).join('');
}

window.renderHistoryList = renderHistoryList;

window.handleHistoryClick = function (e, id, displayIdx) {
    const reversedHistory = [...contentHistory].reverse();

    if (e.shiftKey && lastHistoryIdx !== -1) {
        const start = Math.min(lastHistoryIdx, displayIdx);
        const end = Math.max(lastHistoryIdx, displayIdx);
        for (let i = start; i <= end; i++) selectedHistoryIds.add(reversedHistory[i].id);
    } else if (e.ctrlKey || e.metaKey) {
        if (selectedHistoryIds.has(id)) selectedHistoryIds.delete(id);
        else selectedHistoryIds.add(id);
        lastHistoryIdx = displayIdx;
    } else {
        selectedHistoryIds.clear();
        selectedHistoryIds.add(id);
        lastHistoryIdx = displayIdx;
    }
    renderHistoryList();
}

window.toggleSelectAllHistory = function (isChecked) {
    if (isChecked) contentHistory.forEach(h => selectedHistoryIds.add(h.id));
    else selectedHistoryIds.clear();
    lastHistoryIdx = -1;
    renderHistoryList();
}

window.deleteSelectedHistory = async function () {
    if (selectedHistoryIds.size === 0) return window.showAlert('삭제할 항목을 선택해주세요.');
    showConfirm(`선택한 ${selectedHistoryIds.size}개의 히스토리를 정말 삭제하시겠습니까?`, async () => {
        contentHistory = contentHistory.filter(h => !selectedHistoryIds.has(h.id));
        selectedHistoryIds.clear();
        await saveState();
        toggleHistoryPanel(); // Refresh view
    });
}



window.clearHistory = function () {
    if (!Array.isArray(contentHistory) || contentHistory.length === 0) {
        return window.showAlert('삭제할 히스토리가 없습니다.');
    }

    showConfirm(`전체 ${contentHistory.length}개의 히스토리를 삭제하시겠습니까?`, async () => {
        contentHistory = [];
        selectedHistoryIds.clear();
        lastHistoryIdx = -1;
        await saveState();

        const panel = document.getElementById('history-panel');
        if (panel && !panel.classList.contains('hidden')) {
            renderHistoryUI(panel);
        }
    });
}

window.exportSelectedHistoryMD = function () {

    if (selectedHistoryIds.size === 0) return window.showAlert('내보낼 항목을 선택해주세요.');

    const text = contentHistory

        .filter(h => selectedHistoryIds.has(h.id))

        .map(h => {
            const metadataLabel = getHistoryMetadataLabel(h);
            const metadataLine = metadataLabel ? `\n\n*메타데이터: ${metadataLabel}*` : '';
            return `# ${h.title}

*생성일: ${h.date}*${metadataLine}

${resolveMarkdownImages(h.content, h.images)}`;
        })

        .join('\n\n---\n\n');

    downloadFile(text, `히스토리_선택본_${Date.now()}.md`, 'text/markdown');

}



window.exportSelectedHistoryPDF = async function () {

    if (selectedHistoryIds.size === 0) return window.showAlert('내보낼 항목을 선택해주세요.');

    const items = contentHistory.filter(h => selectedHistoryIds.has(h.id));

    const btn = document.querySelector('button[onclick="exportSelectedHistoryPDF()"]');
    const origHTML = btn ? btn.innerHTML : '';
    if (btn) { btn.innerHTML = '<i class="ph-bold ph-spinner animate-spin"></i> 변환중...'; btn.disabled = true; }

    try {
        // 선택된 히스토리 항목들을 하나의 Markdown으로 합침
        let combinedMarkdown = '';
        const allImages = {};

        items.forEach((h, i) => {
            // 헤더: 제목 + 날짜 + 메타데이터
            combinedMarkdown += `# ${h.title || '제목 없음'}\n\n`;
            combinedMarkdown += `*저장일: ${h.date}*\n\n`;
            const metadataLabel = getHistoryMetadataLabel(h);
            if (metadataLabel) {
                combinedMarkdown += `*메타데이터: ${metadataLabel}*\n\n`;
            }

            // 본문 (이미지 래퍼를 순수 마크다운으로 복원)
            const resolved = resolveMarkdownImages(h.content || '', {});
            combinedMarkdown += resolved;

            // 이미지 수집
            if (h.images) Object.assign(allImages, h.images);

            // 구분자 (마지막 항목 제외)
            if (i < items.length - 1) {
                combinedMarkdown += '\n\n<div style="page-break-after: always;"></div>\n\n---\n\n';
            }
        });

        const title = items.length === 1 ? (items[0].title || '히스토리') : `히스토리 내보내기 (${items.length}건)`;
        await _generatePdfFromMarkdown(combinedMarkdown, title, allImages);

    } catch (e) {
        window.showAlert('PDF 변환 중 오류가 발생했습니다: ' + e.message);
    } finally {
        if (btn) { btn.innerHTML = origHTML; btn.disabled = false; }
    }

}



// 이미지 데이터 치환 헬퍼 함수 (내보내기 용도로 깔끔하게 변환)

function resolveMarkdownImages(content, images) {

    let md = content || '> 내용 없음';



    // 1. 커스텀 HTML 래퍼를 순수 마크다운 이미지 문법으로 되돌림 (WAF 방어 및 텍스트 추출 대비)

    md = md.replace(/<div class="image-wrapper">\s*<img src="(local:img_[^"]+)" alt="([^"]*)"[^>]*>[\s\S]*?<\/div>/gi, '![$2]($1)');



    if (images) {

        for (const [imgId, b64] of Object.entries(images)) {

            md = md.split(`local:${imgId}`).join(b64);

        }

    }

    return md;

}



window.viewHistoryItem = function (id) {
    const item = contentHistory.find(h => h.id === id);
    if (!item) { window.showAlert('해당 히스토리 항목을 찾을 수 없습니다.'); return; }

    try {
        const rawContent = item.content || '(빈 내용)';
        let resolved = rawContent;
        const metadataLabel = getHistoryMetadataLabel(item);

        // 이미지 치환 시도 (실패해도 원본 텍스트로 진행)
        try {
            resolved = resolveMarkdownImages(rawContent, item.images || {});
        } catch (imgErr) {
        console.warn('히스토리 이미지 해석 경고:', imgErr);
        }

        // marked 파서 시도 (실패 시 원본 텍스트를 pre로 대체)
        let htmlContent;
        if (typeof marked !== 'undefined') {
            try {
                htmlContent = marked.parse(resolved);
            } catch (parseErr) {
        console.warn('marked.parse 파싱 경고:', parseErr);
                htmlContent = `<pre style="white-space:pre-wrap;word-break:break-word;">${resolved.replace(/</g, '&lt;')}</pre>`;
            }
        } else {
            htmlContent = `<pre style="white-space:pre-wrap;word-break:break-word;">${resolved.replace(/</g, '&lt;')}</pre>`;
        }

        const metadataHtml = metadataLabel
            ? `<div style="font-size:12px;color:#64748b;margin-bottom:12px;">메타데이터: ${escapeHistoryHtml(metadataLabel)}</div>`
            : '';
        showModal(`[복원] ${item.title || '제목 없음'}`, metadataHtml + htmlContent);

    } catch (e) {
        console.error('히스토리 복원 오류:', e);
        window.showAlert('내용을 로드하는 중 오류가 발생했습니다: ' + e.message);
    }
}



let draggedId = null;

function initDragAndDrop() {

    const cards = document.querySelectorAll('.module-card');

    cards.forEach(card => {

        card.addEventListener('dragstart', (e) => {

            draggedId = card.dataset.id === 'mainQuest' ? 'mainQuest' : parseInt(card.dataset.id);

            card.classList.add('dragging');

            e.dataTransfer.effectAllowed = 'move';

        });

        card.addEventListener('dragend', () => {

            card.classList.remove('dragging');

            draggedId = null;

            document.querySelectorAll('.module-card').forEach(c => c.classList.remove('drag-over'));

        });

        card.addEventListener('dragover', (e) => {

            e.preventDefault();

            e.dataTransfer.dropEffect = 'move';

            card.classList.add('drag-over');

        });

        card.addEventListener('dragleave', () => {

            card.classList.remove('drag-over');

        });

        card.addEventListener('drop', (e) => {

            e.preventDefault();

            card.classList.remove('drag-over');

            const targetId = card.dataset.id === 'mainQuest' ? 'mainQuest' : parseInt(card.dataset.id);



            if (draggedId !== null && draggedId !== targetId && draggedId !== 'mainQuest' && targetId !== 'mainQuest') {

                const fromIdx = courseData.findIndex(m => m.id === draggedId);

                const toIdx = courseData.findIndex(m => m.id === targetId);

                if (fromIdx !== -1 && toIdx !== -1) {

                    const [moved] = courseData.splice(fromIdx, 1);

                    courseData.splice(toIdx, 0, moved);

                    saveState().then(() => {
                        renderSidebar();
                    });

                }

            }

        });

    });

}



function downloadFile(content, fileName, mimeType) {

    const blob = new Blob([content], { type: mimeType });

    const url = URL.createObjectURL(blob);

    const a = document.createElement('a');

    a.href = url;

    a.download = fileName;

    a.click();

    URL.revokeObjectURL(url);

}

function _getNormalizedTeacherNotes(mod) {
    if (!mod || !Array.isArray(mod.teacherNotes)) return [];
    const seen = new Set();
    const notes = [];
    mod.teacherNotes.forEach(item => {
        if (!item || typeof item !== 'object') return;
        const anchor = String(item.anchor || '').trim();
        const note = String(item.note || '').trim();
        if (!anchor || !note || seen.has(anchor)) return;
        seen.add(anchor);
        notes.push({ anchor, note });
    });
    return notes;
}

function _stripTeacherNotesCommentBlock(markdown) {
    const source = typeof markdown === 'string' ? markdown : '';
    return source.replace(/\n*<!--\s*TEACHER:\s*BEGIN[\s\S]*?TEACHER:\s*END\s*-->\s*/gi, '\n').trimEnd();
}

function _extractTeacherNotesFromMarkdown(markdown) {
    const source = typeof markdown === 'string' ? markdown : '';
    const blockMatch = source.match(/<!--\s*TEACHER:\s*BEGIN\s*([\s\S]*?)\s*TEACHER:\s*END\s*-->/i);
    if (!blockMatch) {
        return { cleanMarkdown: source, notes: [] };
    }

    const body = blockMatch[1] || '';
    const notes = [];
    const noteRegex = /\[\d+\]\s*anchor:\s*([^\n]+)\n([\s\S]*?)(?=\n\s*\[\d+\]\s*anchor:|$)/g;
    let match;
    while ((match = noteRegex.exec(body)) !== null) {
        const anchor = String(match[1] || '').trim();
        const note = String(match[2] || '').trim();
        if (!anchor || !note) continue;
        if (!notes.some(item => item.anchor === anchor)) {
            notes.push({ anchor, note });
        }
    }

    return {
        cleanMarkdown: _stripTeacherNotesCommentBlock(source),
        notes
    };
}

function _buildTeacherNotesCommentBlock(mod) {
    const notes = _getNormalizedTeacherNotes(mod);
    if (notes.length === 0) return '';

    const body = notes.map((item, idx) => {
        return `[${idx + 1}] anchor: ${item.anchor}\n${item.note}`;
    }).join('\n\n');

    return `\n\n<!-- TEACHER: BEGIN\n${body}\nTEACHER: END -->`;
}

function _buildMarkdownVariantsForExport(mod, options = {}) {
    const prependTitle = !!options.prependTitle;
    const titleText = prependTitle ? `# ${mod.title}\n\n` : '';
    const coreContent = _stripTeacherNotesCommentBlock(mod.content || '');
    const studentMd = `${titleText}${coreContent}`.trim();
    const teacherBlock = _buildTeacherNotesCommentBlock(mod);
    const teacherMd = `${studentMd}${teacherBlock}`.trim();
    return {
        studentMd: studentMd ? `${studentMd}\n` : '',
        teacherMd: teacherMd ? `${teacherMd}\n` : ''
    };
}

function _splitMarkdownVariantFileNames(baseName) {
    const raw = typeof baseName === 'string' ? baseName : 'module.md';
    const noExt = raw.toLowerCase().endsWith('.md') ? raw.slice(0, -3) : raw;
    return {
        studentFileName: `${noExt}_student.md`,
        teacherFileName: `${noExt}_teacher.md`
    };
}

function _base64StringToUint8Array(base64Text) {
    const text = typeof base64Text === 'string' ? base64Text : '';
    const binaryString = atob(text);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
}

function _rewriteMarkdownImageRefs(markdown, images, onImageExport) {
    let output = typeof markdown === 'string' ? markdown : '';
    if (!images || typeof images !== 'object' || Array.isArray(images)) return output;

    for (const [imgId, value] of Object.entries(images)) {
        let imgFileName = null;
        if (typeof value === 'string') {
            const matches = value.match(/^data:(image\/\w+);base64,(.*)$/);
            if (matches) {
                let ext = matches[1].split('/')[1];
                if (ext === 'jpeg') ext = 'jpg';
                imgFileName = `${imgId}.${ext}`;
                if (typeof onImageExport === 'function') {
                    onImageExport(imgFileName, matches[2], value);
                }
            } else if (value.startsWith('__FILE__:')) {
                imgFileName = value.substring('__FILE__:'.length);
            }
        }
        if (!imgFileName) continue;

        const tagRegex = new RegExp(`<!--\\s*\\[IMG:\\s*"?local:${imgId}"?\\]\\s*-->`, 'g');
        const imgRegex = new RegExp(`src="local:${imgId}"`, 'g');
        output = output.replace(tagRegex, `![${imgId}](../첨부파일/${imgFileName})`);
        output = output.replace(imgRegex, `src="../첨부파일/${imgFileName}"`);
    }

    return output;
}



window.exportCurrentModule = async function () {
    const mod = getEditingModule();
    if (!mod || !mod.content) return window.showAlert('현재 내용이 없습니다.');
    const subj = globalState.subjects.find(s => s.id === currentSubjectId);

    // 과정명(Project Name), 교과명(Subject Name) 안전화
    const rawCourseTitle = globalState.courseTitle || '내 교안 프로젝트';
    const safeCourseName = _toSafeFolderName(rawCourseTitle, 'course');
    const safeSubjName = _toSafeFolderName(subj ? subj.title : '', 'subject');
    const fallbackFileName = `${_sanitizeFileStem(mod.title || 'module', 'module')}.md`;
    const fileName = getModuleExportFileNameByConvention(subj, mod.id, fallbackFileName, '.md');

    try {
        const zip = new JSZip();

        // 1. 최상위 과정명 폴더 생성
        const rootFolder = zip.folder(safeCourseName);

        // 2. 메타데이터 루트 배치
        const metaObj = {
            project: rawCourseTitle,
            subject: subj ? subj.title : '',
            module: mod.title,
            timestamp: new Date().toISOString()
        };
        rootFolder.file('save_data.yaml', JSON.stringify(metaObj, null, 2));

        // 3. 리소스(첨부파일) 및 교과 폴더 생성
        const attachFolder = rootFolder.folder("첨부파일");
        const subjFolder = rootFolder.folder(safeSubjName);

        const variants = _buildMarkdownVariantsForExport(mod, { prependTitle: false });
        const { studentFileName, teacherFileName } = _splitMarkdownVariantFileNames(fileName);
        const writtenImageFiles = new Set();
        const appendImageToZip = (imgFileName, base64Data) => {
            if (writtenImageFiles.has(imgFileName)) return;
            writtenImageFiles.add(imgFileName);
            attachFolder.file(imgFileName, base64Data, { base64: true });
        };

        const studentMd = _rewriteMarkdownImageRefs(variants.studentMd, mod.images, appendImageToZip);
        const teacherMd = _rewriteMarkdownImageRefs(variants.teacherMd, mod.images, appendImageToZip);

        subjFolder.file(studentFileName, studentMd);
        subjFolder.file(teacherFileName, teacherMd);

        const content = await zip.generateAsync({ type: "blob" });
        saveAs(content, `${safeCourseName}_${fileName.replace('.md', '')}_teacher_student.zip`);

    } catch (e) {
        console.error('ZIP 생성 오류:', e);
        window.showAlert('압축 파일 생성 중 오류가 발생했습니다. JSZip 라이브러리가 로드되었는지 확인해주세요.');
    }
}



window.exportAllModules = async function () {
    if (!Array.isArray(courseData) || courseData.length === 0) return window.showAlert('현재 데이터가 없습니다.');
    const subj = globalState.subjects.find(s => s.id === currentSubjectId);

    // 과정명(Project Name) 안전화
    const rawCourseTitle = globalState.courseTitle || '내 교안 프로젝트';
    const safeCourseName = rawCourseTitle.replace(/[\/\?<>\\:\*\|"]/g, '_').trim();
    // 교과명(Subject Name) 안전화
    const safeSubjName = subj ? subj.title.replace(/[\/\?<>\\:\*\|"]/g, '_').trim() : '기본_교과';

    try {
        const zip = new JSZip();

        // 1. 최상위 과정명 폴더 생성
        const rootFolder = zip.folder(safeCourseName);

        // 2. 메타데이터(save_data.yaml) 루트 배치
        const metaObj = {
            project: rawCourseTitle,
            subject: subj ? subj.title : '',
            timestamp: new Date().toISOString(),
            module_count: courseData.length,
            context: buildCompactStateForExternalSave(globalState) // 전체 설정 및 호환 컨텍스트 직렬화
        };
        rootFolder.file('save_data.yaml', JSON.stringify(metaObj, null, 2)); // 편의상 JSON 직렬화를 yaml 확장자로 보존

        // 3. 리소스(첨부파일) 서브폴더 및 교과 폴더 생성
        const attachFolder = rootFolder.folder("첨부파일");
        const subjFolder = rootFolder.folder(safeSubjName);

        const writtenImageFiles = new Set();
        const appendImageToZip = (imgFileName, base64Data) => {
            if (writtenImageFiles.has(imgFileName)) return;
            writtenImageFiles.add(imgFileName);
            attachFolder.file(imgFileName, base64Data, { base64: true });
        };

        courseData.forEach((m, idx) => {
            if (String(m?.id) === 'mainQuest') return;
            const fallbackFileName = _buildDefaultModuleFileName(m, idx);
            const mdFileName = getModuleExportFileNameByConvention(subj, m.id, fallbackFileName, '.md');

            const variants = _buildMarkdownVariantsForExport(m, { prependTitle: true });
            const { studentFileName, teacherFileName } = _splitMarkdownVariantFileNames(mdFileName);
            const studentMd = _rewriteMarkdownImageRefs(variants.studentMd, m.images, appendImageToZip);
            const teacherMd = _rewriteMarkdownImageRefs(variants.teacherMd, m.images, appendImageToZip);

            subjFolder.file(studentFileName, studentMd);
            subjFolder.file(teacherFileName, teacherMd);
        });

        // 4. mainQuest 별도 내보내기
        if (subj && subj.mainQuest && subj.mainQuest.content) {
            const mq = subj.mainQuest;
            const mqFallbackFileName = _buildDefaultModuleFileName(mq, -1);
            const mqFileName = getModuleExportFileNameByConvention(subj, mq.id, mqFallbackFileName, '.md');

            const variants = _buildMarkdownVariantsForExport(mq, { prependTitle: true });
            const { studentFileName, teacherFileName } = _splitMarkdownVariantFileNames(mqFileName);
            const studentMd = _rewriteMarkdownImageRefs(variants.studentMd, mq.images, appendImageToZip);
            const teacherMd = _rewriteMarkdownImageRefs(variants.teacherMd, mq.images, appendImageToZip);

            subjFolder.file(studentFileName, studentMd);
            subjFolder.file(teacherFileName, teacherMd);
        }

        // 묶음 ZIP 생성 (이름: 프로젝트_교과명)
        const content = await zip.generateAsync({ type: "blob" });
        saveAs(content, `${safeCourseName}_${safeSubjName}.zip`);

    } catch (e) {
        console.error('전체 ZIP 생성 오류:', e);
        window.showAlert('압축 파일 생성 중 오류가 발생했습니다. JSZip 라이브러리가 로드되었는지 확인해주세요.');
    }
}



// =========================================================================
// PDF 내보내기 (현재 차시)
// =========================================================================
window.exportToPDF = async function () {
    const mod = getEditingModule();
    if (!mod || !mod.content) {
        return window.showAlert('PDF로 변환할 교안 내용이 없습니다. 차시를 선택하고 교안을 먼저 생성해주세요.');
    }

    const btn = document.getElementById('pdf-dropdown-btn');
    let originalHTML = '';
    if (btn) { originalHTML = btn.innerHTML; btn.innerHTML = '<i class="ph-bold ph-spinner animate-spin"></i> 변환중'; btn.disabled = true; }

    try {
        await _generatePdfFromMarkdown(mod.content, mod.title, mod.images || {});
    } catch (e) {
        window.showAlert('PDF 변환 오류가 발생했습니다: ' + e.message);
    } finally {
        if (btn) { btn.innerHTML = originalHTML; btn.disabled = false; }
    }
}

// =========================================================================
// PDF 내보내기 (현재 교과 전체 - 차시별 페이지)
// =========================================================================
window.exportSubjectToPDF = async function () {
    if (!Array.isArray(courseData) || courseData.length === 0) {
        return window.showAlert('현재 교과의 차시가 없습니다.');
    }

    const contentModules = courseData.filter(m => m.content);
    if (contentModules.length === 0) {
        return window.showAlert('PDF로 변환할 교안이 없습니다. 교안을 먼저 생성해주세요.');
    }

    const btn = document.getElementById('pdf-dropdown-btn');
    let originalHTML = '';
    if (btn) { originalHTML = btn.innerHTML; btn.innerHTML = '<i class="ph-bold ph-spinner animate-spin"></i> 변환중'; btn.disabled = true; }

    try {
        // 모든 차시의 Markdown을 차시 구분선과 함께 합침
        let combinedMarkdown = '';
        for (let i = 0; i < contentModules.length; i++) {
            const m = contentModules[i];
            combinedMarkdown += m.content;
            if (i < contentModules.length - 1) {
                combinedMarkdown += '\n\n<div style="page-break-after: always;"></div>\n\n---\n\n';
            }
        }

        // 모든 이미지를 병합
        const allImages = {};
        contentModules.forEach(m => {
            if (m.images) Object.assign(allImages, m.images);
        });

        const subj = globalState.subjects.find(s => s.id === currentSubjectId);
        const subjTitle = subj ? subj.title : '제목 없음';

        await _generatePdfFromMarkdown(combinedMarkdown, subjTitle, allImages);
    } catch (e) {
        window.showAlert('PDF 변환 오류가 발생했습니다: ' + e.message);
    } finally {
        if (btn) { btn.innerHTML = originalHTML; btn.disabled = false; }
    }
}

// =========================================================================
// PDF 공통 유틸: Markdown -> HTML -> html2pdf.js 변환
async function _generatePdfFromMarkdown(markdownContent, title, images) {
    var tempDiv = null;

    try {
        // 1. Markdown -> HTML 변환
        var htmlContent = '';
        if (typeof marked !== 'undefined') {
            htmlContent = marked.parse(markdownContent);
        } else {
            htmlContent = '<pre style="white-space:pre-wrap;">' + markdownContent + '</pre>';
        }

        // 2. 이미지 참조를 base64 data URI로 교체
        if (images && Object.keys(images).length > 0) {
            for (const [imgId, b64] of Object.entries(images)) {
                htmlContent = htmlContent.replace(new RegExp('src="local:' + imgId + '"', 'g'), 'src="' + b64 + '"');
            }
        }

        // 3. 오프스크린 렌더링 컨테이너 생성
        var html2pdfFactory = window.html2pdf;
        if (typeof html2pdfFactory !== 'function') {
            throw new Error('html2pdf.js가 로드되지 않았습니다.');
        }

        tempDiv = document.createElement('div');
        tempDiv.id = 'pdf-temp-render-root';
        tempDiv.setAttribute('aria-hidden', 'true');
        tempDiv.style.cssText = [
            'position:fixed',
            'left:-100000px',
            'top:0',
            'width:180mm',
            'padding:0',
            'margin:0',
            'background:#ffffff',
            'color:#111827',
            'overflow:hidden',
            'z-index:-1'
        ].join(';') + ';';
        tempDiv.innerHTML = `
            <div style="background:#ffffff; color:#111827; font-family:'Malgun Gothic','Apple SD Gothic Neo','Noto Sans KR',sans-serif; font-size:14px; line-height:1.7; word-break:keep-all;">
                <style>
                    * { box-sizing: border-box; }
                    h1 { font-size: 28px; font-weight: 800; margin: 0 0 16px; padding-bottom: 8px; border-bottom: 2px solid #2563eb; color: #111827; }
                    h2 { font-size: 22px; font-weight: 700; margin: 28px 0 12px; color: #111827; }
                    h3 { font-size: 18px; font-weight: 700; margin: 22px 0 10px; color: #1f2937; }
                    p { margin: 0 0 12px; }
                    ul, ol { margin: 0 0 12px; padding-left: 24px; }
                    li { margin-bottom: 4px; }
                    hr { border: 0; border-top: 1px solid #d1d5db; margin: 24px 0; }
                    code { background: #f3f4f6; color: #1d4ed8; padding: 2px 5px; border-radius: 4px; font-family: Consolas, 'Courier New', monospace; }
                    pre { margin: 0 0 16px; padding: 16px; background: #f8fafc; border: 1px solid #d1d5db; border-radius: 8px; overflow-x: auto; white-space: pre-wrap; page-break-inside: avoid; break-inside: avoid; }
                    pre code { background: transparent; color: #111827; padding: 0; }
                    blockquote { margin: 0 0 16px; padding: 12px 16px; border-left: 4px solid #2563eb; background: #eff6ff; color: #1f2937; page-break-inside: avoid; break-inside: avoid; }
                    table { width: 100%; border-collapse: collapse; margin: 0 0 16px; page-break-inside: avoid; break-inside: avoid; }
                    th, td { border: 1px solid #d1d5db; padding: 8px 10px; text-align: left; vertical-align: top; }
                    th { background: #f3f4f6; font-weight: 700; }
                    img { display: block; max-width: 100%; height: auto; margin: 16px auto; page-break-inside: avoid; break-inside: avoid; }
                    .image-wrapper button, .image-wrapper span.absolute, .image-regenerate-btn { display: none !important; }
                </style>
                ${htmlContent}
            </div>
        `;
        document.body.appendChild(tempDiv);

        // 4. 이미지/폰트 로드 대기
        var imgEls = tempDiv.querySelectorAll('img');
        if (imgEls.length > 0) {
            await Promise.all(Array.from(imgEls).map(function (img) {
                if (img.complete) return Promise.resolve();
                return new Promise(function (res) { img.onload = res; img.onerror = res; });
            }));
        }

        if (document.fonts && document.fonts.ready) {
            await document.fonts.ready;
        }
        await new Promise(function (res) {
            requestAnimationFrame(function () {
                requestAnimationFrame(res);
            });
        });

        // 5. html2pdf.js로 PDF 저장
        await html2pdfFactory().set({
            margin: [15, 15, 15, 15],
            filename: (title || '교안') + '.pdf',
            image: { type: 'jpeg', quality: 0.95 },
            html2canvas: { scale: 2, useCORS: true, logging: false },
            jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
        }).from(tempDiv).save();

    } catch (e) {
        console.error('PDF 변환 오류:', e);
        window.showAlert('PDF (인쇄) 기능을 사용하는 중 예상치 못한 오류가 발생했습니다.');
    } finally {
        if (tempDiv && tempDiv.parentNode) {
            tempDiv.remove();
        }
    }
}

// =========================================================================
// PDF 드롭다운 토글 (클릭 기반)
// =========================================================================
window.togglePdfDropdown = function (event) {
    const dropdown = document.getElementById('pdf-dropdown-menu');
    if (!dropdown) return;
    const isOpen = !dropdown.classList.contains('hidden');
    if (isOpen) {
        dropdown.classList.add('hidden');
        document.removeEventListener('click', _closePdfDropdownOnOutside);
        return;
    }
    const btn = document.getElementById('pdf-dropdown-btn');
    if (btn) {
        const btnRect = btn.getBoundingClientRect();
        const dropW = 160; // w-40 = 10rem = 160px
        const top = btnRect.bottom + 4;
        // 화면 오른쪽에서 넘치면 왼쪽으로 맞추고, 아니면 원래 위치 유지
        const left = (btnRect.left + dropW > window.innerWidth)
            ? window.innerWidth - dropW - 8
            : btnRect.left;
        dropdown.style.top = top + 'px';
        dropdown.style.left = left + 'px';
    }
    dropdown.classList.remove('hidden');
    setTimeout(() => { document.addEventListener('click', _closePdfDropdownOnOutside); }, 0);
    if (event) event.stopPropagation();
}
function _closePdfDropdownOnOutside(e) {
    const dropdown = document.getElementById('pdf-dropdown-menu');
    const btn = document.getElementById('pdf-dropdown-btn');
    if (dropdown && !dropdown.contains(e.target) && btn && !btn.contains(e.target)) {
        dropdown.classList.add('hidden');
        document.removeEventListener('click', _closePdfDropdownOnOutside);
    }
}



function handleImageFileInsertion(file, target) {
    const fileType = file.type; // e.g. 'image/png', 'image/gif'
    const reader = new FileReader();

    reader.onload = (event) => {
        const originalB64 = event.target.result;

        // GIF는 특수 포맷이라 캔버스 압축을 건너뛰고 원본을 유지
        if (fileType === 'image/gif') {
            const mod = getEditingModule();
            if (!mod.images) mod.images = {};
            const imgId = 'img_' + Date.now() + Math.floor(Math.random() * 1000);
            mod.images[imgId] = originalB64; // 원본 B64 보존

            const imgTag = `\n<img src="local:${imgId}" alt="inserted image" style="max-width:100%; border-radius:8px;">\n`;
            insertTextAtCursor(target, imgTag);
            return;
        }

        // 일반 정적 이미지는 리사이즈 후 png(또는 jpeg) 단일 파일로 처리
        const img = new Image();
        img.onload = () => {
            const canvas = document.createElement('canvas');
            let width = img.width;
            let height = img.height;
            const MAX_WIDTH = 800;

            if (width > MAX_WIDTH) {
                height = Math.round((height * MAX_WIDTH) / width);
                width = MAX_WIDTH;
            }

            canvas.width = width;
            canvas.height = height;
            const ctx = canvas.getContext('2d');
            ctx.drawImage(img, 0, 0, width, height);

            // 규정에 따라 정적 이미지는 png로 단일화
            const compressedBase64 = canvas.toDataURL('image/png');

            const mod = getEditingModule();
            if (!mod.images) mod.images = {};
            const imgId = 'img_' + Date.now() + Math.floor(Math.random() * 1000);
            mod.images[imgId] = compressedBase64;

            const imgTag = `\n<img src="local:${imgId}" alt="inserted image" style="max-width:100%; border-radius:8px;">\n`;
            insertTextAtCursor(target, imgTag);
        };
        img.src = originalB64;
    };
    reader.readAsDataURL(file);
}

function insertTextAtCursor(target, text) {
    const pos = target.selectionStart;
    target.value = target.value.substring(0, pos) + text + target.value.substring(pos);
    target.setSelectionRange(pos + text.length, pos + text.length);

    // 메인 에디터인 경우에만 즉시 원문 저장 로직까지 수행
    // (모달 에디터 팝업은 onBlur/Enter 이벤트에서 직접 AST 저장하므로 제외)
    if (target.id === 'raw-view') {
        if (typeof saveRawContent === 'function') saveRawContent();
    }
}

function initImageInsertionHandlers() {
    const isInsertionTarget = (target) => {
        if (!target) return false;
        // 메인 에디터(#raw-view) 또는 모달 에디터(TEXTAREA)인 경우 허용
        return target.id === 'raw-view' || (target.tagName === 'TEXTAREA' && target.closest('#render-view'));
    };

    // Paste Event
    document.addEventListener('paste', (e) => {
        const target = e.target;
        if (isInsertionTarget(target)) {
            const items = (e.clipboardData || window.clipboardData).items;
            for (let i = 0; i < items.length; i++) {
                if (items[i].kind === 'file' && items[i].type.startsWith('image/')) {
                    e.preventDefault();
                    handleImageFileInsertion(items[i].getAsFile(), target);
                    break;
                }
            }
        }
    });

    // Dragover Event (To allow drop)
    document.addEventListener('dragover', (e) => {
        const target = e.target;
        if (isInsertionTarget(target)) {
            e.preventDefault(); // allow drop
            target.classList.add('border-accent', 'bg-accent/10'); // Optional: Add visual cue
        }
    });

    // Dragleave Event
    document.addEventListener('dragleave', (e) => {
        const target = e.target;
        if (isInsertionTarget(target)) {
            target.classList.remove('border-accent', 'bg-accent/10');
        }
    });

    // Drop Event
    document.addEventListener('drop', (e) => {
        const target = e.target;
        if (isInsertionTarget(target)) {
            e.preventDefault();
            target.classList.remove('border-accent', 'bg-accent/10');

            const files = e.dataTransfer.files;
            if (files && files.length > 0) {
                // Handle multiple files if dropped
                for (let i = 0; i < files.length; i++) {
                    if (files[i].type.startsWith('image/')) {
                        handleImageFileInsertion(files[i], target);
                    }
                }
            }
        }
    });
}


// =========================================================================
// 이미지 파일 선택 삽입 핸들러 (에디터 도구모음 "이미지 삽입" 버튼)
// =========================================================================
window.handleImageInputSelect = function (event) {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    // 삽입 대상은 수정 모드(raw-view) 또는 활성 모달 에디터 textarea
    let target = document.getElementById('raw-view');
    if (!target || target.classList.contains('hidden')) {
        // 모달 에디터의 textarea 탐색
        const renderView = document.getElementById('render-view');
        if (renderView) {
            target = renderView.querySelector('textarea');
        }
    }

    if (!target) {
    window.showAlert('이미지를 삽입하려면 설정 모드로 전환하세요. 우측 버튼을 활성화하여 인라인 편집을 시작해주세요.');
        event.target.value = '';
        return;
    }

    for (let i = 0; i < files.length; i++) {
        if (files[i].type.startsWith('image/')) {
            handleImageFileInsertion(files[i], target);
        }
    }

    // 같은 파일 우선순위를 사용하기 위해 인풋 리셋
    event.target.value = '';
};

// =========================================================================
// ZIP 아카이브 파일 복원 (Load Import) 체계
// =========================================================================
window.importProjectZip = async function (event) {
    const file = event.target.files[0];
    if (!file) return;

    if (!file.name.endsWith('.zip')) {
    window.showAlert('지원하지 않는 파일 형식입니다. (.zip 형식만 가능)');
        event.target.value = '';
        return;
    }

    try {
        const zip = await JSZip.loadAsync(file);
        let metaObj = null;
        let imageMap = new Map(); // fileName -> base64
        let mdFiles = [];

        // 1회차: 메타데이터/이미지/마크다운 경로 수집
        const entries = Object.keys(zip.files);
        for (const relativePath of entries) {
            const zipEntry = zip.files[relativePath];
            if (zipEntry.dir) continue;

            if (relativePath.includes('save_data.yaml')) {
                const yamlText = await zipEntry.async("string");
                metaObj = safeJSONParse(yamlText); // yaml이지만 이전 단계에서 임의의 JSON 직렬화가 저장됨
            } else if (relativePath.includes('첨부파일/')) {
                const binaryData = await zipEntry.async("base64");
                const ext = relativePath.split('.').pop().toLowerCase();
                const mimeType = ext === 'jpg' ? 'image/jpeg' : `image/${ext}`;
                const safeB64 = `data:${mimeType};base64,${binaryData}`;

                // 파일명을 키로 사용 (예: "img_12345.png")
                const fileName = relativePath.split('/').pop();
                imageMap.set(fileName, safeB64);
            } else if (relativePath.endsWith('.md')) {
                const mdContent = await zipEntry.async("string");
                mdFiles.push({ path: relativePath, content: mdContent });
            }
        }

        if (!metaObj) {
        throw new Error('유효한 Web Agent 파일(save_data.yaml 파싱 실패 또는 없음)이 아닙니다.');
        }

        let isSingleModule = !metaObj.context;

        if (isSingleModule) {
            // 단일 차시(exportCurrentModule) 복원 모드: 현재 교과에 새 모듈로 종속
            const subj = globalState.subjects.find(s => s.id === currentSubjectId);
    if (!subj) throw new Error('현재 선택된 교과가 없습니다. 교과를 먼저 생성해주세요.');

            let newMod = {
                id: 'm_' + Date.now() + Math.floor(Math.random() * 1000),
                title: metaObj.module || '불러온 교안',
                description: '',
                status: 'waiting',
                content: '',
                images: {},
                teacherNotes: [],
                qualityEvaluation: null,
                uploadedMdName: null,
                uploadedMdContent: null
            };

            const matchedMd = mdFiles.find(mf => mf.path.endsWith('.md'));
            if (matchedMd) {
                let content = matchedMd.content;
                // YAML 헤더 스트립
                const yamlEndIdx = content.indexOf('---\n\n');
                if (yamlEndIdx !== -1 && content.startsWith('---')) {
                    content = content.substring(yamlEndIdx + 5);
                } else if (content.startsWith('# ' + newMod.title)) {
                    content = content.replace(new RegExp(`^# ${newMod.title}\\n\\n`), '');
                }

        // 이미지 경로 역변환 (../첨부파일/img_xxx -> local:img_xxx)
        const revertTagRegex = /!\[([^\]]+)\]\(\.\.\/첨부파일\/([^)]+)\)/g;
        const revertImgRegex = /src="\.\.\/첨부파일\/([^"]+)"/g;

                content = content.replace(revertTagRegex, (match, altStr, fileName) => {
                    const originalId = fileName.split('.')[0];
                    if (imageMap.has(fileName)) newMod.images[originalId] = imageMap.get(fileName);
                    return `<!-- [IMG: "local:${originalId}"] -->`;
                });

                content = content.replace(revertImgRegex, (match, fileName) => {
                    const originalId = fileName.split('.')[0];
                    if (imageMap.has(fileName)) newMod.images[originalId] = imageMap.get(fileName);
                    return `src="local:${originalId}"`;
                });

                const extracted = _extractTeacherNotesFromMarkdown(content);
                newMod.content = extracted.cleanMarkdown;
                if (Array.isArray(extracted.notes) && extracted.notes.length > 0) {
                    newMod.teacherNotes = extracted.notes;
                }
            }

            courseData.push(newMod);

            await saveState(); // 로컬스토리지 백업
            if (typeof renderSidebar === 'function') renderSidebar();
            if (typeof viewModule === 'function') viewModule(newMod.id);
        window.showAlert('파일 차시 교안이 현재 교과에 성공적으로 적용되었습니다!');

        } else {
            // 기존 교안 데이터를 히스토리로 백업 (덮어쓰기 전 안전장치)
            if (Array.isArray(courseData) && courseData.length > 0) {
                courseData.forEach(mod => {
                    if (mod && mod.content) archiveContent(mod);
                });
            }

            // 2단계: globalState 전체 복원 (전체 코스 모드)
            globalState = metaObj.context;
            // API 키는 브라우저 보안 정책으로 별도 보존
            if (typeof apiKey !== 'undefined') globalState.apiKey = apiKey;

            // 3회차: courseData 재구성 및 이미지 재매핑 (Map -> 로컬 이미지 맵)
            const restoredSubj = globalState.subjects.find(s => s.id === currentSubjectId) || globalState.subjects[0];
            if (restoredSubj) {
                currentSubjectId = restoredSubj.id;
                courseData = restoredSubj.lessons || [];

                courseData.forEach(mod => {
                    if (!mod.images) mod.images = {};

                    const matchedMd = mdFiles.find(mf => mf.path.includes(mod.title) || mf.content.includes(`# ${mod.title}`));
                    if (matchedMd) {
                        let content = matchedMd.content;

                        const yamlEndIdx = content.indexOf('---\n\n');
                        if (yamlEndIdx !== -1 && content.startsWith('---')) {
                            content = content.substring(yamlEndIdx + 5);
                        } else if (content.startsWith('# ' + mod.title)) {
                            content = content.replace(new RegExp(`^# ${mod.title}\\n\\n`), '');
                        }

        const revertTagRegex = /!\[([^\]]+)\]\(\.\.\/첨부파일\/([^)]+)\)/g;
        const revertImgRegex = /src="\.\.\/첨부파일\/([^"]+)"/g;

                        content = content.replace(revertTagRegex, (match, altStr, fileName) => {
                            const originalId = fileName.split('.')[0]; // img_123
                            if (imageMap.has(fileName)) mod.images[originalId] = imageMap.get(fileName);
                            return `<!-- [IMG: "local:${originalId}"] -->`;
                        });

                        content = content.replace(revertImgRegex, (match, fileName) => {
                            const originalId = fileName.split('.')[0];
                            if (imageMap.has(fileName)) mod.images[originalId] = imageMap.get(fileName);
                            return `src="local:${originalId}"`;
                        });

                        const extracted = _extractTeacherNotesFromMarkdown(content);
                        mod.content = extracted.cleanMarkdown;
                        if ((!Array.isArray(mod.teacherNotes) || mod.teacherNotes.length === 0) && Array.isArray(extracted.notes) && extracted.notes.length > 0) {
                            mod.teacherNotes = extracted.notes;
                        }
                    }
                });
            }

            // 4. UI 및 메모리 싱크
            await saveState(); // 로컬스토리지 증분 백업
            if (typeof renderSidebar === 'function') renderSidebar();
            // SPA 라우팅을 위해 개요 화면으로 안전하게 전환
            location.hash = '#overview';

        window.showAlert('성공적으로 저장 파일이 로드된 상태로 복원됩니다!');
        }

    } catch (e) {
        console.error('ZIP 불러오기 오류:', e);
        window.showAlert(`불러오기 실패: ${e.message}`);
    } finally {
        event.target.value = ''; // 재업로드를 위해 입력 리셋
    }
};


// =========================================================================
// 내보내기용 로컬 파일 시스템 유틸 (File System Access API)
// =========================================================================

/**
 * base64 Data URL을 Uint8Array 바이너리로 변환하는 헬퍼
 */
function base64ToUint8Array(b64DataUrl) {
    const base64 = b64DataUrl.split(',')[1];
    const binaryString = atob(base64);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
}

/**
 * FileSystemDirectoryHandle에 텍스트 파일 쓰기 헬퍼
 */
async function writeTextFile(dirHandle, fileName, content) {
    const fileHandle = await dirHandle.getFileHandle(fileName, { create: true });
    const writable = await fileHandle.createWritable();
    await writable.write(content);
    await writable.close();
}

/**
 * FileSystemDirectoryHandle에 바이너리 파일 쓰기 헬퍼
 */
async function writeBinaryFile(dirHandle, fileName, uint8Array) {
    const fileHandle = await dirHandle.getFileHandle(fileName, { create: true });
    const writable = await fileHandle.createWritable();
    await writable.write(uint8Array);
    await writable.close();
}


// =========================================================================
// 로컬 프로젝트 폴더 실시간 연결/동기화 시스템 (Phase F7)
// =========================================================================

function removeFolderReauthBanner() {
    const banner = document.getElementById('folder-reauth-banner');
    if (banner) banner.remove();
}

function showFolderReauthBanner(folderName, onReauthClick) {
    let banner = document.getElementById('folder-reauth-banner');
    if (!banner) {
        banner = document.createElement('div');
        banner.id = 'folder-reauth-banner';
        banner.className = 'fixed top-[68px] right-4 z-[260] w-[340px] max-w-[calc(100vw-24px)] rounded-xl border border-orange-400/40 bg-[#2a1e15]/95 shadow-[0_14px_30px_rgba(0,0,0,0.5)] backdrop-blur-sm p-3 text-[0.72rem] text-orange-100 animate-fade-in';
        banner.innerHTML = `
            <div class="flex items-start gap-2">
                <i class="ph-fill ph-warning-circle text-orange-300 text-base mt-0.5"></i>
                <div class="min-w-0 flex-1">
                    <p class="font-semibold leading-5">폴더 권한이 만료되었습니다.</p>
                    <p class="text-orange-100/80 leading-5 mt-0.5 truncate"><span data-folder-name></span> 폴더에 다시 접근하려면 재인증이 필요합니다.</p>
                    <div class="mt-2 flex justify-end gap-1.5">
                        <button type="button" data-close-btn class="px-2 py-1 rounded-md border border-orange-300/30 text-orange-100/80 hover:text-white hover:bg-orange-500/20 transition-colors">닫기</button>
                        <button type="button" data-reauth-btn class="px-2.5 py-1 rounded-md bg-orange-500/80 hover:bg-orange-500 text-white font-semibold transition-colors">재인증</button>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(banner);
    }

    const folderNameNode = banner.querySelector('[data-folder-name]');
    if (folderNameNode) folderNameNode.textContent = folderName || '연결된 폴더';

    const closeBtn = banner.querySelector('[data-close-btn]');
    if (closeBtn) {
        closeBtn.onclick = () => removeFolderReauthBanner();
    }

    const reauthBtn = banner.querySelector('[data-reauth-btn]');
    if (reauthBtn) {
        reauthBtn.onclick = () => {
            if (typeof onReauthClick === 'function') onReauthClick();
        };
    }
}

/**
 * 프로젝트 폴더 연결. 이후 모든 saveState() 호출 시 해당 폴더에 자동으로 데이터를 동기화합니다.
 */
window.connectProjectFolder = async function () {
    if (!('showDirectoryPicker' in window)) {
        return window.showAlert('이 브라우저는 폴더 연결을 지원하지 않습니다.\nChrome 또는 Edge를 사용해주세요.');
    }

    try {
        const dirHandle = await window.showDirectoryPicker({
            mode: 'readwrite'
        });
        projectFolderHandle = dirHandle;

        // IndexedDB에 디렉토리 핸들 저장(가능한 경우)
        if (typeof DBManager !== 'undefined') {
            try {
                await DBManager.setItem('projectFolderHandle', dirHandle);
            } catch (dbErr) {
            console.warn('폴더 연결 정보 저장(IndexedDB) 실패:', dbErr);
            }
        }

        // 연결 직후 현재 상태를 폴더에 즉시 동기화
        await syncToLinkedFolder();

        // UI 업데이트
        const indicator = document.getElementById('folder-connection-indicator');
        if (indicator) {
            indicator.innerHTML = `
                <i class="ph-fill ph-folder text-cyan-400 text-sm"></i>
                <span class="text-white/90 font-medium truncate max-w-[100px]">${dirHandle.name}</span>
                <i class="ph-bold ph-caret-down text-[0.6rem] text-white/50 ml-1"></i>
            `;
            indicator.title = `연결된 폴더: ${dirHandle.name} (클릭해 메뉴 열기)`;
            indicator.onclick = toggleFolderDropdown;
        }
        removeFolderReauthBanner();

        window.showToast(`[${dirHandle.name}] 폴더가 연결되었습니다! 이후 모든 변경사항이 자동 동기화됩니다.`);

    } catch (err) {
        if (err.name !== 'AbortError') {
        console.error('폴더 연결 오류:', err);
            window.showAlert('폴더 연결 중 오류가 발생했습니다: ' + err.message);
        }
    }
};

/**
 * 프로젝트 폴더 연결 해제
 */
window.disconnectProjectFolder = async function () {
    projectFolderHandle = null;

    // [추가] DB에서 폴더 핸들 삭제
    if (typeof DBManager !== 'undefined') {
        try {
            await DBManager.deleteItem('projectFolderHandle');
        } catch (dbErr) {
            console.warn('DB에서 폴더 핸들을 삭제하는 데 실패했습니다:', dbErr);
        }
    }

    const indicator = document.getElementById('folder-connection-indicator');
    if (indicator) {
        indicator.innerHTML = `
            <i class="ph ph-folder-dashed text-sm text-white/40"></i>
            <span class="text-white/40">연결 안됨</span>
        `;
        indicator.title = '프로젝트 폴더 연결하기';
        // 클릭 시 바로 폴더 연결 창 띄우기 (미연결 상태)
        indicator.onclick = () => window.connectProjectFolder();
    }
    removeFolderReauthBanner();
    window.showToast('폴더 연결이 해제되었습니다');
};

/**
 * FileSystemDirectoryHandle의 권한을 확인하고 필요시 요청합니다.
 * @param {FileSystemDirectoryHandle} handle
 * @param {boolean} requestIfNotGranted 클릭 이벤트 컨텍스트 외 상황에서도 권한을 물어볼지 여부
 * @returns {Promise<boolean>} 권한이 부여되었으면 true, 아니면 false
 */
async function verifyPermission(handle, requestIfNotGranted = false) {
    const options = { mode: 'readwrite' };
    let permission = await handle.queryPermission(options);
    if (permission === 'granted') {
        return true;
    }

    // 사용자 클릭 컨텍스트에서만 requestPermission 호출
    if (requestIfNotGranted) {
        permission = await handle.requestPermission(options);
        return permission === 'granted';
    }
    return false;
}

/**
 * 페이지 로드 시 IndexedDB에 저장된 프로젝트 폴더 연결을 복원합니다.
 */
window.restoreProjectFolderConnection = async function () {
    if (!('showDirectoryPicker' in window) || typeof DBManager === 'undefined') {
        return;
    }

    try {
        let storedHandle = null;
        try {
            storedHandle = await DBManager.getItem('projectFolderHandle');
        } catch (dbErr) {
        console.warn('DB에서 폴더 핸들 읽기 실패:', dbErr);
            return; // 읽기 실패 시 복원 중단
        }

        if (storedHandle) {
            // 초기 로딩에서는 requestPermission 팝업을 띄울 수 없어 query 상태만 체크
            const hasPermission = await verifyPermission(storedHandle, false);

            if (hasPermission) {
                // 이미 권한이 유지되고 있으면 바로 복원
                projectFolderHandle = storedHandle;
                const indicator = document.getElementById('folder-connection-indicator');
                if (indicator) {
                    indicator.innerHTML = `
                        <i class="ph-fill ph-folder text-cyan-400 text-sm"></i>
                        <span class="text-white/90 font-medium truncate max-w-[100px]">${storedHandle.name}</span>
                        <i class="ph-bold ph-caret-down text-[0.6rem] text-white/50 ml-1"></i>
                    `;
                    indicator.title = `연결된 폴더: ${storedHandle.name} (클릭해 메뉴 열기)`;
                    indicator.onclick = toggleFolderDropdown;
                }
                removeFolderReauthBanner();
                console.log(`[${storedHandle.name}] 폴더 연결이 자동 복원되었습니다`);
            } else {
                // 권한 만료 상태면 사용자 클릭 시에만 requestPermission 호출
                console.warn('저장된 폴더 핸들의 권한이 만료되었습니다. 클릭을 통해 재인증이 필요합니다');

                const indicator = document.getElementById('folder-connection-indicator');
                if (!indicator) return;

                const requestReauth = async () => {
                    try {
                        const granted = await verifyPermission(storedHandle, true); // 클릭 이벤트 컨텍스트에서만 팝업 가능
                        if (!granted) {
                            window.showToast('폴더 권한이 아직 허용되지 않았습니다. 다시 시도해 주세요.');
                            return;
                        }

                        projectFolderHandle = storedHandle;
                        indicator.innerHTML = `
                            <i class="ph-fill ph-folder text-cyan-400 text-sm"></i>
                            <span class="text-white/90 font-medium truncate max-w-[100px]">${storedHandle.name}</span>
                            <i class="ph-bold ph-caret-down text-[0.6rem] text-white/50 ml-1"></i>
                        `;
                        indicator.title = `연결된 폴더: ${storedHandle.name} (클릭해 메뉴 열기)`;
                        indicator.onclick = toggleFolderDropdown; // 드롭다운으로 롤백
                        removeFolderReauthBanner();
                        window.showToast(`[${storedHandle.name}] 폴더 접근 권한이 복원되었습니다`);
                    } catch (permError) {
                    console.error('권한 요청 실패', permError);
                        window.showAlert('폴더 권한 복구에 실패했습니다. 다시 폴더 연결을 시도해주세요.');
                    }
                };

                indicator.innerHTML = `
                    <i class="ph-fill ph-folder-lock text-orange-400 text-sm animate-pulse"></i>
                    <span class="text-orange-300 font-medium truncate max-w-[100px]">${storedHandle.name}</span>
                    <span class="text-orange-300/80">재인증 필요</span>
                `;
                indicator.title = `폴더 권한 만료: ${storedHandle.name} (클릭해 재인증)`;
                // 사용자 클릭 시 권한 재요청
                indicator.onclick = requestReauth;
                showFolderReauthBanner(storedHandle.name, requestReauth);
            }
        }
    } catch (e) {
        console.error('폴더 연결 복원 중 오류 발생:', e);
        await window.disconnectProjectFolder();
    }
}

/**
 * 연결된 프로젝트 폴더에서 데이터 불러오기
 */
window.loadFromProjectFolder = async function () {
    if (!('showDirectoryPicker' in window)) {
        return window.showAlert('이 브라우저는 폴더 불러오기를 지원하지 않습니다.');
    }

    try {
        const dirHandle = await window.showDirectoryPicker({ mode: 'readwrite' });

        // save_data.yaml 존재 여부 확인
        let saveDataHandle;
        try {
            saveDataHandle = await dirHandle.getFileHandle('save_data.yaml');
        } catch (e) {
            // JSON 폴백 (이전 버전 호환)
            try { saveDataHandle = await dirHandle.getFileHandle('save_data.json'); }
            catch (e2) { return window.showAlert('유효한 프로젝트 폴더가 아닙니다.\nsave_data.yaml 파일을 찾을 수 없습니다.'); }
        }

        const file = await saveDataHandle.getFile();
        const text = await file.text();
        const parsed = simpleYamlParse(text);

        if (!parsed.state) {
            return window.showAlert('save_data.yaml에 유효한 상태 데이터가 없습니다.');
        }

        // 현재 데이터 백업
        if (Array.isArray(courseData) && courseData.length > 0) {
            courseData.forEach(mod => {
                if (mod && mod.content) archiveContent(mod);
            });
        }

        // 상태 복원
        const sanitized = sanitizeState(parsed.state);
        if (sanitized) {
            globalState = sanitized;
            await rehydrateStateImagesFromFileRefs(dirHandle, globalState);
        }

        // 히스토리 복원
        if (Array.isArray(parsed.history)) {
            contentHistory = normalizeHistoryItems(parsed.history);
            await rehydrateHistoryImagesFromFileRefs(dirHandle, globalState, contentHistory);
        }

        // 교과 데이터 복원
        if (globalState.subjects.length > 0) {
            const firstSubj = globalState.subjects[0];
            currentSubjectId = firstSubj.id;
            courseData = firstSubj.lessons || [];
        }

        // 폴더 연결 유지
        projectFolderHandle = dirHandle; // linkedDirHandle -> projectFolderHandle
        if (typeof DBManager !== 'undefined') {
            try {
                await DBManager.setItem('projectFolderHandle', dirHandle);
            } catch (dbErr) {
                console.warn('기존 불러오기 폴더 연결 정보 저장(IndexedDB) 실패:', dbErr);
            }
        }

        // UI 동기화
        await saveState();
        document.getElementById('folder-connection-indicator').innerHTML = `
            <i class="ph-fill ph-folder text-cyan-400 text-sm"></i>
            <span class="text-white/90 font-medium truncate max-w-[100px]">${dirHandle.name}</span>
            <i class="ph-bold ph-caret-down text-[0.6rem] text-white/50 ml-1"></i>
        `;
        document.getElementById('folder-connection-indicator').title = `연결된 폴더: ${dirHandle.name} (클릭해 메뉴 열기)`;
        document.getElementById('folder-connection-indicator').onclick = toggleFolderDropdown;
        removeFolderReauthBanner();


        if (typeof renderSidebar === 'function') renderSidebar();
        location.hash = '#overview';

        window.showAlert(`✅ 프로젝트 폴더에서 성공적으로 불러왔습니다!\n📁 ${dirHandle.name}\n\n폴더가 자동으로 연결되어 이후 변경사항도 자동 동기화됩니다.`);

    } catch (e) {
        if (e.name === 'AbortError') return;
        console.error('폴더 불러오기 오류:', e);
        window.showAlert('폴더 불러오기 중 오류가 발생했습니다: ' + e.message);
    }
}

/**
 * 연결된 폴더에 전체 상태를 동기화 (saveState 훅에서 호출)
 */
async function syncToLinkedFolder() {
    if (!projectFolderHandle) return; // linkedDirHandle -> projectFolderHandle

    try {
        // 권한 재확인 (자동 순환 중 권한 만료 방어)
        const permission = await projectFolderHandle.queryPermission({ mode: 'readwrite' }); // linkedDirHandle -> projectFolderHandle
        if (permission !== 'granted') {
            const request = await projectFolderHandle.requestPermission({ mode: 'readwrite' }); // linkedDirHandle -> projectFolderHandle
            if (request !== 'granted') {
                projectFolderHandle = null; // linkedDirHandle -> projectFolderHandle
                // updateFolderConnectionUI(false); // Removed, replaced by direct UI update in disconnect
            console.warn('폴더 접근 권한이 거부되어 연결이 해제되었습니다');
                await window.disconnectProjectFolder(); // Call the new disconnect function
                return;
            }
        }

        // 1. save_data.yaml (전체 상태 + 히스토리)
        const saveData = {
            state: buildCompactStateForExternalSave(globalState),
            history: buildCompactHistoryForExternalSave(contentHistory),
            lastSync: new Date().toISOString()
        };
        await writeTextFile(projectFolderHandle, 'save_data.yaml', simpleYamlStringify(saveData)); // linkedDirHandle -> projectFolderHandle

        // 2. 교과별 md/이미지 동기화
        const subj = globalState.subjects.find(s => s.id === currentSubjectId);
        if (subj && Array.isArray(courseData) && courseData.length > 0) {
            const rawCourseTitle = globalState.courseTitle || '내 교안 프로젝트';
            const safeCourseName = rawCourseTitle.replace(/[\/\?<>\\:\*\|"]/g, '_').trim();
            const safeSubjName = subj.title.replace(/[\/\?<>\\:\*\|"]/g, '_').trim();

            const courseFolder = await projectFolderHandle.getDirectoryHandle(safeCourseName, { create: true }); // linkedDirHandle -> projectFolderHandle
            const attachFolder = await courseFolder.getDirectoryHandle('첨부파일', { create: true });
            const subjFolder = await courseFolder.getDirectoryHandle(safeSubjName, { create: true });
            const writtenImageFiles = new Set();
            const pendingImageWrites = [];
            const appendImageToFolder = (imgFileName, base64Data) => {
                if (writtenImageFiles.has(imgFileName)) return;
                writtenImageFiles.add(imgFileName);
                pendingImageWrites.push(
                    writeBinaryFile(attachFolder, imgFileName, _base64StringToUint8Array(base64Data))
                );
            };

            for (let idx = 0; idx < courseData.length; idx++) {
                const m = courseData[idx];
                if (String(m?.id) === 'mainQuest') continue;
                if (!m.content) continue;

                const fallbackFileName = _buildDefaultModuleFileName(m, idx);
                const mdFileName = getModuleExportFileNameByConvention(subj, m.id, fallbackFileName, '.md');

                const variants = _buildMarkdownVariantsForExport(m, { prependTitle: true });
                const { studentFileName, teacherFileName } = _splitMarkdownVariantFileNames(mdFileName);
                const studentMd = _rewriteMarkdownImageRefs(variants.studentMd, m.images, appendImageToFolder);
                const teacherMd = _rewriteMarkdownImageRefs(variants.teacherMd, m.images, appendImageToFolder);

                const safeStudentName = studentFileName.replace(/[\/\?<>\\:\*\|"]/g, '_');
                const safeTeacherName = teacherFileName.replace(/[\/\?<>\\:\*\|"]/g, '_');
                await writeTextFile(subjFolder, safeStudentName, studentMd);
                await writeTextFile(subjFolder, safeTeacherName, teacherMd);
            }

            // mainQuest 별도 저장
            if (subj.mainQuest && subj.mainQuest.content) {
                const mq = subj.mainQuest;
                const mqFallbackFileName = _buildDefaultModuleFileName(mq, -1);
                const mqFileName = getModuleExportFileNameByConvention(subj, mq.id, mqFallbackFileName, '.md');

                const variants = _buildMarkdownVariantsForExport(mq, { prependTitle: true });
                const { studentFileName, teacherFileName } = _splitMarkdownVariantFileNames(mqFileName);
                const studentMd = _rewriteMarkdownImageRefs(variants.studentMd, mq.images, appendImageToFolder);
                const teacherMd = _rewriteMarkdownImageRefs(variants.teacherMd, mq.images, appendImageToFolder);

                const safeStudentName = studentFileName.replace(/[\/\?<>\\:\*\|"]/g, '_');
                const safeTeacherName = teacherFileName.replace(/[\/\?<>\\:\*\|"]/g, '_');
                await writeTextFile(subjFolder, safeStudentName, studentMd);
                await writeTextFile(subjFolder, safeTeacherName, teacherMd);
            }

            if (pendingImageWrites.length > 0) {
                await Promise.all(pendingImageWrites);
            }
        }

    } catch (e) {
        console.warn('폴더 동기화 실패:', e.message);
        // 상태 캐시 에러 처리 (크롬 버그 대응)
        if (e.message && e.message.includes('state cached in an interface object')) {
            console.warn('File System 핸들 만료 문제. 연결 해제 처리합니다');
            projectFolderHandle = null; // linkedDirHandle -> projectFolderHandle
            // updateFolderConnectionUI(false); // Removed
            await window.disconnectProjectFolder(); // Call the new disconnect function
            return;
        }

        // 핸들 접근 실패 시 자동 연결 해제 (삭제/권한 만료 등)
        if (e.name === 'NotFoundError' || e.name === 'NotAllowedError') {
            projectFolderHandle = null; // linkedDirHandle -> projectFolderHandle
            // updateFolderConnectionUI(false); // Removed
            await window.disconnectProjectFolder(); // Call the new disconnect function
        }
    }
}

/**
 * 히스토리 신규 1건을 연결된 폴더의 히스토리 디렉토리에 저장 */
async function syncHistoryItemToFolder(historyItem) {
    if (!projectFolderHandle || !historyItem) return; // linkedDirHandle -> projectFolderHandle

    try {
        const historyFolder = await projectFolderHandle.getDirectoryHandle('히스토리', { create: true }); // linkedDirHandle -> projectFolderHandle
        const metadata = normalizeHistoryMetadata(historyItem.metadata, historyItem.date);
        const targetSubject = metadata.subjectId
            ? globalState.subjects.find(s => String(s?.id) === String(metadata.subjectId))
            : null;
        const historyFallback = _sanitizeFileStem(historyItem.title || 'history', 'history');
        let namingStem = historyFallback;

        if (targetSubject && metadata.moduleId) {
            const named = getModuleExportFileNameByConvention(targetSubject, metadata.moduleId, historyFallback, '.json');
            namingStem = _sanitizeFileStem(named.replace(/\.json$/i, ''), historyFallback);
        }
        const safeStem = namingStem.substring(0, 60) || 'history';
        const fileName = `${historyItem.id}_${safeStem}.json`;

        // 이미지 제외한 경량 메타만 저장 (용량 절약)
        const lightItem = {
            id: historyItem.id,
            title: historyItem.title,
            content: historyItem.content,
            date: historyItem.date,
            metadata,
            hasImages: historyItem.images ? Object.keys(historyItem.images).length : 0
        };

        await writeTextFile(historyFolder, fileName, JSON.stringify(lightItem, null, 2));
    } catch (e) {
        console.warn('히스토리 동기화 실패:', e.message);
    }
}

/**
 * 폴더 연결 상태 UI 업데이트
 */
function updateFolderConnectionUI(connected, folderName = '') {
    const indicator = document.getElementById('folder-connection-indicator');
    if (!indicator) return;

    if (connected) {
        indicator.innerHTML = `<i class="ph-fill ph-folder-open text-sm text-emerald-400"></i> <span class="text-emerald-300">${folderName}</span>`;
    indicator.title = `연결됨: ${folderName} (클릭하여 해제)`;
        indicator.onclick = () => window.disconnectProjectFolder(); // Changed to call the new disconnect function
    } else {
    indicator.innerHTML = `<i class="ph ph-folder-dashed text-sm text-white/40"></i> <span class="text-white/40">미연결</span>`;
    indicator.title = '프로젝트 폴더 연결하기';
        indicator.onclick = () => connectProjectFolder();
    }
}


// =========================================================================
// 데이터 관리 드롭다운 (클릭 기반 토글)
// =========================================================================

window.toggleDataManageDropdown = function (event) {
    const dropdown = document.getElementById('data-manage-dropdown');
    if (!dropdown) return;

    const isOpen = !dropdown.classList.contains('hidden');

    if (isOpen) {
        dropdown.classList.add('hidden');
        document.removeEventListener('click', _closeDataManageOnOutside);
        return;
    }

    // 버튼 위치 기준으로 드롭다운 배치
    const btn = document.getElementById('data-manage-btn');
    if (btn) {
        const rect = btn.getBoundingClientRect();
        dropdown.style.top = (rect.bottom + 4) + 'px';
        dropdown.style.left = rect.left + 'px';
    }

    dropdown.classList.remove('hidden');

    // 문서 클릭으로 닫기 (다음 틱에 등록해 현재 클릭으로 즉시 닫힘 방지)
    setTimeout(() => {
        document.addEventListener('click', _closeDataManageOnOutside);
    }, 0);

    if (event) event.stopPropagation();
}

function _closeDataManageOnOutside(e) {
    const dropdown = document.getElementById('data-manage-dropdown');
    const btn = document.getElementById('data-manage-btn');
    if (dropdown && !dropdown.contains(e.target) && btn && !btn.contains(e.target)) {
        dropdown.classList.add('hidden');
        document.removeEventListener('click', _closeDataManageOnOutside);
    }
}
