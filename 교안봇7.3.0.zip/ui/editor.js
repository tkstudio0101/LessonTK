let _savedViewScrollTop = 0;

function renderEditor(mod) {

    const area = document.getElementById('editor-content-area');

    const cmdBar = document.getElementById('ai-command-bar');
    const namingPreviewFileName = escapeHtmlAttr(getNamingConventionPreviewFileName(mod));
    const lessonInfoPanelKey = escapeHtmlAttr(String(mod.id || 'unknown'));



    if (!mod.content) {
        // 현재 렌더 작업 취소 (이전 비동기 렌더 결과가 뒤늦게 덮어쓰는 것 방지)
        activeEditorRenderJob++;
        cleanupTeacherNotesScrollSync();

        area.innerHTML = `

                    <div class="h-full flex flex-col items-center justify-center text-center animate-fade-in p-8">

                        <i class="ph-duotone ${mod.id === 'mainQuest' ? 'ph-crown text-yellow-400/30' : 'ph-file-dashed text-white/20'} text-6xl mb-4"></i>

                        <h2 class="text-xl font-bold text-white mb-2">${mod.title}</h2>

                        <p class="text-textMuted text-sm mb-6">아직 교안 내용이 생성되지 않았습니다</p>

                        <button onclick="${mod.id === 'mainQuest' ? 'promptAndGenerateMainQuest()' : `promptAndGenerateModule(${mod.id})`}" class="px-6 py-2.5 bg-accent hover:bg-accentHover text-white font-bold rounded-lg shadow-lg transition-colors flex items-center gap-2">

                            <i class="ph-bold ph-sparkle"></i> AI 교안 생성 시작하기

                        </button>

                    </div>

                `;

        cmdBar.classList.add('hidden');

        return;

    }

    ensureTeacherNotesArray(mod);
    cleanupTeacherNotesScrollSync();
    const lowQualityCount = Array.isArray(mod.qualityEvaluation?.lowDimensions) ? mod.qualityEvaluation.lowDimensions.length : 0;
    const canRunTargetedRefine = lowQualityCount > 0;
    const refineBtnClass = canRunTargetedRefine
        ? 'px-3 py-1.5 text-xs font-bold bg-rose-50 text-rose-600 border border-rose-200 rounded hover:bg-rose-100 flex items-center gap-1 transition-colors'
        : 'px-3 py-1.5 text-xs font-bold bg-gray-100 text-gray-400 border border-gray-200 rounded flex items-center gap-1 cursor-not-allowed';

    area.innerHTML = `

                <div class="sticky top-0 bg-bgEditor/95 backdrop-blur-sm border-b border-gray-200 z-30 shadow-sm">

                    <div class="p-4 flex justify-between items-center gap-3">

                        <div class="flex items-center gap-2 min-w-0">
                            <h2 class="font-bold text-gray-800 truncate pr-1">${mod.title}</h2>
                            <button type="button" onclick="openNamingConventionEditorModal()" title="파일명 컨벤션 편집"
                                class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md border border-gray-200 bg-white text-[0.68rem] text-gray-700 hover:border-accent hover:text-accent transition-colors shrink-0">
                                <i class="ph-bold ph-file-code text-[0.72rem]"></i>
                                <span class="font-mono">${namingPreviewFileName}</span>
                            </button>
                        </div>

                        <div class="flex items-center gap-2 shrink-0">

<button onclick="generateAllImagesInModule('${mod.id}')" id="img-batch-btn" class="px-3 py-1.5 text-xs font-bold bg-purple-50 text-purple-600 border border-purple-200 rounded hover:bg-purple-100 flex items-center gap-1 transition-colors hover:-translate-y-0.5"><i class="ph-bold ph-image-square"></i> 검색 이미지 찾기</button>
                            
                            <label class="cursor-pointer px-3 py-1.5 text-xs font-bold bg-blue-50 text-blue-600 border border-blue-200 rounded hover:bg-blue-100 flex items-center gap-1 transition-colors" title="에디터에 이미지 삽입">
                                <i class="ph-bold ph-image"></i> 이미지 삽입
                                <input type="file" accept="image/*" class="hidden" multiple onchange="handleImageInputSelect(event)">
                            </label>
                            <button onclick="runModuleQualityEvaluation()" id="quality-eval-btn" class="px-3 py-1.5 text-xs font-bold bg-indigo-50 text-indigo-600 border border-indigo-200 rounded hover:bg-indigo-100 flex items-center gap-1 transition-colors"><i class="ph-bold ph-shield-check"></i> 품질 점검</button>
                            <button onclick="runModuleQualityRefinement()" id="quality-refine-btn" ${canRunTargetedRefine ? '' : 'disabled'} class="${refineBtnClass}"><i class="ph-bold ph-magic-wand"></i> 집중 보완${canRunTargetedRefine ? ` (${lowQualityCount})` : ''}</button>

                            <div class="w-px h-4 bg-gray-300 mx-1"></div>

                            <div class="flex bg-gray-100 rounded p-1 border border-gray-200">

                                <button onclick="toggleEditorMode('view')" id="toggle-view" class="px-3 py-1 text-xs font-bold rounded bg-white text-gray-800 shadow-sm transition-all">보기</button>

                                <button onclick="toggleEditorMode('script')" id="toggle-script" class="px-3 py-1 text-xs font-bold rounded text-gray-500 hover:text-gray-800 transition-all" title="Lecture script view">대본</button>

                                <button onclick="toggleEditorMode('quiz')" id="toggle-quiz" class="px-3 py-1 text-xs font-bold rounded text-gray-500 hover:text-gray-800 transition-all" title="학습 이해도 확인">학습 이해도</button>

                                <button onclick="toggleEditorMode('edit')" id="toggle-edit" class="px-3 py-1 text-xs font-bold rounded text-gray-500 hover:text-gray-800 transition-all">수정</button>

                            </div>

                        </div>

                    </div>

                    <div id="lesson-info-panel" class="mx-4 mb-3 border-t border-gray-100 pt-2">
                        <div class="rounded-lg border border-gray-200 bg-white overflow-hidden">
                            <div class="px-3 py-1.5 flex items-center justify-between gap-2">
                                <div class="inline-flex items-center gap-1.5 text-[0.68rem] font-bold text-gray-700 shrink-0">
                                    <i class="ph-fill ph-list-checks text-accent"></i>
                                    차시 정보
                                </div>
                                <div id="completeness-checklist" class="flex items-center gap-1 shrink-0 ml-2"></div>
                                <div id="lesson-info-summary" class="min-w-0 flex-1 flex items-center justify-end gap-1 text-[0.62rem]"></div>
                                <button id="lesson-info-toggle-btn"
                                    type="button"
                                    data-lesson-info-key="${lessonInfoPanelKey}"
                                    onclick="toggleLessonInfoPanel(this.dataset.lessonInfoKey, this)"
                                    class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md border border-accent/30 bg-accent/10 text-[0.65rem] font-bold text-accent hover:bg-accent/20 hover:border-accent/45 transition-all shadow-sm"
                                    aria-expanded="false">
                                    <i class="ph-bold ph-sliders-horizontal text-[0.78rem]"></i>
                                    <span data-lesson-info-toggle-label>서식 조절</span>
                                </button>
                            </div>
                            <div id="lesson-info-body" class="max-h-0 opacity-0 overflow-hidden border-t border-transparent px-3 py-0 space-y-1.5 transition-all duration-300">
                                <div id="tone-toolbar" class="flex items-center gap-2 flex-wrap">
                                    <span class="text-[0.6rem] font-bold text-gray-500 uppercase tracking-wider shrink-0 mr-1">문체</span>
                                    ${typeof TONE_PRESETS !== 'undefined' ? TONE_PRESETS.map(t =>
        `<button onclick="applyToneConversion('${t.id}')" data-tone="${t.id}" class="tone-btn px-2 py-1 text-[0.63rem] font-bold rounded-md border transition-all hover:scale-[1.02] hover:shadow-sm ${t.color}">${t.label}</button>`
    ).join('') : ''}
                                    <div class="w-px h-4 bg-gray-200 mx-1 shrink-0"></div>
                                    <span class="text-[0.6rem] font-bold text-gray-500 uppercase tracking-wider shrink-0 mr-1">분량</span>
                                    <button onclick="applyVolumeControl('shorter')" class="px-2 py-1 text-[0.63rem] font-bold rounded-md border transition-all hover:scale-[1.02] bg-cyan-500/10 text-cyan-600 border-cyan-500/25 hover:shadow-sm">짧게</button>
                                    <button onclick="applyVolumeControl('longer')" class="px-2 py-1 text-[0.63rem] font-bold rounded-md border transition-all hover:scale-[1.02] bg-orange-500/10 text-orange-600 border-orange-500/25 hover:shadow-sm">길게</button>
                                    <div id="tone-loading" class="hidden items-center gap-1.5 ml-1.5">
                                        <div class="w-3 h-3 border-2 border-accent/30 border-t-accent rounded-full animate-spin"></div>
                                        <span class="text-[0.62rem] font-bold text-accent" id="tone-loading-text">변환 중...</span>
                                    </div>
                                </div>
                                <div id="format-lint-banner" class="hidden"></div>
                                <div id="image-search-status-banner" class="hidden"></div>
                                <div id="quality-eval-banner" class="hidden"></div>
                            </div>
                        </div>
                    </div>

                </div>

                

                <div class="max-w-[1260px] mx-auto p-8 pb-32">
                    <div class="grid grid-cols-1 xl:grid-cols-[minmax(0,1fr)_320px] gap-6 items-start">
                        <div class="min-w-0">
                            <div id="render-view" class="markdown-body animate-fade-in"></div>
                            <div id="script-view" class="hidden"></div>
                            <div id="quiz-view" class="hidden w-full px-6 py-6 max-w-3xl mx-auto"></div>
                            <textarea id="raw-view" class="hidden w-full h-[600px] p-6 font-mono text-sm bg-gray-900 text-gray-100 rounded-xl outline-none focus:ring-2 focus:ring-accent resize-y" spellcheck="false" onchange="saveRawContent()"></textarea>
                        </div>
                        <aside id="teacher-notes-panel" class="rounded-xl border border-gray-200 bg-white shadow-sm overflow-y-auto max-h-[calc(100vh-180px)] xl:sticky xl:top-24"></aside>
                    </div>
                </div>

            `;

    const rawView = document.getElementById('raw-view');
    if (rawView) rawView.value = mod.content || '';
    if (typeof window.renderLessonInfoSummary === 'function') {
        window.renderLessonInfoSummary(mod, {});
    }
    if (typeof window.renderCompletenessChecklist === 'function') {
        window.renderCompletenessChecklist(mod);
    }
    if (typeof window.syncLessonInfoPanelState === 'function') {
        window.syncLessonInfoPanelState(String(mod.id || 'unknown'));
    }

    cmdBar.classList.remove('hidden');
    toggleEditorMode('view');

    // 인라인 에디팅 기능 활성화 (약간의 지연 후 렌더 트리가 안전할 때)
    setTimeout(() => initInlineEditing(), 100);
}

async function renderMarkdownInView(mod, rawText, options = {}) {
    const renderView = document.getElementById('render-view');
    if (!renderView || !mod) return;

    const jobId = ++activeEditorRenderJob;
    const source = typeof rawText === 'string' ? rawText : (mod.content || '');
    const isHeavy = source.length > 25000 || Object.keys(mod.images || {}).length > 40;

    if (isHeavy) {
        renderView.innerHTML = `<div class="p-4 bg-slate-500/20 border border-slate-500 text-slate-100 rounded">대용량 문서를 렌더링 중입니다...</div>`;
        await nextAnimationFrame();
    }

    const renderText = await buildRenderTextAsync(source, mod.images, jobId);
    if (renderText === null || jobId !== activeEditorRenderJob) return;

    let htmlContent = '';
    try {
        htmlContent = typeof marked !== 'undefined'
            ? marked.parse(renderText)
            : `<pre class="text-gray-200 whitespace-pre-wrap">${renderText.replace(/</g, '&lt;')}</pre>`;
    } catch (e) {
        htmlContent = `<div class="p-4 bg-red-500/20 border border-red-500 text-red-400 rounded">마크다운 파싱 오류: ${e.message}</div><pre class="text-gray-200 mt-4">${renderText.replace(/</g, '&lt;')}</pre>`;
    }

    if (jobId !== activeEditorRenderJob) return;
    renderView.innerHTML = htmlContent;

    applyRenderedHeadingAnchors();
    const h2Headings = Array.from(renderView.querySelectorAll('h2'));
    if (h2Headings.length > 0) {
        const tocNav = document.createElement('nav');
        tocNav.id = 'view-toc-nav';
        tocNav.setAttribute('ondblclick', 'event.stopPropagation()');
        tocNav.className = 'sticky top-0 z-20 -mx-2 mb-5 flex items-center gap-2 overflow-x-auto rounded-xl border border-white/10 bg-[#1a1a2e]/95 px-3 py-2 text-xs shadow-lg backdrop-blur-sm';
        tocNav.setAttribute('aria-label', '문서 목차');

        h2Headings.forEach((heading, index) => {
            const tocButton = document.createElement('button');
            tocButton.type = 'button';
            tocButton.className = 'shrink-0 whitespace-nowrap rounded-full border border-white/10 bg-white/5 px-3 py-1 font-semibold text-slate-100 transition-colors hover:bg-white/10 hover:text-white';
            tocButton.textContent = (heading.textContent || '').trim() || `섹션 ${index + 1}`;
            tocButton.onclick = (event) => {
                event.preventDefault();
                event.stopPropagation();
                heading.style.scrollMarginTop = `${(tocNav.offsetHeight || 0) + 96}px`;
                heading.scrollIntoView({ behavior: 'smooth', block: 'start' });
            };
            tocNav.appendChild(tocButton);
        });

        renderView.prepend(tocNav);
    } else {
        const existingToc = renderView.querySelector('#view-toc-nav');
        if (existingToc) existingToc.remove();
    }
    renderTeacherNotesPanel(mod);
    bindTeacherNotesScrollSync();

    if (window.mermaid) {
        setTimeout(() => {
            try {
                window.mermaid.init(undefined, renderView.querySelectorAll('.mermaid'));
            } catch (err) {
                console.warn('Mermaid rendering failed:', err);
            }
        }, 50);
    }

    const formatReport = typeof window.renderFormatLintBanner === 'function'
        ? window.renderFormatLintBanner(mod, { toast: !!options.showLintToast })
        : null;
    const imageStatus = typeof window.renderImageSearchStatusBanner === 'function'
        ? window.renderImageSearchStatusBanner(mod)
        : null;
    const qualityState = typeof window.renderQualityEvaluationBanner === 'function'
        ? window.renderQualityEvaluationBanner(mod, { toast: !!options.showQualityToast })
        : null;
    if (typeof window.renderLessonInfoSummary === 'function') {
        window.renderLessonInfoSummary(mod, {
            formatReport,
            imageStatus,
            quality: qualityState
        });
    }
    if (typeof window.syncLessonInfoPanelState === 'function') {
        window.syncLessonInfoPanelState(String(mod.id || 'unknown'));
    }

    if (_savedViewScrollTop > 0) {
        renderView.scrollTop = _savedViewScrollTop;
        _savedViewScrollTop = 0;
    }
}

window.initInlineEditing = function () {
    const renderView = document.getElementById('render-view');
    if (!renderView) return;

    // 중복 바인딩 방지
    renderView.removeEventListener('dblclick', handleInlineEditDblClick);
    renderView.addEventListener('dblclick', handleInlineEditDblClick);
};

window.executeAICommand = async function () {

    const input = document.getElementById('ai-command-input');
    const btn = document.getElementById('ai-command-send');
    const command = input.value.trim();
    if (!command) return;

    const renderView = document.getElementById('render-view');
    const rawView = document.getElementById('raw-view');
    if (!rawView) return;

    // ── 1. 실행 전 선택 텍스트 캡처 (보기 모드 / 수정 모드 양쪽 지원) ──
    let capturedSelection = '';
    let selStart = -1;
    let selEnd = -1;
    const isViewMode = renderView && !renderView.classList.contains('hidden');

    if (aiCommandMode === 'edit') {
        if (isViewMode) {
            // 보기 모드: UI에서 캡처해둔 텍스트 우선 사용, 없으면 현재 드래그 영역 사용
            if (window.currentCapturedSelection) {
                capturedSelection = window.currentCapturedSelection;
            } else {
                const sel = window.getSelection();
                capturedSelection = sel ? sel.toString().trim() : '';
            }
        } else {
            // 수정 모드: raw-view textarea 선택 범위 직접 사용
            selStart = rawView.selectionStart;
            selEnd = rawView.selectionEnd;
            capturedSelection = rawView.value.substring(selStart, selEnd).trim();
        }
        if (!capturedSelection) {
            return window.showAlert('수정할 텍스트를 먼저 드래그하여 선택해주세요.');
        }
    }

    // ── 2. 수정 모드로 전환하여 raw-view 접근 확보 ──
    toggleEditorMode('edit');

    // 보기 모드에서 캡처한 선택 텍스트를 raw 원문에서 위치 매핑
    if (aiCommandMode === 'edit' && isViewMode && capturedSelection) {
        const rawText = rawView.value;
        // HTML 태그/엔티티 제거된 순수 텍스트로 검색 (렌더링 산물 차이 보정)
        const plainCapture = capturedSelection.replace(/\s+/g, ' ');

        // 1차: 원문에서 그대로 검색
        let idx = rawText.indexOf(capturedSelection);

        // 2차: 공백 정규화 후 재시도
        if (idx === -1) {
            const normalizedRaw = rawText.replace(/\s+/g, ' ');
            const normIdx = normalizedRaw.indexOf(plainCapture);
            if (normIdx !== -1) {
                // 정규화 인덱스를 원본 인덱스로 역변환 (근사치)
                let count = 0, origIdx = 0;
                for (let i = 0; i < rawText.length && count < normIdx; i++) {
                    if (rawText[i] === normalizedRaw[count]) count++;
                    origIdx = i + 1;
                }
                idx = origIdx > 0 ? origIdx - 1 : 0;
            }
        }

        if (idx !== -1) {
            selStart = idx;
            // 원본에서 캡처 텍스트의 실제 끝 위치 (줄바꿈 포함 원본 기준)
            const remaining = rawText.substring(idx);
            // 캡처 텍스트의 각 단어를 순서대로 매칭하여 끝 위치 산출
            let endSearch = idx + capturedSelection.length;
            // 보수적 확장: 마크다운 기호 등으로 인한 오프셋 보정
            const snippet = rawText.substring(idx, Math.min(idx + capturedSelection.length + 50, rawText.length));
            const lastWordMatch = capturedSelection.split(/\s+/).pop();
            if (lastWordMatch) {
                const lwIdx = snippet.lastIndexOf(lastWordMatch);
                if (lwIdx !== -1) endSearch = idx + lwIdx + lastWordMatch.length;
            }
            selEnd = Math.min(endSearch, rawText.length);
        } else {
            // 매핑 실패 시 사용자에게 수정 모드 안내
            return window.showAlert('선택한 텍스트를 원문에서 찾지 못했습니다.\n"수정" 탭에서 직접 텍스트를 선택한 뒤 다시 시도해주세요.');
        }
    }

    input.disabled = true;
    btn.innerHTML = '<i class="ph-bold ph-spinner animate-spin"></i>';

    try {
        if (aiCommandMode === 'edit') {
            if (selStart === selEnd || selStart < 0) throw new Error("수정할 텍스트를 영역 선택해주세요.");

            const text = rawView.value;
            const selectedText = text.substring(selStart, selEnd);
            const context = text.substring(Math.max(0, selStart - 300), selStart);

            const { systemInstruction, userPrompt } = buildTaskContext('edit', { context, selectedText, command });

            const res = await fetchWithRetry(
                `https://generativelanguage.googleapis.com/v1beta/models/${TEXT_MODEL}:generateContent?key=${apiKey}`,
                {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        contents: [{ parts: [{ text: userPrompt }] }],
                        systemInstruction: { parts: [{ text: systemInstruction }] }
                    })
                }
            );

            let newText = extractText(res);
            newText = newText.replace(/^```\w*\n?/i, '').replace(/\n?```$/i, '').trim();

            rawView.value = text.substring(0, selStart) + newText + text.substring(selEnd);

            if (typeof clearAISelection === 'function') clearAISelection();

        } else if (aiCommandMode === 'image') {
            const b64 = await generateImageAPI(command);
            if (b64) {
                const mod = getEditingModule();
                if (!mod.images) mod.images = {};
                const imgId = 'img_' + Date.now() + Math.floor(Math.random() * 1000);
                mod.images[imgId] = b64;
                const safeCommand = escapeHtmlAttr(command || '');
                const encodedCommand = encodeURIComponent(command || '').replace(/'/g, '%27');
                const imgTag = `\n<div class="image-wrapper"><img src="local:${imgId}" alt="${command}" class="rounded-lg border-2 border-accent/30 shadow-md max-w-full"><span class="absolute bottom-3 left-3 bg-black/80 text-white text-[0.6rem] px-2 py-1 rounded border border-white/20 flex items-center gap-1 pointer-events-none"><i class="ph-fill ph-sparkle text-accent"></i> AI 생성 이미지</span><button class="image-regenerate-btn px-3 py-1.5 text-xs text-white font-bold rounded flex items-center gap-1 border border-accent/50 hover:bg-accent transition-colors" onclick="promptRegenerateImage(this, '${command}', '${imgId}')"><i class="ph-bold ph-arrows-clockwise"></i> 다시 생성</button></div>\n`;

                const text = rawView.value;
                // 보기 모드에서 진입한 경우 커서가 0이므로 문서 끝에 삽입
                const pos = (isViewMode || rawView.selectionStart === 0) ? text.length : rawView.selectionStart;
                rawView.value = text.substring(0, pos) + imgTag + text.substring(pos);
            } else {
                window.showAlert('이미지 생성에 실패했습니다.');
            }
        }

        // 저장 후 보기 모드로 복귀하여 렌더링 결과 표시
        saveRawContent();
        toggleEditorMode('view');
        input.value = '';
        window.showAlert(aiCommandMode === 'edit' ? '✅ 텍스트 수정 완료!' : '✅ 이미지 삽입 완료!');

    } catch (err) {
        window.showAlert(err.message || '명령 실행 중 오류 발생');
    } finally {
        input.disabled = false;
        btn.innerHTML = '실행';
        input.focus();
    }
}

window.viewModule = function (id) {

    document.querySelectorAll('.module-card').forEach(c => c.classList.remove('border-accent', 'bg-accent/10', 'border-yellow-400', 'bg-yellow-400/5'));

    const card = document.querySelector(`.module-card[data-id="${id}"]`);

    if (card) {

        if (id === 'mainQuest') card.classList.add('border-yellow-400', 'bg-yellow-400/5');

        else card.classList.add('border-accent', 'bg-accent/10');

    }



    const mod = getEditingModule(id);

    if (mod) {

        currentEditingModuleId = id;

        renderEditor(mod);

    }

}

window.toggleEditorMode = function (mode) {

    const renderView = document.getElementById('render-view');
    const scriptView = document.getElementById('script-view');

    const rawView = document.getElementById('raw-view');

    const btnView = document.getElementById('toggle-view');

    const btnEdit = document.getElementById('toggle-edit');
    const btnScript = document.getElementById('toggle-script');
    const btnQuiz = document.getElementById('toggle-quiz');
    const quizView = document.getElementById('quiz-view');
    const notesPanel = document.getElementById('teacher-notes-panel');



    if (!renderView || !rawView) return;



    if (mode === 'edit') {
        // 보기 모드에서 진행 중인 비동기 렌더 작업을 즉시 취소
        activeEditorRenderJob++;
        cleanupTeacherNotesScrollSync();
        _savedViewScrollTop = (renderView ? renderView.scrollTop : 0);

        renderView.classList.add('hidden');
        if (scriptView) scriptView.classList.add('hidden');
        if (quizView) quizView.classList.add('hidden');

        rawView.classList.remove('hidden');
        if (notesPanel) notesPanel.classList.add('hidden');

        btnEdit.classList.add('bg-white', 'text-gray-800', 'shadow-sm');

        btnEdit.classList.remove('text-gray-500');

        btnView.classList.remove('bg-white', 'text-gray-800', 'shadow-sm');

        btnView.classList.add('text-gray-500');

        if (btnScript) {
            btnScript.classList.remove('bg-white', 'text-gray-800', 'shadow-sm');
            btnScript.classList.add('text-gray-500');
        }

        if (btnQuiz) {
            btnQuiz.classList.remove('bg-white', 'text-gray-800', 'shadow-sm');
            btnQuiz.classList.add('text-gray-500');
        }

    } else if (mode === 'script') {
        activeEditorRenderJob++;
        cleanupTeacherNotesScrollSync();

        renderView.classList.add('hidden');
        rawView.classList.add('hidden');
        if (quizView) quizView.classList.add('hidden');
        if (notesPanel) notesPanel.classList.add('hidden');
        if (scriptView) scriptView.classList.remove('hidden');

        btnView.classList.remove('bg-white', 'text-gray-800', 'shadow-sm');
        btnView.classList.add('text-gray-500');

        btnEdit.classList.remove('bg-white', 'text-gray-800', 'shadow-sm');
        btnEdit.classList.add('text-gray-500');

        if (btnScript) {
            btnScript.classList.add('bg-white', 'text-gray-800', 'shadow-sm');
            btnScript.classList.remove('text-gray-500');
        }

        if (btnQuiz) {
            btnQuiz.classList.remove('bg-white', 'text-gray-800', 'shadow-sm');
            btnQuiz.classList.add('text-gray-500');
        }

        const mod = getEditingModule();
        if (mod) renderScriptView(mod);

    } else if (mode === 'quiz') {
        activeEditorRenderJob++;
        cleanupTeacherNotesScrollSync();

        renderView.classList.add('hidden');
        rawView.classList.add('hidden');
        if (scriptView) scriptView.classList.add('hidden');
        if (notesPanel) notesPanel.classList.add('hidden');
        if (quizView) quizView.classList.remove('hidden');

        btnView.classList.remove('bg-white', 'text-gray-800', 'shadow-sm');
        btnView.classList.add('text-gray-500');

        btnEdit.classList.remove('bg-white', 'text-gray-800', 'shadow-sm');
        btnEdit.classList.add('text-gray-500');

        if (btnScript) {
            btnScript.classList.remove('bg-white', 'text-gray-800', 'shadow-sm');
            btnScript.classList.add('text-gray-500');
        }

        if (btnQuiz) {
            btnQuiz.classList.add('bg-white', 'text-gray-800', 'shadow-sm');
            btnQuiz.classList.remove('text-gray-500');
        }

        const mod = getEditingModule();
        renderQuizView(mod);

    } else {

        renderView.classList.remove('hidden');
        if (scriptView) scriptView.classList.add('hidden');
        if (quizView) quizView.classList.add('hidden');

        rawView.classList.add('hidden');
        if (notesPanel) notesPanel.classList.remove('hidden');

        btnView.classList.add('bg-white', 'text-gray-800', 'shadow-sm');

        btnView.classList.remove('text-gray-500');

        btnEdit.classList.remove('bg-white', 'text-gray-800', 'shadow-sm');

        btnEdit.classList.add('text-gray-500');

        if (btnScript) {
            btnScript.classList.remove('bg-white', 'text-gray-800', 'shadow-sm');
            btnScript.classList.add('text-gray-500');
        }

        if (btnQuiz) {
            btnQuiz.classList.remove('bg-white', 'text-gray-800', 'shadow-sm');
            btnQuiz.classList.add('text-gray-500');
        }



        const mod = getEditingModule();

        if (mod) {
            renderMarkdownInView(mod, rawView.value, { showLintToast: false });

        } else {
            cleanupTeacherNotesScrollSync();
        }

    }

}

window.initSelectionHoverUI = function () {
    document.addEventListener('selectionchange', () => {
        const renderView = document.getElementById('render-view');
        // 보기 모드가 아니거나, 마우스 클릭 유지중이면 무시
        if (!renderView || renderView.classList.contains('hidden')) {
            hideHoverTooltip();
            return;
        }

        const sel = window.getSelection();
        if (!sel || sel.isCollapsed || sel.toString().trim() === '') {
            hideHoverTooltip();
            return;
        }

        // 선택 영역이 render-view 내부인지 확인
        let node = sel.anchorNode;
        if (node && node.nodeType === 3) node = node.parentNode;
        if (!node || !renderView.contains(node)) {
            hideHoverTooltip();
            return;
        }

        // 선택된 Range의 화면 좌표 계산
        const range = sel.getRangeAt(0);
        const rect = range.getBoundingClientRect();

        const tooltip = document.getElementById('ai-floating-toolbar');
        if (tooltip && rect.width > 0 && rect.height > 0) {
            // 위치 계산 (선택 영역의 중앙 상단 바깥쪽)
            const top = rect.top + window.scrollY - 10; // 10px 위로 띄움
            const left = rect.left + window.scrollX + (rect.width / 2);

            tooltip.style.top = `${top}px`;
            tooltip.style.left = `${left}px`;
            tooltip.classList.remove('hidden');

            // 약간의 딜레이 후 opacity 전환하여 부드러운 페이드인
            setTimeout(() => {
                tooltip.classList.remove('opacity-0');
            }, 10);
        }
    });

    document.addEventListener('mousedown', (e) => {
        const tooltip = document.getElementById('ai-floating-toolbar');
        if (tooltip && !tooltip.contains(e.target)) {
            // 툴팁 외부 클릭 시 선택이 해제되므로 숨김 처리 보강
            hideHoverTooltip();
        }
    });
};

window.activateHoverAIEdit = function () {
    hideHoverTooltip();

    // 선택된 텍스트 보관 및 UI 갱신
    const sel = window.getSelection();
    let text = sel ? sel.toString().trim() : '';
    if (text) {
        window.currentCapturedSelection = text;
        const displayRegion = document.getElementById('ai-selected-text-display');
        const displayContent = document.getElementById('ai-selected-text-content');
        if (displayRegion && displayContent) {
            displayContent.textContent = text;
            displayRegion.classList.remove('hidden');
        }
    }

    // AI 커맨드 바가 숨겨져 있다면 강제로 보이게 전환 (로직 우회 등 대비)
    const cmdBar = document.getElementById('ai-command-bar');
    if (cmdBar) cmdBar.classList.remove('hidden');

    // api.js의 전역 함수 재활용하여 모드 전환
    if (typeof switchAIMode === 'function') switchAIMode('edit');

    // 입력창 포커싱
    const input = document.getElementById('ai-command-input');
    if (input) {
        input.focus();
        input.scrollIntoView({ behavior: 'smooth', block: 'center' }); // 화면 가운데로 스크롤
    }
};

function hideHoverTooltip() {
    const tooltip = document.getElementById('ai-floating-toolbar');
    if (tooltip && !tooltip.classList.contains('hidden')) {
        tooltip.classList.add('opacity-0');
        setTimeout(() => {
            tooltip.classList.add('hidden');
        }, 200); // transition-opacity duration 후 hidden
    }
}
