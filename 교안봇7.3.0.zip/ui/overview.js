function renderOverview() {

    const titleInput = document.getElementById('overview-course-title-input');
    if (titleInput) titleInput.value = globalState.courseTitle || '새로운 과정';

    // 기존 호환성용 DOM 파트가 남아있을지도 모르니
    const titleEl = document.getElementById('overview-course-title');
    if (titleEl) titleEl.innerText = globalState.courseTitle || '새로운 과정';

    renderOverviewLNB();

}

function createNewSubject() {

    const newId = 'subject_' + Date.now();

    if (!Array.isArray(globalState.subjects)) globalState.subjects = [];



    globalState.subjects.push({

        id: newId,

        title: '새로운 교과',

        description: '이 교과에서 다룰 핵심 내용을 설명해주세요.',

        namingConvention: '',

        lessonCount: 0,

        hasLevelTest: true,

        mainQuest: {

            id: 'mainQuest',

            title: '👑 메인 퀘스트 (최종 과제)',

            description: '모든 일일 퀘스트를 종합한 최종 평가입니다.',

            status: 'waiting',

            content: null,

            images: {},

            teacherNotes: [],
            qualityEvaluation: null

        },

        lessons: []

    });

    saveState().then(() => {
        renderOverviewLNB();
        setTimeout(() => openSubjectDetail(newId), 50);
    });

}

function deleteSubject(id) {

    showConfirm('이 교과를 정말 삭제하시겠습니까? (하위 차시 모두 삭제됨)', () => {

        globalState.subjects = globalState.subjects.filter(s => String(s.id) !== String(id));

        saveState().then(() => {
            renderOverviewLNB();
            closeDetailPanel();
        });

    });

}

window.handleSubjDragStart = function (e, idx) {
    _subjDragIdx = idx;
    e.dataTransfer.effectAllowed = 'move';
    e.currentTarget.style.opacity = '0.4';
    setTimeout(() => { e.target.style.opacity = ''; }, 0);
};

window.handleSubjDragOver = function (e) {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
};

window.handleSubjDrop = function (e, dropIdx) {
    e.preventDefault();
    if (_subjDragIdx < 0 || _subjDragIdx === dropIdx) return;
    const arr = globalState.subjects;
    const [moved] = arr.splice(_subjDragIdx, 1);
    arr.splice(dropIdx, 0, moved);
    _subjDragIdx = -1;
    saveState().then(() => {
        renderOverviewLNB();
    });
};
