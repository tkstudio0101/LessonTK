async function fetchWithRetry(url, options, retries = 5) {
    // 503 과부하 에러 등을 대비해 기본 재시도 횟수 5회 및 대기 시간 대폭 연장 (1.5s, 3s, 6s, 10s, 15s)
    const delays = [1500, 3000, 6000, 10000, 15000];

    for (let i = 0; i < retries; i++) {
        try {
            const res = await fetch(url, options);
            if (!res.ok) {
                // 400/403 에러는 변경 없이 재요청해도 실패하므로 별도로 캐치
                if (res.status === 400 || res.status === 403) {
                    const errText = await res.text();
                    throw new Error(`HTTP error! status: ${res.status}, ${res.status === 400 ? 'Bad Request' : 'Forbidden'}: ${errText.substring(0, 150)}`);
                }
                // 401, 429, 500, 503 등은 throw하여 아래 catch 블록에서 지연 재시도를 타게 만듦
                throw new Error(`HTTP error! status: ${res.status}`);
            }
            return await res.json();
        } catch (e) {
            // 마지막 재시도까지 실패하거나 400/403 에러면 즉시 중단
            if (i === retries - 1 || e.message.includes('status: 400') || e.message.includes('status: 403')) {
                throw e;
            }

            console.warn(`[fetchWithRetry] API 오류 또는 지연 발생. ${delays[i] / 1000}초 후 재시도합니다... (${i + 1}/${retries - 1}) | 사유: ${e.message}`);
            await new Promise(r => setTimeout(r, delays[i]));
        }
    }
}

async function fetchImageToBlob(fetchUrl, timeoutMs = IMAGE_BASE64_TIMEOUT_MS) {
    const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
    const timer = setTimeout(() => {
        if (controller) controller.abort();
    }, Math.max(1000, timeoutMs));

    try {
        const res = await fetch(fetchUrl, {
            method: 'GET',
            mode: 'cors',
            cache: 'no-store',
            signal: controller ? controller.signal : undefined
        });

        if (!res.ok) {
            throw new Error(`HTTP ${res.status}`);
        }

        const blob = await res.blob();
        if (!blob || blob.size <= 0) {
            throw new Error('Empty image blob');
        }
        const type = String(blob.type || '').toLowerCase();
        if (type && !type.startsWith('image/')) {
            throw new Error(`Non-image response: ${type}`);
        }
        return blob;
    } finally {
        clearTimeout(timer);
    }
}

async function fetchWithUrlContextFallback(url, fetchBaseOptions, payloadNoTools) {
    const payloadWithCtx = { ...payloadNoTools, tools: [{ url_context: {} }] };
    try {
        return await fetchWithRetry(url, { ...fetchBaseOptions, body: JSON.stringify(payloadWithCtx) }, 2);
    } catch (e) {
        if (e.message && e.message.includes('status: 400')) throw e;
        console.warn('[url_context] Notion 컨벤션 참조 실패, url_context 없이 재시도합니다. 사유:', e.message);
        return await fetchWithRetry(url, { ...fetchBaseOptions, body: JSON.stringify(payloadNoTools) });
    }
}

async function searchImageAPI(query) {
    if (!naverClientId || !naverClientSecret) {
        return null; // 설정 안되어있으면 즉시 폴백
    }

    const siteFilter = (typeof googleSearchSites !== 'undefined' && Array.isArray(googleSearchSites) && googleSearchSites.length > 0)
        ? ' ' + googleSearchSites.map(s => 'site:' + s).join(' OR ')
        : '';

    // 로컬 프록시(node server.js) 경유 → Naver CORS 우회
    const isLocalServer = window.location.protocol === 'http:' && (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1');
    // Naver는 부정 연산자(-word)를 지원하지 않으므로 제거
    const naverQuery = (query + siteFilter).replace(/-\S+/g, '').replace(/\s+/g, ' ').trim();
    const endpoint = isLocalServer
        ? `/api/naver-image?query=${encodeURIComponent(naverQuery)}&display=10&sort=sim`
        : `https://openapi.naver.com/v1/search/image?query=${encodeURIComponent(naverQuery)}&display=10&sort=sim`;

    try {
        const res = await fetch(endpoint, {
            headers: {
                'X-Naver-Client-Id': naverClientId,
                'X-Naver-Client-Secret': naverClientSecret
            }
        });
        if (res.status === 429) {
            console.warn('[Search API] Naver 이미지 검색 일일 한도 초과(429).');
            if (window.showToast) window.showToast('Naver 검색 API 일일 한도 소진. AI 이미지 생성으로 전환합니다.', 'error');
            return null;
        }
        if (!res.ok) {
            console.error(`[Search API] Naver HTTP Error: ${res.status}`);
            return null;
        }
        const data = await res.json();
        if (data.items && data.items.length > 0) {
            const candidates = [];
            for (const item of data.items) {
                const imgUrl = item.link;
                console.log(`[Search API] Naver 이미지 시도: ${imgUrl}`);
                try {
                    const b64 = await fetchImageAsBase64(imgUrl);
                    if (b64) {
                        console.log(`[Search API] Naver 이미지 로드 성공: ${imgUrl}`);
                        candidates.push({ b64, source: imgUrl, vendor: "Naver" });
                        if (candidates.length >= 5) break; // 최대 5개 후보 수집
                    }
                } catch (imgErr) {
                    console.warn(`[Search API] 이미지 변환 실패, 다음 항목 시도: ${imgUrl} | ${imgErr?.message}`);
                }
            }
            if (candidates.length > 0) return candidates;
            console.warn('[Search API] Naver 검색 결과 전체 이미지 변환 실패');
        }
        return null;
    } catch (e) {
        console.error('[Search API] Naver 네트워크/파싱 에러:', e);
        return null;
    }
}

async function fetchImageAsBase64(imageUrl) {
    const normalized = normalizeImageSourceUrl(imageUrl);
    if (!normalized) throw new Error('Empty image URL');
    if (/^data:image\//i.test(normalized)) return normalized;

    const candidates = [{ label: 'direct', url: normalized }];
    IMAGE_FETCH_PROXY_BUILDERS.forEach(proxy => {
        try {
            candidates.push({ label: proxy.label, url: proxy.build(normalized) });
        } catch (e) {
            console.warn(`[Image Convert] proxy URL build failed (${proxy.label}):`, e);
        }
    });

    const errors = [];
    for (const candidate of candidates) {
        try {
            const b64 = await loadImageToDataURLViaCanvas(candidate.url);
            console.log(`[Image Convert] success via ${candidate.label} (canvas)`);
            return b64;
        } catch (canvasErr) {
            errors.push(`${candidate.label}/canvas: ${canvasErr?.message || canvasErr}`);
        }

        try {
            const b64 = await loadImageToDataURLViaFetch(candidate.url);
            console.log(`[Image Convert] success via ${candidate.label} (fetch)`);
            return b64;
        } catch (fetchErr) {
            errors.push(`${candidate.label}/fetch: ${fetchErr?.message || fetchErr}`);
        }
    }

    const reason = errors.slice(0, 8).join(' | ') || 'unknown';
    throw new Error(`Image conversion failed: ${reason}`);
}
