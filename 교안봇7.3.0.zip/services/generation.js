async function handleGenerate() {

    const topic = document.getElementById('topic-input').value.trim();

    if (!topic) return window.showAlert('교육 주제를 입력해주세요.');



    document.getElementById('sidebar-loading').style.display = 'flex';

    document.getElementById('generate-btn').disabled = true;



    const { systemInstruction, userPrompt } = buildTaskContext('blueprint', topic);



    const payload = {

        contents: [{ parts: [{ text: userPrompt }] }],

        systemInstruction: { parts: [{ text: systemInstruction }] },

        generationConfig: { responseMimeType: "application/json" }

    };



    try {

        const data = await fetchWithRetry(

            `https://generativelanguage.googleapis.com/v1beta/models/${TEXT_MODEL}:generateContent?key=${apiKey}`,

            { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }

        );



        const rawText = extractText(data);

        const parsed = safeJSONParse(rawText);



        if (!Array.isArray(parsed)) throw new Error("Invalid format received");



        courseData = parsed.map((item, idx) => ({

            id: Date.now() + idx,

            title: item.title,

            description: item.description,

            hours: item.hours || 2,

            status: 'waiting',

            content: null,

            teacherNotes: [],
            qualityEvaluation: null,

            uploadedMdName: null,

            uploadedMdContent: null

        }));

        currentTopic = topic;



        renderSidebar();

        saveState();

    } catch (err) {

        console.error(err);

        if (err.message && err.message.includes('401')) {

            window.showAlert('API 인증 오류(401)가 발생했습니다. 세션 토큰 갱신 지연일 수 있으니 10초 후 재시도하거나 새로고침(F5) 해주세요.');

        } else {

            window.showAlert('목차 생성 중 오류가 발생했습니다. 다시 시도해주세요.');

        }

    } finally {

        document.getElementById('sidebar-loading').style.display = 'none';

        document.getElementById('generate-btn').disabled = false;

    }

}

async function generateModuleContent(moduleId, keyConcepts) {

    const mod = getEditingModule(moduleId);

    if (!mod) return;

    // F1-2: 핵심개념 저장 (재생성 시 기본값으로 재활용)
    if (Array.isArray(keyConcepts) && keyConcepts.length > 0) {
        mod.keyConcepts = keyConcepts;
    }


    const subj = globalState.subjects.find(s => s.id === currentSubjectId);

    let hasMainQuest = false;

    let mainQuestText = "";

    let otherLessonsText = "";



    if (subj && subj.mainQuest && subj.mainQuest.status === 'done' && subj.mainQuest.content) {

        hasMainQuest = true;

        const cleanMqContent = cleanForAPI(subj.mainQuest.content).substring(0, 300);

        mainQuestText = `${subj.mainQuest.title}: ${subj.mainQuest.description}\n[핵심 내용 요약] ${cleanMqContent}...`;



        const otherQuests = subj.lessons

            .filter(l => String(l.id) !== String(moduleId) && l.status === 'done' && l.content)

            .map(l => {

                const match = l.content.match(/# ⚔️ 일일 퀘스트[\s\S]*/);

                const qText = match ? cleanForAPI(match[0]).substring(0, 150) : '퀘스트 없음';

                return `- [${l.title}]의 일일 퀘스트: ${qText}`;

            });

        otherLessonsText = otherQuests.join('\n');

    }



    if (window.EditorLoading) {
        window.EditorLoading.show([
            "AI가 상세 교안의 뼈대를 구상 중입니다...",
            "학습 목표와 핵심 내용을 분석하고 있습니다...",
            "상세 설명과 예시 구문을 작성 중입니다...",
            "(거의 다 되었습니다) 서식을 정돈 중입니다..."
        ]);
    }



    document.querySelectorAll('.module-card').forEach(c => c.classList.remove('border-accent', 'bg-accent/10', 'border-yellow-400', 'bg-yellow-400/10'));

    const card = document.querySelector(`.module-card[data-id="${moduleId}"]`);

    if (card) {

        if (moduleId === 'mainQuest') card.classList.add('border-yellow-400', 'bg-yellow-400/10');

        else card.classList.add('border-accent', 'bg-accent/10');

    }



    // ── F2: 분할 생성 파이프라인 ──
    const MAX_CHUNKS = 5;
    const CONTINUE_MARKER = '<!-- CONTINUE -->';
    const END_MARKER = '<!-- END -->';
    let fullContent = '';
    let chunkCount = 0;

    try {
        // ── Chunk 1: 최초 생성 ──
        const { systemInstruction, userPrompt } = buildTaskContext('module', {
            title: mod.title,
            description: mod.description,
            keyConcepts: mod.keyConcepts || [],
            hasMainQuest: hasMainQuest,
            mainQuestText: mainQuestText,
            otherLessonsText: otherLessonsText,
            uploadedMdContent: mod.uploadedMdContent
        });

        if (window.EditorLoading) {
            window.EditorLoading.show([
                "교안 초안 작성 중... (1단계)",
                "학습 목표와 핵심 내용을 구성하고 있습니다...",
                "상세 설명과 구조를 다듬는 중입니다..."
            ]);
        }

        const _firstPayload = {
            safetySettings: [
                { category: 'HARM_CATEGORY_HARASSMENT', threshold: 'BLOCK_ONLY_HIGH' },
                { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_ONLY_HIGH' },
                { category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT', threshold: 'BLOCK_ONLY_HIGH' },
                { category: 'HARM_CATEGORY_DANGEROUS_CONTENT', threshold: 'BLOCK_ONLY_HIGH' }
            ],
            contents: [{ parts: [{ text: userPrompt }] }],
            systemInstruction: { parts: [{ text: systemInstruction }] }
        };
        const firstData = await fetchWithUrlContextFallback(
            `https://generativelanguage.googleapis.com/v1beta/models/${TEXT_MODEL}:generateContent?key=${apiKey}`,
            { method: 'POST', headers: { 'Content-Type': 'application/json' } },
            _firstPayload
        );

        let chunkText = extractText(firstData);
        chunkText = chunkText.replace(/^```\w*\n?/i, '').replace(/\n?```$/i, '').trim();
        fullContent = chunkText;
        chunkCount = 1;

        // ── Chunk 2~N: 이어쓰기 루프 ──
        while (fullContent.includes(CONTINUE_MARKER) && chunkCount < MAX_CHUNKS) {
            chunkCount++;
            // CONTINUE 마커 제거
            fullContent = fullContent.replace(CONTINUE_MARKER, '').trimEnd();

            if (window.EditorLoading) {
                window.EditorLoading.show([
                    `교안 이어쓰기 중... (${chunkCount}단계 진행)`,
                    "내용이 풍부하여 이어서 작성하고 있습니다...",
                    "(조금만 더 기다려 주세요) 마무리 단계를 생성 중입니다..."
                ]);
            }

            // 이전 내용의 마지막 1500자를 컨텍스트로 전달 (토큰 절약)
            const contextTail = fullContent.length > 1500 ? fullContent.slice(-1500) : fullContent;

            const { systemInstruction: contSys, userPrompt: contPrompt } = buildTaskContext('module_continue', {
                title: mod.title,
                description: mod.description,
                keyConcepts: mod.keyConcepts || [],
                hasMainQuest: hasMainQuest,
                chunkIndex: chunkCount,
                previousContent: contextTail
            });

            // API 쿨다운
            await new Promise(r => setTimeout(r, 1500));

            const _contPayload = {
                safetySettings: [
                    { category: 'HARM_CATEGORY_HARASSMENT', threshold: 'BLOCK_ONLY_HIGH' },
                    { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_ONLY_HIGH' },
                    { category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT', threshold: 'BLOCK_ONLY_HIGH' },
                    { category: 'HARM_CATEGORY_DANGEROUS_CONTENT', threshold: 'BLOCK_ONLY_HIGH' }
                ],
                contents: [{ parts: [{ text: contPrompt }] }],
                systemInstruction: { parts: [{ text: contSys }] }
            };
            const contData = await fetchWithUrlContextFallback(
                `https://generativelanguage.googleapis.com/v1beta/models/${TEXT_MODEL}:generateContent?key=${apiKey}`,
                { method: 'POST', headers: { 'Content-Type': 'application/json' } },
                _contPayload
            );

            let contText = extractText(contData);
            contText = contText.replace(/^```\w*\n?/i, '').replace(/\n?```$/i, '').trim();

            // 이어쓰기 내용 병합 (중복 헤딩 방지: 이전 마지막 헤딩과 동일하면 제거)
            const lastHeadingMatch = fullContent.match(/^(#{1,4}\s+.+)$/gm);
            if (lastHeadingMatch) {
                const lastHeading = lastHeadingMatch[lastHeadingMatch.length - 1].trim();
                const contLines = contText.split('\n');
                if (contLines[0] && contLines[0].trim() === lastHeading) {
                    contLines.shift();
                    contText = contLines.join('\n');
                }
            }

            fullContent += '\n\n' + contText;
        }

        // END 마커 정리
        fullContent = fullContent.replace(END_MARKER, '').trimEnd();
        // 잔여 CONTINUE 마커 정리 (MAX_CHUNKS 초과 시)
        fullContent = fullContent.replace(new RegExp(CONTINUE_MARKER, 'g'), '').trimEnd();

        // ── 이미지 태그 처리 ──
        if (window.EditorLoading) {
            window.EditorLoading.show([
                chunkCount > 1 ? `이미지 공간 확보 중... (${chunkCount}단계 완료)` : '이미지 공간 확보 중...',
                "레이아웃 정리를 마무리하고 있습니다..."
            ]);
        }

        mod.content = fullContent;
        mod.imageSearchReport = null;
        if (typeof window.invalidateModuleQualityEvaluation === 'function') {
            window.invalidateModuleQualityEvaluation(mod);
        }
        applyAutoTeacherGuides(mod, { force: true });
        mod.status = 'done';
        currentEditingModuleId = mod.id;

        await saveState();
        renderSidebar();
        renderEditor(mod);
        if (typeof window.renderFormatLintBanner === 'function') {
            window.renderFormatLintBanner(mod, { toast: true, forceToast: true });
        }

        if (chunkCount > 1) {
            window.showAlert(`✅ 교안이 ${chunkCount}단계에 걸쳐 생성되었습니다.`);
        }

        // [옵션 B] 이미지 백그라운드 처리 — 교안 텍스트를 즉시 표시한 뒤 이미지를 비동기로 확보
        if (mod.content && mod.content.includes('<!-- [IMG:')) {
            generateAllImagesInModule(mod.id);
        }

    } catch (err) {

        console.error("교안 생성 중 에러 상세 (generateModuleContent):", err, err.stack);

        if (err.message && err.message.includes('401')) {

            window.showAlert('API 인증 오류(401)가 발생했습니다. 시스템 토큰 갱신 지연일 수 있으니 10초 후 시도하거나 새로고침(F5) 해주세요.');

        } else {

            window.showAlert('교안 생성 중 오류가 발생했습니다.\n' + (err.message || ''));

        }

        // 부분 생성 복구: 일부 청크가 성공한 경우 저장
        if (fullContent && fullContent.length > 200) {
            fullContent = fullContent.replace(new RegExp(CONTINUE_MARKER, 'g'), '').replace(END_MARKER, '').trimEnd();
            mod.content = fullContent;
            mod.imageSearchReport = null;
            if (typeof window.invalidateModuleQualityEvaluation === 'function') {
                window.invalidateModuleQualityEvaluation(mod);
            }
            applyAutoTeacherGuides(mod, { force: true });
            mod.status = 'done';
            await saveState();
            renderSidebar();
            renderEditor(mod);
            if (typeof window.renderFormatLintBanner === 'function') {
                window.renderFormatLintBanner(mod, { toast: true, forceToast: true });
            }
            window.showAlert('⚠️ 중간 오류가 발생했지만 작성된 부분까지 저장했습니다.\n수동으로 나머지를 보완하거나 재생성하세요.');
        }

    } finally {

        if (window.EditorLoading) window.EditorLoading.hide();

    }

}

async function generateMainQuest() {

    const subj = globalState.subjects.find(s => s.id === currentSubjectId);

    if (!subj) return;

    const mq = subj.mainQuest;



    if (window.EditorLoading) {
        window.EditorLoading.show([
            "AI가 메인 퀘스트 시나리오를 구상 중입니다...",
            "모든 차시의 내용을 종합하여 연결성을 분석 중입니다...",
            "최종 퀘스트 목차와 세부 지침을 작성 중입니다..."
        ]);
    }



    document.querySelectorAll('.module-card').forEach(c => c.classList.remove('border-accent', 'bg-accent/10', 'border-yellow-400', 'bg-yellow-400/10'));

    const card = document.querySelector(`.module-card[data-id="mainQuest"]`);

    if (card) card.classList.add('border-yellow-400', 'bg-yellow-400/10');



    let contextStr = subj.lessons
        .map(l => `- ${l.title}: ${l.description}\n  summary: ${l.content ? cleanForAPI(l.content).substring(0, 150) + '...' : 'N/A'}`)
        .join('\n\n');



    const { systemInstruction, userPrompt } = buildTaskContext('main_quest', contextStr);



    const payload = {
        safetySettings: [
            { category: 'HARM_CATEGORY_HARASSMENT', threshold: 'BLOCK_ONLY_HIGH' },
            { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_ONLY_HIGH' },
            { category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT', threshold: 'BLOCK_ONLY_HIGH' },
            { category: 'HARM_CATEGORY_DANGEROUS_CONTENT', threshold: 'BLOCK_ONLY_HIGH' }
        ],
        contents: [{ parts: [{ text: userPrompt }] }],
        systemInstruction: { parts: [{ text: systemInstruction }] }
    };



    try {

        const data = await fetchWithUrlContextFallback(

            `https://generativelanguage.googleapis.com/v1beta/models/${TEXT_MODEL}:generateContent?key=${apiKey}`,

            { method: 'POST', headers: { 'Content-Type': 'application/json' } },

            payload

        );



        let markdownContent = extractText(data);

        mq.content = markdownContent;
        mq.imageSearchReport = null;
        if (typeof window.invalidateModuleQualityEvaluation === 'function') {
            window.invalidateModuleQualityEvaluation(mq);
        }
        applyAutoTeacherGuides(mq, { force: true });

        mq.status = 'done';

        currentEditingModuleId = 'mainQuest';



        await saveState();

        renderSidebar();

        renderEditor(mq);
        if (typeof window.renderFormatLintBanner === 'function') {
            window.renderFormatLintBanner(mq, { toast: true, forceToast: true });
        }

        // [옵션 B] 메인 퀘스트 이미지 백그라운드 처리
        if (mq.content && mq.content.includes('<!-- [IMG:')) {
            (async () => {
                try {
                    const newContent = await processImageTags(mq, mq.content);
                    mq.content = newContent;
                    if (typeof window.invalidateModuleQualityEvaluation === 'function') {
                        window.invalidateModuleQualityEvaluation(mq);
                    }
                    await saveState();
                    // 현재 메인 퀘스트를 보고 있는 경우에만 리렌더링
                    if (currentEditingModuleId === 'mainQuest') renderEditor(mq);
                } catch (e) {
                    console.warn('[BG Image] 메인 퀘스트 이미지 백그라운드 처리 실패:', e);
                }
            })();
        }

    } catch (err) {

        console.error(err);

        if (err.message && err.message.includes('401')) {

            window.showAlert('API 인증 오류(401)가 발생했습니다. 세션 토큰 갱신 지연일 수 있으니 10초 후 재시도하거나 새로고침(F5) 해주세요.');

        } else {

            window.showAlert('메인 퀘스트 생성 중 오류가 발생했습니다.');

        }

    } finally {

        if (window.EditorLoading) window.EditorLoading.hide();

    }

}

async function resolveImageBySearchChain({ keyword, context = '', fallbackGeneratePrompt = '', intent = null, logPrefix = 'Image Search Chain' } = {}) {
    const baseKeyword = (keyword || '').trim() || '게임 기획 관련 이미지';
    const contextText = (context || '').trim();
    const providerStatus = getImageSearchProviderStatus();
    let searchIntent = intent;

    if (!searchIntent) {
        try {
            searchIntent = await extractSearchIntent(baseKeyword, contextText || baseKeyword);
        } catch (e) {
            console.error(`[${logPrefix}] 검색 의도 추출 실패:`, e);
            searchIntent = null;
        }
    }

    const searchQueryKo = (searchIntent && searchIntent.search_query_ko) ? searchIntent.search_query_ko
        : (searchIntent && searchIntent.search_query) ? searchIntent.search_query : baseKeyword;
    const searchQueryEn = (searchIntent && searchIntent.search_query_en) ? searchIntent.search_query_en : null;
    const searchQuery = searchQueryKo;
    console.log(`[${logPrefix}] 원본 키워드: ${baseKeyword} -> KO: ${searchQueryKo} / EN: ${searchQueryEn}`, searchIntent);

    let b64Image = null;
    let vendorLabel = "AI 생성 이미지";

    let cached = null;
    if (typeof DBManager !== 'undefined' && DBManager && typeof DBManager.getCache === 'function') {
        try {
            cached = await DBManager.getCache(searchQuery);
        } catch (cacheErr) {
            console.warn(`[${logPrefix}] 캐시 조회 실패, 검색 체인을 계속 진행합니다.`, cacheErr);
        }
    }
    if (cached && cached.base64) {
        b64Image = cached.base64;
        vendorLabel = `캐시 이미지 (${cached.format})`;
        console.log(`[Cache Hit] 저장된 검색 결과를 불러왔습니다: ${searchQuery}`);
        if (window.showToast) window.showToast(`로컬 캐시에서 이미지를 로드했습니다: ${searchQuery}`, 'success');
        return { b64Image, vendorLabel, searchQuery, intent: searchIntent, resolvedBy: 'cache', providerStatus, fallbackReason: null };
    }

    let candidates = [];
    if (providerStatus.hasAny) {
        const searches = [searchImageAPI(searchQueryKo)];
        if (searchQueryEn && searchQueryEn !== searchQueryKo) searches.push(searchImageAPI(searchQueryEn));
        const results = await Promise.all(searches);
        for (const r of results) {
            if (Array.isArray(r)) candidates.push(...r);
            else if (r) candidates.push(r);
        }
        console.log(`[${logPrefix}] 투트랙 검색 후보 수집: ${candidates.length}개`);
    }
    if (candidates.length > 0) {
        const validationContext = contextText || baseKeyword;
        const validationIntent = searchIntent || { search_query: searchQuery, reasoning: fallbackGeneratePrompt || baseKeyword };
        for (const searchResult of candidates) {
            const validation = await validateImageWithVLM(searchResult.b64, validationIntent, validationContext);
            if (validation && validation.isValid !== false) {
                b64Image = searchResult.b64;
                vendorLabel = `${searchResult.vendor || '검색'} 검색 이미지`;
                if (typeof DBManager !== 'undefined' && DBManager && typeof DBManager.setCache === 'function') {
                    try {
                        await DBManager.setCache(searchQuery, b64Image, searchResult.source, vendorLabel);
                    } catch (cacheErr) {
                        console.warn(`[${logPrefix}] 검색 결과 캐시 저장 실패:`, cacheErr);
                    }
                }
                console.log(`[Cache Save] 검열을 통과한 새 검색 결과를 저장했습니다: ${searchQuery}`);
                return { b64Image, vendorLabel, searchQuery, intent: searchIntent, resolvedBy: 'naver', providerStatus, fallbackReason: null };
            }
            console.warn(`[VLM Validator] 이미지 부적합 판정, 다음 후보 시도: ${validation?.reason || '이유 불명'}`);
        }
        console.warn('[VLM Validator] 모든 후보 부적합 판정, AI 생성으로 전환');
        if (window.showToast) window.showToast(`검색 이미지 전체 부적합 판정. AI 이미지 생성으로 전환합니다.`, 'warning');
    }

    const fallbackReason = providerStatus.hasAny ? 'search_unavailable_or_no_result' : 'providers_not_configured';
    const generatePrompt = (fallbackGeneratePrompt && fallbackGeneratePrompt.trim())
        ? fallbackGeneratePrompt.trim()
        : ((searchIntent && searchIntent.reasoning) ? `[Context: ${searchIntent.reasoning}]\nQuery: ${searchQuery}` : baseKeyword);
    console.log(`[Fallback] 검색 엔진 결과가 없어 AI 생성으로 최종 대처: ${searchQuery}`);
    const imageFetchFailMessage = '이미지를 가져오지 못했습니다. 텍스트 교안으로 저장됩니다.';
    const notifyImageFetchFailure = () => {
        if (typeof window.showBannerError === 'function') {
            window.showBannerError(imageFetchFailMessage);
            return;
        }
        if (typeof window.showToast === 'function') {
            window.showToast(imageFetchFailMessage, 'warning');
            return;
        }
        console.warn(`[${logPrefix}] ${imageFetchFailMessage}`);
    };
    try {
        b64Image = await generateImageAPI(generatePrompt);
        if (!b64Image) {
            b64Image = null;
            console.warn(`[${logPrefix}] AI 이미지 생성 결과가 비어 있습니다.`);
            notifyImageFetchFailure();
        }
    } catch (generateErr) {
        console.warn(`[${logPrefix}] AI 이미지 생성 실패:`, generateErr);
        notifyImageFetchFailure();
        b64Image = null;
    }
    vendorLabel = fallbackReason === 'providers_not_configured'
        ? "AI 생성 이미지 (검색 API 미설정)"
        : "AI 생성 이미지 (검색 결과 없음/오류)";

    return { b64Image, vendorLabel, searchQuery, intent: searchIntent, resolvedBy: 'ai', providerStatus, fallbackReason };
}

window.startBatchGeneration = async function () {

    const title = document.getElementById('batch-title').value.trim();

    const count = parseInt(document.getElementById('batch-count').value);

    const goal = document.getElementById('batch-goal').value.trim();



    // 5단 별점 중요도 키워드 수집
    const concepts = [];
    [5,4,3,2,1].forEach(n => {
        const el = document.getElementById(`batch-star-${n}`);
        if (!el) return;
        const val = el.value.trim();
        if (val) val.split(',').map(s => s.trim()).filter(Boolean).forEach(s => concepts.push(`[★${n}]${s}`));
    });
    // blueprint 프롬프트용 태그 제거 버전
    const plainConcepts = concepts.map(c => c.replace(/^\[★\d\]/, '').trim());



    if (!title) return window.showAlert('교과 제목을 입력해주세요.');

    if (isNaN(count) || count < 1 || count > 15) return window.showAlert('생성할 차시 수를 1~15 사이로 입력해주세요.');



    const submitBtn = document.getElementById('batch-submit-btn');

    const cancelBtn = document.getElementById('batch-cancel-btn');

    const progressText = document.getElementById('batch-progress-text');

    const progressSpan = progressText.querySelector('span');



    submitBtn.classList.add('hidden');

    cancelBtn.classList.add('hidden');

    progressText.classList.remove('hidden');

    progressSpan.innerText = '목차(Blueprint) 설계 중... (1/' + (goal ? '3' : '2') + ')';



    try {

        // 1. Blueprint 생성

        const blueprintPrompt = `

                    다음 조건에 맞춰 게임 기획 교육과정 목차를 설계해주세요.

                    - 교과 제목: ${title}

                    - 차시 수: ${count}

                    - 최종 목표(레벨테스트): ${goal || '없음'}

                    - 핵심 개념: ${plainConcepts.length > 0 ? plainConcepts.join(', ') : '자유롭게 구성'}

                    ${batchUploadedFiles.length > 0 ? `- 참고 자료 요약:\n${batchUploadedFiles.slice(0, 5).map(f => `[${f.name}]\n${cleanForAPI(f.content).substring(0, 800)}`).join('\n\n')}` : ''}



                    응답은 반드시 순수 JSON 배열이어야 합니다.

                    예시: [{"title": "차시명", "description": "이 차시의 학습 목표 및 주요 내용 요약", "hours": 2}]

                `;



        const bpPayload = {
            contents: [{ parts: [{ text: blueprintPrompt }] }],
            systemInstruction: { parts: [{ text: CONTEXT_CORE.personas.orchestrator + "\n[규칙]\n- " + CONTEXT_CORE.rules.json_only }] }
        };



        const bpData = await fetchWithUrlContextFallback(

            `https://generativelanguage.googleapis.com/v1beta/models/${TEXT_MODEL}:generateContent?key=${apiKey}`,

            { method: 'POST', headers: { 'Content-Type': 'application/json' } },

            bpPayload

        );



        const blueprint = safeJSONParse(extractText(bpData));

        if (!Array.isArray(blueprint)) throw new Error("유효하지 않은 목차 데이터가 반환되었습니다.");



        // 2. 상세 교안 순차 생성 및 에러 방어 로직 적용

        const generatedLessons = [];

        for (let idx = 0; idx < blueprint.length; idx++) {

            const item = blueprint[idx];

            progressSpan.innerText = `차시 교안 생성 중... (${idx + 1}/${blueprint.length} 진행)`;



            try {

                const _lessonFile = batchUploadedFiles.length > 0
                    ? batchUploadedFiles[idx % batchUploadedFiles.length]
                    : null;

                const lessonPrompt = `

                            [현재 작업: 상세 교안 작성 (단원 일괄 생성 중)]

                            교과 제목: ${title}

                            차시명: ${item.title}

                            설명/목표: ${item.description}

                            단원 전체 핵심 개념: ${plainConcepts.join(', ')}

                            ${goal ? `최종 목표 연계성: 이 차시 내용은 최종적으로 '${goal}'을(를) 달성하기 위한 빌드업 과정이어야 합니다.` : ''}

                            ${_lessonFile ? `참고 자료 [${_lessonFile.name}]:\n${cleanForAPI(_lessonFile.content).substring(0, 2000)}` : ''}

                            

                            위 내용을 바탕으로 우리 교안 규격(1.개요, 2.학습 목표, 3.핵심 내용, 4.실습/예제, 5.요약)에 맞게 마크다운 교안을 작성하세요.
                            [중요 지침] 본문 작성 시 단순한 이론 나열을 금지합니다. 반드시 최근 업계 트렌드에 부합하는 실제 고유명사 게임 사례나 명확한 실제 데이터를 적극적으로 예시로 들어 설명하세요. (단, 존재하지 않는 허위 데이터나 사례를 지어내는 환각은 절대 금지합니다.)

                            마지막에는 '# ⚔️ 일일 퀘스트 (실습 과제)'를 포함하세요.

                        `;



                const lessonPayload = {
                    safetySettings: [
                        { category: "HARM_CATEGORY_HARASSMENT", threshold: "BLOCK_ONLY_HIGH" },
                        { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "BLOCK_ONLY_HIGH" },
                        { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_ONLY_HIGH" },
                        { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_ONLY_HIGH" }
                    ],
                    contents: [{ parts: [{ text: lessonPrompt }] }],
                    systemInstruction: { parts: [{ text: buildTaskContext('module', { title: item.title, description: item.description, keyConcepts: concepts }).systemInstruction }] }
                };



                const lessonData = await fetchWithUrlContextFallback(

                    `https://generativelanguage.googleapis.com/v1beta/models/${TEXT_MODEL}:generateContent?key=${apiKey}`,

                    { method: 'POST', headers: { 'Content-Type': 'application/json' } },

                    lessonPayload

                );



                let rawMarkdown = extractText(lessonData);

                let tempMod = { images: {} };
                const autoTeacherNotes = typeof window.buildAutoTeacherGuideNotes === 'function'
                    ? window.buildAutoTeacherGuideNotes(rawMarkdown)
                    : [];

                // rawMarkdown = await processImageTags(tempMod, rawMarkdown); // 이미지 지연 생성 전환으로 임시 비활성화



                generatedLessons.push({

                    id: Date.now() + idx,

                    title: item.title,

                    description: item.description,

                    hours: item.hours || 2,

                    status: 'done',

                    content: rawMarkdown,

                    images: tempMod.images,

                    imageSearchReport: null,
                    teacherNotes: autoTeacherNotes,
                    qualityEvaluation: null,

                    uploadedMdName: null,

                    uploadedMdContent: null

                });



                // [방어 설정] API Rate Limit(RPM) 우회를 위해 차시 생성 간 4초 대기 (Gemini 무료 티어 방어)
                if (idx < blueprint.length - 1) {
                    progressSpan.innerText = `API 쿨다운 대기 중... (${idx + 1}/${blueprint.length})`;
                    await new Promise(resolve => setTimeout(resolve, 4000));
                }



            } catch (err) {

                console.error(`[차시 생성 실패] ${item.title}:`, err);

                // [방어 설정] 특정 차시가 실패해도 전체 프로세스가 중단되지 않고, 해당 차시를 '대기중' 상태로 등록

                generatedLessons.push({

                    id: Date.now() + idx,

                    title: item.title,

                    description: item.description,

                    hours: item.hours || 2,

                    status: 'waiting', // 수동 생성 가능하도록 빈 껍데기 반환

                    content: null,

                    images: {},

                    imageSearchReport: null,
                    teacherNotes: [],
                    qualityEvaluation: null,

                    uploadedMdName: null,

                    uploadedMdContent: null

                });

            }

        }



        // 3. 전역 상태 업데이트 (Step 4)

        let subj = globalState.subjects.find(s => s.id === currentSubjectId);

        if (subj) {

            subj.title = title;

            subj.lessons = generatedLessons;



            if (goal) {

                if (!subj.mainQuest) subj.mainQuest = { images: {}, status: 'waiting', content: null, teacherNotes: [], qualityEvaluation: null };

                subj.mainQuest.title = "👑 메인 퀘스트: " + goal;

                subj.mainQuest.description = "최종 결과물: " + goal + " (모든 차시의 내용을 종합하여 완성하세요.)";

                subj.mainQuest.status = 'waiting';

                subj.mainQuest.content = null;
                subj.mainQuest.imageSearchReport = null;
                subj.mainQuest.teacherNotes = [];
                subj.mainQuest.qualityEvaluation = null;

            }



            courseData = subj.lessons;

        }



        await saveState();

        // 4. 메인 퀘스트 콘텐츠 자동 생성 (goal 입력 시)
        if (goal) {
            const subj = globalState.subjects.find(s => s.id === currentSubjectId);
            if (subj && subj.mainQuest) {
                progressSpan.innerText = 'API 쿨다운 대기 중... (메인 퀘스트)';
                await new Promise(resolve => setTimeout(resolve, 3000));
                progressSpan.innerText = '메인 퀘스트 교안 생성 중...';

                try {
                    // 생성된 차시들의 컨텍스트 수집
                    const contextStr = generatedLessons.map(l =>
                        `- ${l.title}: ${l.description}\n  내용 요약: ${l.content ? cleanForAPI(l.content).substring(0, 150) + '...' : '미작성'}`
                    ).join('\n\n');

                    const { systemInstruction, userPrompt } = buildTaskContext('main_quest', contextStr);

                    const mqPayload = {
                        contents: [{ parts: [{ text: userPrompt }] }],
                        systemInstruction: { parts: [{ text: systemInstruction }] }
                    };

                    const mqData = await fetchWithUrlContextFallback(
                        `https://generativelanguage.googleapis.com/v1beta/models/${TEXT_MODEL}:generateContent?key=${apiKey}`,
                        { method: 'POST', headers: { 'Content-Type': 'application/json' } },
                        mqPayload
                    );

                    let mqMarkdown = extractText(mqData);
                    mqMarkdown = await processImageTags(subj.mainQuest, mqMarkdown);

                    subj.mainQuest.content = mqMarkdown;
                    subj.mainQuest.status = 'done';
                    if (typeof window.applyAutoTeacherGuides === 'function') {
                        window.applyAutoTeacherGuides(subj.mainQuest, { force: true });
                    }
                    subj.mainQuest.qualityEvaluation = null;
                    await saveState();

                } catch (mqErr) {
                    console.error('[메인 퀘스트 생성 실패]', mqErr);
                    // 실패해도 전체 프로세스는 중단하지 않음 — 수동 생성 가능
                }
            }
        }



        // 화면 동기화

        renderSidebar();

        renderOverviewLNB();



        // 첫 번째 차시 열기

        if (courseData.length > 0) {

            viewModule(courseData[0].id);

        }

        if (typeof window.validateCurriculumFormat === 'function' && window.showToast) {
            const lintTargets = generatedLessons.filter(l => l && typeof l.content === 'string' && l.content.trim().length > 0);
            const mq = globalState.subjects.find(s => s.id === currentSubjectId)?.mainQuest;
            if (mq && typeof mq.content === 'string' && mq.content.trim().length > 0) {
                lintTargets.push(mq);
            }

            let issueCount = 0;
            for (const lesson of lintTargets) {
                const report = window.validateCurriculumFormat(lesson.content || '');
                if (report.errors.length > 0 || report.warnings.length > 0) {
                    issueCount += 1;
                }
            }

            if (issueCount > 0) {
                window.showToast(`서식 점검: ${issueCount}개 교안에서 점검 항목이 발견되었습니다.`, 'warning');
            } else if (lintTargets.length > 0) {
                window.showToast('서식 점검: 생성된 교안이 기본 규격을 통과했습니다.', 'success');
            }
        }

        // [옵션 B] 일괄 생성 이미지 백그라운드 처리 — 차시별 순차 처리로 Rate Limit 방어
        (async () => {
            for (const lesson of generatedLessons) {
                if (lesson.content && lesson.content.includes('<!-- [IMG:')) {
                    try {
                        await generateAllImagesInModule(lesson.id);
                    } catch (e) {
                        console.warn(`[BG Image] 차시 이미지 처리 실패 (${lesson.title}):`, e);
                    }
                }
            }
        })();



        closeBatchModal();

        const mqDone = goal && globalState.subjects.find(s => s.id === currentSubjectId)?.mainQuest?.status === 'done';
        window.showAlert(mqDone
            ? '🎉 단원 일괄 생성 + 메인 퀘스트 생성이 완료되었습니다!'
            : '🎉 단원 단위 일괄 생성이 완료되었습니다!' + (goal ? '\n⚠️ 메인 퀘스트는 생성에 실패했습니다. 수동으로 생성해 주세요.' : ''));



    } catch (e) {

        console.error("일괄 차시 생성 중 에러 발생 상세:", e, e.stack);

        window.showAlert('생성 중 오류가 발생했습니다.\n에러 내용: ' + e.message);

    } finally {

        submitBtn.classList.remove('hidden');

        cancelBtn.classList.remove('hidden');

        progressText.classList.add('hidden');

    }
}

function initBatchFileDropzone() {

    const dropzone = document.getElementById('batch-dropzone');

    const fileInput = document.getElementById('batch-file-input');

    if (!dropzone || !fileInput) return;



    dropzone.addEventListener('dragover', (e) => {

        e.preventDefault();

        dropzone.classList.add('border-accent', 'bg-accent/10');

    });



    // 드래그가 영역을 벗어나면 하이라이트 제거

    dropzone.addEventListener('dragleave', (e) => {

        e.preventDefault();

        dropzone.classList.remove('border-accent', 'bg-accent/10');

    });



    dropzone.addEventListener('drop', (e) => {

        e.preventDefault();

        dropzone.classList.remove('border-accent', 'bg-accent/10');

        if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {

            handleBatchFiles(e.dataTransfer.files);

        }

    });



    fileInput.addEventListener('change', (e) => {

        if (e.target.files && e.target.files.length > 0) {

            handleBatchFiles(e.target.files);

        }

    });

}
