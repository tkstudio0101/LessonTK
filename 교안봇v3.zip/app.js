/* ═══════════════════════════════════════════════════════════════
   게임 기획 교안 생성 에이전트 — Application Logic
   ═══════════════════════════════════════════════════════════════ */

/* ─── localStorage 초기화 (콘텐츠 데이터 전용) ────────────────
 *  키: 'vibe_coding_course_data'
 *
 *  [보안 주의] 이 localStorage는 교안 콘텐츠 데이터만 저장합니다.
 *  API 키는 sessionStorage에만 저장되며, 탭을 닫으면 자동 소멸됩니다.
 *  localStorage나 cookie에는 절대 저장하지 않습니다.
 * ──────────────────────────────────────────────────────────── */
const STORAGE_KEY = 'vibe_coding_course_data';

function initLocalStorage() {
    if (!localStorage.getItem(STORAGE_KEY)) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify({
            version: '3.0',
            createdAt: new Date().toISOString(),
            chapters: [],
            metadata: {}
        }));
    }
}

/* ─── API 키 관리 (sessionStorage) ────────────────────────── */
let GEMINI_API_KEY = null;

const apiKeyInput = document.getElementById('api-key-input');
const lockIcon = document.getElementById('lock-icon');

function handleApiKeyInput() {
    const value = apiKeyInput.value.trim();
    if (value.length > 0) {
        GEMINI_API_KEY = value;
        sessionStorage.setItem('gemini_api_key', value);
        setLockState(true);
    } else {
        GEMINI_API_KEY = null;
        sessionStorage.removeItem('gemini_api_key');
        setLockState(false);
    }
}

function setLockState(isLocked) {
    if (isLocked) {
        lockIcon.textContent = '\u2705';
        lockIcon.classList.add('locked');
        lockIcon.title = 'API 키가 설정되었습니다 (메모리 전용)';
    } else {
        lockIcon.textContent = '\u23F3';
        lockIcon.classList.remove('locked');
        lockIcon.title = 'API 키를 입력해 주세요';
    }
}

function isApiKeySet() {
    return GEMINI_API_KEY !== null && GEMINI_API_KEY.length > 0;
}

function parseJsonResponse(text) {
    try {
        return JSON.parse(text);
    } catch (e) {
        const match = text.match(/```(?:json)?\s*([\s\S]*?)```/);
        if (match) return JSON.parse(match[1].trim());
        throw new Error('JSON 파싱 실패: ' + e.message);
    }
}

/* ═══════════════════════════════════════════════════════════════
   Phase 2 — Gemini API 목차 생성
   ═══════════════════════════════════════════════════════════════ */

let courseData = [];
let currentTopic = '';
let contentHistory = [];
let currentEditingModuleId = null;

const topicInput = document.getElementById('topic-input');
const generateBtn = document.getElementById('generate-btn');
const moduleList = document.getElementById('module-list');
const loadingOverlay = document.getElementById('loading-overlay');

const editorPanel = document.getElementById('editor-panel');
const editorContent = editorPanel ? editorPanel.querySelector('.editor-content') : null;

async function generateBlueprint(topic) {
    if (!isApiKeySet()) { alert('\u26A0\uFE0F Gemini API 키를 먼저 입력해 주세요.'); return; }
    if (!topic || topic.trim().length === 0) { alert('\u26A0\uFE0F 교육 주제를 입력해 주세요.'); return; }

    showLoading(true);
    setGenerateButtonState(false);

    const GEMINI_API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${GEMINI_API_KEY}`;

    const systemPrompt = `당신은 [AntiGravity Curriculum Orchestrator]입니다.
게임 기획 교육과정의 목차(Table of Contents)를 설계하는 전문가입니다.

[용어 정의]
- Course: 가장 큰 학습 주제 단위 (예: '시스템 기획 입문', 'Unity 기초')
- Session: Course 내 세부 주제. 1일 수업(4~6시간) 기준.
- 교안: 각 Session의 교육 자료. 기본학습 / 기본실습 / 심화학습 / 심화실습 4가지 유형.

[교육 대상]
게임 기획을 처음 공부하는 예비 기획자(비전공 포함).

[응답 스키마]
- 응답은 반드시 순수한 JSON Array여야 합니다.
- 각 아이템 필드:
  - id: 숫자 (1부터 순번)
  - title: 문자열 (Session 제목 — 핵심 키워드 중심)
  - description: 문자열 (해당 Session에서 다루는 핵심 내용 1~2문장)
  - hours: 숫자 (해당 Session 예상 소요 시간, 기본 8)

[규칙]
- 5~10개 Session을 생성하십시오.
- 각 Session은 8시간 기준으로 설계하십시오.
- 구성 원칙: Why(왜 배우는가) → What(무엇을 배우는가) → How(어떻게 적용하는가)
- 실용적이고 프로젝트 기반의 학습이 가능하도록 구성하십시오.
- 마지막 Session에는 반드시 평가 과제(교과목 레벨 테스트)를 포함하십시오.
- 순수 JSON만 반환하십시오.`;

    const requestBody = {
        contents: [{ role: 'user', parts: [{ text: `교육 주제: ${topic}` }] }],
        systemInstruction: { parts: [{ text: systemPrompt }] },
        generationConfig: { temperature: 0.7, topP: 0.9, responseMimeType: 'application/json' }
    };

    try {
        const response = await fetch(GEMINI_API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(requestBody)
        });
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(`API 호출 실패: ${errorData?.error?.message || 'HTTP ' + response.status}`);
        }
        const data = await response.json();
        const rawText = data?.candidates?.[0]?.content?.parts?.[0]?.text;
        if (!rawText) throw new Error('API 응답에서 텍스트를 찾을 수 없습니다.');

        const parsed = parseJsonResponse(rawText);
        if (!Array.isArray(parsed) || parsed.length === 0) throw new Error('유효한 JSON Array 응답을 받지 못했습니다.');

        courseData = parsed.map(item => ({
            id: item.id, title: item.title, description: item.description,
            hours: item.hours || 8, status: 'waiting', content: null
        }));
        currentTopic = topic;
        renderSidebar();
        saveState();
        console.log(`[교안 에이전트] 목차 생성 완료: ${courseData.length}개 챕터`);
    } catch (error) {
        console.error('[교안 에이전트] 목차 생성 실패:', error);
        showError(error.message, topic);
    } finally {
        showLoading(false);
        setGenerateButtonState(true);
    }
}

/* ─── 사이드바 렌더링 ─────────────────────────────────────── */
function renderSidebar() {
    if (!moduleList) return;

    if (courseData.length === 0) {
        moduleList.innerHTML = `
            <p class="panel-placeholder">교육 주제를 입력하고 '교안 생성' 버튼을 눌러주세요.</p>
            <button class="add-module-btn" onclick="addModule()">+ 모듈 수동 추가</button>`;
        return;
    }

    const cards = courseData.map((item, index) => {
        const statusClass = item.status;
        const statusLabel = item.status === 'done' ? '\u2705 완료' : '대기중';
        const btnLabel = item.status === 'done' ? '\uD83D\uDD04 재생성' : '\u2728 생성';
        const btnClass = item.status === 'done' ? 'module-gen-btn regen' : 'module-gen-btn';
        return `
            <div class="module-card ${statusClass}" data-id="${item.id}" draggable="true"
                 style="animation-delay: ${index * 0.06}s" onclick="handleModuleClick(${item.id})">
                <div class="module-card-header">
                    <span class="module-card-number">${item.id}</span>
                    <div class="module-card-actions">
                        <span class="drag-handle" title="드래그하여 순서 변경">\u2630</span>
                        <button class="module-delete-btn" title="모듈 삭제"
                                onclick="event.stopPropagation(); deleteModule(${item.id})">\u2715</button>
                    </div>
                </div>
                <h3 class="module-editable" contenteditable="true" spellcheck="false"
                    data-field="title" data-id="${item.id}"
                    onblur="handleModuleEdit(${item.id}, 'title', this.textContent)"
                    onclick="event.stopPropagation()">${escapeHtml(item.title)}</h3>
                <p class="module-editable" contenteditable="true" spellcheck="false"
                   data-field="description" data-id="${item.id}"
                   onblur="handleModuleEdit(${item.id}, 'description', this.textContent)"
                   onclick="event.stopPropagation()">${escapeHtml(item.description)}</p>
                <div class="module-card-footer">
                    <span class="module-card-status ${statusClass}">${statusLabel}</span>
                    <button class="${btnClass}" onclick="event.stopPropagation(); handleModuleGenerate(${item.id})">${btnLabel}</button>
                </div>
            </div>`;
    }).join('');

    moduleList.innerHTML = cards + '<button class="add-module-btn" onclick="addModule()">+ 모듈 추가</button>';
    initDragAndDrop();
}

/* ─── 모듈 카드 클릭 (확인 전용) ──────────────────────────── */
function handleModuleClick(moduleId) {
    document.querySelectorAll('.module-card').forEach(c => c.classList.remove('active'));
    const card = document.querySelector(`.module-card[data-id="${moduleId}"]`);
    if (card) card.classList.add('active');

    currentEditingModuleId = moduleId;
    const mod = courseData.find(m => m.id === moduleId);
    if (!mod) return;
    mod.content ? renderEditorContent(mod.content, mod.title) : showEditorEmpty(mod.title);
}

/* ─── 생성/수정 버튼 → API 호출 ──────────────────────────── */
async function handleModuleGenerate(moduleId) {
    document.querySelectorAll('.module-card').forEach(c => c.classList.remove('active'));
    const card = document.querySelector(`.module-card[data-id="${moduleId}"]`);
    if (card) card.classList.add('active');

    const mod = courseData.find(m => m.id === moduleId);
    if (!mod) return;
    await generateModuleContent(mod);
}

/* ─── 미생성 안내 ─────────────────────────────────────────── */
function showEditorEmpty(title) {
    if (!editorContent) return;
    editorContent.innerHTML = `
        <div class="editor-empty">
            <span class="empty-icon">\uD83D\uDCC4</span>
            <h2>아직 생성되지 않았습니다</h2>
            <p><strong>${escapeHtml(title)}</strong> 모듈의 교안이 아직 작성되지 않았습니다.<br>좌측 카드의 <em>\u2728 생성</em> 버튼을 클릭하여 시작하세요.</p>
        </div>`;
}

/* ═══════════════════════════════════════════════════════════════
   Phase 5 — 모듈 편집 (CRUD / 드래그 / 인라인 / 히스토리)
   ═══════════════════════════════════════════════════════════════ */

const HISTORY_KEY = 'vibe_coding_history';

function addModule() {
    const newId = courseData.length > 0 ? Math.max(...courseData.map(m => m.id)) + 1 : 1;
    courseData.push({ id: newId, title: '새 모듈', description: '모듈 설명을 입력하세요.', status: 'waiting', content: null });
    renumberModules();
    renderSidebar();
    saveState();
}

function deleteModule(moduleId) {
    const target = courseData.find(m => m.id === moduleId);
    if (!target) return;
    if (!confirm(`"${target.title}" 모듈을 삭제하시겠습니까?`)) return;
    if (target.content) archiveContent(target);
    courseData = courseData.filter(m => m.id !== moduleId);
    renumberModules();
    renderSidebar();
    saveState();
}

function renumberModules() {
    courseData.forEach((m, i) => { m.id = i + 1; });
}

function handleModuleEdit(moduleId, field, newValue) {
    const target = courseData.find(m => m.id === moduleId);
    if (!target) return;
    const trimmed = newValue.trim();
    if (trimmed === target[field]) return;

    if (target.content) {
        archiveContent(target);
        target.content = null;
        target.status = 'waiting';
    }
    target[field] = trimmed;
    renderSidebar();
    saveState();
    const card = document.querySelector(`.module-card[data-id="${moduleId}"]`);
    if (card) card.classList.add('active');
}

/* ─── 드래그 & 드롭 ───────────────────────────────────────── */
let draggedId = null;

function initDragAndDrop() {
    const cards = moduleList.querySelectorAll('.module-card');
    cards.forEach(card => {
        card.addEventListener('dragstart', (e) => {
            draggedId = parseInt(card.dataset.id);
            card.classList.add('dragging');
            e.dataTransfer.effectAllowed = 'move';
        });
        card.addEventListener('dragend', () => {
            card.classList.remove('dragging');
            draggedId = null;
            moduleList.querySelectorAll('.module-card').forEach(c => c.classList.remove('drag-over'));
        });
        card.addEventListener('dragover', (e) => {
            e.preventDefault();
            e.dataTransfer.dropEffect = 'move';
            card.classList.add('drag-over');
        });
        card.addEventListener('dragleave', () => { card.classList.remove('drag-over'); });
        card.addEventListener('drop', (e) => {
            e.preventDefault();
            card.classList.remove('drag-over');
            const targetId = parseInt(card.dataset.id);
            if (draggedId !== null && draggedId !== targetId) handleDrop(draggedId, targetId);
        });
    });
}

function handleDrop(fromId, toId) {
    const fromIdx = courseData.findIndex(m => m.id === fromId);
    const toIdx = courseData.findIndex(m => m.id === toId);
    if (fromIdx === -1 || toIdx === -1) return;
    const [moved] = courseData.splice(fromIdx, 1);
    courseData.splice(toIdx, 0, moved);
    renumberModules();
    renderSidebar();
    saveState();
}

/* ─── 교안 히스토리 ───────────────────────────────────────── */
function archiveContent(module) {
    contentHistory.push({
        moduleTitle: module.title,
        description: module.description,
        content: module.content,
        topic: currentTopic,
        archivedAt: new Date().toISOString()
    });
    saveHistory();
}

function saveHistory() {
    try { localStorage.setItem(HISTORY_KEY, JSON.stringify(contentHistory)); }
    catch (e) { console.error('[교안 에이전트] 히스토리 저장 실패:', e); }
}

function restoreHistory() {
    try {
        const raw = localStorage.getItem(HISTORY_KEY);
        if (raw) contentHistory = JSON.parse(raw) || [];
    } catch (e) { contentHistory = []; }
}

function deleteHistoryItem(index) {
    contentHistory.splice(index, 1);
    saveHistory();
    renderHistoryPanel();
}

function clearHistory() {
    if (!confirm('모든 히스토리를 삭제하시겠습니까?')) return;
    contentHistory = [];
    saveHistory();
    renderHistoryPanel();
}

/* ─── 히스토리 패널 UI ─────────────────────────────────────── */
function toggleHistoryPanel() {
    if (!editorContent) return;
    const existing = editorContent.querySelector('.history-panel');
    if (existing) {
        editorContent.innerHTML = `
            <div class="editor-placeholder">
                <span class="placeholder-icon">\uD83D\uDCDD</span>
                <h2>교안 편집 영역</h2>
                <p>좌측 목차에서 항목을 선택하면<br>이곳에 콘텐츠가 렌더링됩니다.</p>
            </div>`;
        return;
    }
    renderHistoryPanel();
}

function renderHistoryPanel() {
    if (!editorContent) return;

    if (contentHistory.length === 0) {
        editorContent.innerHTML = `
            <div class="history-panel">
                <div class="history-header"><h2>\uD83D\uDCDC 교안 히스토리</h2></div>
                <div class="editor-empty">
                    <span class="empty-icon">\uD83D\uDCE6</span>
                    <h2>아카이브된 교안이 없습니다</h2>
                    <p>모듈 제목/설명을 편집하면 기존 교안이<br>자동으로 히스토리에 보관됩니다.</p>
                </div>
            </div>`;
        return;
    }

    const items = contentHistory.map((h, i) => {
        const date = new Date(h.archivedAt).toLocaleString('ko-KR', {
            month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
        });
        return `
            <div class="history-item" onclick="viewHistoryItem(${i})">
                <div class="history-item-info">
                    <strong>${escapeHtml(h.moduleTitle)}</strong>
                    <span class="history-meta">${escapeHtml(h.topic || '')} \u00B7 ${date}</span>
                </div>
                <button class="history-delete-btn" title="삭제"
                        onclick="event.stopPropagation(); deleteHistoryItem(${i})">\u2715</button>
            </div>`;
    }).reverse().join('');

    editorContent.innerHTML = `
        <div class="history-panel">
            <div class="history-header">
                <h2>\uD83D\uDCDC 교안 히스토리 (${contentHistory.length})</h2>
                <button class="history-clear-btn" onclick="clearHistory()">\uD83D\uDDD1\uFE0F 전체 삭제</button>
            </div>
            <div class="history-list">${items}</div>
        </div>`;
}

function viewHistoryItem(index) {
    const item = contentHistory[index];
    if (!item) return;
    renderEditorContent(item.content, `[히스토리] ${item.moduleTitle}`);
}

/* ═════════════════════════════════════════════════════════════════
   Phase 2.5 — 이미지 검색 및 태그 해석 (Asset Resolver)
   ═════════════════════════════════════════════════════════════════ */

/* ─── 키워드 단순화: 검색 성공률 향상 ────────────────────────── */
function simplifyKeyword(keyword) {
    // 핵심 단어만 추출 (최대 4개), 불필요한 수식어 제거
    const stopWords = new Set(['with', 'and', 'the', 'for', 'from', 'that', 'this', 'into', 'about', 'elements', 'traits', 'aspects', 'features', 'overview', 'example', 'various']);
    const words = keyword.split(/\s+/).filter(w => !stopWords.has(w.toLowerCase()));
    return words.slice(0, 4).join(' ');
}

/* ─── Wikimedia Commons 이미지 검색 (무료, API 키 불필요) ───────── */
async function searchWikimediaImage(keyword) {
    const searchTerm = simplifyKeyword(keyword);
    const url = `https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrsearch=${encodeURIComponent(searchTerm)}&gsrnamespace=6&prop=imageinfo&iiprop=url&iiurlwidth=800&format=json&origin=*`;
    try {
        const res = await fetch(url);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();
        const pages = data?.query?.pages;
        if (!pages) return null;
        const imagePages = Object.values(pages).filter(p => {
            const thumbUrl = p?.imageinfo?.[0]?.thumburl || '';
            return /\.(png|jpg|jpeg|webp|gif)/i.test(thumbUrl);
        });
        if (imagePages.length === 0) return null;
        console.log(`[Asset Resolver] Wikimedia 검색 성공: "${searchTerm}" → ${imagePages.length}개 결과`);
        return imagePages[0].imageinfo[0].thumburl;
    } catch (e) {
        console.warn('[Asset Resolver] Wikimedia 검색 실패:', searchTerm, e.message);
        return null;
    }
}

/* ─── Wikipedia 페이지 이미지 fallback ──────────────────────── */
async function searchWikipediaImage(keyword) {
    const searchTerm = simplifyKeyword(keyword).split(' ').slice(0, 2).join(' ');
    const url = `https://en.wikipedia.org/w/api.php?action=query&generator=search&gsrsearch=${encodeURIComponent(searchTerm)}&prop=pageimages&piprop=thumbnail&pithumbsize=800&format=json&origin=*`;
    try {
        const res = await fetch(url);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();
        const pages = data?.query?.pages;
        if (!pages) return null;
        const withThumb = Object.values(pages).find(p => p?.thumbnail?.source);
        if (!withThumb) return null;
        console.log(`[Asset Resolver] Wikipedia 검색 성공: "${searchTerm}"`);
        return withThumb.thumbnail.source;
    } catch (e) {
        console.warn('[Asset Resolver] Wikipedia 검색 실패:', searchTerm, e.message);
        return null;
    }
}

/* ─── 통합 이미지 검색 (다중 소스 순차 시도) ───────────────── */
async function searchImage(keyword) {
    // 1차: Wikimedia Commons (전체 키워드)
    let result = await searchWikimediaImage(keyword);
    if (result) return result;

    // 2차: Wikipedia 페이지 이미지
    result = await searchWikipediaImage(keyword);
    if (result) return result;

    console.log(`[Asset Resolver] 모든 소스에서 이미지 미발견: "${keyword}"`);
    return null;
}

/* ─── 이미지 태그 후처리: <!-- [IMG: "keyword"] --> → 실제 이미지 ─── */
async function resolveImageTags(markdown) {
    const regex = /<!--\s*\[IMG:\s*"?(.+?)"?\s*\]\s*-->/g;
    const matches = [...markdown.matchAll(regex)];
    if (matches.length === 0) return markdown;

    console.log(`[Asset Resolver] ${matches.length}개 이미지 태그 발견, 검색 시작...`);
    let result = markdown;

    for (const match of matches) {
        const keyword = match[1].trim();
        const imgUrl = await searchImage(keyword);

        let replacement;
        if (imgUrl) {
            replacement = `\n<p align="center" data-asset-tag="ai-resolved"><img src="${imgUrl}" alt="${keyword}" title="[AI Asset] ${keyword}" style="max-width:100%;border-radius:8px;border:2px solid rgba(124,91,245,0.3);"></p>\n`;
            console.log(`[Asset Resolver] ✅ 이미지 발견: ${keyword}`);
        } else {
            // Fallback: 스타일드 placeholder
            replacement = `\n<div data-asset-tag="ai-placeholder" style="background:linear-gradient(135deg,#1a1a3e,#2a2a5e);border:1px dashed rgba(124,91,245,0.3);border-radius:12px;padding:32px 24px;text-align:center;margin:16px 0;"><span style="font-size:2.5rem;">🖼️</span><br><span style="color:#aaaadd;font-size:0.85rem;font-weight:600;">[AI Asset] ${keyword}</span></div>\n`;
            console.log(`[Asset Resolver] ⚠️ Placeholder 삽입: ${keyword}`);
        }
        result = result.replace(match[0], replacement);
    }

    console.log(`[Asset Resolver] 이미지 태그 해석 완료`);
    return result;
}

/* ─── 이미지 위치 재배치: ## 제목 바로 아래, 본문 위로 이동 ─── */
function repositionImages(markdown) {
    const lines = markdown.split('\n');
    const result = [];
    const pendingImages = [];

    for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        const isImage = /^\s*<p[^>]*>\s*<img/.test(line) || /^\s*<div[^>]*>.*🖼️/.test(line);
        const isHeading = /^#{1,2}\s/.test(line);

        if (isImage) {
            // Collect image lines for later placement
            pendingImages.push(line);
            continue;
        }

        if (isHeading && pendingImages.length > 0) {
            // Flush any pending images before new heading, then write heading
            result.push(...pendingImages, '');
            pendingImages.length = 0;
            result.push(line);
            continue;
        }

        if (isHeading) {
            result.push(line);
            // Look ahead: collect images that follow later in this section
            continue;
        }

        // Non-image, non-heading line
        if (pendingImages.length > 0) {
            // We have pending images and hit body text — insert images before body
            // Pattern: heading was already added → images → <br> → body
            result.push(...pendingImages, '', '<br>', '');
            pendingImages.length = 0;
        }
        result.push(line);
    }

    // Flush remaining images at end
    if (pendingImages.length > 0) {
        result.push(...pendingImages);
    }

    return result.join('\n');
}

/* ═══════════════════════════════════════════════════════════════
   Phase 3 — 모듈 상세 교안 생성
   ═══════════════════════════════════════════════════════════════ */

async function generateModuleContent(blockData) {
    if (!isApiKeySet()) { alert('\u26A0\uFE0F Gemini API 키를 먼저 입력해 주세요.'); return; }

    showEditorWriting(blockData.title);

    const GEMINI_API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${GEMINI_API_KEY}`;

    const systemPrompt = `당신은 [AntiGravity Curriculum Orchestrator] 산하 교안 작성 모듈입니다.
게임 기획 아카데미의 교보조이며, 교안을 Markdown으로 작성합니다.

═══════════════════════════════════════
[1. 교육 대상]
═══════════════════════════════════════
- 게임 기획을 처음 공부하는 예비 기획자(비전공 포함).
- 코딩을 모르는 완전한 초보자입니다.
- 추상적인 이론 대신 구체적인 게임 예시를 들어 설명하십시오.

═══════════════════════════════════════
[2. 교안 구조 — 반드시 이 순서를 따름]
═══════════════════════════════════════
1. [개요] (기본학습): 교안 내용을 소개하고, 교육 목적을 제시하며, 흥미를 유도합니다.
2. [학습 목표] (기본학습): 이 수업을 통해 얻게 되는 지식과 역량을 구체적으로 명시합니다.
   - 형식: "- **항목명:**" 줄 아래에 "    - 설명" 들여쓰기
3. [상세 내용] (기본학습): '개념 정의(Concepts) → 이론/사례/예제' 구조로 작성합니다.
   - 핵심 용어는 표(Table)로 정리합니다.
   - 구체적인 게임 사례를 최소 3개 이상 포함합니다.
   - 절차적 설명에는 mermaid 다이어그램 구문을 사용합니다.
   - 각 소주제마다 충분한 깊이(Level 3~4 헤딩)로 설명합니다.
4. [실습] (기본실습): 학생이 1시간 이상 스스로 수행하는 과제입니다.
   - 반드시 [소요 시간 / 난이도 / 평가 기준]을 명시합니다.
   - 퀘스트 형식(배경→완료 조건→절차(Step 1~N)→제출 형태)으로 작성합니다.
5. [심화] (심화학습/실습): 고급 학습자용 참고 자료, 팁, 챌린지 과제입니다.

═══════════════════════════════════════
[3. 헤딩 체계 — Heading Depth]
═══════════════════════════════════════
- Level 1: "# " + 📝 아이콘 + Session 제목  (예: # 📝 생성형 AI와 게임 기획 개요)
- Level 2: "## " + 주요 내용 제목  (예: ## 개요)
- Level 3: "### ■ " + 소주제 제목  (예: ### ■ 3D 렌더링의 핵심 3요소)
- Level 4: "#### &nbsp;&nbsp; ▣ " + 하위 소주제  (예: #### &nbsp;&nbsp; ▣ 메쉬 : 기하학적 형상)
- 헤더에 번호(1., 1.1. 등)를 절대 붙이지 마십시오.
- 헤딩 어미: 짧은 구(명사형 종결) 또는 '~음, ~함' 스타일.

═══════════════════════════════════════
[4. 서식 규칙 — Spacing & Layout (엄밀 적용)]
═══════════════════════════════════════

4-A. 요소 분류
- **서술 요소(Narrative):** Heading(# ~ ####), Body(일반 텍스트, 리스트 '-')
- **블록 요소(Block/Content):** 이미지, 코드 블록, 표(Table), 인용문(>), mermaid
  → 블록 요소는 '콘텐츠(Content)'로 취급하며, 전후 줄바꿈 규칙이 적용됩니다.

4-B. Spacing Zone 정의
- Spacing Zone = [빈 줄] + <br> 태그 + [빈 줄]
- 값: <br> (1줄바꿈), <br><br> (2줄바꿈)

4-C. 배치 규칙 매트릭스 (우선순위: 4-D 특수 패턴 > 4-C 기본 매트릭스)
| 관계 | 상황 | 적용 규칙 |
| Heading 내부 | Body가 Heading 바로 아래 올 때 | 없음(0회) — Heading과 설명은 한 몸 |
| Heading-Content | Content가 Heading 바로 아래 올 때 | 단순 1줄 Enter (빈행만, <br> 없음) |
| 단락 분리 | 단락 ↔ 단락/Heading 사이 | 1줄바꿈 Zone 적용 ([빈줄]+<br>+[빈줄]) |
| 요소 분리 | 텍스트 ↔ Content 사이 | 1줄바꿈 Zone 적용 |
| Content 분리 | Content ↔ Content 연속 | 2줄바꿈 Zone 적용 ([빈줄]+<br><br>+[빈줄]) |
| Session 전환 | → Session 제목(# 📝) | <br><br> + --- + <br> |

4-D. 특수 패턴 (4-C보다 우선)
1. **샌드위치 구조:** Content(A) → 텍스트(B) → Content(C) 순서일 때
   → B 위에 1줄바꿈(<br>), B 아래에 2줄바꿈(<br><br>) 적용.
2. **Level 1 직후:** # 📝 바로 아래는 별도 규칙 없으면 1줄바꿈.
3. **연속 미디어:** 이미지/비디오가 연속 나열 시 [Enter]만으로 구분.

4-E. 기타 서식
- 표(Table) 정렬: 헤더/주제 → 가운데 정렬(:---:), 긴 설명 → 왼쪽 정렬(:---)
- 이미지: <p align="center"><img src="URL" alt="설명"></p>
- 본문 리스트: "-" Depth 1, "  -" Depth 2, "    -" Depth 3
- 핵심 개념(Key Concept) 형식:
  - "- **용어명 (Bold):**" 줄 + 아래에 "    - 설명 내용" (들여쓰기)
- Level 4 헤딩은 &nbsp;&nbsp; 접두 들여쓰기: #### &nbsp;&nbsp; ▣ 제목
- 접두사 없는 일반 텍스트에도 &nbsp;&nbsp; 시각 들여쓰기 적용.

═══════════════════════════════════════
[4-F. 이미지 삽입 규칙 — ★ 필수 ★]
═══════════════════════════════════════
- 교안에는 이미지 요청 태그를 삽입하여 시각 자료를 배치합니다.
- **태그 형식:** <!-- [IMG: "영어 검색 키워드"] -->
- **필수 삽입 위치 (최소 기준):**
  1. 개요(##) 직후: 수업 분위기를 설정하는 대표 이미지 1장
  2. 각 대주제(##)마다: 해당 주제를 설명하는 이미지 최소 1장
  3. 추상적 개념 설명 직후: 시각화 이미지
  4. 특정 게임 사례 언급 시: 해당 게임 스크린샷/로고
- **키워드 작성 규칙:**
  - 반드시 영어로 작성합니다.
  - 구체적이고 검색 가능한 키워드를 사용합니다.
  - 예: <!-- [IMG: "game inventory UI design RPG"] -->
  - 예: <!-- [IMG: "Unity 3D scene editor screenshot"] -->

- **★ 태그 배치 위치 (핵심) ★:**
  - IMG 태그는 반드시 **## 제목 바로 아래, 본문(불릿) 위**에 배치합니다.
  - 제목 → 이미지 → <br> → 본문 순서를 엄격히 지키십시오.

[올바른 예시]
## 개요
<!-- [IMG: "game design overview concept art"] -->

<br>

- 캠릭터와 세계관은 게임의 영혼과 같습니다.
- 플레이어가 게임에 몰입하고 감동을 느끼게 하는 핵심 요소입니다.

[잘못된 예시 — 이렇게 쓰지 마십시오]
## 개요
- 캠릭터와 세계관은 게임의 영혼과 같습니다.
- 플레이어가 게임에 몰입하고...
<!-- [IMG: "game design overview concept art"] -->

═══════════════════════════════════════
[5. 시맨틱 아이콘 — 용도 명세]
═══════════════════════════════════════
아래 아이콘은 해당 키워드/맥락이 등장하는 줄 앞에 삽입합니다.
| 아이콘 | 의미 | 용도 |
| 💡 | 중요 | 핵심 개념을 연결하거나 강조할 때 |
| ✅ | 체크 | 학습 체크리스트, 완료 확인 항목 |
| ☑️ | 강조 | 2차 강조(보라색 계열 부가 강조) |
| ℹ️ | 정보 | 부가 설명, 추가 배경 정보 |
| 💬 | TMI | 사소하지만 흥미로운 부가 정보 |
| 🎮 | 예시 | 실무/현장 게임 사례를 제시할 때 |
| ⚠️ | 주의 | 주의사항, 실수 방지 유의점 |
| ⚙️ | 실습 | 실습 가이드 및 따라하기 안내 |

═══════════════════════════════════════
[6. 어투 — Tone & Manner]
═══════════════════════════════════════
- 헤딩: 짧은 구(명사형 종결) 또는 '~음, ~함' 형태
- 본문: 합쇼체(~합니다, ~입니다, ~하십시오)
- 초보자 눈높이 설명 + 구체적 비유 적극 활용
  예) DB 정규화 → "RPG 인벤토리에서 아이템을 ID로 참조하는 시스템"
  예) 행동 트리 → "회사의 조직도 및 결재 시스템"
  예) UI/UX 어포던스 → "빨간 드럼통은 터진다, 문손잡이는 잡아당긴다"

═══════════════════════════════════════
[6-1. 문장 구조 — ★ 최우선 적용 ★]
═══════════════════════════════════════
교안은 '읽히는 교과서'가 아니라 '훑어볼 수 있는 자료'입니다.
아래 규칙을 반드시 지키십시오:

[절대 금지]
- 3문장 이상의 장문 산문 단락을 작성하지 마십시오.
- 연속된 평문 문장 나열 (문단 형식) 금지.

[필수 규칙]
- 모든 설명은 "- " 불릿 포인트로 시작합니다.
- 불릿 1개당 1문장 원칙 (최대 2문장까지만 허용).
- 개념 나열 시 반드시 Key Concept 형식 사용:
  - **용어명 (Bold):**
      - 설명 내용 (들여쓰기)
- 3개 이상 속성/항목 비교 시 반드시 표(Table) 사용.
- 절차/흐름 설명 시 반드시 mermaid 또는 번호 리스트 사용.
- 구체적인 게임 제목(예: 위쳐3, 젤다 BotW) 사용 필수.

[올바른 예시 — studyplanexample.md 기준]
(아래처럼 작성하십시오)

## 개요
- 2022년 ChatGPT, Midjourney 등 강력한 성능의 생성형 AI가 본격적으로 상용화 된 이후, AI는 산업계의 핵심 기술이 되었습니다.
- 게임 개발 관점에서도 반복 작업을 줄이고 검증 속도를 높여주는 강력한 도구입니다.
- 본 교과에서는 생성형 AI의 원리를 이해하고, 실제 기획 프로세스에 안전하게 적용하는 방법을 학습합니다.

## 학습 목표
- **핵심 개념 이해:**
    - AI, 머신러닝, 딥러닝, 생성형 AI의 관계와 원리를 구분하여 설명할 수 있다.
- **실무 활용 파악:**
    - 실제 게임 프로젝트(블리자드, 유비소프트 등)의 AI 도입 사례를 분석한다.

## 주요 용어 정리
| 용어 | 정의 | 비고 |
| :---: | :--- | :--- |
| **머신러닝** | 데이터를 통해 스스로 규칙을 찾는 학습 방법 | AI의 하위 집합 |
| **LLM** | 거대 언어 모델. 텍스트 패턴을 확률적으로 예측하여 생성 | GPT, Gemini 등 |

## 게임 개발 활용 사례
- **기획:**
    - 세계관 설정, 퀘스트 지문 작성, 밸런스 시뮬레이션 코드 초안 작성.
- **아트:**
    - 컨셉 아트(Stable Diffusion), UI 아이콘 생성, 애니메이션 레퍼런스.
- **사례:**
    - 🎮 유비소프트 'Ghostwriter': NPC의 반복적인 대사(Bark) 자동 생성.
    - 🎮 블리자드: 내부 데이터 학습 모델을 활용한 컨셉 아트 초안 제작.

[잘못된 예시 — 이렇게 쓰지 마십시오]
(아래와 같은 장문 산문은 절대 금지)
"게임 기획에서 AI는 매우 중요한 역할을 하고 있습니다. 특히 최근에는 다양한 분야에서 활용되고 있는데, 기획 분야에서는 세계관 설정이나 퀘스트 지문 작성 등에 사용되며, 아트 분야에서는 컨셉 아트 생성이나 UI 아이콘 제작에 활용되고 있습니다. 프로그래밍 분야에서도..."

═══════════════════════════════════════
[7. 분량 — ★ 최소 보장 기준 ★]
═══════════════════════════════════════

[분량 측정 기준 — 중요]
- 아래 '자' 수는 **서식 문법을 제외한 순수 텍스트** 기준입니다.
- 제외 대상: Markdown 기호(#, ##, ###, -, >, |, ---, 코드블록, \<br\>, \&nbsp; 등)
        - 포함 대상: 사람이 읽는 실제 문장, 단어, 용어, 설명 텍스트

        [기본학습 (개요 + 학습목표 + 상세내용)]
        - **순수 텍스트 최소 10,000자 이상 (서식 제외, 필수)**
        - '상세 내용'이 전체 기본학습의 80% 이상을 차지해야 합니다.
        - 상세 내용 확보 방법:
        - Level 2(##) 대주제 최소 3개
        - Level 3(### ■) 소주제 최소 6개
        - 각 소주제(### ■) 아래 Key Concept 불릿 최소 6개
        - 각 Level 4(#### ▣) 하위 소주제 아래 설명 불릿 최소 4개
        - 표(Table) 최소 2개 (표 내부 텍스트도 분량에 포함)
        - mermaid 다이어그램 최소 1개
        - 구체적 게임 사례(게임명 명시) 최소 5개

        [실습 + 심화]
        - 실습: 1,500~3,000자
        - 심화: 800~2,000자

        [전체 합계]
        - 서식 제외 순수 텍스트 기준 최소 13,000자 이상

        ※ 짧은 설명은 절대 불가합니다. 한 소주제가 불릿 3개 이하로 끝나면 내용이 부족한 것입니다.
        ※ 모든 개념에 대해 '정의 → 왜 중요한가 → 게임 예시 → 실무 적용법' 흐름으로 설명합니다.

        ═══════════════════════════════════════
        [8. 자기검증 — Self-Correction]
        ═══════════════════════════════════════
        작성 후 아래 체크리스트로 내부 점검 후 최종본만 출력하십시오:
        1. 헤딩 체계가 Level 1~4 규칙(■, ▣, &nbsp; 포함)을 따르는가?
        2. Spacing Zone(<br>)이 4-C 매트릭스에 따라 올바르게 적용되었는가?
            3. Sandwich 구조 특수 패턴이 올바르게 적용되었는가?
            4. 핵심 용어 표(Table)가 2개 이상 포함되었는가?
            5. 구체적인 게임 사례(게임명)가 3개 이상 포함되었는가?
            6. 실습에 [소요 시간 / 난이도 / 평가 기준]이 명시되었는가?
            7. 어투가 합쇼체로 통일되었는가?
            8. 기본학습 분량이 공백 포함 10,000자 이상인가?
            9. 시맨틱 아이콘이 용도에 맞게 삽입되었는가?
            10. 3문장 이상 장문 산문 단락이 없는가? (불릿 1문장 원칙)
            11. Key Concept 형식("- **Bold:**\\n    - 설명")이 적용되었는가?
            12. 각 ##(Level 2) 헤딩마다 <!-- [IMG: "keyword"] --> 태그가 최소 1개 삽입되었는가?`;

    const userPrompt = `다음 교안 모듈에 대한 상세 강의 콘텐츠를 작성하십시오.

            📌 주제: ${blockData.title}
            🎯 목표: ${blockData.description}

            ⚠️ 분량 주의: 기본학습(개요+학습목표+상세내용)의 순수 텍스트(서식 제외)가 반드시 10,000자 이상이어야 합니다. 상세 내용에서 소주제별로 깊이 있게 설명하십시오. 짧게 작성하지 마십시오.`;

    const requestBody = {
        contents: [{ role: 'user', parts: [{ text: userPrompt }] }],
        systemInstruction: { parts: [{ text: systemPrompt }] },
        generationConfig: { temperature: 0.8, topP: 0.92, maxOutputTokens: 65536 }
    };

    try {
        const response = await fetch(GEMINI_API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(requestBody)
        });
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(`API 호출 실패: ${errorData?.error?.message || 'HTTP ' + response.status}`);
        }
        const data = await response.json();
        const rawText = data?.candidates?.[0]?.content?.parts?.[0]?.text;
        if (!rawText) throw new Error('API 응답에서 콘텐츠를 찾을 수 없습니다.');

        // Phase 2.5: 이미지 태그 해석 (Asset Resolver) + 위치 재배치
        const resolvedText = await resolveImageTags(rawText);
        const finalText = repositionImages(resolvedText);

        blockData.content = finalText;
        blockData.status = 'done';
        renderEditorContent(finalText, blockData.title);
        renderSidebar();
        saveState();

        const updatedCard = document.querySelector(`.module-card[data-id="${blockData.id}"]`);
        if (updatedCard) updatedCard.classList.add('active');
    } catch (error) {
        console.error('[교안 에이전트] 교안 생성 실패:', error);
        showEditorError(error.message, blockData);
    }
}

/* ─── 에디터 렌더링 ───────────────────────────────────────── */
let aiCommandMode = 'edit'; // 'edit' | 'image'

function renderEditorContent(markdownText, title) {
    if (!editorContent) return;
    const toolbar = `
        <div class="editor-toolbar">
            <span class="editor-toolbar-title">${escapeHtml(title || '')}</span>
            <div class="editor-toolbar-actions">
                <button class="editor-mode-btn active" data-mode="view" onclick="switchEditorMode('view')">\uD83D\uDC41 보기</button>
                <button class="editor-mode-btn" data-mode="edit" onclick="switchEditorMode('edit')">✏️ 편집</button>
                <button class="editor-save-btn hidden" onclick="saveEditorContent()">\uD83D\uDCBE 저장</button>
            </div>
        </div>`;
    const commandBar = `
        <div class="ai-command-bar hidden" id="ai-command-bar">
            <div class="ai-command-mode-group">
                <button class="ai-mode-btn active" data-aimode="edit" onclick="switchAIMode('edit')">✏️ 수정</button>
                <button class="ai-mode-btn" data-aimode="image" onclick="switchAIMode('image')">🎨 이미지</button>
            </div>
            <input type="text" class="ai-command-input" id="ai-command-input"
                   placeholder="텍스트를 선택하고 수정 명령을 입력하세요..."
                   onkeydown="if(event.key==='Enter')executeAICommand()">
            <button class="ai-command-send" id="ai-command-send" onclick="executeAICommand()">✨ 실행</button>
        </div>`;
    try {
        const html = marked.parse(markdownText);
        editorContent.innerHTML = `
            ${toolbar}
            <div class="editor-rendered" style="animation: fadeIn 0.4s ease-out">${html}</div>
            <textarea class="editor-raw hidden" spellcheck="false">${escapeHtml(markdownText)}</textarea>
            ${commandBar}`;
    } catch (e) {
        editorContent.innerHTML = `
            ${toolbar}
            <pre class="editor-rendered" style="white-space: pre-wrap;">${escapeHtml(markdownText)}</pre>
            <textarea class="editor-raw hidden" spellcheck="false">${escapeHtml(markdownText)}</textarea>
            ${commandBar}`;
    }
}

/* ─── 에디터 모드 전환 (보기 ↔ 편집) ─────────────────────── */
function switchEditorMode(mode) {
    if (!editorContent) return;
    const rendered = editorContent.querySelector('.editor-rendered');
    const raw = editorContent.querySelector('.editor-raw');
    const saveBtn = editorContent.querySelector('.editor-save-btn');
    const cmdBar = editorContent.querySelector('.ai-command-bar');
    const btns = editorContent.querySelectorAll('.editor-mode-btn');

    btns.forEach(b => b.classList.toggle('active', b.dataset.mode === mode));

    if (mode === 'edit') {
        if (rendered) rendered.classList.add('hidden');
        if (raw) raw.classList.remove('hidden');
        if (saveBtn) saveBtn.classList.remove('hidden');
        if (cmdBar) cmdBar.classList.remove('hidden');
    } else {
        if (rendered) rendered.classList.remove('hidden');
        if (raw) raw.classList.add('hidden');
        if (saveBtn) saveBtn.classList.add('hidden');
        if (cmdBar) cmdBar.classList.add('hidden');
    }
}

/* ─── 편집 내용 저장 ──────────────────────────────────────── */
function saveEditorContent() {
    if (!editorContent || currentEditingModuleId === null) return;
    const raw = editorContent.querySelector('.editor-raw');
    if (!raw) return;

    const newContent = raw.value;
    const mod = courseData.find(m => m.id === currentEditingModuleId);
    if (!mod) return;

    mod.content = newContent;
    saveState();

    // 렌더링 뷰로 갱신
    renderEditorContent(newContent, mod.title);
    console.log(`[교안 에이전트] 교안 직접 수정 저장: ${mod.title}`);
}

/* ═════════════════════════════════════════════════════════════════
   Phase 6 — AI 명령창 (Editor Command Bar)
   ═════════════════════════════════════════════════════════════════ */

/* ─── AI 모드 토글 (수정 / 이미지) ──────────────────────────── */
function switchAIMode(mode) {
    aiCommandMode = mode;
    const btns = document.querySelectorAll('.ai-mode-btn');
    btns.forEach(b => b.classList.toggle('active', b.dataset.aimode === mode));
    const input = document.getElementById('ai-command-input');
    if (input) {
        input.placeholder = mode === 'image'
            ? '\uD83C\uDFA8 생성할 이미지를 설명하세요 (\uc608: 게임 UI 디자인 컨셉 아트)'
            : '✏️ 텍스트를 선택하고 수정 명령을 입력하세요...';
    }
}

/* ─── AI 명령 실행 디스패치 ───────────────────────────── */
async function executeAICommand() {
    const input = document.getElementById('ai-command-input');
    const sendBtn = document.getElementById('ai-command-send');
    if (!input || !input.value.trim()) return;
    if (!isApiKeySet()) { alert('\u26A0\uFE0F Gemini API \ud0a4\ub97c \uba3c\uc800 \uc785\ub825\ud574 \uc8fc\uc138\uc694.'); return; }

    const command = input.value.trim();
    input.disabled = true;
    sendBtn.disabled = true;
    sendBtn.textContent = '\u23F3 \uCC98\uB9AC\uC911...';

    try {
        if (aiCommandMode === 'image') {
            await generateAIImage(command);
        } else {
            await handleAITextEdit(command);
        }
    } catch (err) {
        console.error('[AI Command]', err);
        alert('AI \uba85\ub839 \uc2e4\ud589 \uc2e4\ud328: ' + err.message);
    } finally {
        input.disabled = false;
        input.value = '';
        sendBtn.disabled = false;
        sendBtn.textContent = '\u2728 \uc2e4\ud589';
    }
}

/* ─── 텍스트 수정 (Gemini 2.5 Flash) ──────────────────── */
async function handleAITextEdit(command) {
    const raw = editorContent?.querySelector('.editor-raw');
    if (!raw) throw new Error('\ud3b8\uc9d1 \ubaa8\ub4dc\uac00 \uc544\ub2d9\ub2c8\ub2e4.');

    const selStart = raw.selectionStart;
    const selEnd = raw.selectionEnd;
    const fullText = raw.value;

    let selectedText, contextBefore, contextAfter;
    if (selStart !== selEnd) {
        selectedText = fullText.substring(selStart, selEnd);
        contextBefore = fullText.substring(Math.max(0, selStart - 200), selStart);
        contextAfter = fullText.substring(selEnd, Math.min(fullText.length, selEnd + 200));
    } else {
        throw new Error('\uc218\uc815\ud560 \ud14d\uc2a4\ud2b8\ub97c \uba3c\uc800 \ub4dc\ub798\uadf8\ud558\uc5ec \uc120\ud0dd\ud574 \uc8fc\uc138\uc694.');
    }

    const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${GEMINI_API_KEY}`;
    const systemPrompt = `\ub2f9\uc2e0\uc740 Markdown \uad50\uc548 \ud3b8\uc9d1 \ub3c4\uc6b0\ubbf8\uc785\ub2c8\ub2e4.
\uc0ac\uc6a9\uc790\uac00 \uc120\ud0dd\ud55c \ud14d\uc2a4\ud2b8\ub97c \uba85\ub839\uc5d0 \ub530\ub77c \uc218\uc815\ud558\uc2ed\uc2dc\uc624.
\uaddc\uce59:
1. \uc218\uc815\ub41c \ud14d\uc2a4\ud2b8\ub9cc \ucd9c\ub825\ud558\uc2ed\uc2dc\uc624 (\uc124\uba85, \uc811\ub450\uc0ac, \ucf54\ub4dc\ube14\ub85d \uac10\uc2f8\uae30 \uae08\uc9c0).
2. Markdown \uc11c\uc2dd\uc744 \uc720\uc9c0\ud558\uc2ed\uc2dc\uc624.
3. \uc5b4\ud22c\ub294 \ud569\uc1fc\uccb4\ub97c \uc0ac\uc6a9\ud558\uc2ed\uc2dc\uc624.
4. \uc6d0\ubb38\uc758 \uad6c\uc870(\ud5e4\ub529, \ubd88\ub9bf, \ud45c)\ub97c \uc720\uc9c0\ud558\uc2ed\uc2dc\uc624.`;

    const userPrompt = `[\uc804\ud6c4 \ub9e5\ub77d]\n...${contextBefore}\n\n[\uc120\ud0dd\ub41c \ud14d\uc2a4\ud2b8 (\uc218\uc815 \ub300\uc0c1)]\n${selectedText}\n\n[\uc0ac\uc6a9\uc790 \uba85\ub839]\n${command}\n\n\uc218\uc815\ub41c \ud14d\uc2a4\ud2b8\ub9cc \ucd9c\ub825\ud558\uc2ed\uc2dc\uc624.`;

    const res = await fetch(apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            contents: [{ role: 'user', parts: [{ text: userPrompt }] }],
            systemInstruction: { parts: [{ text: systemPrompt }] },
            generationConfig: { temperature: 0.7, maxOutputTokens: 8192 }
        })
    });
    if (!res.ok) throw new Error('API \ud638\ucd9c \uc2e4\ud328: HTTP ' + res.status);
    const data = await res.json();
    let result = data?.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!result) throw new Error('AI \uc751\ub2f5\uc774 \ube44\uc5b4 \uc788\uc2b5\ub2c8\ub2e4.');

    // \ucf54\ub4dc\ube14\ub85d \uac10\uc2f8\uae30 \uc81c\uac70 (AI\uac00 \uac00\ub054 ```markdown ... ``` \uc73c\ub85c \uac10\uc2f8\ub294 \uacbd\uc6b0)
    result = result.replace(/^```[\w]*\n?/, '').replace(/\n?```$/, '').trim();

    // \uc120\ud0dd \uc601\uc5ed \uad50\uccb4
    raw.value = fullText.substring(0, selStart) + result + fullText.substring(selEnd);
    raw.focus();
    raw.setSelectionRange(selStart, selStart + result.length);
    console.log(`[AI Command] \ud14d\uc2a4\ud2b8 \uc218\uc815 \uc644\ub8cc (${selectedText.length}\uc790 \u2192 ${result.length}\uc790)`);
}

/* ─── 이미지 생성 (Nanobanana / Gemini 2.0 Flash) ──────── */
async function generateAIImage(prompt) {
    const raw = editorContent?.querySelector('.editor-raw');
    if (!raw) throw new Error('\ud3b8\uc9d1 \ubaa8\ub4dc\uac00 \uc544\ub2d9\ub2c8\ub2e4.');

    // Nanobanana (Gemini 2.0 Flash) \uc774\ubbf8\uc9c0 \uc0dd\uc131 \uc2dc\ub3c4
    const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent?key=${GEMINI_API_KEY}`;
    const engineeringPrompt = `Generate a high-quality illustration for an educational game design lesson plan.
Subject: ${prompt}
Style: Clean, professional, digital art style suitable for educational material.
Composition: Centered, clear, visually engaging.
Do NOT include any text or watermarks in the image.`;

    console.log(`[Nanobanana] \uc774\ubbf8\uc9c0 \uc0dd\uc131 \uc694\uccad: ${prompt}`);

    try {
        const res = await fetch(apiUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                contents: [{ role: 'user', parts: [{ text: engineeringPrompt }] }],
                generationConfig: {
                    responseModalities: ['TEXT', 'IMAGE'],
                    maxOutputTokens: 4096
                }
            })
        });

        if (!res.ok) {
            const errData = await res.json().catch(() => ({}));
            throw new Error(errData?.error?.message || 'HTTP ' + res.status);
        }

        const data = await res.json();
        const parts = data?.candidates?.[0]?.content?.parts || [];

        // inlineData (base64 \uc774\ubbf8\uc9c0) \ucc3e\uae30
        const imagePart = parts.find(p => p.inlineData);

        if (imagePart) {
            const { mimeType, data: b64 } = imagePart.inlineData;
            const imgTag = `\n<p align="center" data-asset-tag="ai-generated"><img src="data:${mimeType};base64,${b64}" alt="[Nanobanana] ${escapeHtml(prompt)}" title="[AI Generated] ${escapeHtml(prompt)}" style="max-width:100%;border-radius:8px;border:2px solid rgba(46,204,113,0.4);"></p>\n`;
            insertAtCursor(raw, imgTag);
            console.log(`[Nanobanana] \u2705 \uc774\ubbf8\uc9c0 \uc0dd\uc131 \uc131\uacf5`);
            return;
        }

        // \uc774\ubbf8\uc9c0 \uc5c6\uc73c\uba74 \ud14d\uc2a4\ud2b8 \uc751\ub2f5 \ud655\uc778
        const textPart = parts.find(p => p.text);
        throw new Error(textPart?.text || '\uc774\ubbf8\uc9c0 \uc0dd\uc131 \uc2e4\ud328: \uc751\ub2f5\uc5d0 \uc774\ubbf8\uc9c0\uac00 \uc5c6\uc2b5\ub2c8\ub2e4.');

    } catch (err) {
        console.warn('[Nanobanana] \uc774\ubbf8\uc9c0 \uc0dd\uc131 \uc2e4\ud328, \uac80\uc0c9 fallback \uc2dc\ub3c4:', err.message);

        // Fallback: Wikimedia/Wikipedia \uac80\uc0c9
        const imgUrl = await searchImage(prompt);
        if (imgUrl) {
            const imgTag = `\n<p align="center" data-asset-tag="ai-resolved"><img src="${imgUrl}" alt="${escapeHtml(prompt)}" title="[Search Fallback] ${escapeHtml(prompt)}" style="max-width:100%;border-radius:8px;border:2px solid rgba(124,91,245,0.3);"></p>\n`;
            insertAtCursor(raw, imgTag);
            console.log(`[AI Command] \u2705 \uac80\uc0c9 fallback \uc131\uacf5: ${prompt}`);
        } else {
            const placeholder = `\n<div data-asset-tag="ai-placeholder" style="background:linear-gradient(135deg,#1a1a3e,#2a2a5e);border:1px dashed rgba(124,91,245,0.3);border-radius:12px;padding:32px 24px;text-align:center;margin:16px 0;"><span style="font-size:2.5rem;">\ud83d\uddbc\ufe0f</span><br><span style="color:#aaaadd;font-size:0.85rem;font-weight:600;">[AI Image] ${escapeHtml(prompt)}</span></div>\n`;
            insertAtCursor(raw, placeholder);
            console.log(`[AI Command] \u26a0\ufe0f Placeholder \uc0bd\uc785: ${prompt}`);
        }
    }
}

/* ─── textarea 커서 위치에 텍스트 삽입 ──────────────────── */
function insertAtCursor(textarea, text) {
    const pos = textarea.selectionEnd || textarea.value.length;
    const before = textarea.value.substring(0, pos);
    const after = textarea.value.substring(pos);
    textarea.value = before + text + after;
    textarea.focus();
    const newPos = pos + text.length;
    textarea.setSelectionRange(newPos, newPos);
}

function showEditorWriting(title) {
    if (!editorContent) return;
    editorContent.innerHTML = `
            <div class="editor-writing">
                <div class="writing-animation">
                    <span class="writing-dot"></span><span class="writing-dot"></span><span class="writing-dot"></span>
                </div>
                <h2>\u270D\uFE0F 교안 작성 중</h2>
                <p><strong>${escapeHtml(title)}</strong> 모듈의 상세 교안을<br>AI가 작성하고 있습니다...</p>
            </div>`;
}

function showEditorError(message, blockData) {
    if (!editorContent) return;
    editorContent.innerHTML = `
            <div class="editor-error">
                <h2>\u26A0\uFE0F 교안 생성 실패</h2>
                <p>${escapeHtml(message)}</p>
                <button onclick="generateModuleContent(courseData.find(m => m.id === ${blockData.id}))">\uD83D\uDD04 재시도</button>
            </div>`;
}

/* ─── UI 유틸리티 ─────────────────────────────────────────── */
function handleGenerate() { generateBlueprint(topicInput.value.trim()); }

function showLoading(visible) {
    if (loadingOverlay) loadingOverlay.classList.toggle('hidden', !visible);
}

function setGenerateButtonState(enabled) {
    if (generateBtn) generateBtn.disabled = !enabled;
}

function showError(message, topic) {
    if (!moduleList) return;
    moduleList.innerHTML = `
            <div class="error-message">
                <p>\u274C ${escapeHtml(message)}</p>
                <button onclick="retryGenerate('${escapeHtml(topic)}')">\uD83D\uDD04 재시도</button>
            </div>`;
}

function retryGenerate(topic) {
    if (topic) topicInput.value = topic;
    generateBlueprint(topicInput.value.trim());
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

/* ═══════════════════════════════════════════════════════════════
   Phase 4 — Auto-Save / Restore / Export
   ═══════════════════════════════════════════════════════════════ */

const SAVE_KEY = 'vibe_coding_data';

function saveState() {
    try {
        const state = { topic: currentTopic, data: courseData, savedAt: new Date().toISOString() };
        localStorage.setItem(SAVE_KEY, JSON.stringify(state));
    } catch (e) { console.error('[교안 에이전트] 상태 저장 실패:', e); }
}

function restoreState() {
    try {
        const raw = localStorage.getItem(SAVE_KEY);
        if (!raw) return false;
        const state = JSON.parse(raw);
        if (!state || !Array.isArray(state.data) || state.data.length === 0) return false;
        courseData = state.data;
        currentTopic = state.topic || '';
        if (topicInput && currentTopic) topicInput.value = currentTopic;
        renderSidebar();
        return true;
    } catch (e) { return false; }
}

/* ─── 모듈 Markdown 변환 헬퍼 ──────────────────────────────── */
function buildModuleMarkdown(mod) {
    const today = new Date().toISOString().split('T')[0];
    const topic = currentTopic || '미지정 주제';
    const fm = ['---', `topic: "${topic}"`, `module: "${mod.title}"`, `date: "${today}"`, 'tags: [vibe-coding-generated]', '---'].join('\n');
    const content = mod.content || `> ⚠️ 이 모듈의 콘텐츠는 아직 생성되지 않았습니다.\n>\n> **설명:** ${mod.description}`;
    return `${fm}\n\n# ${mod.title}\n\n${content}`;
}

function downloadMarkdown(text, filename) {
    const blob = new Blob([text], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { document.body.removeChild(a); URL.revokeObjectURL(url); }, 100);
}

/* ─── 현재 문서 추출 ──────────────────────────────────────── */
function exportCurrentModule() {
    if (currentEditingModuleId === null) { alert('⚠️ 먼저 좌측에서 모듈을 선택해 주세요.'); return; }
    const mod = courseData.find(m => m.id === currentEditingModuleId);
    if (!mod) { alert('⚠️ 선택된 모듈을 찾을 수 없습니다.'); return; }
    if (!mod.content) { alert('⚠️ 이 모듈의 콘텐츠가 아직 생성되지 않았습니다.'); return; }

    const today = new Date().toISOString().split('T')[0];
    const safeName = mod.title.replace(/[\\/:*?"<>|]/g, '_');
    downloadMarkdown(buildModuleMarkdown(mod), `${safeName}_${today}.md`);
}

/* ─── 전체 문서 추출 ──────────────────────────────────────── */
function exportAllModules() {
    if (courseData.length === 0) { alert('⚠️ 내보낼 교안 데이터가 없습니다.'); return; }

    const today = new Date().toISOString().split('T')[0];
    const topic = (currentTopic || '미지정_주제').replace(/[\\/:*?"<>|]/g, '_');
    const parts = courseData.map(mod => buildModuleMarkdown(mod));
    downloadMarkdown(parts.join('\n\n---\n\n'), `${topic}_교안_${today}.md`);
}

/* ─── 초기화 ─────────────────────────────────────────────── */
function init() {
    initLocalStorage();
    apiKeyInput.addEventListener('input', handleApiKeyInput);
    setLockState(false);

    const savedKey = sessionStorage.getItem('gemini_api_key');
    if (savedKey) {
        GEMINI_API_KEY = savedKey;
        apiKeyInput.value = savedKey;
        setLockState(true);
    }

    restoreState();
    restoreHistory();

    if (topicInput) {
        topicInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') { e.preventDefault(); handleGenerate(); }
        });
    }

    console.log('[교안 에이전트] 앱 초기화 완료');
}

document.addEventListener('DOMContentLoaded', init);
